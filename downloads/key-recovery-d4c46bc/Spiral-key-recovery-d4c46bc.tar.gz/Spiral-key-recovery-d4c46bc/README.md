# Portable encrypted key recovery validation

Immutable source commit: d4c46bc81012e095ab8c78ac6e362ce2b6a63798
Runtime baseline commit: d2f19b9e733359f14331d7064a41697c851a1d80
Trusted SOURCE.json SHA256: 20707a5119e58d55fd8f133120b2a70bdca2ed17b5d787972c9101084d9f8c63
Trusted collector SHA256: c2bb73e5238aa0fbb801ba1b12ae5cce912865a12316c47ad792a2f841d30468

Extract under the native Linux home filesystem. No Git/GitHub authentication is
needed. Run as a normal user. Required: Linux aarch64 (OCI) or x86_64 Microsoft
WSL kernel; Python 3.12; exact Rust/Cargo 1.99.1; cc, ar, OpenSSL, pkg-config and
libssl-dev. The collector creates a private temporary venv with pinned packages.

OCI Ubuntu ARM:
python3 "$HOME/Spiral-key-recovery-d4c46bc/run_checks.py" --platform oci

WSL Ubuntu x86-64:
python3 "$HOME/Spiral-key-recovery-d4c46bc/run_checks.py" --platform wsl

Use --python /absolute/venv/bin/python to reuse a Python 3.12 venv with the exact
requirements. Use --toolchain-dir /absolute/rust-prefix for an installed exact
toolchain. --offline requires --python and already cached Cargo dependencies.
--check-only checks source integrity and never records a platform test pass.
--output-parent selects an existing result directory outside the source tree.

Checks: 94 passing default Rust library tests, five ignored tests, release build,
11 baseline key-operation tests, and 20 encrypted backup/restore and cold
rotation recovery tests. Test credentials, BUILD and venv stay in private scratch
outside results. Success and failure preserve public reports and raw logs in
Spiral-key-recovery-{platform}-{arch}-{UTC}-{unique}.tar.gz and its checksum.
Return the result archive whose path is printed by the final JSON record.

This bounded run does not approve memory cleanup, constant time, whole Goal 2 or
Goal 5, or deployment. The OCI label records Linux ARM execution and a requested
environment label; it does not independently attest the cloud provider.
