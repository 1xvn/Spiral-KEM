#!/usr/bin/env python3
"""Verify the fixed collector before running Linux key-operations collection."""
import hashlib
import os
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
MANIFEST_SHA256 = "e60c9fe1da07e0db98fb20327646a0c4837a550419d7fee4ca080ba433e9730b"
COLLECTOR_SHA256 = "5e3099ff78ca9cab6793126517cdb615140683f3c18b080d091247597edc8fd4"
manifest = ROOT / "SOURCE.json"
collector = ROOT / "source/protocol_rust/validation/key_operations_platform.py"
try:
    for path, expected in ((manifest, MANIFEST_SHA256), (collector, COLLECTOR_SHA256)):
        if path.is_symlink() or not path.is_file():
            raise ValueError("missing or linked collection input")
        if hashlib.sha256(path.read_bytes()).hexdigest() != expected:
            raise ValueError("fixed collection input changed; extract a fresh bundle")
except (OSError, ValueError) as error:
    print("Bundle verification failed: " + str(error), file=sys.stderr)
    raise SystemExit(1)

# Isolated mode ignores PYTHONPATH and disables local site customization.
os.execv(sys.executable, [sys.executable, "-I", "-B", str(collector), *sys.argv[1:],
         "--source-manifest", str(manifest),
         "--expected-manifest-sha256", MANIFEST_SHA256])
