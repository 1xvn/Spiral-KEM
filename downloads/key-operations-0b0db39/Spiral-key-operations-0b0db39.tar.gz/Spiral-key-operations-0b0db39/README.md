# OCI·WSL operational key management validation bundle

Pinned source: 0b0db39d36b9a6f243486615ca2624a6b76ce02b
Operational code baseline: 486697682beb66db1af05bdc45867d122a25d145 (PR #28)

Run without Git/GitHub authentication. Extract into a Linux home filesystem.
Python 3.12, Rust/Cargo 1.99.1, cc/build-essential, pkg-config, libssl-dev,
OpenSSL is required. Reuse the Rust toolchain from the previous validation environment.
Exact Python dependency versions are installed in a private temporary venv.

OCI Ubuntu ARM:
python3 "$HOME/Spiral-key-operations-0b0db39/run_checks.py" --platform oci

WSL Ubuntu x86-64:
python3 "$HOME/Spiral-key-operations-0b0db39/run_checks.py" --platform wsl

To use an existing Python venv, add --python /absolute/venv/bin/python.
If rustup is unavailable, add --toolchain-dir /absolute/rust-prefix.
--check-only verifies source integrity only and does not count as a test pass.

Check 81 Rust unit tests (5 separately ignored), a release build, and 11 key-management/live TLS rotation tests.
Test keys are created and cleaned in a temporary 0700 path outside the result directory.
Both success and failure produce a Spiral-key-ops-*.tar.gz result archive in the home directory.
The result archive path is printed at completion. Missing tool installations produce preserved
failure logs; tools are not silently replaced with different versions.

This run does not execute full functional CI, Memcheck, long-duration load testing, or constant-time/memory/
production deployment approval checks. The OCI label records a Linux ARM run and the user-selected
environment name; it does not independently attest the cloud provider's identity.
