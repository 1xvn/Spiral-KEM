# OCI/WSL functional revalidation of pinned source

The source commit is `fcf7ff07ecba260f6b446baa7f1efd55bbe11ec2`.
We placed 603 files from the original Git subtrees needed for checking in `source/` and recorded SHA-256 hashes
in `SOURCE.json`. This is not a mirror of the entire repository.

This bundle's `run_checks.py` uses its own `source/`. It does not use the terminal's
existing channel lifecycle directory. It first verifies all source hashes,
then executes that source's `ci/validate.py` by absolute path. Source changes cause it to stop.
It creates a new results directory each time without overwriting existing test files/logs.

## Execution

Place this `.tar.gz` file in each OCI and WSL Ubuntu home directory and run it.
Both environments require the Python3.12/Rust1.99.1/C/OpenSSL environment from the previous validation.

Shared extraction steps:

```bash
cd "$HOME" && tar -xzf Spiral-platform-check-fcf7ff0.tar.gz
```

OCI ARM terminal:

```bash
python3 "$HOME/Spiral-platform-check-fcf7ff0/run_checks.py" --platform oci
```

WSL Ubuntu x86-64 terminal:

```bash
python3 "$HOME/Spiral-platform-check-fcf7ff0/run_checks.py" --platform wsl
```

At startup, `Fixed source verified: fcf7ff07...` appears. Existing Rust instrumentation
environment variables are cleared in child processes, and the exact rustup 1.99.1 tools are selected.
Pinned requirements are installed into the bundle's `.platform-venv`, and actual versions and pip check are verified.
Python/Cargo dependencies may need downloading.

Detailed output is saved in logs in the Results directory shown at the start. While compiling,
absence of new lines on screen does not mean completion. The archive path appears at the end.
New results are created in the home directory on both success and failure, as follows.

```text
Spiral-check-oci-aarch64-date-time-unique-value.tar.gz
Spiral-check-wsl-x86_64-date-time-unique-value.tar.gz
```

These two files contain the review material. Archiving the source directory, build artifacts, or the entire venv is
Preserve failure logs in their original form as well; do not overwrite earlier result files.

## Expected scope

Python85/diagnostic20/C9/Rust70/documentation6/release build/realTLS35.
ARM's ignored0 versus x86-64's ignored5 reflects instrumentation-only target differences; these are not added to the functional
pass count. Memory, constant time, and Spiral's own cryptographic security approval are separate.
This bundle does not run x86-64-only taint requests on ARM.

The bundle's functional execution was verified on local Linux x86-64, but this is not counted as OCI/WSL
validation. `BUNDLE_VALIDATION.json` records that scope and the source-change rejection control.

Advanced option `--python` specifies an existing pinned Python3.12 venv, `--toolchain-dir` an installed
Rust1.99.1 directory, and `--output-parent` the parent for new results.
`--platform local` is for local diagnostics and is not labeled as OCI/WSL results.
`--check-only` verifies source only and does not run tests.
