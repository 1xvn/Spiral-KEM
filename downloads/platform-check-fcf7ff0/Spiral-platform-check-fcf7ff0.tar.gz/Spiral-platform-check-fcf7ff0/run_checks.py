#!/usr/bin/env python3
"""Check the bundled fixed source, then collect one functional platform run."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys
import tarfile
import tempfile

ROOT=Path(__file__).resolve().parent
SOURCE=ROOT/'source'
COMMIT='fcf7ff07ecba260f6b446baa7f1efd55bbe11ec2'
MANIFEST_SHA256='29944b7d762c2e94f5bb6f9dfebcefbcd326ac1eaafe4af0ebc659dc40bbc146'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def verify_source():
    manifest=ROOT/'SOURCE.json'
    if digest(manifest)!=MANIFEST_SHA256:
        raise ValueError('SOURCE.json differs from this fixed bundle')
    data=json.loads(manifest.read_text())
    if data['source_commit']!=COMMIT:
        raise ValueError('unexpected source commit')
    for name,expected in data['files'].items():
        relative=Path(name)
        if relative.is_absolute() or '..' in relative.parts:
            raise ValueError('invalid manifest path')
        path=SOURCE/relative
        if not path.is_file() or any(parent.is_symlink() for parent in (path,*path.parents)):
            raise ValueError('missing or linked source: '+name)
        if digest(path)!=expected:
            raise ValueError('source changed: '+name+'; extract a fresh bundle')
    return {'commit':COMMIT,'manifest_sha256':digest(manifest),
      'files_verified':len(data['files']),'runner_sha256':digest(SOURCE/'ci/validate.py'),
      'cargo_lock_sha256':digest(SOURCE/'protocol_rust/Cargo.lock')}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--platform',choices=('oci','wsl','local'),required=True)
    parser.add_argument('--check-only',action='store_true',help='verify source only; do not run tests')
    parser.add_argument('--python',type=Path,help='existing Python 3.12 venv with pinned requirements')
    parser.add_argument('--toolchain-dir',type=Path,help='installed Rust 1.99.1 directory; otherwise use rustup')
    parser.add_argument('--output-parent',type=Path,default=Path.home(),help='existing parent for new result folders')
    args=parser.parse_args()
    machine=platform.machine().lower()
    if args.check_only:
        try:
            checked=verify_source()
            print(json.dumps({'source_verified':True,'functional_tests_run':False,**checked}))
            return 0
        except Exception as error:
            print('Source verification failed: '+str(error),file=sys.stderr)
            return 1
    now=datetime.now(timezone.utc)
    out=Path(tempfile.mkdtemp(prefix=f'Spiral-check-{args.platform}-{machine}-{now:%Y%m%d-%H%M%S}-',dir=args.output_parent))
    archive=Path(str(out)+'.tar.gz')
    report={'schema':'spiral-fixed-platform-functional/v1','status':'failed',
      'requested_environment':args.platform,'platform':platform.uname()._asdict(),
      'started_utc':now.isoformat(),'source_verified':False,'source_commit':COMMIT,
      'launcher_sha256':digest(Path(__file__)),'commands':[],
      'memory_checked':False,'constant_time_approved':False,'errors':[]}
    print('Results:',out,flush=True)
    env=os.environ.copy()
    for key in list(env):
        if key in ('RUSTC','RUSTDOC','RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS',
          'RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER','CARGO_BUILD_TARGET','CARGO_TARGET_DIR',
          'ASAN_OPTIONS','LSAN_OPTIONS','RUST_TEST_NOCAPTURE') or key.startswith(('CFLAGS','CXXFLAGS','CARGO_PROFILE_')):
            env.pop(key,None)
    env.update(LC_ALL='C',PYTHONDONTWRITEBYTECODE='1',RUSTUP_TOOLCHAIN='1.99.1')

    def run(name,command,timeout):
        print(name,flush=True)
        log=out/(name+'.log')
        record={'name':name,'argv':command,'timeout_seconds':timeout,'log':log.name}
        report['commands'].append(record)
        with log.open('wb') as stream:
            try:
                done=subprocess.run(command,cwd=SOURCE,env=env,stdout=stream,stderr=subprocess.STDOUT,timeout=timeout)
                record['exit']=done.returncode
            except subprocess.TimeoutExpired:
                record.update(exit=None,timed_out=True)
                raise RuntimeError(name+' timeout; partial log preserved')
        if record['exit']!=0:
            raise RuntimeError(name+' failed; see '+str(log))
        return log.read_text(errors='replace')

    try:
        if sys.version_info[:2]!=(3,12):
            raise RuntimeError('run this launcher with Python 3.12')
        expected_machine={'oci':'aarch64','wsl':'x86_64','local':machine}[args.platform]
        if platform.system()!='Linux' or machine!=expected_machine or machine not in ('x86_64','aarch64'):
            raise RuntimeError('this bundle expects OCI Linux aarch64 or WSL Linux x86_64')
        if args.platform=='wsl' and not ('microsoft' in platform.release().lower() or 'WSL_INTEROP' in env):
            raise RuntimeError('run --platform wsl inside the WSL Ubuntu terminal')
        report['source']=verify_source();report['source_verified']=True
        print('Fixed source verified:',COMMIT,flush=True)
        rustup=shutil.which('rustup')
        if not rustup and not args.toolchain_dir:
            raise RuntimeError('rustup is required; the previous checks already used Rust 1.99.1')
        for name in ('cc','make','pkg-config'):
            if not shutil.which(name):raise RuntimeError('missing prerequisite: '+name)
        tools={}
        for name in ('cargo','rustc','rustdoc'):
            text=str(args.toolchain_dir.resolve()/'bin'/name) if args.toolchain_dir else run('locate-'+name,[rustup,'which','--toolchain','1.99.1',name],30).strip()
            if '\n' in text or not Path(text).is_file():raise RuntimeError('invalid tool path: '+name)
            tools[name]=text
        env.update(RUSTC=tools['rustc'],RUSTDOC=tools['rustdoc'])
        if args.python:
            python=Path(os.path.abspath(args.python))
        else:
            venv=ROOT/'.platform-venv'
            run('create-venv',[sys.executable,'-m','venv',str(venv)],120)
            python=venv/'bin/python'
            run('install-requirements',[str(python),'-m','pip','install','-r',str(SOURCE/'protocol_v01/requirements.txt')],600)
        run('python-version',[str(python),'-c','import sys; print(sys.version); assert sys.version_info[:2] == (3,12)'],30)
        run('pinned-requirements',[str(python),'-c',
          'from importlib.metadata import version; from pathlib import Path; '
          'rows=[s.strip().split("==") for s in Path("protocol_v01/requirements.txt").read_text().splitlines() if s.strip() and not s.startswith("#")]; '
          'actual={name:version(name) for name,wanted in rows}; print(actual); '
          'assert all(actual[name]==wanted for name,wanted in rows)'],30)
        run('pip-check',[str(python),'-m','pip','check'],60)
        run('functional',[str(python),str(SOURCE/'ci/validate.py'),'--python',str(python),
          '--cargo',tools['cargo'],'--output',str(out/'functional')],3600)
        data=json.loads((out/'functional/result.json').read_text())
        if data.get('status')!='passed':raise RuntimeError('functional report did not pass')
        report['functional_summary']={r['name']:{k:v for k,v in r.items() if k in
          ('passed','exit','tests_run','test_groups','structured_tests')} for r in data['checks']}
        if verify_source()!=report['source']:raise RuntimeError('source changed while checking')
        report['source_unchanged']=True
        report['status']='passed'
    except Exception as error:
        report['errors'].append(str(error))
        print(str(error),file=sys.stderr,flush=True)
    finally:
        report['finished_utc']=datetime.now(timezone.utc).isoformat()
        (out/'result.json').write_text(json.dumps(report,indent=2)+'\n')
        files={str(p.relative_to(out)):digest(p) for p in sorted(out.rglob('*')) if p.is_file() and p.name!='SHA256.json'}
        (out/'SHA256.json').write_text(json.dumps(files,indent=2)+'\n')
        with tarfile.open(archive,'x:gz') as tar:
            tar.add(out,arcname=out.name)
        print(json.dumps({'status':report['status'],'source_verified':report['source_verified'],
          'archive':str(archive),'memory_checked':False,'constant_time_approved':False}),flush=True)
    return 0 if report['status']=='passed' else 1


if __name__=='__main__':raise SystemExit(main())
