# Target environment remeasurement of the temporary secret copy cleanup patch

Pinned source: 7f26fed5b8176ddd009d44264fb5e9ab08fb8d31. Includes pinned dependency patches under third_party and requires no .git.
Use the existing Rust 1.99.1, Valgrind/binutils/C/OpenSSL environment.

Extract in the OCI Ubuntu home directory, then:
python3 "$HOME/Spiral-secret-copy-7f26fed/run_checks.py" --platform oci

Extract in the WSL Ubuntu home directory, then:
python3 "$HOME/Spiral-secret-copy-7f26fed/run_checks.py" --platform wsl

Collects 70 regular Rust tests and 160 Memcheck runs and automatically creates a .tar.gz in the home directory.
Existing warnings/original exit 99 are preserved. Completed collection does not approve constant time/full memory checks.
Earlier ARM/WSL evidence is not counted as execution of this patch; new submissions will be reviewed.
