#!/usr/bin/env python3
import argparse, hashlib, json, os, platform, sys
from pathlib import Path
root=Path(__file__).resolve().parent/'source'
p=argparse.ArgumentParser(description='Verify fixed source and run secret-flow collection; completion is not security approval.')
p.add_argument('--platform',choices=('oci','wsl','local'),required=True)
p.add_argument('--check-only',action='store_true')
args,extra=p.parse_known_args()
try:
    manifest=root/'SOURCE.json'
    if hashlib.sha256(manifest.read_bytes()).hexdigest()!='36013f94f0cb3bca0d3482a775831f4037fac2a9e553e679fe0cabf9031c8d39':raise ValueError('source manifest differs')
    data=json.loads(manifest.read_text())
    for name,digest in data['files'].items():
        relative=Path(name)
        if relative.is_absolute() or '..' in relative.parts:raise ValueError('invalid source path')
        file=root/relative
        if not file.is_file() or any(v.is_symlink() for v in (file,*file.parents)):raise ValueError('missing or linked source: '+name)
        if hashlib.sha256(file.read_bytes()).hexdigest()!=digest:raise ValueError('changed source: '+name)
    print('Fixed source verified:',data['source_commit'],'files:',len(data['files']),flush=True)
    if args.check_only:sys.exit(0)
    if platform.system()!='Linux':raise ValueError('use the Ubuntu terminal')
    if args.platform=='oci' and platform.machine()!='aarch64':raise ValueError('OCI ARM requires aarch64')
    if args.platform=='wsl' and (platform.machine()!='x86_64' or 'microsoft' not in platform.release().lower()):raise ValueError('use WSL Ubuntu x86-64')
except Exception as error:
    print(str(error),file=sys.stderr);sys.exit(1)
os.execv(sys.executable,[sys.executable,str(root/'protocol_rust/diagnostics/secret_flow_campaign.py'),*extra])
