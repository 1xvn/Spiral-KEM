# ARM secret flow collection without Git information

Pinned source: `7bff0e49132b76e6c4271ebb3c219f625a46d816`.
The collector error requiring `.git` in the previous source bundle was fixed.
It checks `source/SOURCE.json` and SHA-256 hashes of 641 source files; `.git` is not required.

Place the archive in the OCI Ubuntu home directory, then run it.

```bash
cd "$HOME" &&
tar -xzf "$HOME/Spiral-arm-secret-flow-7bff0e4.tar.gz" -C "$HOME" &&
python3 "$HOME/Spiral-arm-secret-flow-7bff0e4/run_checks.py" --platform oci
```

Use exactly Rust 1.99.1 and the existing Valgrind/binutils/C/OpenSSL development environment.
No external Python packages are required. The initial Cargo build may download dependencies.
Results are stored in a new home directory folder, and a `.tar.gz` is generated automatically. At the final `archive` path,
file is the result bundle for review. Preserve logs and the results archive even on failure.

The corrected bundle was run locally on x86-64 outside a Git repository, confirming 70 basic tests and
160 Memcheck collection runs. OCI ARM execution results must be obtained again.
Completed collection does not approve constant time/full memory checks. Original warnings and exit 99 remain.
