# ARM secret-flow collection

Extract in OCI Ubuntu home, then run.

```bash
python3 "$HOME/Spiral-arm-secret-flow-26dd0d6/run_checks.py" --platform oci
```

Requires Rust 1.99.1, Valgrind, libc6-dbg, binutils, and C/OpenSSL development tools. No external Python packages are needed. The first build may download Cargo dependencies.

Collects 2 branch/address positive controls,2 public/secret key-derivation/send/signature cases, and 78 receive pairs. Automatically creates `Spiral-secret-flow-aarch64-...tar.gz` in home and displays the archive path at completion. Failures/timeouts also retain results. Build/detailed progress is logged in the displayed result folder.

Exit 0 and diagnostic_complete mean collection completed, including original exit 99; they do not approve constant-time behavior or overall memory safety. Actual ARM results require review after upload. See source/protocol_rust/ARM_SECRET_FLOW.md for explanation.
