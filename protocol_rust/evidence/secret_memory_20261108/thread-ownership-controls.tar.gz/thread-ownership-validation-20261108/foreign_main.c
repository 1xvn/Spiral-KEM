#include <pthread.h>
#include <stddef.h>
#include <stdio.h>
#include <string.h>

extern size_t ownership_touch_current(void);

int main(int argc, char **argv) {
    if (argc != 2) return 42;
    int touch = 0;
    int thread_exit = 0;
    if (strcmp(argv[1], "foreign-empty-return") == 0) {}
    else if (strcmp(argv[1], "foreign-touch-return") == 0) touch = 1;
    else if (strcmp(argv[1], "foreign-empty-pthread-exit") == 0) thread_exit = 1;
    else if (strcmp(argv[1], "foreign-touch-pthread-exit") == 0) {
        touch = 1;
        thread_exit = 1;
    } else return 42;
    if (touch && ownership_touch_current() != 73) return 43;
    if (printf("CONTROL_COMPLETED %s\n", argv[1]) < 0 || fflush(stdout) != 0) return 44;
    // This is C main after ownership_touch_current has returned completely.
    // No pthread cancellation unwinds across a live Rust stack frame.
    if (thread_exit) pthread_exit(NULL);
    return 0;
}
