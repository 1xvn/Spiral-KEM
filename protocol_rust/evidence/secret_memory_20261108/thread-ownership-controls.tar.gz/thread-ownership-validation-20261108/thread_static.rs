#[unsafe(no_mangle)]
pub extern "C" fn ownership_touch_current() -> usize {
    // The temporary public Thread handle is dropped before returning to C.
    // No Rust frame remains when the C caller later invokes pthread_exit.
    std::hint::black_box(std::thread::current().id());
    73
}
