use std::hint::black_box;
use std::thread;

fn touch(count: usize) {
    for _ in 0..count {
        black_box(thread::current().id());
    }
}

fn main() {
    let mode = std::env::args().nth(1).expect("one mode is required");
    match mode.as_str() {
        "empty-main" => {},
        "current-once" => touch(1),
        "current-many" => touch(10_000),
        "workers-1" | "workers-8" | "workers-64" => {
            let count: usize = mode.strip_prefix("workers-").unwrap().parse().unwrap();
            // This main thread never calls current(). Each worker owns and
            // drops its temporary Thread handles before its joined exit.
            let workers: Vec<_> = (0..count).map(|_| thread::spawn(|| {
                touch(10);
                73_u32
            })).collect();
            for worker in workers {
                assert_eq!(worker.join().expect("worker panic"), 73);
            }
        },
        _ => panic!("unknown ownership control"),
    }
    println!("CONTROL_COMPLETED {}", mode);
}
