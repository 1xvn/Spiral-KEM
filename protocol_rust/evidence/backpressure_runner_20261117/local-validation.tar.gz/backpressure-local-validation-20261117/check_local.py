"""Short local release/cancel and normal recovery; deliberately no60s timeout run."""
from contextlib import ExitStack
import json
import os
from pathlib import Path
import selectors
import subprocess
import sys
import tempfile
import time

REPO=Path('/workspace/Spiral-KEM-public-release')
OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(REPO/'protocol_rust/validation'))
sys.path.insert(0,str(REPO/'protocol_rust'))
import cross_host_smoke as base
import slow_consumer as runner
from interop import identities

base.BINARY=Path('/workspace/spiral-load-build/release/spiral-lab')


def ready(process):
    data=b''
    with selectors.DefaultSelector() as selector:
        selector.register(process.stdout,selectors.EVENT_READ)
        end=time.monotonic()+5
        while time.monotonic()<end:
            for key,_ in selector.select(.1):
                chunk=os.read(key.fd,65536)
                if not chunk:raise ValueError('early readiness EOF')
                data+=chunk
                if b'\n' in data:return data
    raise TimeoutError('local readiness')


def server_command(private,case):
    command=[str(base.BINARY),'server','--name',base.NAME,'--service',base.SERVICE,
             '--port','0','--connections','1','--messages','10','--workers','1',
             '--cert',str(private/'cert.pem'),'--key',str(private/'key.pem'),'--auth',str(private/'auth.bin')]
    return command+(['--backpressure-case',case,'--payload','1024'] if case else [])


def run():
    started=time.monotonic();before=base.source();results=[];owned=[]
    try:
        with tempfile.TemporaryDirectory(prefix='spiral-pressure-private-') as temp:
            private=Path(temp);identities(private)
            for case in ('release','cancel'):
                folder=OUT/case;folder.mkdir(mode=0o700)
                with ExitStack() as stack:
                    errors={role:stack.enter_context((folder/(role+'.stderr.log')).open('wb')) for role in ('server','client')}
                    outputs={role:stack.enter_context((folder/(role+'.jsonl')).open('wb')) for role in ('server','client')}
                    controller=stack.enter_context((folder/'controller.jsonl').open('w'))
                    server=subprocess.Popen(server_command(private,case),stdout=subprocess.PIPE,stderr=errors['server']);owned.append(server)
                    first=ready(server);outputs['server'].write(first)
                    port=base.campaign.strict_json(first)['listening']
                    client=subprocess.Popen(base.client_command(port,private)+['--backpressure-case',case],stdout=subprocess.PIPE,stderr=errors['client']);owned.append(client)
                    tracker,codes=runner.monitor(client,server,None,outputs,controller,case)
                tracker.validate(codes,{role:(folder/(role+'.stderr.log')).read_bytes() for role in ('server','client')})
                results.append({'case':case,'status':'passed','endpoint_events':tracker.events,'endpoint_finals':tracker.finals,'endpoint_exit_codes':codes})
            with (OUT/'recovery-server.stderr.log').open('wb') as errors:
                server=subprocess.Popen(server_command(private,None),stdout=subprocess.PIPE,stderr=errors);owned.append(server)
                first=ready(server);port=base.campaign.strict_json(first)['listening']
                client=subprocess.run(base.client_command(port,private),capture_output=True,timeout=10)
                rest,_=server.communicate(timeout=5)
                (OUT/'recovery-server.jsonl').write_bytes(first+rest)
                (OUT/'recovery-client.jsonl').write_bytes(client.stdout)
                (OUT/'recovery-client.stderr.log').write_bytes(client.stderr)
                left=base.final_report(first+rest);right=base.final_report(client.stdout)
                assert client.returncode==server.returncode==0
                base.validate_pair(left,right)
                recovery={'server':left,'client':right}
                assert runner.recovery_fresh(results,recovery)
        after=base.source()
        assert before['source']['files']==after['source']['files'] and before['binary_sha256']==after['binary_sha256']
        result={'status':'passed','scope':'Short local real loopback TLS: release, cancellation, fresh ordinary recovery. No SSH/OCI/WSL or60s timeout execution.',
                'cases':results,'recovery':recovery,'recovery_session_is_fresh':True,'source_before':before,'source_after':after,
                'wall_seconds':time.monotonic()-started,'private_fixtures_removed':True,'timeout_case_executed':False}
        (OUT/'result.json').write_text(json.dumps(result,indent=2)+'\n')
        print(json.dumps({'status':'passed','cases':['release','cancel','recovery'],'wall_seconds':result['wall_seconds'],'timeout_case_executed':False}))
    finally:
        for process in owned:base.stop(process)


if __name__=='__main__':run()
