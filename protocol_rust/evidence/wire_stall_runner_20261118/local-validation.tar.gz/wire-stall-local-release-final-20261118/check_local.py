"""Short actual Rust/TLS read-release and ordinary recovery, no60s timeout/SSH."""
from contextlib import ExitStack
import json
import os
from pathlib import Path
import selectors
import socket
import subprocess
import sys
import tempfile
import time

REPO=Path('/workspace/Spiral-KEM-public-release')
OUT=Path(os.environ.get('SPIRAL_WIRE_LOCAL_OUT',str(Path(__file__).resolve().parent)))
sys.path.insert(0,str(REPO/'protocol_rust/validation'))
sys.path.insert(0,str(REPO/'protocol_rust'))
import cross_host_smoke as base
import wire_stall as runner
from interop import identities

RELAY=r'''
import asyncio,json,sys
async def pipe(reader,writer):
    while data:=await reader.read(65536):
        writer.write(data);await writer.drain()
    writer.write_eof();await writer.drain()
async def handle(reader,writer):
    peer,remote=await asyncio.open_connection('127.0.0.1',int(sys.argv[1]))
    try:await asyncio.gather(pipe(reader,remote),pipe(peer,writer))
    finally:
        writer.close();remote.close()
        await asyncio.gather(writer.wait_closed(),remote.wait_closed(),return_exceptions=True)
async def main():
    server=await asyncio.start_server(handle,'127.0.0.1',0)
    print(json.dumps({'port':server.sockets[0].getsockname()[1]}),flush=True)
    async with server:await server.serve_forever()
asyncio.run(main())
'''

base.BINARY=Path('/workspace/spiral-load-build/release/spiral-lab')


def line(process):
    with selectors.DefaultSelector() as selector:
        selector.register(process.stdout,selectors.EVENT_READ)
        if not selector.select(5):raise TimeoutError('local readiness')
    return process.stdout.readline()


def command(private,port,wire):
    result=[str(base.BINARY),'server','--name',base.NAME,'--service',base.SERVICE,
            '--port',str(port),'--connections','1','--workers','1','--messages','1024' if wire else '10',
            '--cert',str(private/'cert.pem'),'--key',str(private/'key.pem'),'--auth',str(private/'auth.bin')]
    return result+(['--payload','16384','--wire-stall-case','release'] if wire else [])


def run():
    before=base.source();assert before['source']['working_tree_dirty'] is False
    started=time.monotonic();owned=[];monitor=None
    with socket.socket() as backend,socket.socket() as gate:
        backend.bind(('127.0.0.1',0));gate.bind(('127.0.0.1',0))
        backend_port=backend.getsockname()[1];gate_port=gate.getsockname()[1]
    try:
        with tempfile.TemporaryDirectory(prefix='spiral-wire-private-') as folder,ExitStack() as stack:
            private=Path(folder);identities(private)
            outputs={role:stack.enter_context((OUT/(role+'.jsonl')).open('wb')) for role in ('supervisor','server','client')}
            errors={role:stack.enter_context((OUT/(role+'.stderr.log')).open('wb')) for role in ('supervisor','relay','client')}
            controller=stack.enter_context((OUT/'controller.jsonl').open('w'))
            relay=subprocess.Popen([sys.executable,'-B','-u','-c',RELAY,str(gate_port)],stdout=subprocess.PIPE,stderr=errors['relay']);owned.append(relay)
            relay_port=base.campaign.strict_json(line(relay))['port']
            script=('import json,signal,sys\nsys.path.insert(0,sys.argv[1])\nimport wire_gate\n'
                    'def cancel(signum,frame):raise KeyboardInterrupt()\n'
                    'signal.signal(signal.SIGTERM,cancel)\n'
                    'try:raise SystemExit(wire_gate.supervise(json.loads(sys.argv[2]),"release",int(sys.argv[3]),int(sys.argv[4])))\n'
                    'except (Exception,KeyboardInterrupt):\n import traceback;traceback.print_exc();raise SystemExit(1)\n')
            supervisor=subprocess.Popen([sys.executable,'-B','-u','-c',script,str(REPO/'protocol_rust/validation'),
                json.dumps(command(private,backend_port,True)),str(backend_port),str(gate_port)],
                stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=errors['supervisor']);owned.append(supervisor)
            def start_client():
                process=subprocess.Popen(runner.wire_client_command(relay_port,private,'release'),
                    stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=errors['client']);owned.append(process);return process
            monitor=runner.WireRun('release',supervisor,start_client,lambda:runner.tunnel_state(relay,relay_port),
                outputs,controller,backend_port,gate_port)
            codes=monitor.run()
        monitor.tracker.validate(codes,{'client':(OUT/'client.stderr.log').read_bytes(),
            'server':(OUT/'supervisor.stderr.log').read_bytes()},monitor.tunnel_observations)
        base.stop(relay)
        with tempfile.TemporaryDirectory(prefix='spiral-wire-recovery-') as folder:
            private=Path(folder);identities(private)
            with (OUT/'recovery-server.stderr.log').open('wb') as errors:
                server=subprocess.Popen(command(private,0,False),stdout=subprocess.PIPE,stderr=errors);owned.append(server)
                first=line(server);port=base.campaign.strict_json(first)['listening']
                client=subprocess.run(base.client_command(port,private),capture_output=True,timeout=10)
                rest,_=server.communicate(timeout=5)
                (OUT/'recovery-server.jsonl').write_bytes(first+rest)
                (OUT/'recovery-client.jsonl').write_bytes(client.stdout)
                (OUT/'recovery-client.stderr.log').write_bytes(client.stderr)
                left=base.final_report(first+rest);right=base.final_report(client.stdout)
                assert client.returncode==server.returncode==0
                base.validate_pair(left,right)
                assert all(right['sessions'][0][field]!=monitor.tracker.ready['client'][field] for field in runner.IDENTIFIERS)
        after=base.source()
        assert before==after
        report={'status':'passed','scope':'Actual Rust/TLS wire-read gate release plus ordinary fresh recovery on one Linux host through a disposable TCP relay. No SSH/OCI/WSL or60s timeout execution.',
                'source_before':before,'source_after':after,'endpoint_events':monitor.tracker.events,
                'endpoint_finals':monitor.tracker.finals,'gate_paused':monitor.tracker.paused,
                'wire_stalled':monitor.tracker.stalled,'gate_witness':monitor.tracker.gate_witness,
                'gate_resumed':monitor.tracker.resumed,'gate_finished':monitor.tracker.finished,
                'relay_observations':monitor.tunnel_observations,'exit_codes':codes,
                'recovery':{'server':left,'client':right},'private_fixtures_removed':True,
                'timeout_case_executed':False,'wall_seconds':time.monotonic()-started}
        (OUT/'result.json').write_text(json.dumps(report,indent=2)+'\n')
        print(json.dumps({'status':report['status'],'wall_seconds':report['wall_seconds'],
                          'tcp_stall':monitor.tracker.stalled,'timeout_case_executed':False}))
    finally:
        for process in reversed(owned):base.stop(process)
        for process in owned:
            for stream in (process.stdin,process.stdout):
                if stream is not None and not stream.closed:stream.close()


if __name__=='__main__':run()
