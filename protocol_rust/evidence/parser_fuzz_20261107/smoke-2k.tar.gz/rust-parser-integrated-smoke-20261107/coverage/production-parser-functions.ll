; Verified production function: header_parse
define void @_RNvMNtCs1K0wxfkMoe8_15spiral_protocol4wireNtB2_6Header5parse(ptr dead_on_unwind noalias nofree noundef writable writeonly sret([48 x i8]) align 8 captures(none) dereferenceable(48) initializes((0, 1)) %_0, ptr noalias nofree noundef nonnull readonly captures(none) %raw.0, i64 noundef range(i64 0, -9223372036854775808) %raw.1) unnamed_addr #17 comdat !dbg !29647 !guid !29649 {
start:
  %0 = load i8, ptr @__sancov_gen_.1437, align 1, !dbg !29650, !nosanitize !4116
  %1 = add i8 %0, 1, !dbg !29650
  store i8 %1, ptr @__sancov_gen_.1437, align 1, !dbg !29650, !nosanitize !4116
  call void @__sanitizer_cov_trace_const_cmp8(i64 40, i64 %raw.1), !dbg !29651
  %2 = icmp eq i64 %raw.1, 40, !dbg !29651
  br i1 %2, label %bb1, label %start.bb98_crit_edge, !dbg !29651

start.bb98_crit_edge:                             ; preds = %start
  %3 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 1), align 1, !dbg !29651, !nosanitize !4116
  %4 = add i8 %3, 1, !dbg !29651
  store i8 %4, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 1), align 1, !dbg !29651, !nosanitize !4116
  br label %bb98, !dbg !29651

bb1:                                              ; preds = %start
  %5 = ptrtoint ptr %raw.0 to i64, !dbg !29652
  %6 = add i64 %5, 3, !dbg !29652
  %7 = inttoptr i64 %6 to ptr, !dbg !29652
  %8 = ptrtoint ptr %raw.0 to i64, !dbg !29652
  %9 = lshr i64 %8, 3, !dbg !29652
  %10 = add i64 %9, 2147450880, !dbg !29652
  %11 = inttoptr i64 %10 to ptr, !dbg !29652
  %12 = load i8, ptr %11, align 1, !dbg !29652
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %12), !dbg !29652
  %13 = icmp ne i8 %12, 0, !dbg !29652
  br i1 %13, label %16, label %bb1._crit_edge, !dbg !29652, !prof !4264

bb1._crit_edge:                                   ; preds = %bb1
  %14 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 2), align 1, !dbg !29652, !nosanitize !4116
  %15 = add i8 %14, 1, !dbg !29652
  store i8 %15, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 2), align 1, !dbg !29652, !nosanitize !4116
  br label %25, !dbg !29652

16:                                               ; preds = %bb1
  %17 = and i64 %8, 7, !dbg !29652
  %18 = trunc i64 %17 to i8, !dbg !29652
  call void @__sanitizer_cov_trace_cmp1(i8 %18, i8 %12), !dbg !29652
  %19 = icmp sge i8 %18, %12, !dbg !29652
  br i1 %19, label %22, label %._crit_edge, !dbg !29652

._crit_edge:                                      ; preds = %16
  %20 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 3), align 1, !dbg !29652, !nosanitize !4116
  %21 = add i8 %20, 1, !dbg !29652
  store i8 %21, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 3), align 1, !dbg !29652, !nosanitize !4116
  br label %25, !dbg !29652

22:                                               ; preds = %16
  %23 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 4), align 1, !dbg !29652, !nosanitize !4116
  %24 = add i8 %23, 1, !dbg !29652
  store i8 %24, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 4), align 1, !dbg !29652, !nosanitize !4116
  call void @__asan_report_load_n(i64 %8, i64 4) #42, !dbg !29652
  unreachable

25:                                               ; preds = %._crit_edge, %bb1._crit_edge
  %26 = ptrtoint ptr %7 to i64, !dbg !29652
  %27 = lshr i64 %26, 3, !dbg !29652
  %28 = add i64 %27, 2147450880, !dbg !29652
  %29 = inttoptr i64 %28 to ptr, !dbg !29652
  %30 = load i8, ptr %29, align 1, !dbg !29652
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %30), !dbg !29652
  %31 = icmp ne i8 %30, 0, !dbg !29652
  br i1 %31, label %34, label %._crit_edge70, !dbg !29652, !prof !4264

._crit_edge70:                                    ; preds = %25
  %32 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 5), align 1, !dbg !29652, !nosanitize !4116
  %33 = add i8 %32, 1, !dbg !29652
  store i8 %33, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 5), align 1, !dbg !29652, !nosanitize !4116
  br label %43, !dbg !29652

34:                                               ; preds = %25
  %35 = and i64 %26, 7, !dbg !29652
  %36 = trunc i64 %35 to i8, !dbg !29652
  call void @__sanitizer_cov_trace_cmp1(i8 %36, i8 %30), !dbg !29652
  %37 = icmp sge i8 %36, %30, !dbg !29652
  br i1 %37, label %40, label %._crit_edge71, !dbg !29652

._crit_edge71:                                    ; preds = %34
  %38 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 6), align 1, !dbg !29652, !nosanitize !4116
  %39 = add i8 %38, 1, !dbg !29652
  store i8 %39, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 6), align 1, !dbg !29652, !nosanitize !4116
  br label %43, !dbg !29652

40:                                               ; preds = %34
  %41 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 7), align 1, !dbg !29652, !nosanitize !4116
  %42 = add i8 %41, 1, !dbg !29652
  store i8 %42, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 7), align 1, !dbg !29652, !nosanitize !4116
  call void @__asan_report_load_n(i64 %26, i64 4) #42, !dbg !29652
  unreachable

43:                                               ; preds = %._crit_edge71, %._crit_edge70
  %44 = load i32, ptr %raw.0, align 1, !dbg !29652, !alias.scope !29665, !noalias !29670
  call void @__sanitizer_cov_trace_const_cmp4(i32 827019347, i32 %44), !dbg !29652
  %_3.i.i.i.not = icmp eq i32 %44, 827019347, !dbg !29652
  br i1 %_3.i.i.i.not, label %bb5, label %.bb98_crit_edge, !dbg !29673

.bb98_crit_edge:                                  ; preds = %43
  %45 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 8), align 1, !dbg !29673, !nosanitize !4116
  %46 = add i8 %45, 1, !dbg !29673
  store i8 %46, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 8), align 1, !dbg !29673, !nosanitize !4116
  br label %bb98, !dbg !29673

bb5:                                              ; preds = %43
  %_16.i = getelementptr inbounds nuw i8, ptr %raw.0, i64 4, !dbg !29674
  %47 = ptrtoint ptr %_16.i to i64, !dbg !29682
  %48 = add i64 %47, 1, !dbg !29682
  %49 = inttoptr i64 %48 to ptr, !dbg !29682
  %50 = ptrtoint ptr %_16.i to i64, !dbg !29682
  %51 = lshr i64 %50, 3, !dbg !29682
  %52 = add i64 %51, 2147450880, !dbg !29682
  %53 = inttoptr i64 %52 to ptr, !dbg !29682
  %54 = load i8, ptr %53, align 1, !dbg !29682
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %54), !dbg !29682
  %55 = icmp ne i8 %54, 0, !dbg !29682
  br i1 %55, label %58, label %bb5._crit_edge, !dbg !29682, !prof !4264

bb5._crit_edge:                                   ; preds = %bb5
  %56 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 9), align 1, !dbg !29682, !nosanitize !4116
  %57 = add i8 %56, 1, !dbg !29682
  store i8 %57, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 9), align 1, !dbg !29682, !nosanitize !4116
  br label %67, !dbg !29682

58:                                               ; preds = %bb5
  %59 = and i64 %50, 7, !dbg !29682
  %60 = trunc i64 %59 to i8, !dbg !29682
  call void @__sanitizer_cov_trace_cmp1(i8 %60, i8 %54), !dbg !29682
  %61 = icmp sge i8 %60, %54, !dbg !29682
  br i1 %61, label %64, label %._crit_edge72, !dbg !29682

._crit_edge72:                                    ; preds = %58
  %62 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 10), align 1, !dbg !29682, !nosanitize !4116
  %63 = add i8 %62, 1, !dbg !29682
  store i8 %63, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 10), align 1, !dbg !29682, !nosanitize !4116
  br label %67, !dbg !29682

64:                                               ; preds = %58
  %65 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 11), align 1, !dbg !29682, !nosanitize !4116
  %66 = add i8 %65, 1, !dbg !29682
  store i8 %66, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 11), align 1, !dbg !29682, !nosanitize !4116
  call void @__asan_report_load_n(i64 %50, i64 2) #42, !dbg !29682
  unreachable

67:                                               ; preds = %._crit_edge72, %bb5._crit_edge
  %68 = ptrtoint ptr %49 to i64, !dbg !29682
  %69 = lshr i64 %68, 3, !dbg !29682
  %70 = add i64 %69, 2147450880, !dbg !29682
  %71 = inttoptr i64 %70 to ptr, !dbg !29682
  %72 = load i8, ptr %71, align 1, !dbg !29682
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %72), !dbg !29682
  %73 = icmp ne i8 %72, 0, !dbg !29682
  br i1 %73, label %76, label %._crit_edge73, !dbg !29682, !prof !4264

._crit_edge73:                                    ; preds = %67
  %74 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 12), align 1, !dbg !29682, !nosanitize !4116
  %75 = add i8 %74, 1, !dbg !29682
  store i8 %75, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 12), align 1, !dbg !29682, !nosanitize !4116
  br label %85, !dbg !29682

76:                                               ; preds = %67
  %77 = and i64 %68, 7, !dbg !29682
  %78 = trunc i64 %77 to i8, !dbg !29682
  call void @__sanitizer_cov_trace_cmp1(i8 %78, i8 %72), !dbg !29682
  %79 = icmp sge i8 %78, %72, !dbg !29682
  br i1 %79, label %82, label %._crit_edge74, !dbg !29682

._crit_edge74:                                    ; preds = %76
  %80 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 13), align 1, !dbg !29682, !nosanitize !4116
  %81 = add i8 %80, 1, !dbg !29682
  store i8 %81, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 13), align 1, !dbg !29682, !nosanitize !4116
  br label %85, !dbg !29682

82:                                               ; preds = %76
  %83 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 14), align 1, !dbg !29682, !nosanitize !4116
  %84 = add i8 %83, 1, !dbg !29682
  store i8 %84, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 14), align 1, !dbg !29682, !nosanitize !4116
  call void @__asan_report_load_n(i64 %68, i64 2) #42, !dbg !29682
  unreachable

85:                                               ; preds = %._crit_edge74, %._crit_edge73
  %86 = load i16, ptr %_16.i, align 1, !dbg !29682, !alias.scope !29692, !noalias !29697
  call void @__sanitizer_cov_trace_const_cmp2(i16 256, i16 %86), !dbg !29682
  %_3.i.i.not = icmp eq i16 %86, 256, !dbg !29682
  br i1 %_3.i.i.not, label %bb9, label %.bb98_crit_edge75, !dbg !29700

.bb98_crit_edge75:                                ; preds = %85
  %87 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 15), align 1, !dbg !29700, !nosanitize !4116
  %88 = add i8 %87, 1, !dbg !29700
  store i8 %88, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 15), align 1, !dbg !29700, !nosanitize !4116
  br label %bb98, !dbg !29700

bb9:                                              ; preds = %85
  %_16.i26 = getelementptr inbounds nuw i8, ptr %raw.0, i64 10, !dbg !29701
  %89 = ptrtoint ptr %_16.i26 to i64, !dbg !29705
  %90 = add i64 %89, 1, !dbg !29705
  %91 = inttoptr i64 %90 to ptr, !dbg !29705
  %92 = ptrtoint ptr %_16.i26 to i64, !dbg !29705
  %93 = lshr i64 %92, 3, !dbg !29705
  %94 = add i64 %93, 2147450880, !dbg !29705
  %95 = inttoptr i64 %94 to ptr, !dbg !29705
  %96 = load i8, ptr %95, align 1, !dbg !29705
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %96), !dbg !29705
  %97 = icmp ne i8 %96, 0, !dbg !29705
  br i1 %97, label %100, label %bb9._crit_edge, !dbg !29705, !prof !4264

bb9._crit_edge:                                   ; preds = %bb9
  %98 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 16), align 1, !dbg !29705, !nosanitize !4116
  %99 = add i8 %98, 1, !dbg !29705
  store i8 %99, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 16), align 1, !dbg !29705, !nosanitize !4116
  br label %109, !dbg !29705

100:                                              ; preds = %bb9
  %101 = and i64 %92, 7, !dbg !29705
  %102 = trunc i64 %101 to i8, !dbg !29705
  call void @__sanitizer_cov_trace_cmp1(i8 %102, i8 %96), !dbg !29705
  %103 = icmp sge i8 %102, %96, !dbg !29705
  br i1 %103, label %106, label %._crit_edge76, !dbg !29705

._crit_edge76:                                    ; preds = %100
  %104 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 17), align 1, !dbg !29705, !nosanitize !4116
  %105 = add i8 %104, 1, !dbg !29705
  store i8 %105, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 17), align 1, !dbg !29705, !nosanitize !4116
  br label %109, !dbg !29705

106:                                              ; preds = %100
  %107 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 18), align 1, !dbg !29705, !nosanitize !4116
  %108 = add i8 %107, 1, !dbg !29705
  store i8 %108, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 18), align 1, !dbg !29705, !nosanitize !4116
  call void @__asan_report_load_n(i64 %92, i64 2) #42, !dbg !29705
  unreachable

109:                                              ; preds = %._crit_edge76, %bb9._crit_edge
  %110 = ptrtoint ptr %91 to i64, !dbg !29705
  %111 = lshr i64 %110, 3, !dbg !29705
  %112 = add i64 %111, 2147450880, !dbg !29705
  %113 = inttoptr i64 %112 to ptr, !dbg !29705
  %114 = load i8, ptr %113, align 1, !dbg !29705
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %114), !dbg !29705
  %115 = icmp ne i8 %114, 0, !dbg !29705
  br i1 %115, label %118, label %._crit_edge77, !dbg !29705, !prof !4264

._crit_edge77:                                    ; preds = %109
  %116 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 19), align 1, !dbg !29705, !nosanitize !4116
  %117 = add i8 %116, 1, !dbg !29705
  store i8 %117, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 19), align 1, !dbg !29705, !nosanitize !4116
  br label %127, !dbg !29705

118:                                              ; preds = %109
  %119 = and i64 %110, 7, !dbg !29705
  %120 = trunc i64 %119 to i8, !dbg !29705
  call void @__sanitizer_cov_trace_cmp1(i8 %120, i8 %114), !dbg !29705
  %121 = icmp sge i8 %120, %114, !dbg !29705
  br i1 %121, label %124, label %._crit_edge78, !dbg !29705

._crit_edge78:                                    ; preds = %118
  %122 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 20), align 1, !dbg !29705, !nosanitize !4116
  %123 = add i8 %122, 1, !dbg !29705
  store i8 %123, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 20), align 1, !dbg !29705, !nosanitize !4116
  br label %127, !dbg !29705

124:                                              ; preds = %118
  %125 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 21), align 1, !dbg !29705, !nosanitize !4116
  %126 = add i8 %125, 1, !dbg !29705
  store i8 %126, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 21), align 1, !dbg !29705, !nosanitize !4116
  call void @__asan_report_load_n(i64 %110, i64 2) #42, !dbg !29705
  unreachable

127:                                              ; preds = %._crit_edge78, %._crit_edge77
  %128 = load i16, ptr %_16.i26, align 1, !dbg !29705, !alias.scope !29710, !noalias !29715
  call void @__sanitizer_cov_trace_const_cmp2(i16 0, i16 %128), !dbg !29705
  %_3.i.i35.not = icmp eq i16 %128, 0, !dbg !29705
  br i1 %_3.i.i35.not, label %bb14, label %.bb98_crit_edge79, !dbg !29718

.bb98_crit_edge79:                                ; preds = %127
  %129 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 22), align 1, !dbg !29718, !nosanitize !4116
  %130 = add i8 %129, 1, !dbg !29718
  store i8 %130, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 22), align 1, !dbg !29718, !nosanitize !4116
  br label %bb98, !dbg !29718

bb14:                                             ; preds = %127
  %131 = getelementptr inbounds nuw i8, ptr %raw.0, i64 6, !dbg !29719
  %132 = ptrtoint ptr %131 to i64, !dbg !29719
  %133 = lshr i64 %132, 3, !dbg !29719
  %134 = add i64 %133, 2147450880, !dbg !29719
  %135 = inttoptr i64 %134 to ptr, !dbg !29719
  %136 = load i8, ptr %135, align 1, !dbg !29719
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %136), !dbg !29719
  %137 = icmp ne i8 %136, 0, !dbg !29719
  br i1 %137, label %140, label %bb14._crit_edge, !dbg !29719, !prof !4264

bb14._crit_edge:                                  ; preds = %bb14
  %138 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 23), align 1, !dbg !29719, !nosanitize !4116
  %139 = add i8 %138, 1, !dbg !29719
  store i8 %139, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 23), align 1, !dbg !29719, !nosanitize !4116
  br label %149, !dbg !29719

140:                                              ; preds = %bb14
  %141 = and i64 %132, 7, !dbg !29719
  %142 = trunc i64 %141 to i8, !dbg !29719
  call void @__sanitizer_cov_trace_cmp1(i8 %142, i8 %136), !dbg !29719
  %143 = icmp sge i8 %142, %136, !dbg !29719
  br i1 %143, label %146, label %._crit_edge80, !dbg !29719

._crit_edge80:                                    ; preds = %140
  %144 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 24), align 1, !dbg !29719, !nosanitize !4116
  %145 = add i8 %144, 1, !dbg !29719
  store i8 %145, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 24), align 1, !dbg !29719, !nosanitize !4116
  br label %149, !dbg !29719

146:                                              ; preds = %140
  %147 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 25), align 1, !dbg !29719, !nosanitize !4116
  %148 = add i8 %147, 1, !dbg !29719
  store i8 %148, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 25), align 1, !dbg !29719, !nosanitize !4116
  call void @__asan_report_load1(i64 %132) #42, !dbg !29719
  unreachable

149:                                              ; preds = %._crit_edge80, %bb14._crit_edge
  %_12 = load i8, ptr %131, align 1, !dbg !29719, !noundef !4116
  %150 = getelementptr inbounds nuw i8, ptr %raw.0, i64 7, !dbg !29720
  %151 = ptrtoint ptr %150 to i64, !dbg !29720
  %152 = lshr i64 %151, 3, !dbg !29720
  %153 = add i64 %152, 2147450880, !dbg !29720
  %154 = inttoptr i64 %153 to ptr, !dbg !29720
  %155 = load i8, ptr %154, align 1, !dbg !29720
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %155), !dbg !29720
  %156 = icmp ne i8 %155, 0, !dbg !29720
  br i1 %156, label %159, label %._crit_edge81, !dbg !29720, !prof !4264

._crit_edge81:                                    ; preds = %149
  %157 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 26), align 1, !dbg !29720, !nosanitize !4116
  %158 = add i8 %157, 1, !dbg !29720
  store i8 %158, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 26), align 1, !dbg !29720, !nosanitize !4116
  br label %168, !dbg !29720

159:                                              ; preds = %149
  %160 = and i64 %151, 7, !dbg !29720
  %161 = trunc i64 %160 to i8, !dbg !29720
  call void @__sanitizer_cov_trace_cmp1(i8 %161, i8 %155), !dbg !29720
  %162 = icmp sge i8 %161, %155, !dbg !29720
  br i1 %162, label %165, label %._crit_edge82, !dbg !29720

._crit_edge82:                                    ; preds = %159
  %163 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 27), align 1, !dbg !29720, !nosanitize !4116
  %164 = add i8 %163, 1, !dbg !29720
  store i8 %164, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 27), align 1, !dbg !29720, !nosanitize !4116
  br label %168, !dbg !29720

165:                                              ; preds = %159
  %166 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 28), align 1, !dbg !29720, !nosanitize !4116
  %167 = add i8 %166, 1, !dbg !29720
  store i8 %167, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 28), align 1, !dbg !29720, !nosanitize !4116
  call void @__asan_report_load1(i64 %151) #42, !dbg !29720
  unreachable

168:                                              ; preds = %._crit_edge82, %._crit_edge81
  %_14 = load i8, ptr %150, align 1, !dbg !29720, !noundef !4116
  %_16.i27 = getelementptr inbounds nuw i8, ptr %raw.0, i64 12, !dbg !29721
  %169 = ptrtoint ptr %_16.i27 to i64, !dbg !29725
  %170 = add i64 %169, 15, !dbg !29725
  %171 = inttoptr i64 %170 to ptr, !dbg !29725
  %172 = ptrtoint ptr %_16.i27 to i64, !dbg !29725
  %173 = lshr i64 %172, 3, !dbg !29725
  %174 = add i64 %173, 2147450880, !dbg !29725
  %175 = inttoptr i64 %174 to ptr, !dbg !29725
  %176 = load i8, ptr %175, align 1, !dbg !29725
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %176), !dbg !29725
  %177 = icmp ne i8 %176, 0, !dbg !29725
  br i1 %177, label %180, label %._crit_edge83, !dbg !29725, !prof !4264

._crit_edge83:                                    ; preds = %168
  %178 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 29), align 1, !dbg !29725, !nosanitize !4116
  %179 = add i8 %178, 1, !dbg !29725
  store i8 %179, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 29), align 1, !dbg !29725, !nosanitize !4116
  br label %189, !dbg !29725

180:                                              ; preds = %168
  %181 = and i64 %172, 7, !dbg !29725
  %182 = trunc i64 %181 to i8, !dbg !29725
  call void @__sanitizer_cov_trace_cmp1(i8 %182, i8 %176), !dbg !29725
  %183 = icmp sge i8 %182, %176, !dbg !29725
  br i1 %183, label %186, label %._crit_edge84, !dbg !29725

._crit_edge84:                                    ; preds = %180
  %184 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 30), align 1, !dbg !29725, !nosanitize !4116
  %185 = add i8 %184, 1, !dbg !29725
  store i8 %185, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 30), align 1, !dbg !29725, !nosanitize !4116
  br label %189, !dbg !29725

186:                                              ; preds = %180
  %187 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 31), align 1, !dbg !29725, !nosanitize !4116
  %188 = add i8 %187, 1, !dbg !29725
  store i8 %188, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 31), align 1, !dbg !29725, !nosanitize !4116
  call void @__asan_report_load_n(i64 %172, i64 16) #42, !dbg !29725
  unreachable

189:                                              ; preds = %._crit_edge84, %._crit_edge83
  %190 = ptrtoint ptr %171 to i64, !dbg !29725
  %191 = lshr i64 %190, 3, !dbg !29725
  %192 = add i64 %191, 2147450880, !dbg !29725
  %193 = inttoptr i64 %192 to ptr, !dbg !29725
  %194 = load i8, ptr %193, align 1, !dbg !29725
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %194), !dbg !29725
  %195 = icmp ne i8 %194, 0, !dbg !29725
  br i1 %195, label %198, label %._crit_edge85, !dbg !29725, !prof !4264

._crit_edge85:                                    ; preds = %189
  %196 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 32), align 1, !dbg !29725, !nosanitize !4116
  %197 = add i8 %196, 1, !dbg !29725
  store i8 %197, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 32), align 1, !dbg !29725, !nosanitize !4116
  br label %207, !dbg !29725

198:                                              ; preds = %189
  %199 = and i64 %190, 7, !dbg !29725
  %200 = trunc i64 %199 to i8, !dbg !29725
  call void @__sanitizer_cov_trace_cmp1(i8 %200, i8 %194), !dbg !29725
  %201 = icmp sge i8 %200, %194, !dbg !29725
  br i1 %201, label %204, label %._crit_edge86, !dbg !29725

._crit_edge86:                                    ; preds = %198
  %202 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 33), align 1, !dbg !29725, !nosanitize !4116
  %203 = add i8 %202, 1, !dbg !29725
  store i8 %203, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 33), align 1, !dbg !29725, !nosanitize !4116
  br label %207, !dbg !29725

204:                                              ; preds = %198
  %205 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 34), align 1, !dbg !29725, !nosanitize !4116
  %206 = add i8 %205, 1, !dbg !29725
  store i8 %206, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 34), align 1, !dbg !29725, !nosanitize !4116
  call void @__asan_report_load_n(i64 %190, i64 16) #42, !dbg !29725
  unreachable

207:                                              ; preds = %._crit_edge86, %._crit_edge85
  %_17.sroa.4.1.copyload = load i128, ptr %_16.i27, align 1, !dbg !29725, !alias.scope !29734
  %_16.i28 = getelementptr inbounds nuw i8, ptr %raw.0, i64 28, !dbg !29741
  %208 = ptrtoint ptr %_16.i28 to i64, !dbg !29745
  %209 = add i64 %208, 7, !dbg !29745
  %210 = inttoptr i64 %209 to ptr, !dbg !29745
  %211 = ptrtoint ptr %_16.i28 to i64, !dbg !29745
  %212 = lshr i64 %211, 3, !dbg !29745
  %213 = add i64 %212, 2147450880, !dbg !29745
  %214 = inttoptr i64 %213 to ptr, !dbg !29745
  %215 = load i8, ptr %214, align 1, !dbg !29745
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %215), !dbg !29745
  %216 = icmp ne i8 %215, 0, !dbg !29745
  br i1 %216, label %219, label %._crit_edge87, !dbg !29745, !prof !4264

._crit_edge87:                                    ; preds = %207
  %217 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 35), align 1, !dbg !29745, !nosanitize !4116
  %218 = add i8 %217, 1, !dbg !29745
  store i8 %218, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 35), align 1, !dbg !29745, !nosanitize !4116
  br label %228, !dbg !29745

219:                                              ; preds = %207
  %220 = and i64 %211, 7, !dbg !29745
  %221 = trunc i64 %220 to i8, !dbg !29745
  call void @__sanitizer_cov_trace_cmp1(i8 %221, i8 %215), !dbg !29745
  %222 = icmp sge i8 %221, %215, !dbg !29745
  br i1 %222, label %225, label %._crit_edge88, !dbg !29745

._crit_edge88:                                    ; preds = %219
  %223 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 36), align 1, !dbg !29745, !nosanitize !4116
  %224 = add i8 %223, 1, !dbg !29745
  store i8 %224, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 36), align 1, !dbg !29745, !nosanitize !4116
  br label %228, !dbg !29745

225:                                              ; preds = %219
  %226 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 37), align 1, !dbg !29745, !nosanitize !4116
  %227 = add i8 %226, 1, !dbg !29745
  store i8 %227, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 37), align 1, !dbg !29745, !nosanitize !4116
  call void @__asan_report_load_n(i64 %211, i64 8) #42, !dbg !29745
  unreachable

228:                                              ; preds = %._crit_edge88, %._crit_edge87
  %229 = ptrtoint ptr %210 to i64, !dbg !29745
  %230 = lshr i64 %229, 3, !dbg !29745
  %231 = add i64 %230, 2147450880, !dbg !29745
  %232 = inttoptr i64 %231 to ptr, !dbg !29745
  %233 = load i8, ptr %232, align 1, !dbg !29745
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %233), !dbg !29745
  %234 = icmp ne i8 %233, 0, !dbg !29745
  br i1 %234, label %237, label %._crit_edge89, !dbg !29745, !prof !4264

._crit_edge89:                                    ; preds = %228
  %235 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 38), align 1, !dbg !29745, !nosanitize !4116
  %236 = add i8 %235, 1, !dbg !29745
  store i8 %236, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 38), align 1, !dbg !29745, !nosanitize !4116
  br label %246, !dbg !29745

237:                                              ; preds = %228
  %238 = and i64 %229, 7, !dbg !29745
  %239 = trunc i64 %238 to i8, !dbg !29745
  call void @__sanitizer_cov_trace_cmp1(i8 %239, i8 %233), !dbg !29745
  %240 = icmp sge i8 %239, %233, !dbg !29745
  br i1 %240, label %243, label %._crit_edge90, !dbg !29745

._crit_edge90:                                    ; preds = %237
  %241 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 39), align 1, !dbg !29745, !nosanitize !4116
  %242 = add i8 %241, 1, !dbg !29745
  store i8 %242, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 39), align 1, !dbg !29745, !nosanitize !4116
  br label %246, !dbg !29745

243:                                              ; preds = %237
  %244 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 40), align 1, !dbg !29745, !nosanitize !4116
  %245 = add i8 %244, 1, !dbg !29745
  store i8 %245, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 40), align 1, !dbg !29745, !nosanitize !4116
  call void @__asan_report_load_n(i64 %229, i64 8) #42, !dbg !29745
  unreachable

246:                                              ; preds = %._crit_edge90, %._crit_edge89
  %v.sroa.0.0.copyload.i.i = load i64, ptr %_16.i28, align 1, !dbg !29745, !alias.scope !29752, !noalias !29757
  %_0.i = tail call noundef i64 @llvm.bswap.i64(i64 %v.sroa.0.0.copyload.i.i), !dbg !29760
  %_16.i29 = getelementptr inbounds nuw i8, ptr %raw.0, i64 36, !dbg !29767
  %247 = ptrtoint ptr %_16.i29 to i64, !dbg !29771
  %248 = add i64 %247, 3, !dbg !29771
  %249 = inttoptr i64 %248 to ptr, !dbg !29771
  %250 = ptrtoint ptr %_16.i29 to i64, !dbg !29771
  %251 = lshr i64 %250, 3, !dbg !29771
  %252 = add i64 %251, 2147450880, !dbg !29771
  %253 = inttoptr i64 %252 to ptr, !dbg !29771
  %254 = load i8, ptr %253, align 1, !dbg !29771
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %254), !dbg !29771
  %255 = icmp ne i8 %254, 0, !dbg !29771
  br i1 %255, label %258, label %._crit_edge91, !dbg !29771, !prof !4264

._crit_edge91:                                    ; preds = %246
  %256 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 41), align 1, !dbg !29771, !nosanitize !4116
  %257 = add i8 %256, 1, !dbg !29771
  store i8 %257, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 41), align 1, !dbg !29771, !nosanitize !4116
  br label %267, !dbg !29771

258:                                              ; preds = %246
  %259 = and i64 %250, 7, !dbg !29771
  %260 = trunc i64 %259 to i8, !dbg !29771
  call void @__sanitizer_cov_trace_cmp1(i8 %260, i8 %254), !dbg !29771
  %261 = icmp sge i8 %260, %254, !dbg !29771
  br i1 %261, label %264, label %._crit_edge92, !dbg !29771

._crit_edge92:                                    ; preds = %258
  %262 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 42), align 1, !dbg !29771, !nosanitize !4116
  %263 = add i8 %262, 1, !dbg !29771
  store i8 %263, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 42), align 1, !dbg !29771, !nosanitize !4116
  br label %267, !dbg !29771

264:                                              ; preds = %258
  %265 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 43), align 1, !dbg !29771, !nosanitize !4116
  %266 = add i8 %265, 1, !dbg !29771
  store i8 %266, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 43), align 1, !dbg !29771, !nosanitize !4116
  call void @__asan_report_load_n(i64 %250, i64 4) #42, !dbg !29771
  unreachable

267:                                              ; preds = %._crit_edge92, %._crit_edge91
  %268 = ptrtoint ptr %249 to i64, !dbg !29771
  %269 = lshr i64 %268, 3, !dbg !29771
  %270 = add i64 %269, 2147450880, !dbg !29771
  %271 = inttoptr i64 %270 to ptr, !dbg !29771
  %272 = load i8, ptr %271, align 1, !dbg !29771
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %272), !dbg !29771
  %273 = icmp ne i8 %272, 0, !dbg !29771
  br i1 %273, label %276, label %._crit_edge93, !dbg !29771, !prof !4264

._crit_edge93:                                    ; preds = %267
  %274 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 44), align 1, !dbg !29771, !nosanitize !4116
  %275 = add i8 %274, 1, !dbg !29771
  store i8 %275, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 44), align 1, !dbg !29771, !nosanitize !4116
  br label %285, !dbg !29771

276:                                              ; preds = %267
  %277 = and i64 %268, 7, !dbg !29771
  %278 = trunc i64 %277 to i8, !dbg !29771
  call void @__sanitizer_cov_trace_cmp1(i8 %278, i8 %272), !dbg !29771
  %279 = icmp sge i8 %278, %272, !dbg !29771
  br i1 %279, label %282, label %._crit_edge94, !dbg !29771

._crit_edge94:                                    ; preds = %276
  %280 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 45), align 1, !dbg !29771, !nosanitize !4116
  %281 = add i8 %280, 1, !dbg !29771
  store i8 %281, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 45), align 1, !dbg !29771, !nosanitize !4116
  br label %285, !dbg !29771

282:                                              ; preds = %276
  %283 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 46), align 1, !dbg !29771, !nosanitize !4116
  %284 = add i8 %283, 1, !dbg !29771
  store i8 %284, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 46), align 1, !dbg !29771, !nosanitize !4116
  call void @__asan_report_load_n(i64 %268, i64 4) #42, !dbg !29771
  unreachable

285:                                              ; preds = %._crit_edge94, %._crit_edge93
  %v.sroa.0.0.copyload.i.i43 = load i32, ptr %_16.i29, align 1, !dbg !29771, !alias.scope !29778
  %_0.i44 = tail call noundef i32 @llvm.bswap.i32(i32 %v.sroa.0.0.copyload.i.i43), !dbg !29783
  %_23 = zext i32 %_0.i44 to i64, !dbg !29790
  %switch.tableidx = add i8 %_12, -1, !dbg !29791
  call void @__sanitizer_cov_trace_const_cmp1(i8 17, i8 %switch.tableidx), !dbg !29791
  %286 = icmp ult i8 %switch.tableidx, 17, !dbg !29791
  br i1 %286, label %switch.hole_check, label %.bb98_crit_edge95, !dbg !29791

.bb98_crit_edge95:                                ; preds = %285
  %287 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 47), align 1, !dbg !29791, !nosanitize !4116
  %288 = add i8 %287, 1, !dbg !29791
  store i8 %288, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 47), align 1, !dbg !29791, !nosanitize !4116
  br label %bb98, !dbg !29791

switch.hole_check:                                ; preds = %285
  %switch.maskindex = zext nneg i8 %switch.tableidx to i32, !dbg !29791
  %switch.shifted = lshr i32 98319, %switch.maskindex, !dbg !29791
  %switch.lobit = trunc i32 %switch.shifted to i1, !dbg !29791
  %switch.lobit.not = xor i1 %switch.lobit, true, !dbg !29791
  call void @__sanitizer_cov_trace_const_cmp1(i8 1, i8 %_14), !dbg !29793
  %_28 = icmp ugt i8 %_14, 1
  %or.cond69 = or i1 %switch.lobit.not, %_28, !dbg !29791
  br i1 %or.cond69, label %switch.hole_check.bb98_crit_edge, label %bb36, !dbg !29791

switch.hole_check.bb98_crit_edge:                 ; preds = %switch.hole_check
  %289 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 48), align 1, !dbg !29791, !nosanitize !4116
  %290 = add i8 %289, 1, !dbg !29791
  store i8 %290, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 48), align 1, !dbg !29791, !nosanitize !4116
  br label %bb98, !dbg !29791

bb36:                                             ; preds = %switch.hole_check
  %291 = zext nneg i8 %switch.tableidx to i64, !dbg !29791
  %switch.gep62 = getelementptr inbounds nuw [2 x i8], ptr @switch.table._RNvMNtCs1K0wxfkMoe8_15spiral_protocol4wireNtB2_6Header5parse.1, i64 %291, !dbg !29791
  %292 = ptrtoint ptr %switch.gep62 to i64, !dbg !29791
  %293 = lshr i64 %292, 3, !dbg !29791
  %294 = add i64 %293, 2147450880, !dbg !29791
  %295 = inttoptr i64 %294 to ptr, !dbg !29791
  %296 = load i8, ptr %295, align 1, !dbg !29791
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %296), !dbg !29791
  %297 = icmp ne i8 %296, 0, !dbg !29791
  br i1 %297, label %300, label %bb36._crit_edge, !dbg !29791, !prof !4264

bb36._crit_edge:                                  ; preds = %bb36
  %298 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 49), align 1, !dbg !29791, !nosanitize !4116
  %299 = add i8 %298, 1, !dbg !29791
  store i8 %299, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 49), align 1, !dbg !29791, !nosanitize !4116
  br label %310, !dbg !29791

300:                                              ; preds = %bb36
  %301 = and i64 %292, 7, !dbg !29791
  %302 = add i64 %301, 1, !dbg !29791
  %303 = trunc i64 %302 to i8, !dbg !29791
  call void @__sanitizer_cov_trace_cmp1(i8 %303, i8 %296), !dbg !29791
  %304 = icmp sge i8 %303, %296, !dbg !29791
  br i1 %304, label %307, label %._crit_edge96, !dbg !29791

._crit_edge96:                                    ; preds = %300
  %305 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 50), align 1, !dbg !29791, !nosanitize !4116
  %306 = add i8 %305, 1, !dbg !29791
  store i8 %306, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 50), align 1, !dbg !29791, !nosanitize !4116
  br label %310, !dbg !29791

307:                                              ; preds = %300
  %308 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 51), align 1, !dbg !29791, !nosanitize !4116
  %309 = add i8 %308, 1, !dbg !29791
  store i8 %309, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 51), align 1, !dbg !29791, !nosanitize !4116
  call void @__asan_report_load2(i64 %292) #42, !dbg !29791
  unreachable

310:                                              ; preds = %._crit_edge96, %bb36._crit_edge
  %switch.load63 = load i16, ptr %switch.gep62, align 2, !dbg !29791
  %311 = zext nneg i8 %switch.tableidx to i64, !dbg !29791
  %switch.gep = getelementptr inbounds nuw [2 x i8], ptr @switch.table._RNvMNtCs1K0wxfkMoe8_15spiral_protocol4wireNtB2_6Header5parse, i64 %311, !dbg !29791
  %312 = ptrtoint ptr %switch.gep to i64, !dbg !29791
  %313 = lshr i64 %312, 3, !dbg !29791
  %314 = add i64 %313, 2147450880, !dbg !29791
  %315 = inttoptr i64 %314 to ptr, !dbg !29791
  %316 = load i8, ptr %315, align 1, !dbg !29791
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %316), !dbg !29791
  %317 = icmp ne i8 %316, 0, !dbg !29791
  br i1 %317, label %320, label %._crit_edge97, !dbg !29791, !prof !4264

._crit_edge97:                                    ; preds = %310
  %318 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 52), align 1, !dbg !29791, !nosanitize !4116
  %319 = add i8 %318, 1, !dbg !29791
  store i8 %319, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 52), align 1, !dbg !29791, !nosanitize !4116
  br label %330, !dbg !29791

320:                                              ; preds = %310
  %321 = and i64 %312, 7, !dbg !29791
  %322 = add i64 %321, 1, !dbg !29791
  %323 = trunc i64 %322 to i8, !dbg !29791
  call void @__sanitizer_cov_trace_cmp1(i8 %323, i8 %316), !dbg !29791
  %324 = icmp sge i8 %323, %316, !dbg !29791
  br i1 %324, label %327, label %._crit_edge98, !dbg !29791

._crit_edge98:                                    ; preds = %320
  %325 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 53), align 1, !dbg !29791, !nosanitize !4116
  %326 = add i8 %325, 1, !dbg !29791
  store i8 %326, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 53), align 1, !dbg !29791, !nosanitize !4116
  br label %330, !dbg !29791

327:                                              ; preds = %320
  %328 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 54), align 1, !dbg !29791, !nosanitize !4116
  %329 = add i8 %328, 1, !dbg !29791
  store i8 %329, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 54), align 1, !dbg !29791, !nosanitize !4116
  call void @__asan_report_load2(i64 %312) #42, !dbg !29791
  unreachable

330:                                              ; preds = %._crit_edge98, %._crit_edge97
  %switch.load = load i16, ptr %switch.gep, align 2, !dbg !29791
  %331 = zext i16 %switch.load to i32, !dbg !29794
  call void @__sanitizer_cov_trace_cmp4(i32 %_0.i44, i32 %331), !dbg !29794
  %_0.i6.not.i.i = icmp uge i32 %_0.i44, %331, !dbg !29794
  %332 = zext i16 %switch.load63 to i32, !dbg !29810
  call void @__sanitizer_cov_trace_cmp4(i32 %_0.i44, i32 %332), !dbg !29810
  %_0.i.i.i = icmp ule i32 %_0.i44, %332, !dbg !29810
  %_0.sroa.0.0.i.i45 = select i1 %_0.i6.not.i.i, i1 %_0.i.i.i, i1 false, !dbg !29810
  br i1 %_0.sroa.0.0.i.i45, label %_RNvMNtCshZBO5P2NUJi_4core6resultINtB2_6ResultAhj2_NtNtB4_5array17TryFromSliceErrorE6unwrapCs1K0wxfkMoe8_15spiral_protocol.exit, label %.bb98_crit_edge99, !dbg !29811

.bb98_crit_edge99:                                ; preds = %330
  %333 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 55), align 1, !dbg !29811, !nosanitize !4116
  %334 = add i8 %333, 1, !dbg !29811
  store i8 %334, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 55), align 1, !dbg !29811, !nosanitize !4116
  br label %bb98, !dbg !29811

_RNvMNtCshZBO5P2NUJi_4core6resultINtB2_6ResultAhj2_NtNtB4_5array17TryFromSliceErrorE6unwrapCs1K0wxfkMoe8_15spiral_protocol.exit: ; preds = %330
  %_16.i30 = getelementptr inbounds nuw i8, ptr %raw.0, i64 8, !dbg !29812
  %335 = ptrtoint ptr %_16.i30 to i64, !dbg !29816
  %336 = add i64 %335, 1, !dbg !29816
  %337 = inttoptr i64 %336 to ptr, !dbg !29816
  %338 = ptrtoint ptr %_16.i30 to i64, !dbg !29816
  %339 = lshr i64 %338, 3, !dbg !29816
  %340 = add i64 %339, 2147450880, !dbg !29816
  %341 = inttoptr i64 %340 to ptr, !dbg !29816
  %342 = load i8, ptr %341, align 1, !dbg !29816
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %342), !dbg !29816
  %343 = icmp ne i8 %342, 0, !dbg !29816
  br i1 %343, label %346, label %_RNvMNtCshZBO5P2NUJi_4core6resultINtB2_6ResultAhj2_NtNtB4_5array17TryFromSliceErrorE6unwrapCs1K0wxfkMoe8_15spiral_protocol.exit._crit_edge, !dbg !29816, !prof !4264

_RNvMNtCshZBO5P2NUJi_4core6resultINtB2_6ResultAhj2_NtNtB4_5array17TryFromSliceErrorE6unwrapCs1K0wxfkMoe8_15spiral_protocol.exit._crit_edge: ; preds = %_RNvMNtCshZBO5P2NUJi_4core6resultINtB2_6ResultAhj2_NtNtB4_5array17TryFromSliceErrorE6unwrapCs1K0wxfkMoe8_15spiral_protocol.exit
  %344 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 56), align 1, !dbg !29816, !nosanitize !4116
  %345 = add i8 %344, 1, !dbg !29816
  store i8 %345, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 56), align 1, !dbg !29816, !nosanitize !4116
  br label %355, !dbg !29816

346:                                              ; preds = %_RNvMNtCshZBO5P2NUJi_4core6resultINtB2_6ResultAhj2_NtNtB4_5array17TryFromSliceErrorE6unwrapCs1K0wxfkMoe8_15spiral_protocol.exit
  %347 = and i64 %338, 7, !dbg !29816
  %348 = trunc i64 %347 to i8, !dbg !29816
  call void @__sanitizer_cov_trace_cmp1(i8 %348, i8 %342), !dbg !29816
  %349 = icmp sge i8 %348, %342, !dbg !29816
  br i1 %349, label %352, label %._crit_edge100, !dbg !29816

._crit_edge100:                                   ; preds = %346
  %350 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 57), align 1, !dbg !29816, !nosanitize !4116
  %351 = add i8 %350, 1, !dbg !29816
  store i8 %351, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 57), align 1, !dbg !29816, !nosanitize !4116
  br label %355, !dbg !29816

352:                                              ; preds = %346
  %353 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 58), align 1, !dbg !29816, !nosanitize !4116
  %354 = add i8 %353, 1, !dbg !29816
  store i8 %354, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 58), align 1, !dbg !29816, !nosanitize !4116
  call void @__asan_report_load_n(i64 %338, i64 2) #42, !dbg !29816
  unreachable

355:                                              ; preds = %._crit_edge100, %_RNvMNtCshZBO5P2NUJi_4core6resultINtB2_6ResultAhj2_NtNtB4_5array17TryFromSliceErrorE6unwrapCs1K0wxfkMoe8_15spiral_protocol.exit._crit_edge
  %356 = ptrtoint ptr %337 to i64, !dbg !29816
  %357 = lshr i64 %356, 3, !dbg !29816
  %358 = add i64 %357, 2147450880, !dbg !29816
  %359 = inttoptr i64 %358 to ptr, !dbg !29816
  %360 = load i8, ptr %359, align 1, !dbg !29816
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %360), !dbg !29816
  %361 = icmp ne i8 %360, 0, !dbg !29816
  br i1 %361, label %364, label %._crit_edge101, !dbg !29816, !prof !4264

._crit_edge101:                                   ; preds = %355
  %362 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 59), align 1, !dbg !29816, !nosanitize !4116
  %363 = add i8 %362, 1, !dbg !29816
  store i8 %363, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 59), align 1, !dbg !29816, !nosanitize !4116
  br label %373, !dbg !29816

364:                                              ; preds = %355
  %365 = and i64 %356, 7, !dbg !29816
  %366 = trunc i64 %365 to i8, !dbg !29816
  call void @__sanitizer_cov_trace_cmp1(i8 %366, i8 %360), !dbg !29816
  %367 = icmp sge i8 %366, %360, !dbg !29816
  br i1 %367, label %370, label %._crit_edge102, !dbg !29816

._crit_edge102:                                   ; preds = %364
  %368 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 60), align 1, !dbg !29816, !nosanitize !4116
  %369 = add i8 %368, 1, !dbg !29816
  store i8 %369, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 60), align 1, !dbg !29816, !nosanitize !4116
  br label %373, !dbg !29816

370:                                              ; preds = %364
  %371 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 61), align 1, !dbg !29816, !nosanitize !4116
  %372 = add i8 %371, 1, !dbg !29816
  store i8 %372, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 61), align 1, !dbg !29816, !nosanitize !4116
  call void @__asan_report_load_n(i64 %356, i64 2) #42, !dbg !29816
  unreachable

373:                                              ; preds = %._crit_edge102, %._crit_edge101
  %v.sroa.0.0.copyload.i.i54 = load i16, ptr %_16.i30, align 1, !dbg !29816, !alias.scope !29823
  %_0.i55 = tail call noundef i16 @llvm.bswap.i16(i16 %v.sroa.0.0.copyload.i.i54), !dbg !29828
  call void @__sanitizer_cov_trace_const_cmp1(i8 1, i8 %_12), !dbg !29835
  %_39 = icmp eq i8 %_12, 1, !dbg !29835
  %. = select i1 %_39, i16 0, i16 -4095, !dbg !29836
  call void @__sanitizer_cov_trace_cmp2(i16 %_0.i55, i16 %.), !dbg !29837
  %_33.not = icmp eq i16 %_0.i55, %., !dbg !29837
  %_3.i.i56 = icmp ne i128 %_17.sroa.4.1.copyload, 0
  %374 = xor i1 %_39, %_3.i.i56
  %or.cond68 = select i1 %_33.not, i1 %374, i1 false, !dbg !29837
  br i1 %or.cond68, label %bb53, label %.bb98_crit_edge103, !dbg !29837

.bb98_crit_edge103:                               ; preds = %373
  %375 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 62), align 1, !dbg !29837, !nosanitize !4116
  %376 = add i8 %375, 1, !dbg !29837
  store i8 %376, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 62), align 1, !dbg !29837, !nosanitize !4116
  br label %bb98, !dbg !29837

bb53:                                             ; preds = %373
  %377 = zext i8 %_12 to i64, !dbg !29838
  call void @__sanitizer_cov_trace_switch(i64 %377, ptr @__sancov_gen_cov_switch_values.1439), !dbg !29838
  switch i8 %_12, label %bb53.bb54_crit_edge [
    i8 1, label %bb60
    i8 2, label %bb59
    i8 3, label %bb58
    i8 4, label %bb57
    i8 16, label %bb56
    i8 17, label %bb55
  ], !dbg !29838

bb53.bb54_crit_edge:                              ; preds = %bb53
  %378 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 63), align 1, !dbg !29838, !nosanitize !4116
  %379 = add i8 %378, 1, !dbg !29838
  store i8 %379, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 63), align 1, !dbg !29838, !nosanitize !4116
  br label %bb54, !dbg !29838

bb54:                                             ; preds = %bb55.bb54_crit_edge, %bb56.bb54_crit_edge, %bb57.bb54_crit_edge, %bb58.bb54_crit_edge, %bb59.bb54_crit_edge, %bb60.bb54_crit_edge, %bb53.bb54_crit_edge
  %380 = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !29839
  %381 = ptrtoint ptr %380 to i64, !dbg !29839
  %382 = lshr i64 %381, 3, !dbg !29839
  %383 = add i64 %382, 2147450880, !dbg !29839
  %384 = inttoptr i64 %383 to ptr, !dbg !29839
  %385 = load i16, ptr %384, align 1, !dbg !29839
  call void @__sanitizer_cov_trace_const_cmp2(i16 0, i16 %385), !dbg !29839
  %386 = icmp ne i16 %385, 0, !dbg !29839
  br i1 %386, label %387, label %390, !dbg !29839

387:                                              ; preds = %bb54
  %388 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 64), align 1, !dbg !29839, !nosanitize !4116
  %389 = add i8 %388, 1, !dbg !29839
  store i8 %389, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 64), align 1, !dbg !29839, !nosanitize !4116
  call void @__asan_report_store16(i64 %381) #42, !dbg !29839
  unreachable, !dbg !29839

390:                                              ; preds = %bb54
  store i128 %_17.sroa.4.1.copyload, ptr %380, align 8, !dbg !29839
  %h.sroa.6.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 24, !dbg !29839
  %391 = ptrtoint ptr %h.sroa.6.0..sroa_idx to i64, !dbg !29839
  %392 = lshr i64 %391, 3, !dbg !29839
  %393 = add i64 %392, 2147450880, !dbg !29839
  %394 = inttoptr i64 %393 to ptr, !dbg !29839
  %395 = load i8, ptr %394, align 1, !dbg !29839
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %395), !dbg !29839
  %396 = icmp ne i8 %395, 0, !dbg !29839
  br i1 %396, label %397, label %400, !dbg !29839

397:                                              ; preds = %390
  %398 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 65), align 1, !dbg !29839, !nosanitize !4116
  %399 = add i8 %398, 1, !dbg !29839
  store i8 %399, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 65), align 1, !dbg !29839, !nosanitize !4116
  call void @__asan_report_store8(i64 %391) #42, !dbg !29839
  unreachable, !dbg !29839

400:                                              ; preds = %390
  store i64 %_0.i, ptr %h.sroa.6.0..sroa_idx, align 8, !dbg !29839
  %h.sroa.7.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 32, !dbg !29839
  %401 = ptrtoint ptr %h.sroa.7.0..sroa_idx to i64, !dbg !29839
  %402 = lshr i64 %401, 3, !dbg !29839
  %403 = add i64 %402, 2147450880, !dbg !29839
  %404 = inttoptr i64 %403 to ptr, !dbg !29839
  %405 = load i8, ptr %404, align 1, !dbg !29839
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %405), !dbg !29839
  %406 = icmp ne i8 %405, 0, !dbg !29839
  br i1 %406, label %407, label %410, !dbg !29839

407:                                              ; preds = %400
  %408 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 66), align 1, !dbg !29839, !nosanitize !4116
  %409 = add i8 %408, 1, !dbg !29839
  store i8 %409, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 66), align 1, !dbg !29839, !nosanitize !4116
  call void @__asan_report_store8(i64 %401) #42, !dbg !29839
  unreachable, !dbg !29839

410:                                              ; preds = %400
  store i64 %_23, ptr %h.sroa.7.0..sroa_idx, align 8, !dbg !29839
  %h.sroa.9.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 40, !dbg !29839
  %411 = ptrtoint ptr %h.sroa.9.0..sroa_idx to i64, !dbg !29839
  %412 = lshr i64 %411, 3, !dbg !29839
  %413 = add i64 %412, 2147450880, !dbg !29839
  %414 = inttoptr i64 %413 to ptr, !dbg !29839
  %415 = load i8, ptr %414, align 1, !dbg !29839
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %415), !dbg !29839
  %416 = icmp ne i8 %415, 0, !dbg !29839
  br i1 %416, label %419, label %._crit_edge104, !dbg !29839, !prof !4264

._crit_edge104:                                   ; preds = %410
  %417 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 67), align 1, !dbg !29839, !nosanitize !4116
  %418 = add i8 %417, 1, !dbg !29839
  store i8 %418, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 67), align 1, !dbg !29839, !nosanitize !4116
  br label %428, !dbg !29839

419:                                              ; preds = %410
  %420 = and i64 %411, 7, !dbg !29839
  %421 = trunc i64 %420 to i8, !dbg !29839
  call void @__sanitizer_cov_trace_cmp1(i8 %421, i8 %415), !dbg !29839
  %422 = icmp sge i8 %421, %415, !dbg !29839
  br i1 %422, label %425, label %._crit_edge105, !dbg !29839

._crit_edge105:                                   ; preds = %419
  %423 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 68), align 1, !dbg !29839, !nosanitize !4116
  %424 = add i8 %423, 1, !dbg !29839
  store i8 %424, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 68), align 1, !dbg !29839, !nosanitize !4116
  br label %428, !dbg !29839

425:                                              ; preds = %419
  %426 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 69), align 1, !dbg !29839, !nosanitize !4116
  %427 = add i8 %426, 1, !dbg !29839
  store i8 %427, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 69), align 1, !dbg !29839, !nosanitize !4116
  call void @__asan_report_store1(i64 %411) #42, !dbg !29839
  unreachable

428:                                              ; preds = %._crit_edge105, %._crit_edge104
  store i8 %_12, ptr %h.sroa.9.0..sroa_idx, align 8, !dbg !29839
  br label %bb98, !dbg !29840

bb60:                                             ; preds = %bb53
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %_14), !dbg !29841
  %_46 = icmp eq i8 %_14, 0, !dbg !29841
  call void @__sanitizer_cov_trace_const_cmp8(i64 0, i64 %v.sroa.0.0.copyload.i.i), !dbg !29793
  %429 = icmp eq i64 %v.sroa.0.0.copyload.i.i, 0
  %or.cond = and i1 %_46, %429, !dbg !29841
  br i1 %or.cond, label %bb60.bb54_crit_edge, label %bb60.bb98_crit_edge, !dbg !29841

bb60.bb98_crit_edge:                              ; preds = %bb60
  %430 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 70), align 1, !dbg !29841, !nosanitize !4116
  %431 = add i8 %430, 1, !dbg !29841
  store i8 %431, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 70), align 1, !dbg !29841, !nosanitize !4116
  br label %bb98, !dbg !29841

bb60.bb54_crit_edge:                              ; preds = %bb60
  %432 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 71), align 1, !dbg !29841, !nosanitize !4116
  %433 = add i8 %432, 1, !dbg !29841
  store i8 %433, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 71), align 1, !dbg !29841, !nosanitize !4116
  br label %bb54, !dbg !29841

bb59:                                             ; preds = %bb53
  call void @__sanitizer_cov_trace_const_cmp1(i8 1, i8 %_14), !dbg !29841
  %_43 = icmp eq i8 %_14, 1, !dbg !29841
  call void @__sanitizer_cov_trace_const_cmp8(i64 0, i64 %v.sroa.0.0.copyload.i.i), !dbg !29793
  %434 = icmp eq i64 %v.sroa.0.0.copyload.i.i, 0
  %or.cond2 = and i1 %_43, %434, !dbg !29841
  br i1 %or.cond2, label %bb59.bb54_crit_edge, label %bb59.bb98_crit_edge, !dbg !29841

bb59.bb98_crit_edge:                              ; preds = %bb59
  %435 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 72), align 1, !dbg !29841, !nosanitize !4116
  %436 = add i8 %435, 1, !dbg !29841
  store i8 %436, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 72), align 1, !dbg !29841, !nosanitize !4116
  br label %bb98, !dbg !29841

bb59.bb54_crit_edge:                              ; preds = %bb59
  %437 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 73), align 1, !dbg !29841, !nosanitize !4116
  %438 = add i8 %437, 1, !dbg !29841
  store i8 %438, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 73), align 1, !dbg !29841, !nosanitize !4116
  br label %bb54, !dbg !29841

bb58:                                             ; preds = %bb53
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %_14), !dbg !29842
  %_52 = icmp eq i8 %_14, 0, !dbg !29842
  call void @__sanitizer_cov_trace_const_cmp8(i64 72057594037927936, i64 %v.sroa.0.0.copyload.i.i), !dbg !29793
  %439 = icmp eq i64 %v.sroa.0.0.copyload.i.i, 72057594037927936
  %or.cond3 = and i1 %_52, %439, !dbg !29842
  br i1 %or.cond3, label %bb58.bb54_crit_edge, label %bb58.bb98_crit_edge, !dbg !29842

bb58.bb98_crit_edge:                              ; preds = %bb58
  %440 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 74), align 1, !dbg !29842, !nosanitize !4116
  %441 = add i8 %440, 1, !dbg !29842
  store i8 %441, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 74), align 1, !dbg !29842, !nosanitize !4116
  br label %bb98, !dbg !29842

bb58.bb54_crit_edge:                              ; preds = %bb58
  %442 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 75), align 1, !dbg !29842, !nosanitize !4116
  %443 = add i8 %442, 1, !dbg !29842
  store i8 %443, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 75), align 1, !dbg !29842, !nosanitize !4116
  br label %bb54, !dbg !29842

bb57:                                             ; preds = %bb53
  call void @__sanitizer_cov_trace_const_cmp1(i8 1, i8 %_14), !dbg !29842
  %_49 = icmp eq i8 %_14, 1, !dbg !29842
  call void @__sanitizer_cov_trace_const_cmp8(i64 72057594037927936, i64 %v.sroa.0.0.copyload.i.i), !dbg !29793
  %444 = icmp eq i64 %v.sroa.0.0.copyload.i.i, 72057594037927936
  %or.cond4 = and i1 %_49, %444, !dbg !29842
  br i1 %or.cond4, label %bb57.bb54_crit_edge, label %bb57.bb98_crit_edge, !dbg !29842

bb57.bb98_crit_edge:                              ; preds = %bb57
  %445 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 76), align 1, !dbg !29842, !nosanitize !4116
  %446 = add i8 %445, 1, !dbg !29842
  store i8 %446, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 76), align 1, !dbg !29842, !nosanitize !4116
  br label %bb98, !dbg !29842

bb57.bb54_crit_edge:                              ; preds = %bb57
  %447 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 77), align 1, !dbg !29842, !nosanitize !4116
  %448 = add i8 %447, 1, !dbg !29842
  store i8 %448, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 77), align 1, !dbg !29842, !nosanitize !4116
  br label %bb54, !dbg !29842

bb56:                                             ; preds = %bb53
  call void @__sanitizer_cov_trace_const_cmp8(i64 1048574, i64 %_0.i), !dbg !29843
  %or.cond5 = icmp ugt i64 %_0.i, 1048574, !dbg !29843
  br i1 %or.cond5, label %bb56.bb98_crit_edge, label %bb56.bb54_crit_edge, !dbg !29843

bb56.bb54_crit_edge:                              ; preds = %bb56
  %449 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 78), align 1, !dbg !29843, !nosanitize !4116
  %450 = add i8 %449, 1, !dbg !29843
  store i8 %450, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 78), align 1, !dbg !29843, !nosanitize !4116
  br label %bb54, !dbg !29843

bb56.bb98_crit_edge:                              ; preds = %bb56
  %451 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 79), align 1, !dbg !29843, !nosanitize !4116
  %452 = add i8 %451, 1, !dbg !29843
  store i8 %452, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 79), align 1, !dbg !29843, !nosanitize !4116
  br label %bb98, !dbg !29843

bb55:                                             ; preds = %bb53
  call void @__sanitizer_cov_trace_const_cmp8(i64 1048575, i64 %_0.i), !dbg !29843
  %_55 = icmp ugt i64 %_0.i, 1048575, !dbg !29843
  br i1 %_55, label %bb55.bb98_crit_edge, label %bb55.bb54_crit_edge, !dbg !29843

bb55.bb54_crit_edge:                              ; preds = %bb55
  %453 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 80), align 1, !dbg !29843, !nosanitize !4116
  %454 = add i8 %453, 1, !dbg !29843
  store i8 %454, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 80), align 1, !dbg !29843, !nosanitize !4116
  br label %bb54, !dbg !29843

bb55.bb98_crit_edge:                              ; preds = %bb55
  %455 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 81), align 1, !dbg !29843, !nosanitize !4116
  %456 = add i8 %455, 1, !dbg !29843
  store i8 %456, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 81), align 1, !dbg !29843, !nosanitize !4116
  br label %bb98, !dbg !29843

bb98:                                             ; preds = %bb55.bb98_crit_edge, %bb56.bb98_crit_edge, %bb57.bb98_crit_edge, %bb58.bb98_crit_edge, %bb59.bb98_crit_edge, %bb60.bb98_crit_edge, %.bb98_crit_edge103, %.bb98_crit_edge99, %switch.hole_check.bb98_crit_edge, %.bb98_crit_edge95, %.bb98_crit_edge79, %.bb98_crit_edge75, %.bb98_crit_edge, %start.bb98_crit_edge, %428
  %.sink67 = phi i64 [ 1, %start.bb98_crit_edge ], [ 1, %.bb98_crit_edge95 ], [ 1, %bb55.bb98_crit_edge ], [ 1, %bb58.bb98_crit_edge ], [ 1, %bb60.bb98_crit_edge ], [ 1, %bb56.bb98_crit_edge ], [ 41, %428 ], [ 1, %.bb98_crit_edge ], [ 1, %.bb98_crit_edge79 ], [ 1, %.bb98_crit_edge75 ], [ 1, %switch.hole_check.bb98_crit_edge ], [ 1, %.bb98_crit_edge99 ], [ 1, %.bb98_crit_edge103 ], [ 1, %bb59.bb98_crit_edge ], [ 1, %bb57.bb98_crit_edge ]
  %.sink65 = phi i8 [ 0, %start.bb98_crit_edge ], [ 0, %.bb98_crit_edge95 ], [ 0, %bb55.bb98_crit_edge ], [ 0, %bb58.bb98_crit_edge ], [ 0, %bb60.bb98_crit_edge ], [ 0, %bb56.bb98_crit_edge ], [ %_14, %428 ], [ 0, %.bb98_crit_edge ], [ 0, %.bb98_crit_edge79 ], [ 0, %.bb98_crit_edge75 ], [ 0, %switch.hole_check.bb98_crit_edge ], [ 0, %.bb98_crit_edge99 ], [ 0, %.bb98_crit_edge103 ], [ 0, %bb59.bb98_crit_edge ], [ 0, %bb57.bb98_crit_edge ]
  %.sink = phi i8 [ 1, %start.bb98_crit_edge ], [ 1, %.bb98_crit_edge95 ], [ 1, %bb55.bb98_crit_edge ], [ 1, %bb58.bb98_crit_edge ], [ 1, %bb60.bb98_crit_edge ], [ 1, %bb56.bb98_crit_edge ], [ 0, %428 ], [ 1, %.bb98_crit_edge ], [ 1, %.bb98_crit_edge79 ], [ 1, %.bb98_crit_edge75 ], [ 1, %switch.hole_check.bb98_crit_edge ], [ 1, %.bb98_crit_edge99 ], [ 1, %.bb98_crit_edge103 ], [ 1, %bb59.bb98_crit_edge ], [ 1, %bb57.bb98_crit_edge ]
  %457 = getelementptr inbounds nuw i8, ptr %_0, i64 %.sink67, !dbg !29793
  %458 = ptrtoint ptr %457 to i64, !dbg !29793
  %459 = lshr i64 %458, 3, !dbg !29793
  %460 = add i64 %459, 2147450880, !dbg !29793
  %461 = inttoptr i64 %460 to ptr, !dbg !29793
  %462 = load i8, ptr %461, align 1, !dbg !29793
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %462), !dbg !29793
  %463 = icmp ne i8 %462, 0, !dbg !29793
  br i1 %463, label %466, label %bb98._crit_edge, !dbg !29793, !prof !4264

bb98._crit_edge:                                  ; preds = %bb98
  %464 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 82), align 1, !dbg !29793, !nosanitize !4116
  %465 = add i8 %464, 1, !dbg !29793
  store i8 %465, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 82), align 1, !dbg !29793, !nosanitize !4116
  br label %475, !dbg !29793

466:                                              ; preds = %bb98
  %467 = and i64 %458, 7, !dbg !29793
  %468 = trunc i64 %467 to i8, !dbg !29793
  call void @__sanitizer_cov_trace_cmp1(i8 %468, i8 %462), !dbg !29793
  %469 = icmp sge i8 %468, %462, !dbg !29793
  br i1 %469, label %472, label %._crit_edge106, !dbg !29793

._crit_edge106:                                   ; preds = %466
  %470 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 83), align 1, !dbg !29793, !nosanitize !4116
  %471 = add i8 %470, 1, !dbg !29793
  store i8 %471, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 83), align 1, !dbg !29793, !nosanitize !4116
  br label %475, !dbg !29793

472:                                              ; preds = %466
  %473 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 84), align 1, !dbg !29793, !nosanitize !4116
  %474 = add i8 %473, 1, !dbg !29793
  store i8 %474, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 84), align 1, !dbg !29793, !nosanitize !4116
  call void @__asan_report_store1(i64 %458) #42, !dbg !29793
  unreachable

475:                                              ; preds = %._crit_edge106, %bb98._crit_edge
  store i8 %.sink65, ptr %457, align 1, !dbg !29793
  %476 = ptrtoint ptr %_0 to i64, !dbg !29793
  %477 = lshr i64 %476, 3, !dbg !29793
  %478 = add i64 %477, 2147450880, !dbg !29793
  %479 = inttoptr i64 %478 to ptr, !dbg !29793
  %480 = load i8, ptr %479, align 1, !dbg !29793
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %480), !dbg !29793
  %481 = icmp ne i8 %480, 0, !dbg !29793
  br i1 %481, label %484, label %._crit_edge107, !dbg !29793, !prof !4264

._crit_edge107:                                   ; preds = %475
  %482 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 85), align 1, !dbg !29793, !nosanitize !4116
  %483 = add i8 %482, 1, !dbg !29793
  store i8 %483, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 85), align 1, !dbg !29793, !nosanitize !4116
  br label %493, !dbg !29793

484:                                              ; preds = %475
  %485 = and i64 %476, 7, !dbg !29793
  %486 = trunc i64 %485 to i8, !dbg !29793
  call void @__sanitizer_cov_trace_cmp1(i8 %486, i8 %480), !dbg !29793
  %487 = icmp sge i8 %486, %480, !dbg !29793
  br i1 %487, label %490, label %._crit_edge108, !dbg !29793

._crit_edge108:                                   ; preds = %484
  %488 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 86), align 1, !dbg !29793, !nosanitize !4116
  %489 = add i8 %488, 1, !dbg !29793
  store i8 %489, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 86), align 1, !dbg !29793, !nosanitize !4116
  br label %493, !dbg !29793

490:                                              ; preds = %484
  %491 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 87), align 1, !dbg !29793, !nosanitize !4116
  %492 = add i8 %491, 1, !dbg !29793
  store i8 %492, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1437, i64 0, i64 87), align 1, !dbg !29793, !nosanitize !4116
  call void @__asan_report_store1(i64 %476) #42, !dbg !29793
  unreachable

493:                                              ; preds = %._crit_edge108, %._crit_edge107
  store i8 %.sink, ptr %_0, align 8, !dbg !29793
  ret void, !dbg !29840
}

; Verified production function: wire_parse
define void @_RNvNtCs1K0wxfkMoe8_15spiral_protocol4wire5parse(ptr dead_on_unwind noalias nofree noundef writable writeonly sret([56 x i8]) align 8 captures(none) dereferenceable(56) %_0, ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) %raw.0, i64 noundef range(i64 0, -9223372036854775808) %raw.1) unnamed_addr #0 comdat !dbg !28905 !guid !53804 {
start:
  %h.sroa.0 = alloca [24 x i8], align 8
  %_4.sroa.9 = alloca [29 x i8], align 1
  %asan_local_stack_base = alloca i64, align 8
  %0 = load i8, ptr @__sancov_gen_.2142, align 1, !dbg !53805, !nosanitize !4116
  %1 = add i8 %0, 1, !dbg !53805
  store i8 %1, ptr @__sancov_gen_.2142, align 1, !dbg !53805, !nosanitize !4116
  %2 = load i32, ptr @__asan_option_detect_stack_use_after_return, align 4
  call void @__sanitizer_cov_trace_const_cmp4(i32 0, i32 %2), !dbg !53806
  %3 = icmp ne i32 %2, 0
  br i1 %3, label %6, label %start._crit_edge

start._crit_edge:                                 ; preds = %start
  %4 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2142, i64 0, i64 1), align 1, !dbg !53806, !nosanitize !4116
  %5 = add i8 %4, 1, !dbg !53806
  store i8 %5, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2142, i64 0, i64 1), align 1, !dbg !53806, !nosanitize !4116
  br label %10

6:                                                ; preds = %start
  %7 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2142, i64 0, i64 2), align 1, !dbg !53806, !nosanitize !4116
  %8 = add i8 %7, 1, !dbg !53806
  store i8 %8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2142, i64 0, i64 2), align 1, !dbg !53806, !nosanitize !4116
  %9 = call i64 @__asan_stack_malloc_1(i64 128)
  br label %10

10:                                               ; preds = %start._crit_edge, %6
  %11 = phi i64 [ 0, %start._crit_edge ], [ %9, %6 ]
  %12 = inttoptr i64 %11 to ptr
  call void @__sanitizer_cov_trace_const_cmp8(i64 0, i64 %11), !dbg !53806
  %13 = icmp eq i64 %11, 0
  br i1 %13, label %16, label %._crit_edge

._crit_edge:                                      ; preds = %10
  %14 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2142, i64 0, i64 3), align 1, !dbg !53806, !nosanitize !4116
  %15 = add i8 %14, 1, !dbg !53806
  store i8 %15, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2142, i64 0, i64 3), align 1, !dbg !53806, !nosanitize !4116
  br label %19

16:                                               ; preds = %10
  %17 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2142, i64 0, i64 4), align 1, !dbg !53806, !nosanitize !4116
  %18 = add i8 %17, 1, !dbg !53806
  store i8 %18, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2142, i64 0, i64 4), align 1, !dbg !53806, !nosanitize !4116
  %MyAlloca = alloca i8, i64 128, align 32
  br label %19

19:                                               ; preds = %._crit_edge, %16
  %20 = phi ptr [ %12, %._crit_edge ], [ %MyAlloca, %16 ]
  store ptr %20, ptr %asan_local_stack_base, align 8
  %21 = getelementptr i8, ptr %20, i64 32
  store i64 1102416563, ptr %20, align 8
  %22 = getelementptr i8, ptr %20, i64 8
  store i64 ptrtoint (ptr @___asan_gen_stack.236 to i64), ptr %22, align 8
  %23 = getelementptr i8, ptr %20, i64 16
  store i64 ptrtoint (ptr @_RNvNtCs1K0wxfkMoe8_15spiral_protocol4wire5parse to i64), ptr %23, align 8
  %24 = ptrtoint ptr %20 to i64
  %25 = lshr i64 %24, 3
  %26 = add i64 %25, 2147450880
  %27 = add i64 %26, 0
  %28 = inttoptr i64 %27 to ptr
  store i64 -506381209984437775, ptr %28, align 1
  %29 = add i64 %26, 8
  %30 = inttoptr i64 %29 to ptr
  store i64 -868082074056918792, ptr %30, align 1
  call void @__sanitizer_cov_trace_const_cmp8(i64 40, i64 %raw.1), !dbg !53807
  %_2 = icmp samesign ult i64 %raw.1, 40, !dbg !53807
  br i1 %_2, label %bb1, label %bb2, !dbg !53807

bb2:                                              ; preds = %19
  call void @llvm.lifetime.start.p0(ptr nonnull %_4.sroa.9), !dbg !53808
  %31 = add i64 %26, 4, !dbg !53808
  %32 = inttoptr i64 %31 to ptr, !dbg !53808
  store i32 0, ptr %32, align 1, !dbg !53808
  %33 = add i64 %26, 8, !dbg !53808
  %34 = inttoptr i64 %33 to ptr, !dbg !53808
  store i16 0, ptr %34, align 1, !dbg !53808
; call <spiral_protocol::wire::Header>::parse
  call void @_RNvMNtCs1K0wxfkMoe8_15spiral_protocol4wireNtB2_6Header5parse(ptr noalias nofree noundef sret([48 x i8]) align 8 captures(none) dereferenceable(48) %21, ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) %raw.0, i64 noundef 40) #35, !dbg !53808
  tail call void @llvm.experimental.noalias.scope.decl(metadata !53809), !dbg !53808
  %35 = load i8, ptr %21, align 8, !dbg !53812, !range !4431, !alias.scope !53814, !noalias !53809, !noundef !4116
  %36 = trunc nuw i8 %35 to i1, !dbg !53812
  br i1 %36, label %bb2.i, label %bb3.i, !dbg !53816

bb2.i:                                            ; preds = %bb2
  %37 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2142, i64 0, i64 5), align 1, !dbg !53817, !nosanitize !4116
  %38 = add i8 %37, 1, !dbg !53817
  store i8 %38, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2142, i64 0, i64 5), align 1, !dbg !53817, !nosanitize !4116
  %39 = getelementptr inbounds nuw i8, ptr %21, i64 1, !dbg !53817
  %e.0.i = load i8, ptr %39, align 1, !dbg !53817, !range !19535, !alias.scope !53814, !noalias !53809, !noundef !4116
  %40 = getelementptr inbounds nuw i8, ptr %21, i64 2, !dbg !53817
  %e.1.i = load i8, ptr %40, align 2, !dbg !53817, !alias.scope !53814, !noalias !53809
  br label %_RNvXsp_NtCshZBO5P2NUJi_4core6resultINtB5_6ResultNtNtCs1K0wxfkMoe8_15spiral_protocol4wire6HeaderNtNtBO_5error5ErrorENtNtNtB7_3ops9try_trait3Try6branchBO_.exit, !dbg !53818

bb3.i:                                            ; preds = %bb2
  %41 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2142, i64 0, i64 6), align 1, !dbg !53819, !nosanitize !4116
  %42 = add i8 %41, 1, !dbg !53819
  store i8 %42, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2142, i64 0, i64 6), align 1, !dbg !53819, !nosanitize !4116
  %43 = getelementptr inbounds nuw i8, ptr %21, i64 8, !dbg !53819
  %_4.sroa.9.8..sroa_idx = getelementptr inbounds nuw i8, ptr %_4.sroa.9, i64 5, !dbg !53819
  %44 = call ptr @__asan_memcpy(ptr %_4.sroa.9.8..sroa_idx, ptr %43, i64 24), !dbg !53819
  %_4.sroa.11.8..sroa_idx = getelementptr inbounds nuw i8, ptr %21, i64 32, !dbg !53819
  %_4.sroa.11.8.copyload = load i64, ptr %_4.sroa.11.8..sroa_idx, align 8, !dbg !53819, !alias.scope !53820
  %_4.sroa.12.8..sroa_idx = getelementptr inbounds nuw i8, ptr %21, i64 40, !dbg !53819
  %_4.sroa.12.8.copyload = load i64, ptr %_4.sroa.12.8..sroa_idx, align 8, !dbg !53819, !alias.scope !53820
  br label %_RNvXsp_NtCshZBO5P2NUJi_4core6resultINtB5_6ResultNtNtCs1K0wxfkMoe8_15spiral_protocol4wire6HeaderNtNtBO_5error5ErrorENtNtNtB7_3ops9try_trait3Try6branchBO_.exit, !dbg !53821

_RNvXsp_NtCshZBO5P2NUJi_4core6resultINtB5_6ResultNtNtCs1K0wxfkMoe8_15spiral_protocol4wire6HeaderNtNtBO_5error5ErrorENtNtNtB7_3ops9try_trait3Try6branchBO_.exit: ; preds = %bb2.i, %bb3.i
  %_4.sroa.11.0 = phi i64 [ undef, %bb2.i ], [ %_4.sroa.11.8.copyload, %bb3.i ]
  %_4.sroa.7.0 = phi i8 [ %e.1.i, %bb2.i ], [ undef, %bb3.i ]
  %_4.sroa.5.0 = phi i8 [ %e.0.i, %bb2.i ], [ undef, %bb3.i ]
  %_4.sroa.12.0 = phi i64 [ undef, %bb2.i ], [ %_4.sroa.12.8.copyload, %bb3.i ]
  %45 = add i64 %26, 4, !dbg !53822
  %46 = inttoptr i64 %45 to ptr, !dbg !53822
  store i32 -117901064, ptr %46, align 1, !dbg !53822
  %47 = add i64 %26, 8, !dbg !53822
  %48 = inttoptr i64 %47 to ptr, !dbg !53822
  store i16 -1800, ptr %48, align 1, !dbg !53822
  br i1 %36, label %bb8, label %bb7, !dbg !53808

bb1:                                              ; preds = %19
  %49 = ptrtoint ptr %_0 to i64, !dbg !53823
  %50 = lshr i64 %49, 3, !dbg !53823
  %51 = add i64 %50, 2147450880, !dbg !53823
  %52 = inttoptr i64 %51 to ptr, !dbg !53823
  %53 = load i8, ptr %52, align 1, !dbg !53823
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %53), !dbg !53823
  %54 = icmp ne i8 %53, 0, !dbg !53823
  br i1 %54, label %57, label %bb1._crit_edge, !dbg !53823, !prof !4264

bb1._crit_edge:                                   ; preds = %bb1
  %55 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2142, i64 0, i64 7), align 1, !dbg !53823, !nosanitize !4116
  %56 = add i8 %55, 1, !dbg !53823
  store i8 %56, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2142, i64 0, i64 7), align 1, !dbg !53823, !nosanitize !4116
  br label %66, !dbg !53823

57:                                               ; preds = %bb1
  %58 = and i64 %49, 7, !dbg !53823
  %59 = trunc i64 %58 to i8, !dbg !53823
  call void @__sanitizer_cov_trace_cmp1(i8 %59, i8 %53), !dbg !53823
  %60 = icmp sge i8 %59, %53, !dbg !53823
  br i1 %60, label %63, label %._crit_edge5, !dbg !53823

._crit_edge5:                                     ; preds = %57
  %61 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2142, i64 0, i64 8), align 1, !dbg !53823, !nosanitize !4116
  %62 = add i8 %61, 1, !dbg !53823
  store i8 %62, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2142, i64 0, i64 8), align 1, !dbg !53823, !nosanitize !4116
  br label %66, !dbg !53823

63:                                               ; preds = %57
  %64 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2142, i64 0, i64 9), align 1, !dbg !53823, !nosanitize !4116
  %65 = add i8 %64, 1, !dbg !53823
  store i8 %65, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2142, i64 0, i64 9), align 1, !dbg !53823, !nosanitize !4116
  call void @__asan_report_store1(i64 %49) #42, !dbg !53823
  unreachable

66:                                               ; preds = %._crit_edge5, %bb1._crit_edge
  store i8 0, ptr %_0, align 8, !dbg !53823
  %67 = getelementptr inbounds nuw i8, ptr %_0, i64 40, !dbg !53823
  %68 = ptrtoint ptr %67 to i64, !dbg !53823
  %69 = lshr i64 %68, 3, !dbg !53823
  %70 = add i64 %69, 2147450880, !dbg !53823
  %71 = inttoptr i64 %70 to ptr, !dbg !53823
  %72 = load i8, ptr %71, align 1, !dbg !53823
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %72), !dbg !53823
  %73 = icmp ne i8 %72, 0, !dbg !53823
  br i1 %73, label %74, label %77, !dbg !53823

74:                                               ; preds = %66
  %75 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2142, i64 0, i64 10), align 1, !dbg !53823, !nosanitize !4116
  %76 = add i8 %75, 1, !dbg !53823
  store i8 %76, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2142, i64 0, i64 10), align 1, !dbg !53823, !nosanitize !4116
  call void @__asan_report_store8(i64 %68) #42, !dbg !53823
  unreachable, !dbg !53823

77:                                               ; preds = %66
  %78 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2142, i64 0, i64 11), align 1, !dbg !53823, !nosanitize !4116
  %79 = add i8 %78, 1, !dbg !53823
  store i8 %79, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2142, i64 0, i64 11), align 1, !dbg !53823, !nosanitize !4116
  store ptr null, ptr %67, align 8, !dbg !53823
  br label %bb15, !dbg !53824

bb8:                                              ; preds = %_RNvXsp_NtCshZBO5P2NUJi_4core6resultINtB5_6ResultNtNtCs1K0wxfkMoe8_15spiral_protocol4wire6HeaderNtNtBO_5error5ErrorENtNtNtB7_3ops9try_trait3Try6branchBO_.exit
  %80 = ptrtoint ptr %_0 to i64, !dbg !53825
  %81 = lshr i64 %80, 3, !dbg !53825
  %82 = add i64 %81, 2147450880, !dbg !53825
  %83 = inttoptr i64 %82 to ptr, !dbg !53825
  %84 = load i8, ptr %83, align 1, !dbg !53825
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %84), !dbg !53825
  %85 = icmp ne i8 %84, 0, !dbg !53825
  br i1 %85, label %88, label %bb8._crit_edge, !dbg !53825, !prof !4264

bb8._crit_edge:                                   ; preds = %bb8
  %86 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2142, i64 0, i64 12), align 1, !dbg !53825, !nosanitize !4116
  %87 = add i8 %86, 1, !dbg !53825
  store i8 %87, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2142, i64 0, i64 12), align 1, !dbg !53825, !nosanitize !4116
  br label %97, !dbg !53825

88:                                               ; preds = %bb8
  %89 = and i64 %80, 7, !dbg !53825
  %90 = trunc i64 %89 to i8, !dbg !53825
  call void @__sanitizer_cov_trace_cmp1(i8 %90, i8 %84), !dbg !53825
  %91 = icmp sge i8 %90, %84, !dbg !53825
  br i1 %91, label %94, label %._crit_edge6, !dbg !53825

._crit_edge6:                                     ; preds = %88
  %92 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2142, i64 0, i64 13), align 1, !dbg !53825, !nosanitize !4116
  %93 = add i8 %92, 1, !dbg !53825
  store i8 %93, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2142, i64 0, i64 13), align 1, !dbg !53825, !nosanitize !4116
  br label %97, !dbg !53825

94:                                               ; preds = %88
  %95 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2142, i64 0, i64 14), align 1, !dbg !53825, !nosanitize !4116
  %96 = add i8 %95, 1, !dbg !53825
  store i8 %96, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2142, i64 0, i64 14), align 1, !dbg !53825, !nosanitize !4116
  call void @__asan_report_store1(i64 %80) #42, !dbg !53825
  unreachable

97:                                               ; preds = %._crit_edge6, %bb8._crit_edge
  store i8 %_4.sroa.5.0, ptr %_0, align 8, !dbg !53825, !alias.scope !53827
  %98 = getelementptr inbounds nuw i8, ptr %_0, i64 1, !dbg !53825
  %99 = ptrtoint ptr %98 to i64, !dbg !53825
  %100 = lshr i64 %99, 3, !dbg !53825
  %101 = add i64 %100, 2147450880, !dbg !53825
  %102 = inttoptr i64 %101 to ptr, !dbg !53825
  %103 = load i8, ptr %102, align 1, !dbg !53825
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %103), !dbg !53825
  %104 = icmp ne i8 %103, 0, !dbg !53825
  br i1 %104, label %107, label %._crit_edge7, !dbg !53825, !prof !4264

._crit_edge7:                                     ; preds = %97
  %105 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2142, i64 0, i64 15), align 1, !dbg !53825, !nosanitize !4116
  %106 = add i8 %105, 1, !dbg !53825
  store i8 %106, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2142, i64 0, i64 15), align 1, !dbg !53825, !nosanitize !4116
  br label %116, !dbg !53825

107:                                              ; preds = %97
  %108 = and i64 %99, 7, !dbg !53825
  %109 = trunc i64 %108 to i8, !dbg !53825
  call void @__sanitizer_cov_trace_cmp1(i8 %109, i8 %103), !dbg !53825
  %110 = icmp sge i8 %109, %103, !dbg !53825
  br i1 %110, label %113, label %._crit_edge8, !dbg !53825

._crit_edge8:                                     ; preds = %107
  %111 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2142, i64 0, i64 16), align 1, !dbg !53825, !nosanitize !4116
  %112 = add i8 %111, 1, !dbg !53825
  store i8 %112, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2142, i64 0, i64 16), align 1, !dbg !53825, !nosanitize !4116
  br label %116, !dbg !53825

113:                                              ; preds = %107
  %114 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2142, i64 0, i64 17), align 1, !dbg !53825, !nosanitize !4116
  %115 = add i8 %114, 1, !dbg !53825
  store i8 %115, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2142, i64 0, i64 17), align 1, !dbg !53825, !nosanitize !4116
  call void @__asan_report_store1(i64 %99) #42, !dbg !53825
  unreachable

116:                                              ; preds = %._crit_edge8, %._crit_edge7
  store i8 %_4.sroa.7.0, ptr %98, align 1, !dbg !53825, !alias.scope !53827
  %117 = getelementptr inbounds nuw i8, ptr %_0, i64 40, !dbg !53825
  %118 = ptrtoint ptr %117 to i64, !dbg !53825
  %119 = lshr i64 %118, 3, !dbg !53825
  %120 = add i64 %119, 2147450880, !dbg !53825
  %121 = inttoptr i64 %120 to ptr, !dbg !53825
  %122 = load i8, ptr %121, align 1, !dbg !53825
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %122), !dbg !53825
  %123 = icmp ne i8 %122, 0, !dbg !53825
  br i1 %123, label %124, label %127, !dbg !53825

124:                                              ; preds = %116
  %125 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2142, i64 0, i64 18), align 1, !dbg !53825, !nosanitize !4116
  %126 = add i8 %125, 1, !dbg !53825
  store i8 %126, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2142, i64 0, i64 18), align 1, !dbg !53825, !nosanitize !4116
  call void @__asan_report_store8(i64 %118) #42, !dbg !53825
  unreachable, !dbg !53825

127:                                              ; preds = %116
  %128 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2142, i64 0, i64 19), align 1, !dbg !53825, !nosanitize !4116
  %129 = add i8 %128, 1, !dbg !53825
  store i8 %129, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2142, i64 0, i64 19), align 1, !dbg !53825, !nosanitize !4116
  store ptr null, ptr %117, align 8, !dbg !53825, !alias.scope !53827
  call void @llvm.lifetime.end.p0(ptr nonnull %_4.sroa.9), !dbg !53830
  br label %bb15, !dbg !53824

bb7:                                              ; preds = %_RNvXsp_NtCshZBO5P2NUJi_4core6resultINtB5_6ResultNtNtCs1K0wxfkMoe8_15spiral_protocol4wire6HeaderNtNtBO_5error5ErrorENtNtNtB7_3ops9try_trait3Try6branchBO_.exit
  %_4.sroa.9.8..sroa_idx4 = getelementptr inbounds nuw i8, ptr %_4.sroa.9, i64 5, !dbg !53808
  %130 = call ptr @__asan_memcpy(ptr %h.sroa.0, ptr %_4.sroa.9.8..sroa_idx4, i64 24), !dbg !53808
  call void @llvm.lifetime.end.p0(ptr nonnull %_4.sroa.9), !dbg !53830
  call void @__sanitizer_cov_trace_const_cmp8(i64 -41, i64 %_4.sroa.11.0), !dbg !53831
  %_13.1 = icmp ugt i64 %_4.sroa.11.0, -41, !dbg !53831
  br i1 %_13.1, label %panic, label %bb10, !dbg !53831

bb10:                                             ; preds = %bb7
  %_13.0 = add nuw i64 %_4.sroa.11.0, 40, !dbg !53831
  call void @__sanitizer_cov_trace_cmp8(i64 %raw.1, i64 %_13.0), !dbg !53832
  %_10.not = icmp eq i64 %raw.1, %_13.0, !dbg !53832
  br i1 %_10.not, label %bb12, label %bb11, !dbg !53832

panic:                                            ; preds = %bb7
  %131 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2142, i64 0, i64 20), align 1, !dbg !53831, !nosanitize !4116
  %132 = add i8 %131, 1, !dbg !53831
  store i8 %132, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2142, i64 0, i64 20), align 1, !dbg !53831, !nosanitize !4116
  call void @__asan_handle_no_return(), !dbg !53831
; call core::panicking::panic_const::panic_const_add_overflow
  tail call void @_RNvNtNtCshZBO5P2NUJi_4core9panicking11panic_const24panic_const_add_overflow(ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_8261cc9843ad33371a73da063aa10507) #43, !dbg !53831
  unreachable, !dbg !53831

bb12:                                             ; preds = %bb10
  %new_len.i = add nsw i64 %raw.1, -40, !dbg !53833
  %_11.i = getelementptr inbounds nuw i8, ptr %raw.0, i64 40, !dbg !53836
  %133 = call ptr @__asan_memcpy(ptr %_0, ptr %h.sroa.0, i64 24), !dbg !53838
  %_14.sroa.4.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 24, !dbg !53839
  %134 = ptrtoint ptr %_14.sroa.4.0._0.sroa_idx to i64, !dbg !53839
  %135 = lshr i64 %134, 3, !dbg !53839
  %136 = add i64 %135, 2147450880, !dbg !53839
  %137 = inttoptr i64 %136 to ptr, !dbg !53839
  %138 = load i8, ptr %137, align 1, !dbg !53839
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %138), !dbg !53839
  %139 = icmp ne i8 %138, 0, !dbg !53839
  br i1 %139, label %140, label %143, !dbg !53839

140:                                              ; preds = %bb12
  %141 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2142, i64 0, i64 21), align 1, !dbg !53839, !nosanitize !4116
  %142 = add i8 %141, 1, !dbg !53839
  store i8 %142, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2142, i64 0, i64 21), align 1, !dbg !53839, !nosanitize !4116
  call void @__asan_report_store8(i64 %134) #42, !dbg !53839
  unreachable, !dbg !53839

143:                                              ; preds = %bb12
  store i64 %_4.sroa.11.0, ptr %_14.sroa.4.0._0.sroa_idx, align 8, !dbg !53839
  %_14.sroa.5.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 32, !dbg !53839
  %144 = ptrtoint ptr %_14.sroa.5.0._0.sroa_idx to i64, !dbg !53839
  %145 = lshr i64 %144, 3, !dbg !53839
  %146 = add i64 %145, 2147450880, !dbg !53839
  %147 = inttoptr i64 %146 to ptr, !dbg !53839
  %148 = load i8, ptr %147, align 1, !dbg !53839
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %148), !dbg !53839
  %149 = icmp ne i8 %148, 0, !dbg !53839
  br i1 %149, label %150, label %153, !dbg !53839

150:                                              ; preds = %143
  %151 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2142, i64 0, i64 22), align 1, !dbg !53839, !nosanitize !4116
  %152 = add i8 %151, 1, !dbg !53839
  store i8 %152, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2142, i64 0, i64 22), align 1, !dbg !53839, !nosanitize !4116
  call void @__asan_report_store8(i64 %144) #42, !dbg !53839
  unreachable, !dbg !53839

153:                                              ; preds = %143
  store i64 %_4.sroa.12.0, ptr %_14.sroa.5.0._0.sroa_idx, align 8, !dbg !53839
  %_14.sroa.6.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 40, !dbg !53839
  %154 = ptrtoint ptr %_14.sroa.6.0._0.sroa_idx to i64, !dbg !53839
  %155 = lshr i64 %154, 3, !dbg !53839
  %156 = add i64 %155, 2147450880, !dbg !53839
  %157 = inttoptr i64 %156 to ptr, !dbg !53839
  %158 = load i8, ptr %157, align 1, !dbg !53839
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %158), !dbg !53839
  %159 = icmp ne i8 %158, 0, !dbg !53839
  br i1 %159, label %160, label %163, !dbg !53839

160:                                              ; preds = %153
  %161 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2142, i64 0, i64 23), align 1, !dbg !53839, !nosanitize !4116
  %162 = add i8 %161, 1, !dbg !53839
  store i8 %162, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2142, i64 0, i64 23), align 1, !dbg !53839, !nosanitize !4116
  call void @__asan_report_store8(i64 %154) #42, !dbg !53839
  unreachable, !dbg !53839

163:                                              ; preds = %153
  store ptr %_11.i, ptr %_14.sroa.6.0._0.sroa_idx, align 8, !dbg !53839
  %_14.sroa.7.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 48, !dbg !53839
  %164 = ptrtoint ptr %_14.sroa.7.0._0.sroa_idx to i64, !dbg !53839
  %165 = lshr i64 %164, 3, !dbg !53839
  %166 = add i64 %165, 2147450880, !dbg !53839
  %167 = inttoptr i64 %166 to ptr, !dbg !53839
  %168 = load i8, ptr %167, align 1, !dbg !53839
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %168), !dbg !53839
  %169 = icmp ne i8 %168, 0, !dbg !53839
  br i1 %169, label %170, label %173, !dbg !53839

170:                                              ; preds = %163
  %171 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2142, i64 0, i64 24), align 1, !dbg !53839, !nosanitize !4116
  %172 = add i8 %171, 1, !dbg !53839
  store i8 %172, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2142, i64 0, i64 24), align 1, !dbg !53839, !nosanitize !4116
  call void @__asan_report_store8(i64 %164) #42, !dbg !53839
  unreachable, !dbg !53839

173:                                              ; preds = %163
  %174 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2142, i64 0, i64 25), align 1, !dbg !53839, !nosanitize !4116
  %175 = add i8 %174, 1, !dbg !53839
  store i8 %175, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2142, i64 0, i64 25), align 1, !dbg !53839, !nosanitize !4116
  store i64 %new_len.i, ptr %_14.sroa.7.0._0.sroa_idx, align 8, !dbg !53839
  br label %bb15, !dbg !53840

bb11:                                             ; preds = %bb10
  %176 = ptrtoint ptr %_0 to i64, !dbg !53841
  %177 = lshr i64 %176, 3, !dbg !53841
  %178 = add i64 %177, 2147450880, !dbg !53841
  %179 = inttoptr i64 %178 to ptr, !dbg !53841
  %180 = load i8, ptr %179, align 1, !dbg !53841
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %180), !dbg !53841
  %181 = icmp ne i8 %180, 0, !dbg !53841
  br i1 %181, label %184, label %bb11._crit_edge, !dbg !53841, !prof !4264

bb11._crit_edge:                                  ; preds = %bb11
  %182 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2142, i64 0, i64 26), align 1, !dbg !53841, !nosanitize !4116
  %183 = add i8 %182, 1, !dbg !53841
  store i8 %183, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2142, i64 0, i64 26), align 1, !dbg !53841, !nosanitize !4116
  br label %193, !dbg !53841

184:                                              ; preds = %bb11
  %185 = and i64 %176, 7, !dbg !53841
  %186 = trunc i64 %185 to i8, !dbg !53841
  call void @__sanitizer_cov_trace_cmp1(i8 %186, i8 %180), !dbg !53841
  %187 = icmp sge i8 %186, %180, !dbg !53841
  br i1 %187, label %190, label %._crit_edge9, !dbg !53841

._crit_edge9:                                     ; preds = %184
  %188 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2142, i64 0, i64 27), align 1, !dbg !53841, !nosanitize !4116
  %189 = add i8 %188, 1, !dbg !53841
  store i8 %189, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2142, i64 0, i64 27), align 1, !dbg !53841, !nosanitize !4116
  br label %193, !dbg !53841

190:                                              ; preds = %184
  %191 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2142, i64 0, i64 28), align 1, !dbg !53841, !nosanitize !4116
  %192 = add i8 %191, 1, !dbg !53841
  store i8 %192, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2142, i64 0, i64 28), align 1, !dbg !53841, !nosanitize !4116
  call void @__asan_report_store1(i64 %176) #42, !dbg !53841
  unreachable

193:                                              ; preds = %._crit_edge9, %bb11._crit_edge
  store i8 0, ptr %_0, align 8, !dbg !53841
  %194 = getelementptr inbounds nuw i8, ptr %_0, i64 40, !dbg !53841
  %195 = ptrtoint ptr %194 to i64, !dbg !53841
  %196 = lshr i64 %195, 3, !dbg !53841
  %197 = add i64 %196, 2147450880, !dbg !53841
  %198 = inttoptr i64 %197 to ptr, !dbg !53841
  %199 = load i8, ptr %198, align 1, !dbg !53841
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %199), !dbg !53841
  %200 = icmp ne i8 %199, 0, !dbg !53841
  br i1 %200, label %201, label %204, !dbg !53841

201:                                              ; preds = %193
  %202 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2142, i64 0, i64 29), align 1, !dbg !53841, !nosanitize !4116
  %203 = add i8 %202, 1, !dbg !53841
  store i8 %203, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2142, i64 0, i64 29), align 1, !dbg !53841, !nosanitize !4116
  call void @__asan_report_store8(i64 %195) #42, !dbg !53841
  unreachable, !dbg !53841

204:                                              ; preds = %193
  %205 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2142, i64 0, i64 30), align 1, !dbg !53841, !nosanitize !4116
  %206 = add i8 %205, 1, !dbg !53841
  store i8 %206, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2142, i64 0, i64 30), align 1, !dbg !53841, !nosanitize !4116
  store ptr null, ptr %194, align 8, !dbg !53841
  br label %bb15, !dbg !53842

bb15:                                             ; preds = %204, %127, %77, %173
  store i64 1172321806, ptr %20, align 8, !dbg !53840
  call void @__sanitizer_cov_trace_const_cmp8(i64 0, i64 %11), !dbg !53840
  %207 = icmp ne i64 %11, 0, !dbg !53840
  br i1 %207, label %208, label %218, !dbg !53840

208:                                              ; preds = %bb15
  %209 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2142, i64 0, i64 31), align 1, !dbg !53840, !nosanitize !4116
  %210 = add i8 %209, 1, !dbg !53840
  store i8 %210, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2142, i64 0, i64 31), align 1, !dbg !53840, !nosanitize !4116
  %211 = add i64 %26, 0, !dbg !53840
  %212 = inttoptr i64 %211 to ptr, !dbg !53840
  store i64 -723401728380766731, ptr %212, align 1, !dbg !53840
  %213 = add i64 %26, 8, !dbg !53840
  %214 = inttoptr i64 %213 to ptr, !dbg !53840
  store i64 -723401728380766731, ptr %214, align 1, !dbg !53840
  %215 = getelementptr i8, ptr %12, i64 120, !dbg !53840
  %216 = load i64, ptr %215, align 8, !dbg !53840
  %217 = inttoptr i64 %216 to ptr, !dbg !53840
  store i8 0, ptr %217, align 1, !dbg !53840
  br label %225, !dbg !53840

218:                                              ; preds = %bb15
  %219 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2142, i64 0, i64 32), align 1, !dbg !53840, !nosanitize !4116
  %220 = add i8 %219, 1, !dbg !53840
  store i8 %220, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2142, i64 0, i64 32), align 1, !dbg !53840, !nosanitize !4116
  %221 = add i64 %26, 0, !dbg !53840
  %222 = inttoptr i64 %221 to ptr, !dbg !53840
  store i64 0, ptr %222, align 1, !dbg !53840
  %223 = add i64 %26, 8, !dbg !53840
  %224 = inttoptr i64 %223 to ptr, !dbg !53840
  store i64 0, ptr %224, align 1, !dbg !53840
  br label %225, !dbg !53840

225:                                              ; preds = %218, %208
  ret void, !dbg !53840
}

; Verified production function: parse_frame
define void @_RNvNtCs1K0wxfkMoe8_15spiral_protocol12test_support11parse_frame(ptr dead_on_unwind noalias nofree noundef writable writeonly sret([56 x i8]) align 8 captures(none) dereferenceable(56) %_0, ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) %data.0, i64 noundef range(i64 0, -9223372036854775808) %data.1) unnamed_addr #12 comdat !dbg !53674 !guid !53677 {
start:
  %h.sroa.0.i = alloca [24 x i8], align 8
  %_4.sroa.9.i = alloca [29 x i8], align 1
  %asan_local_stack_base = alloca i64, align 8
  %0 = load i8, ptr @__sancov_gen_.2136, align 1, !dbg !53678, !nosanitize !4116
  %1 = add i8 %0, 1, !dbg !53678
  store i8 %1, ptr @__sancov_gen_.2136, align 1, !dbg !53678, !nosanitize !4116
  %2 = load i32, ptr @__asan_option_detect_stack_use_after_return, align 4
  call void @__sanitizer_cov_trace_const_cmp4(i32 0, i32 %2), !dbg !53679
  %3 = icmp ne i32 %2, 0
  br i1 %3, label %6, label %start._crit_edge

start._crit_edge:                                 ; preds = %start
  %4 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2136, i64 0, i64 1), align 1, !dbg !53679, !nosanitize !4116
  %5 = add i8 %4, 1, !dbg !53679
  store i8 %5, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2136, i64 0, i64 1), align 1, !dbg !53679, !nosanitize !4116
  br label %10

6:                                                ; preds = %start
  %7 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2136, i64 0, i64 2), align 1, !dbg !53679, !nosanitize !4116
  %8 = add i8 %7, 1, !dbg !53679
  store i8 %8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2136, i64 0, i64 2), align 1, !dbg !53679, !nosanitize !4116
  %9 = call i64 @__asan_stack_malloc_1(i64 128)
  br label %10

10:                                               ; preds = %start._crit_edge, %6
  %11 = phi i64 [ 0, %start._crit_edge ], [ %9, %6 ]
  %12 = inttoptr i64 %11 to ptr
  call void @__sanitizer_cov_trace_const_cmp8(i64 0, i64 %11), !dbg !53679
  %13 = icmp eq i64 %11, 0
  br i1 %13, label %16, label %._crit_edge

._crit_edge:                                      ; preds = %10
  %14 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2136, i64 0, i64 3), align 1, !dbg !53679, !nosanitize !4116
  %15 = add i8 %14, 1, !dbg !53679
  store i8 %15, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2136, i64 0, i64 3), align 1, !dbg !53679, !nosanitize !4116
  br label %19

16:                                               ; preds = %10
  %17 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2136, i64 0, i64 4), align 1, !dbg !53679, !nosanitize !4116
  %18 = add i8 %17, 1, !dbg !53679
  store i8 %18, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2136, i64 0, i64 4), align 1, !dbg !53679, !nosanitize !4116
  %MyAlloca = alloca i8, i64 128, align 32
  br label %19

19:                                               ; preds = %._crit_edge, %16
  %20 = phi ptr [ %12, %._crit_edge ], [ %MyAlloca, %16 ]
  store ptr %20, ptr %asan_local_stack_base, align 8
  %21 = getelementptr i8, ptr %20, i64 32
  store i64 1102416563, ptr %20, align 8
  %22 = getelementptr i8, ptr %20, i64 8
  store i64 ptrtoint (ptr @___asan_gen_stack.234 to i64), ptr %22, align 8
  %23 = getelementptr i8, ptr %20, i64 16
  store i64 ptrtoint (ptr @_RNvNtCs1K0wxfkMoe8_15spiral_protocol12test_support11parse_frame to i64), ptr %23, align 8
  %24 = ptrtoint ptr %20 to i64
  %25 = lshr i64 %24, 3
  %26 = add i64 %25, 2147450880
  %27 = add i64 %26, 0
  %28 = inttoptr i64 %27 to ptr
  store i64 -506381209984437775, ptr %28, align 1
  %29 = add i64 %26, 8
  %30 = inttoptr i64 %29 to ptr
  store i64 -868082074056918792, ptr %30, align 1
  tail call void @llvm.experimental.noalias.scope.decl(metadata !53680), !dbg !53683
  call void @llvm.lifetime.start.p0(ptr nonnull %h.sroa.0.i), !dbg !53684
  call void @__sanitizer_cov_trace_const_cmp8(i64 40, i64 %data.1), !dbg !53684
  %_2.i = icmp samesign ult i64 %data.1, 40, !dbg !53684
  br i1 %_2.i, label %bb1.i, label %bb2.i, !dbg !53684

bb2.i:                                            ; preds = %19
  call void @llvm.lifetime.start.p0(ptr nonnull %_4.sroa.9.i), !dbg !53686
  %31 = add i64 %26, 4, !dbg !53686
  %32 = inttoptr i64 %31 to ptr, !dbg !53686
  store i32 0, ptr %32, align 1, !dbg !53686
  %33 = add i64 %26, 8, !dbg !53686
  %34 = inttoptr i64 %33 to ptr, !dbg !53686
  store i16 0, ptr %34, align 1, !dbg !53686
; call <spiral_protocol::wire::Header>::parse
  call void @_RNvMNtCs1K0wxfkMoe8_15spiral_protocol4wireNtB2_6Header5parse(ptr noalias nofree noundef sret([48 x i8]) align 8 captures(none) dereferenceable(48) %21, ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) %data.0, i64 noundef 40) #35, !dbg !53686, !noalias !53680
  tail call void @llvm.experimental.noalias.scope.decl(metadata !53687), !dbg !53686
  %35 = load i8, ptr %21, align 8, !dbg !53690, !range !4431, !alias.scope !53692, !noalias !53694, !noundef !4116
  %36 = trunc nuw i8 %35 to i1, !dbg !53690
  br i1 %36, label %bb2.i.i, label %bb3.i.i, !dbg !53696

bb2.i.i:                                          ; preds = %bb2.i
  %37 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2136, i64 0, i64 5), align 1, !dbg !53697, !nosanitize !4116
  %38 = add i8 %37, 1, !dbg !53697
  store i8 %38, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2136, i64 0, i64 5), align 1, !dbg !53697, !nosanitize !4116
  %39 = getelementptr inbounds nuw i8, ptr %21, i64 1, !dbg !53697
  %e.0.i.i = load i8, ptr %39, align 1, !dbg !53697, !range !19535, !alias.scope !53692, !noalias !53694, !noundef !4116
  %40 = getelementptr inbounds nuw i8, ptr %21, i64 2, !dbg !53697
  %e.1.i.i = load i8, ptr %40, align 2, !dbg !53697, !alias.scope !53692, !noalias !53694
  br label %_RNvXsp_NtCshZBO5P2NUJi_4core6resultINtB5_6ResultNtNtCs1K0wxfkMoe8_15spiral_protocol4wire6HeaderNtNtBO_5error5ErrorENtNtNtB7_3ops9try_trait3Try6branchBO_.exit.i, !dbg !53698

bb3.i.i:                                          ; preds = %bb2.i
  %41 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2136, i64 0, i64 6), align 1, !dbg !53699, !nosanitize !4116
  %42 = add i8 %41, 1, !dbg !53699
  store i8 %42, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2136, i64 0, i64 6), align 1, !dbg !53699, !nosanitize !4116
  %43 = getelementptr inbounds nuw i8, ptr %21, i64 8, !dbg !53699
  %_4.sroa.9.8..sroa_idx.i = getelementptr inbounds nuw i8, ptr %_4.sroa.9.i, i64 5, !dbg !53699
  %44 = call ptr @__asan_memcpy(ptr %_4.sroa.9.8..sroa_idx.i, ptr %43, i64 24), !dbg !53699
  %_4.sroa.11.8..sroa_idx.i = getelementptr inbounds nuw i8, ptr %21, i64 32, !dbg !53699
  %_4.sroa.11.8.copyload.i = load i64, ptr %_4.sroa.11.8..sroa_idx.i, align 8, !dbg !53699, !alias.scope !53700, !noalias !53701
  %_4.sroa.12.8..sroa_idx.i = getelementptr inbounds nuw i8, ptr %21, i64 40, !dbg !53699
  %_4.sroa.12.8.copyload.i = load i64, ptr %_4.sroa.12.8..sroa_idx.i, align 8, !dbg !53699, !alias.scope !53700, !noalias !53701
  br label %_RNvXsp_NtCshZBO5P2NUJi_4core6resultINtB5_6ResultNtNtCs1K0wxfkMoe8_15spiral_protocol4wire6HeaderNtNtBO_5error5ErrorENtNtNtB7_3ops9try_trait3Try6branchBO_.exit.i, !dbg !53702

_RNvXsp_NtCshZBO5P2NUJi_4core6resultINtB5_6ResultNtNtCs1K0wxfkMoe8_15spiral_protocol4wire6HeaderNtNtBO_5error5ErrorENtNtNtB7_3ops9try_trait3Try6branchBO_.exit.i: ; preds = %bb3.i.i, %bb2.i.i
  %_4.sroa.11.0.i = phi i64 [ undef, %bb2.i.i ], [ %_4.sroa.11.8.copyload.i, %bb3.i.i ]
  %_4.sroa.7.0.i = phi i8 [ %e.1.i.i, %bb2.i.i ], [ undef, %bb3.i.i ]
  %_4.sroa.5.0.i = phi i8 [ %e.0.i.i, %bb2.i.i ], [ undef, %bb3.i.i ]
  %_4.sroa.12.0.i = phi i64 [ undef, %bb2.i.i ], [ %_4.sroa.12.8.copyload.i, %bb3.i.i ]
  %45 = add i64 %26, 4, !dbg !53703
  %46 = inttoptr i64 %45 to ptr, !dbg !53703
  store i32 -117901064, ptr %46, align 1, !dbg !53703
  %47 = add i64 %26, 8, !dbg !53703
  %48 = inttoptr i64 %47 to ptr, !dbg !53703
  store i16 -1800, ptr %48, align 1, !dbg !53703
  br i1 %36, label %bb8.i, label %bb7.i, !dbg !53686

bb1.i:                                            ; preds = %19
  %49 = ptrtoint ptr %_0 to i64, !dbg !53704
  %50 = lshr i64 %49, 3, !dbg !53704
  %51 = add i64 %50, 2147450880, !dbg !53704
  %52 = inttoptr i64 %51 to ptr, !dbg !53704
  %53 = load i8, ptr %52, align 1, !dbg !53704
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %53), !dbg !53704
  %54 = icmp ne i8 %53, 0, !dbg !53704
  br i1 %54, label %57, label %bb1.i._crit_edge, !dbg !53704, !prof !4264

bb1.i._crit_edge:                                 ; preds = %bb1.i
  %55 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2136, i64 0, i64 7), align 1, !dbg !53704, !nosanitize !4116
  %56 = add i8 %55, 1, !dbg !53704
  store i8 %56, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2136, i64 0, i64 7), align 1, !dbg !53704, !nosanitize !4116
  br label %66, !dbg !53704

57:                                               ; preds = %bb1.i
  %58 = and i64 %49, 7, !dbg !53704
  %59 = trunc i64 %58 to i8, !dbg !53704
  call void @__sanitizer_cov_trace_cmp1(i8 %59, i8 %53), !dbg !53704
  %60 = icmp sge i8 %59, %53, !dbg !53704
  br i1 %60, label %63, label %._crit_edge1, !dbg !53704

._crit_edge1:                                     ; preds = %57
  %61 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2136, i64 0, i64 8), align 1, !dbg !53704, !nosanitize !4116
  %62 = add i8 %61, 1, !dbg !53704
  store i8 %62, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2136, i64 0, i64 8), align 1, !dbg !53704, !nosanitize !4116
  br label %66, !dbg !53704

63:                                               ; preds = %57
  %64 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2136, i64 0, i64 9), align 1, !dbg !53704, !nosanitize !4116
  %65 = add i8 %64, 1, !dbg !53704
  store i8 %65, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2136, i64 0, i64 9), align 1, !dbg !53704, !nosanitize !4116
  call void @__asan_report_store1(i64 %49) #42, !dbg !53704
  unreachable

66:                                               ; preds = %._crit_edge1, %bb1.i._crit_edge
  store i8 0, ptr %_0, align 8, !dbg !53704, !alias.scope !53680, !noalias !53705
  %67 = getelementptr inbounds nuw i8, ptr %_0, i64 40, !dbg !53704
  %68 = ptrtoint ptr %67 to i64, !dbg !53704
  %69 = lshr i64 %68, 3, !dbg !53704
  %70 = add i64 %69, 2147450880, !dbg !53704
  %71 = inttoptr i64 %70 to ptr, !dbg !53704
  %72 = load i8, ptr %71, align 1, !dbg !53704
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %72), !dbg !53704
  %73 = icmp ne i8 %72, 0, !dbg !53704
  br i1 %73, label %74, label %77, !dbg !53704

74:                                               ; preds = %66
  %75 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2136, i64 0, i64 10), align 1, !dbg !53704, !nosanitize !4116
  %76 = add i8 %75, 1, !dbg !53704
  store i8 %76, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2136, i64 0, i64 10), align 1, !dbg !53704, !nosanitize !4116
  call void @__asan_report_store8(i64 %68) #42, !dbg !53704
  unreachable, !dbg !53704

77:                                               ; preds = %66
  %78 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2136, i64 0, i64 11), align 1, !dbg !53704, !nosanitize !4116
  %79 = add i8 %78, 1, !dbg !53704
  store i8 %79, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2136, i64 0, i64 11), align 1, !dbg !53704, !nosanitize !4116
  store ptr null, ptr %67, align 8, !dbg !53704, !alias.scope !53680, !noalias !53705
  br label %_RNvNtCs1K0wxfkMoe8_15spiral_protocol4wire5parse.exit, !dbg !53706

bb8.i:                                            ; preds = %_RNvXsp_NtCshZBO5P2NUJi_4core6resultINtB5_6ResultNtNtCs1K0wxfkMoe8_15spiral_protocol4wire6HeaderNtNtBO_5error5ErrorENtNtNtB7_3ops9try_trait3Try6branchBO_.exit.i
  %80 = ptrtoint ptr %_0 to i64, !dbg !53708
  %81 = lshr i64 %80, 3, !dbg !53708
  %82 = add i64 %81, 2147450880, !dbg !53708
  %83 = inttoptr i64 %82 to ptr, !dbg !53708
  %84 = load i8, ptr %83, align 1, !dbg !53708
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %84), !dbg !53708
  %85 = icmp ne i8 %84, 0, !dbg !53708
  br i1 %85, label %88, label %bb8.i._crit_edge, !dbg !53708, !prof !4264

bb8.i._crit_edge:                                 ; preds = %bb8.i
  %86 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2136, i64 0, i64 12), align 1, !dbg !53708, !nosanitize !4116
  %87 = add i8 %86, 1, !dbg !53708
  store i8 %87, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2136, i64 0, i64 12), align 1, !dbg !53708, !nosanitize !4116
  br label %97, !dbg !53708

88:                                               ; preds = %bb8.i
  %89 = and i64 %80, 7, !dbg !53708
  %90 = trunc i64 %89 to i8, !dbg !53708
  call void @__sanitizer_cov_trace_cmp1(i8 %90, i8 %84), !dbg !53708
  %91 = icmp sge i8 %90, %84, !dbg !53708
  br i1 %91, label %94, label %._crit_edge2, !dbg !53708

._crit_edge2:                                     ; preds = %88
  %92 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2136, i64 0, i64 13), align 1, !dbg !53708, !nosanitize !4116
  %93 = add i8 %92, 1, !dbg !53708
  store i8 %93, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2136, i64 0, i64 13), align 1, !dbg !53708, !nosanitize !4116
  br label %97, !dbg !53708

94:                                               ; preds = %88
  %95 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2136, i64 0, i64 14), align 1, !dbg !53708, !nosanitize !4116
  %96 = add i8 %95, 1, !dbg !53708
  store i8 %96, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2136, i64 0, i64 14), align 1, !dbg !53708, !nosanitize !4116
  call void @__asan_report_store1(i64 %80) #42, !dbg !53708
  unreachable

97:                                               ; preds = %._crit_edge2, %bb8.i._crit_edge
  store i8 %_4.sroa.5.0.i, ptr %_0, align 8, !dbg !53708, !alias.scope !53713, !noalias !53705
  %98 = getelementptr inbounds nuw i8, ptr %_0, i64 1, !dbg !53708
  %99 = ptrtoint ptr %98 to i64, !dbg !53708
  %100 = lshr i64 %99, 3, !dbg !53708
  %101 = add i64 %100, 2147450880, !dbg !53708
  %102 = inttoptr i64 %101 to ptr, !dbg !53708
  %103 = load i8, ptr %102, align 1, !dbg !53708
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %103), !dbg !53708
  %104 = icmp ne i8 %103, 0, !dbg !53708
  br i1 %104, label %107, label %._crit_edge3, !dbg !53708, !prof !4264

._crit_edge3:                                     ; preds = %97
  %105 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2136, i64 0, i64 15), align 1, !dbg !53708, !nosanitize !4116
  %106 = add i8 %105, 1, !dbg !53708
  store i8 %106, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2136, i64 0, i64 15), align 1, !dbg !53708, !nosanitize !4116
  br label %116, !dbg !53708

107:                                              ; preds = %97
  %108 = and i64 %99, 7, !dbg !53708
  %109 = trunc i64 %108 to i8, !dbg !53708
  call void @__sanitizer_cov_trace_cmp1(i8 %109, i8 %103), !dbg !53708
  %110 = icmp sge i8 %109, %103, !dbg !53708
  br i1 %110, label %113, label %._crit_edge4, !dbg !53708

._crit_edge4:                                     ; preds = %107
  %111 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2136, i64 0, i64 16), align 1, !dbg !53708, !nosanitize !4116
  %112 = add i8 %111, 1, !dbg !53708
  store i8 %112, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2136, i64 0, i64 16), align 1, !dbg !53708, !nosanitize !4116
  br label %116, !dbg !53708

113:                                              ; preds = %107
  %114 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2136, i64 0, i64 17), align 1, !dbg !53708, !nosanitize !4116
  %115 = add i8 %114, 1, !dbg !53708
  store i8 %115, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2136, i64 0, i64 17), align 1, !dbg !53708, !nosanitize !4116
  call void @__asan_report_store1(i64 %99) #42, !dbg !53708
  unreachable

116:                                              ; preds = %._crit_edge4, %._crit_edge3
  store i8 %_4.sroa.7.0.i, ptr %98, align 1, !dbg !53708, !alias.scope !53713, !noalias !53705
  %117 = getelementptr inbounds nuw i8, ptr %_0, i64 40, !dbg !53708
  %118 = ptrtoint ptr %117 to i64, !dbg !53708
  %119 = lshr i64 %118, 3, !dbg !53708
  %120 = add i64 %119, 2147450880, !dbg !53708
  %121 = inttoptr i64 %120 to ptr, !dbg !53708
  %122 = load i8, ptr %121, align 1, !dbg !53708
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %122), !dbg !53708
  %123 = icmp ne i8 %122, 0, !dbg !53708
  br i1 %123, label %124, label %127, !dbg !53708

124:                                              ; preds = %116
  %125 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2136, i64 0, i64 18), align 1, !dbg !53708, !nosanitize !4116
  %126 = add i8 %125, 1, !dbg !53708
  store i8 %126, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2136, i64 0, i64 18), align 1, !dbg !53708, !nosanitize !4116
  call void @__asan_report_store8(i64 %118) #42, !dbg !53708
  unreachable, !dbg !53708

127:                                              ; preds = %116
  %128 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2136, i64 0, i64 19), align 1, !dbg !53708, !nosanitize !4116
  %129 = add i8 %128, 1, !dbg !53708
  store i8 %129, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2136, i64 0, i64 19), align 1, !dbg !53708, !nosanitize !4116
  store ptr null, ptr %117, align 8, !dbg !53708, !alias.scope !53713, !noalias !53705
  call void @llvm.lifetime.end.p0(ptr nonnull %_4.sroa.9.i), !dbg !53716
  br label %_RNvNtCs1K0wxfkMoe8_15spiral_protocol4wire5parse.exit, !dbg !53706

bb7.i:                                            ; preds = %_RNvXsp_NtCshZBO5P2NUJi_4core6resultINtB5_6ResultNtNtCs1K0wxfkMoe8_15spiral_protocol4wire6HeaderNtNtBO_5error5ErrorENtNtNtB7_3ops9try_trait3Try6branchBO_.exit.i
  %_4.sroa.9.8..sroa_idx4.i = getelementptr inbounds nuw i8, ptr %_4.sroa.9.i, i64 5, !dbg !53686
  %130 = call ptr @__asan_memcpy(ptr %h.sroa.0.i, ptr %_4.sroa.9.8..sroa_idx4.i, i64 24), !dbg !53686
  call void @llvm.lifetime.end.p0(ptr nonnull %_4.sroa.9.i), !dbg !53716
  call void @__sanitizer_cov_trace_const_cmp8(i64 -41, i64 %_4.sroa.11.0.i), !dbg !53717
  %_13.1.i = icmp ugt i64 %_4.sroa.11.0.i, -41, !dbg !53717
  br i1 %_13.1.i, label %panic.i, label %bb10.i, !dbg !53717

bb10.i:                                           ; preds = %bb7.i
  %_13.0.i = add nuw i64 %_4.sroa.11.0.i, 40, !dbg !53717
  call void @__sanitizer_cov_trace_cmp8(i64 %data.1, i64 %_13.0.i), !dbg !53718
  %_10.not.i = icmp eq i64 %data.1, %_13.0.i, !dbg !53718
  br i1 %_10.not.i, label %bb12.i, label %bb11.i, !dbg !53718

panic.i:                                          ; preds = %bb7.i
  %131 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2136, i64 0, i64 20), align 1, !dbg !53717, !nosanitize !4116
  %132 = add i8 %131, 1, !dbg !53717
  store i8 %132, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2136, i64 0, i64 20), align 1, !dbg !53717, !nosanitize !4116
  call void @__asan_handle_no_return(), !dbg !53717
; call core::panicking::panic_const::panic_const_add_overflow
  tail call void @_RNvNtNtCshZBO5P2NUJi_4core9panicking11panic_const24panic_const_add_overflow(ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_8261cc9843ad33371a73da063aa10507) #43, !dbg !53717, !noalias !53701
  unreachable, !dbg !53717

bb12.i:                                           ; preds = %bb10.i
  %new_len.i.i = add nsw i64 %data.1, -40, !dbg !53719
  %_11.i.i = getelementptr inbounds nuw i8, ptr %data.0, i64 40, !dbg !53724
  %133 = call ptr @__asan_memcpy(ptr %_0, ptr %h.sroa.0.i, i64 24), !dbg !53729
  %_14.sroa.4.0._0.sroa_idx.i = getelementptr inbounds nuw i8, ptr %_0, i64 24, !dbg !53730
  %134 = ptrtoint ptr %_14.sroa.4.0._0.sroa_idx.i to i64, !dbg !53730
  %135 = lshr i64 %134, 3, !dbg !53730
  %136 = add i64 %135, 2147450880, !dbg !53730
  %137 = inttoptr i64 %136 to ptr, !dbg !53730
  %138 = load i8, ptr %137, align 1, !dbg !53730
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %138), !dbg !53730
  %139 = icmp ne i8 %138, 0, !dbg !53730
  br i1 %139, label %140, label %143, !dbg !53730

140:                                              ; preds = %bb12.i
  %141 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2136, i64 0, i64 21), align 1, !dbg !53730, !nosanitize !4116
  %142 = add i8 %141, 1, !dbg !53730
  store i8 %142, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2136, i64 0, i64 21), align 1, !dbg !53730, !nosanitize !4116
  call void @__asan_report_store8(i64 %134) #42, !dbg !53730
  unreachable, !dbg !53730

143:                                              ; preds = %bb12.i
  store i64 %_4.sroa.11.0.i, ptr %_14.sroa.4.0._0.sroa_idx.i, align 8, !dbg !53730, !alias.scope !53680, !noalias !53705
  %_14.sroa.5.0._0.sroa_idx.i = getelementptr inbounds nuw i8, ptr %_0, i64 32, !dbg !53730
  %144 = ptrtoint ptr %_14.sroa.5.0._0.sroa_idx.i to i64, !dbg !53730
  %145 = lshr i64 %144, 3, !dbg !53730
  %146 = add i64 %145, 2147450880, !dbg !53730
  %147 = inttoptr i64 %146 to ptr, !dbg !53730
  %148 = load i8, ptr %147, align 1, !dbg !53730
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %148), !dbg !53730
  %149 = icmp ne i8 %148, 0, !dbg !53730
  br i1 %149, label %150, label %153, !dbg !53730

150:                                              ; preds = %143
  %151 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2136, i64 0, i64 22), align 1, !dbg !53730, !nosanitize !4116
  %152 = add i8 %151, 1, !dbg !53730
  store i8 %152, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2136, i64 0, i64 22), align 1, !dbg !53730, !nosanitize !4116
  call void @__asan_report_store8(i64 %144) #42, !dbg !53730
  unreachable, !dbg !53730

153:                                              ; preds = %143
  store i64 %_4.sroa.12.0.i, ptr %_14.sroa.5.0._0.sroa_idx.i, align 8, !dbg !53730, !alias.scope !53680, !noalias !53705
  %_14.sroa.6.0._0.sroa_idx.i = getelementptr inbounds nuw i8, ptr %_0, i64 40, !dbg !53730
  %154 = ptrtoint ptr %_14.sroa.6.0._0.sroa_idx.i to i64, !dbg !53730
  %155 = lshr i64 %154, 3, !dbg !53730
  %156 = add i64 %155, 2147450880, !dbg !53730
  %157 = inttoptr i64 %156 to ptr, !dbg !53730
  %158 = load i8, ptr %157, align 1, !dbg !53730
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %158), !dbg !53730
  %159 = icmp ne i8 %158, 0, !dbg !53730
  br i1 %159, label %160, label %163, !dbg !53730

160:                                              ; preds = %153
  %161 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2136, i64 0, i64 23), align 1, !dbg !53730, !nosanitize !4116
  %162 = add i8 %161, 1, !dbg !53730
  store i8 %162, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2136, i64 0, i64 23), align 1, !dbg !53730, !nosanitize !4116
  call void @__asan_report_store8(i64 %154) #42, !dbg !53730
  unreachable, !dbg !53730

163:                                              ; preds = %153
  store ptr %_11.i.i, ptr %_14.sroa.6.0._0.sroa_idx.i, align 8, !dbg !53730, !alias.scope !53680, !noalias !53705
  %_14.sroa.7.0._0.sroa_idx.i = getelementptr inbounds nuw i8, ptr %_0, i64 48, !dbg !53730
  %164 = ptrtoint ptr %_14.sroa.7.0._0.sroa_idx.i to i64, !dbg !53730
  %165 = lshr i64 %164, 3, !dbg !53730
  %166 = add i64 %165, 2147450880, !dbg !53730
  %167 = inttoptr i64 %166 to ptr, !dbg !53730
  %168 = load i8, ptr %167, align 1, !dbg !53730
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %168), !dbg !53730
  %169 = icmp ne i8 %168, 0, !dbg !53730
  br i1 %169, label %170, label %173, !dbg !53730

170:                                              ; preds = %163
  %171 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2136, i64 0, i64 24), align 1, !dbg !53730, !nosanitize !4116
  %172 = add i8 %171, 1, !dbg !53730
  store i8 %172, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2136, i64 0, i64 24), align 1, !dbg !53730, !nosanitize !4116
  call void @__asan_report_store8(i64 %164) #42, !dbg !53730
  unreachable, !dbg !53730

173:                                              ; preds = %163
  %174 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2136, i64 0, i64 25), align 1, !dbg !53730, !nosanitize !4116
  %175 = add i8 %174, 1, !dbg !53730
  store i8 %175, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2136, i64 0, i64 25), align 1, !dbg !53730, !nosanitize !4116
  store i64 %new_len.i.i, ptr %_14.sroa.7.0._0.sroa_idx.i, align 8, !dbg !53730, !alias.scope !53680, !noalias !53705
  br label %_RNvNtCs1K0wxfkMoe8_15spiral_protocol4wire5parse.exit, !dbg !53731

bb11.i:                                           ; preds = %bb10.i
  %176 = ptrtoint ptr %_0 to i64, !dbg !53732
  %177 = lshr i64 %176, 3, !dbg !53732
  %178 = add i64 %177, 2147450880, !dbg !53732
  %179 = inttoptr i64 %178 to ptr, !dbg !53732
  %180 = load i8, ptr %179, align 1, !dbg !53732
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %180), !dbg !53732
  %181 = icmp ne i8 %180, 0, !dbg !53732
  br i1 %181, label %184, label %bb11.i._crit_edge, !dbg !53732, !prof !4264

bb11.i._crit_edge:                                ; preds = %bb11.i
  %182 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2136, i64 0, i64 26), align 1, !dbg !53732, !nosanitize !4116
  %183 = add i8 %182, 1, !dbg !53732
  store i8 %183, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2136, i64 0, i64 26), align 1, !dbg !53732, !nosanitize !4116
  br label %193, !dbg !53732

184:                                              ; preds = %bb11.i
  %185 = and i64 %176, 7, !dbg !53732
  %186 = trunc i64 %185 to i8, !dbg !53732
  call void @__sanitizer_cov_trace_cmp1(i8 %186, i8 %180), !dbg !53732
  %187 = icmp sge i8 %186, %180, !dbg !53732
  br i1 %187, label %190, label %._crit_edge5, !dbg !53732

._crit_edge5:                                     ; preds = %184
  %188 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2136, i64 0, i64 27), align 1, !dbg !53732, !nosanitize !4116
  %189 = add i8 %188, 1, !dbg !53732
  store i8 %189, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2136, i64 0, i64 27), align 1, !dbg !53732, !nosanitize !4116
  br label %193, !dbg !53732

190:                                              ; preds = %184
  %191 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2136, i64 0, i64 28), align 1, !dbg !53732, !nosanitize !4116
  %192 = add i8 %191, 1, !dbg !53732
  store i8 %192, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2136, i64 0, i64 28), align 1, !dbg !53732, !nosanitize !4116
  call void @__asan_report_store1(i64 %176) #42, !dbg !53732
  unreachable

193:                                              ; preds = %._crit_edge5, %bb11.i._crit_edge
  store i8 0, ptr %_0, align 8, !dbg !53732, !alias.scope !53680, !noalias !53705
  %194 = getelementptr inbounds nuw i8, ptr %_0, i64 40, !dbg !53732
  %195 = ptrtoint ptr %194 to i64, !dbg !53732
  %196 = lshr i64 %195, 3, !dbg !53732
  %197 = add i64 %196, 2147450880, !dbg !53732
  %198 = inttoptr i64 %197 to ptr, !dbg !53732
  %199 = load i8, ptr %198, align 1, !dbg !53732
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %199), !dbg !53732
  %200 = icmp ne i8 %199, 0, !dbg !53732
  br i1 %200, label %201, label %204, !dbg !53732

201:                                              ; preds = %193
  %202 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2136, i64 0, i64 29), align 1, !dbg !53732, !nosanitize !4116
  %203 = add i8 %202, 1, !dbg !53732
  store i8 %203, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2136, i64 0, i64 29), align 1, !dbg !53732, !nosanitize !4116
  call void @__asan_report_store8(i64 %195) #42, !dbg !53732
  unreachable, !dbg !53732

204:                                              ; preds = %193
  %205 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2136, i64 0, i64 30), align 1, !dbg !53732, !nosanitize !4116
  %206 = add i8 %205, 1, !dbg !53732
  store i8 %206, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2136, i64 0, i64 30), align 1, !dbg !53732, !nosanitize !4116
  store ptr null, ptr %194, align 8, !dbg !53732, !alias.scope !53680, !noalias !53705
  br label %_RNvNtCs1K0wxfkMoe8_15spiral_protocol4wire5parse.exit, !dbg !53733

_RNvNtCs1K0wxfkMoe8_15spiral_protocol4wire5parse.exit: ; preds = %77, %127, %173, %204
  call void @llvm.lifetime.end.p0(ptr nonnull %h.sroa.0.i), !dbg !53731
  store i64 1172321806, ptr %20, align 8, !dbg !53735
  call void @__sanitizer_cov_trace_const_cmp8(i64 0, i64 %11), !dbg !53735
  %207 = icmp ne i64 %11, 0, !dbg !53735
  br i1 %207, label %208, label %218, !dbg !53735

208:                                              ; preds = %_RNvNtCs1K0wxfkMoe8_15spiral_protocol4wire5parse.exit
  %209 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2136, i64 0, i64 31), align 1, !dbg !53735, !nosanitize !4116
  %210 = add i8 %209, 1, !dbg !53735
  store i8 %210, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2136, i64 0, i64 31), align 1, !dbg !53735, !nosanitize !4116
  %211 = add i64 %26, 0, !dbg !53735
  %212 = inttoptr i64 %211 to ptr, !dbg !53735
  store i64 -723401728380766731, ptr %212, align 1, !dbg !53735
  %213 = add i64 %26, 8, !dbg !53735
  %214 = inttoptr i64 %213 to ptr, !dbg !53735
  store i64 -723401728380766731, ptr %214, align 1, !dbg !53735
  %215 = getelementptr i8, ptr %12, i64 120, !dbg !53735
  %216 = load i64, ptr %215, align 8, !dbg !53735
  %217 = inttoptr i64 %216 to ptr, !dbg !53735
  store i8 0, ptr %217, align 1, !dbg !53735
  br label %225, !dbg !53735

218:                                              ; preds = %_RNvNtCs1K0wxfkMoe8_15spiral_protocol4wire5parse.exit
  %219 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2136, i64 0, i64 32), align 1, !dbg !53735, !nosanitize !4116
  %220 = add i8 %219, 1, !dbg !53735
  store i8 %220, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2136, i64 0, i64 32), align 1, !dbg !53735, !nosanitize !4116
  %221 = add i64 %26, 0, !dbg !53735
  %222 = inttoptr i64 %221 to ptr, !dbg !53735
  store i64 0, ptr %222, align 1, !dbg !53735
  %223 = add i64 %26, 8, !dbg !53735
  %224 = inttoptr i64 %223 to ptr, !dbg !53735
  store i64 0, ptr %224, align 1, !dbg !53735
  br label %225, !dbg !53735

225:                                              ; preds = %218, %208
  ret void, !dbg !53735
}

; Verified production function: parse_client_hello
define void @_RNvNtCs1K0wxfkMoe8_15spiral_protocol12test_support18parse_client_hello(ptr dead_on_unwind noalias nofree noundef writable writeonly sret([32 x i8]) align 8 captures(none) dereferenceable(32) %_0, ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) %data.0, i64 noundef range(i64 0, -9223372036854775808) %data.1) unnamed_addr #12 comdat !dbg !53736 !guid !53737 {
start:
  %0 = load i8, ptr @__sancov_gen_.2138, align 1, !dbg !53738, !nosanitize !4116
  %1 = add i8 %0, 1, !dbg !53738
  store i8 %1, ptr @__sancov_gen_.2138, align 1, !dbg !53738, !nosanitize !4116
; call spiral_protocol::handshake::parse_hello
  tail call void @_RNvNtCs1K0wxfkMoe8_15spiral_protocol9handshake11parse_hello(ptr noalias nofree noundef sret([32 x i8]) align 8 captures(address) dereferenceable(32) %_0, ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) %data.0, i64 noundef %data.1) #35, !dbg !53739
  ret void, !dbg !53740
}

; Verified production function: parse_hello
define void @_RNvNtCs1K0wxfkMoe8_15spiral_protocol9handshake11parse_hello(ptr dead_on_unwind noalias nofree noundef writable writeonly sret([32 x i8]) align 8 captures(none) dereferenceable(32) %_0, ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) %p.0, i64 noundef range(i64 0, -9223372036854775808) %p.1) unnamed_addr #0 comdat !dbg !54877 !guid !54878 {
start:
  %asan_local_stack_base = alloca i64, align 8
  %0 = load i8, ptr @__sancov_gen_.2156, align 1, !dbg !54879, !nosanitize !4116
  %1 = add i8 %0, 1, !dbg !54879
  store i8 %1, ptr @__sancov_gen_.2156, align 1, !dbg !54879, !nosanitize !4116
  %2 = load i32, ptr @__asan_option_detect_stack_use_after_return, align 4
  call void @__sanitizer_cov_trace_const_cmp4(i32 0, i32 %2), !dbg !54880
  %3 = icmp ne i32 %2, 0
  br i1 %3, label %6, label %start._crit_edge

start._crit_edge:                                 ; preds = %start
  %4 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 1), align 1, !dbg !54880, !nosanitize !4116
  %5 = add i8 %4, 1, !dbg !54880
  store i8 %5, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 1), align 1, !dbg !54880, !nosanitize !4116
  br label %10

6:                                                ; preds = %start
  %7 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 2), align 1, !dbg !54880, !nosanitize !4116
  %8 = add i8 %7, 1, !dbg !54880
  store i8 %8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 2), align 1, !dbg !54880, !nosanitize !4116
  %9 = call i64 @__asan_stack_malloc_2(i64 160)
  br label %10

10:                                               ; preds = %start._crit_edge, %6
  %11 = phi i64 [ 0, %start._crit_edge ], [ %9, %6 ]
  %12 = inttoptr i64 %11 to ptr
  call void @__sanitizer_cov_trace_const_cmp8(i64 0, i64 %11), !dbg !54880
  %13 = icmp eq i64 %11, 0
  br i1 %13, label %16, label %._crit_edge

._crit_edge:                                      ; preds = %10
  %14 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 3), align 1, !dbg !54880, !nosanitize !4116
  %15 = add i8 %14, 1, !dbg !54880
  store i8 %15, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 3), align 1, !dbg !54880, !nosanitize !4116
  br label %19

16:                                               ; preds = %10
  %17 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 4), align 1, !dbg !54880, !nosanitize !4116
  %18 = add i8 %17, 1, !dbg !54880
  store i8 %18, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 4), align 1, !dbg !54880, !nosanitize !4116
  %MyAlloca = alloca i8, i64 160, align 32
  br label %19

19:                                               ; preds = %._crit_edge, %16
  %20 = phi ptr [ %12, %._crit_edge ], [ %MyAlloca, %16 ]
  store ptr %20, ptr %asan_local_stack_base, align 8
  %21 = getelementptr i8, ptr %20, i64 32
  %22 = getelementptr i8, ptr %20, i64 96
  store i64 1102416563, ptr %20, align 8
  %23 = getelementptr i8, ptr %20, i64 8
  store i64 ptrtoint (ptr @___asan_gen_stack.243 to i64), ptr %23, align 8
  %24 = getelementptr i8, ptr %20, i64 16
  store i64 ptrtoint (ptr @_RNvNtCs1K0wxfkMoe8_15spiral_protocol9handshake11parse_hello to i64), ptr %24, align 8
  %25 = ptrtoint ptr %20 to i64
  %26 = lshr i64 %25, 3
  %27 = add i64 %26, 2147450880
  %28 = add i64 %27, 0
  %29 = inttoptr i64 %28 to ptr
  store i64 -938726774212005391, ptr %29, align 1
  %30 = add i64 %27, 8
  %31 = inttoptr i64 %30 to ptr
  store i64 -866669180157234446, ptr %31, align 1
  %32 = add i64 %27, 16
  %33 = inttoptr i64 %32 to ptr
  store i32 -202116109, ptr %33, align 1
  %34 = add nsw i64 %p.1, -75, !dbg !54881
  call void @__sanitizer_cov_trace_const_cmp8(i64 344, i64 %34), !dbg !54881
  %spec.select = icmp ult i64 %34, 344, !dbg !54881
  br i1 %spec.select, label %bb5.i, label %bb3, !dbg !54884

bb3:                                              ; preds = %19
  %35 = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !54885
  %36 = ptrtoint ptr %35 to i64, !dbg !54885
  %37 = lshr i64 %36, 3, !dbg !54885
  %38 = add i64 %37, 2147450880, !dbg !54885
  %39 = inttoptr i64 %38 to ptr, !dbg !54885
  %40 = load i8, ptr %39, align 1, !dbg !54885
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %40), !dbg !54885
  %41 = icmp ne i8 %40, 0, !dbg !54885
  br i1 %41, label %44, label %bb3._crit_edge, !dbg !54885, !prof !4264

bb3._crit_edge:                                   ; preds = %bb3
  %42 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 5), align 1, !dbg !54885, !nosanitize !4116
  %43 = add i8 %42, 1, !dbg !54885
  store i8 %43, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 5), align 1, !dbg !54885, !nosanitize !4116
  br label %53, !dbg !54885

44:                                               ; preds = %bb3
  %45 = and i64 %36, 7, !dbg !54885
  %46 = trunc i64 %45 to i8, !dbg !54885
  call void @__sanitizer_cov_trace_cmp1(i8 %46, i8 %40), !dbg !54885
  %47 = icmp sge i8 %46, %40, !dbg !54885
  br i1 %47, label %50, label %._crit_edge435, !dbg !54885

._crit_edge435:                                   ; preds = %44
  %48 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 6), align 1, !dbg !54885, !nosanitize !4116
  %49 = add i8 %48, 1, !dbg !54885
  store i8 %49, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 6), align 1, !dbg !54885, !nosanitize !4116
  br label %53, !dbg !54885

50:                                               ; preds = %44
  %51 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 7), align 1, !dbg !54885, !nosanitize !4116
  %52 = add i8 %51, 1, !dbg !54885
  store i8 %52, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 7), align 1, !dbg !54885, !nosanitize !4116
  call void @__asan_report_store1(i64 %36) #42, !dbg !54885
  unreachable

53:                                               ; preds = %._crit_edge435, %bb3._crit_edge
  store i8 0, ptr %35, align 8, !dbg !54885
  %54 = ptrtoint ptr %_0 to i64, !dbg !54885
  %55 = lshr i64 %54, 3, !dbg !54885
  %56 = add i64 %55, 2147450880, !dbg !54885
  %57 = inttoptr i64 %56 to ptr, !dbg !54885
  %58 = load i8, ptr %57, align 1, !dbg !54885
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %58), !dbg !54885
  %59 = icmp ne i8 %58, 0, !dbg !54885
  br i1 %59, label %60, label %63, !dbg !54885

60:                                               ; preds = %53
  %61 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 8), align 1, !dbg !54885, !nosanitize !4116
  %62 = add i8 %61, 1, !dbg !54885
  store i8 %62, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 8), align 1, !dbg !54885, !nosanitize !4116
  call void @__asan_report_store8(i64 %54) #42, !dbg !54885
  unreachable, !dbg !54885

63:                                               ; preds = %53
  %64 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 9), align 1, !dbg !54885, !nosanitize !4116
  %65 = add i8 %64, 1, !dbg !54885
  store i8 %65, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 9), align 1, !dbg !54885, !nosanitize !4116
  store ptr null, ptr %_0, align 8, !dbg !54885
  br label %bb89, !dbg !54886

bb89:                                             ; preds = %804, %667, %636, %459, %241, %536, %603, %341, %408, %709, %63
  store i64 1172321806, ptr %20, align 8, !dbg !54888
  call void @__sanitizer_cov_trace_const_cmp8(i64 0, i64 %11), !dbg !54888
  %66 = icmp ne i64 %11, 0, !dbg !54888
  br i1 %66, label %67, label %81, !dbg !54888

67:                                               ; preds = %bb89
  %68 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 10), align 1, !dbg !54888, !nosanitize !4116
  %69 = add i8 %68, 1, !dbg !54888
  store i8 %69, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 10), align 1, !dbg !54888, !nosanitize !4116
  %70 = add i64 %27, 0, !dbg !54888
  %71 = inttoptr i64 %70 to ptr, !dbg !54888
  store i64 -723401728380766731, ptr %71, align 1, !dbg !54888
  %72 = add i64 %27, 8, !dbg !54888
  %73 = inttoptr i64 %72 to ptr, !dbg !54888
  store i64 -723401728380766731, ptr %73, align 1, !dbg !54888
  %74 = add i64 %27, 16, !dbg !54888
  %75 = inttoptr i64 %74 to ptr, !dbg !54888
  store i64 -723401728380766731, ptr %75, align 1, !dbg !54888
  %76 = add i64 %27, 24, !dbg !54888
  %77 = inttoptr i64 %76 to ptr, !dbg !54888
  store i64 -723401728380766731, ptr %77, align 1, !dbg !54888
  %78 = getelementptr i8, ptr %12, i64 248, !dbg !54888
  %79 = load i64, ptr %78, align 8, !dbg !54888
  %80 = inttoptr i64 %79 to ptr, !dbg !54888
  store i8 0, ptr %80, align 1, !dbg !54888
  br label %90, !dbg !54888

81:                                               ; preds = %bb89
  %82 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 11), align 1, !dbg !54888, !nosanitize !4116
  %83 = add i8 %82, 1, !dbg !54888
  store i8 %83, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 11), align 1, !dbg !54888, !nosanitize !4116
  %84 = add i64 %27, 0, !dbg !54888
  %85 = inttoptr i64 %84 to ptr, !dbg !54888
  store i64 0, ptr %85, align 1, !dbg !54888
  %86 = add i64 %27, 8, !dbg !54888
  %87 = inttoptr i64 %86 to ptr, !dbg !54888
  store i64 0, ptr %87, align 1, !dbg !54888
  %88 = add i64 %27, 16, !dbg !54888
  %89 = inttoptr i64 %88 to ptr, !dbg !54888
  store i32 0, ptr %89, align 1, !dbg !54888
  br label %90, !dbg !54888

90:                                               ; preds = %81, %67
  ret void, !dbg !54888

bb5:                                              ; preds = %bb23
  %_4.0.i.i.1 = add i64 %i.sroa.0.7, 1, !dbg !54889
  call void @__sanitizer_cov_trace_const_cmp8(i64 -1, i64 %i.sroa.0.7), !dbg !54889
  %_4.1.i.not.i.1 = icmp eq i64 %i.sroa.0.7, -1, !dbg !54889
  br i1 %_4.1.i.not.i.1, label %bb5._RNvNvNtCs1K0wxfkMoe8_15spiral_protocol9handshake11parse_hello4take.exit.1_crit_edge, label %bb5.i.1, !dbg !54898

bb5._RNvNvNtCs1K0wxfkMoe8_15spiral_protocol9handshake11parse_hello4take.exit.1_crit_edge: ; preds = %bb5
  %91 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 12), align 1, !dbg !54898, !nosanitize !4116
  %92 = add i8 %91, 1, !dbg !54898
  store i8 %92, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 12), align 1, !dbg !54898, !nosanitize !4116
  br label %_RNvNvNtCs1K0wxfkMoe8_15spiral_protocol9handshake11parse_hello4take.exit.1, !dbg !54898

bb5.i.1:                                          ; preds = %bb5
  call void @__sanitizer_cov_trace_cmp8(i64 %_4.0.i.i.1, i64 %p.1), !dbg !54880
  %_7.not.i.i.i.not.1 = icmp ugt i64 %_4.0.i.i.1, %p.1
  br i1 %_7.not.i.i.i.not.1, label %bb5.i.1._RNvNvNtCs1K0wxfkMoe8_15spiral_protocol9handshake11parse_hello4take.exit.1_crit_edge, label %bb11.i.1, !dbg !54899

bb5.i.1._RNvNvNtCs1K0wxfkMoe8_15spiral_protocol9handshake11parse_hello4take.exit.1_crit_edge: ; preds = %bb5.i.1
  %93 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 13), align 1, !dbg !54899, !nosanitize !4116
  %94 = add i8 %93, 1, !dbg !54899
  store i8 %94, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 13), align 1, !dbg !54899, !nosanitize !4116
  br label %_RNvNvNtCs1K0wxfkMoe8_15spiral_protocol9handshake11parse_hello4take.exit.1, !dbg !54899

bb11.i.1:                                         ; preds = %bb5.i.1
  %95 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 14), align 1, !dbg !54901, !nosanitize !4116
  %96 = add i8 %95, 1, !dbg !54901
  store i8 %96, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 14), align 1, !dbg !54901, !nosanitize !4116
  %_15.i.i.i.1 = getelementptr inbounds nuw i8, ptr %p.0, i64 %i.sroa.0.7, !dbg !54901
  br label %_RNvNvNtCs1K0wxfkMoe8_15spiral_protocol9handshake11parse_hello4take.exit.1, !dbg !54908

_RNvNvNtCs1K0wxfkMoe8_15spiral_protocol9handshake11parse_hello4take.exit.1: ; preds = %bb5.i.1._RNvNvNtCs1K0wxfkMoe8_15spiral_protocol9handshake11parse_hello4take.exit.1_crit_edge, %bb5._RNvNvNtCs1K0wxfkMoe8_15spiral_protocol9handshake11parse_hello4take.exit.1_crit_edge, %bb11.i.1
  %_22.not.1 = phi i1 [ true, %bb5.i.1._RNvNvNtCs1K0wxfkMoe8_15spiral_protocol9handshake11parse_hello4take.exit.1_crit_edge ], [ false, %bb11.i.1 ], [ true, %bb5._RNvNvNtCs1K0wxfkMoe8_15spiral_protocol9handshake11parse_hello4take.exit.1_crit_edge ], !dbg !54909
  %_16.sroa.6.1.1 = phi i64 [ 0, %bb5.i.1._RNvNvNtCs1K0wxfkMoe8_15spiral_protocol9handshake11parse_hello4take.exit.1_crit_edge ], [ 1, %bb11.i.1 ], [ 0, %bb5._RNvNvNtCs1K0wxfkMoe8_15spiral_protocol9handshake11parse_hello4take.exit.1_crit_edge ], !dbg !54909
  %_16.sroa.0.0.1 = phi ptr [ null, %bb5.i.1._RNvNvNtCs1K0wxfkMoe8_15spiral_protocol9handshake11parse_hello4take.exit.1_crit_edge ], [ %_15.i.i.i.1, %bb11.i.1 ], [ null, %bb5._RNvNvNtCs1K0wxfkMoe8_15spiral_protocol9handshake11parse_hello4take.exit.1_crit_edge ], !dbg !54909
  %i.sroa.0.2.1 = phi i64 [ %i.sroa.0.7, %bb5.i.1._RNvNvNtCs1K0wxfkMoe8_15spiral_protocol9handshake11parse_hello4take.exit.1_crit_edge ], [ %_4.0.i.i.1, %bb11.i.1 ], [ -1, %bb5._RNvNvNtCs1K0wxfkMoe8_15spiral_protocol9handshake11parse_hello4take.exit.1_crit_edge ], !dbg !54880
  %97 = icmp eq ptr %_16.sroa.0.0.1, null, !dbg !54910
  br i1 %97, label %_RNvNvNtCs1K0wxfkMoe8_15spiral_protocol9handshake11parse_hello4take.exit.1.bb13_crit_edge, label %bb12.1, !dbg !54910

_RNvNvNtCs1K0wxfkMoe8_15spiral_protocol9handshake11parse_hello4take.exit.1.bb13_crit_edge: ; preds = %_RNvNvNtCs1K0wxfkMoe8_15spiral_protocol9handshake11parse_hello4take.exit.1
  %98 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 15), align 1, !dbg !54910, !nosanitize !4116
  %99 = add i8 %98, 1, !dbg !54910
  store i8 %99, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 15), align 1, !dbg !54910, !nosanitize !4116
  br label %bb13, !dbg !54910

bb12.1:                                           ; preds = %_RNvNvNtCs1K0wxfkMoe8_15spiral_protocol9handshake11parse_hello4take.exit.1
  br i1 %_22.not.1, label %bb12.1.panic24_crit_edge, label %bb15.1, !dbg !54910

bb12.1.panic24_crit_edge:                         ; preds = %bb12.1
  %100 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 16), align 1, !dbg !54910, !nosanitize !4116
  %101 = add i8 %100, 1, !dbg !54910
  store i8 %101, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 16), align 1, !dbg !54910, !nosanitize !4116
  br label %panic24, !dbg !54910

bb15.1:                                           ; preds = %bb12.1
  %102 = ptrtoint ptr %_16.sroa.0.0.1 to i64, !dbg !54910
  %103 = lshr i64 %102, 3, !dbg !54910
  %104 = add i64 %103, 2147450880, !dbg !54910
  %105 = inttoptr i64 %104 to ptr, !dbg !54910
  %106 = load i8, ptr %105, align 1, !dbg !54910
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %106), !dbg !54910
  %107 = icmp ne i8 %106, 0, !dbg !54910
  br i1 %107, label %110, label %bb15.1._crit_edge, !dbg !54910, !prof !4264

bb15.1._crit_edge:                                ; preds = %bb15.1
  %108 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 17), align 1, !dbg !54910, !nosanitize !4116
  %109 = add i8 %108, 1, !dbg !54910
  store i8 %109, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 17), align 1, !dbg !54910, !nosanitize !4116
  br label %119, !dbg !54910

110:                                              ; preds = %bb15.1
  %111 = and i64 %102, 7, !dbg !54910
  %112 = trunc i64 %111 to i8, !dbg !54910
  call void @__sanitizer_cov_trace_cmp1(i8 %112, i8 %106), !dbg !54910
  %113 = icmp sge i8 %112, %106, !dbg !54910
  br i1 %113, label %116, label %._crit_edge436, !dbg !54910

._crit_edge436:                                   ; preds = %110
  %114 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 18), align 1, !dbg !54910, !nosanitize !4116
  %115 = add i8 %114, 1, !dbg !54910
  store i8 %115, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 18), align 1, !dbg !54910, !nosanitize !4116
  br label %119, !dbg !54910

116:                                              ; preds = %110
  %117 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 19), align 1, !dbg !54910, !nosanitize !4116
  %118 = add i8 %117, 1, !dbg !54910
  store i8 %118, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 19), align 1, !dbg !54910, !nosanitize !4116
  call void @__asan_report_load1(i64 %102) #42, !dbg !54910
  unreachable

119:                                              ; preds = %._crit_edge436, %bb15.1._crit_edge
  %_14.1 = load i8, ptr %_16.sroa.0.0.1, align 1, !dbg !54910, !noundef !4116
  %120 = zext i8 %_14.1 to i64, !dbg !54910
  %121 = add i8 %_14.1, -1, !dbg !54911
  call void @__sanitizer_cov_trace_const_cmp1(i8 8, i8 %121), !dbg !54911
  %spec.select237.1 = icmp ult i8 %121, 8, !dbg !54911
  br i1 %spec.select237.1, label %bb20.preheader.1, label %.bb18_crit_edge, !dbg !54915

.bb18_crit_edge:                                  ; preds = %119
  %122 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 20), align 1, !dbg !54915, !nosanitize !4116
  %123 = add i8 %122, 1, !dbg !54915
  store i8 %123, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 20), align 1, !dbg !54915, !nosanitize !4116
  br label %bb18, !dbg !54915

bb20.preheader.1:                                 ; preds = %119
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %_14.1), !dbg !54916
  %_0.i.i.i162287.not.1 = icmp eq i8 %_14.1, 0, !dbg !54916
  br i1 %_0.i.i.i162287.not.1, label %bb20.preheader.1.bb35_crit_edge, label %bb20.preheader.1.bb22.1_crit_edge, !dbg !54923

bb20.preheader.1.bb22.1_crit_edge:                ; preds = %bb20.preheader.1
  br label %bb22.1, !dbg !54923

bb20.preheader.1.bb35_crit_edge:                  ; preds = %bb20.preheader.1
  %124 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 21), align 1, !dbg !54923, !nosanitize !4116
  %125 = add i8 %124, 1, !dbg !54923
  store i8 %125, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 21), align 1, !dbg !54923, !nosanitize !4116
  br label %bb35, !dbg !54923

bb22.1:                                           ; preds = %bb33.1.bb22.1_crit_edge, %bb20.preheader.1.bb22.1_crit_edge
  %spec.select238294.1 = phi i64 [ %spec.select238.1, %bb33.1.bb22.1_crit_edge ], [ 1, %bb20.preheader.1.bb22.1_crit_edge ]
  %found.sroa.0.0293.1 = phi i1 [ %181, %bb33.1.bb22.1_crit_edge ], [ false, %bb20.preheader.1.bb22.1_crit_edge ]
  %last.sroa.0.0292.1 = phi i16 [ %178, %bb33.1.bb22.1_crit_edge ], [ 0, %bb20.preheader.1.bb22.1_crit_edge ]
  %i.sroa.0.1291.1 = phi i64 [ %i.sroa.0.7.1, %bb33.1.bb22.1_crit_edge ], [ %i.sroa.0.2.1, %bb20.preheader.1.bb22.1_crit_edge ]
  %_37.sroa.6.1289.1 = phi i64 [ %_37.sroa.6.2.1, %bb33.1.bb22.1_crit_edge ], [ %_37.sroa.6.2, %bb20.preheader.1.bb22.1_crit_edge ]
  %_4.0.i.i165.1 = add i64 %i.sroa.0.1291.1, 2, !dbg !54924
  call void @__sanitizer_cov_trace_const_cmp8(i64 -3, i64 %i.sroa.0.1291.1), !dbg !54924
  %_4.1.i.not.i166.1 = icmp ugt i64 %i.sroa.0.1291.1, -3, !dbg !54924
  br i1 %_4.1.i.not.i166.1, label %bb6.i176.1, label %bb5.i167.1, !dbg !54927

bb5.i167.1:                                       ; preds = %bb22.1
  call void @__sanitizer_cov_trace_cmp8(i64 %_4.0.i.i165.1, i64 %p.1), !dbg !54880
  %_7.not.i.i.i168.1 = icmp ugt i64 %_4.0.i.i165.1, %p.1
  %.n.i169.1 = select i1 %_7.not.i.i.i168.1, i64 0, i64 2, !dbg !54928
  br i1 %_7.not.i.i.i168.1, label %bb12.i172.1, label %bb11.i170.1, !dbg !54931

bb11.i170.1:                                      ; preds = %bb5.i167.1
  %126 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 22), align 1, !dbg !54932, !nosanitize !4116
  %127 = add i8 %126, 1, !dbg !54932
  store i8 %127, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 22), align 1, !dbg !54932, !nosanitize !4116
  %_15.i.i.i171.1 = getelementptr inbounds nuw i8, ptr %p.0, i64 %i.sroa.0.1291.1, !dbg !54932
  br label %_RNvNvNtCs1K0wxfkMoe8_15spiral_protocol9handshake11parse_hello4take.exit177.1, !dbg !54936

bb12.i172.1:                                      ; preds = %bb5.i167.1
  %128 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 23), align 1, !dbg !54937, !nosanitize !4116
  %129 = add i8 %128, 1, !dbg !54937
  store i8 %129, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 23), align 1, !dbg !54937, !nosanitize !4116
  %_37.sroa.6.8.insert.mask.1 = and i64 %_37.sroa.6.1289.1, -65536, !dbg !54937
  %_37.sroa.6.8.insert.insert.1 = or disjoint i64 %.n.i169.1, %_37.sroa.6.8.insert.mask.1, !dbg !54937
  br label %_RNvNvNtCs1K0wxfkMoe8_15spiral_protocol9handshake11parse_hello4take.exit177.1, !dbg !54942

bb6.i176.1:                                       ; preds = %bb22.1
  %130 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 24), align 1, !dbg !54944, !nosanitize !4116
  %131 = add i8 %130, 1, !dbg !54944
  store i8 %131, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 24), align 1, !dbg !54944, !nosanitize !4116
  %_37.sroa.6.8.insert.mask210.1 = and i64 %_37.sroa.6.1289.1, -256, !dbg !54944
  br label %_RNvNvNtCs1K0wxfkMoe8_15spiral_protocol9handshake11parse_hello4take.exit177.1, !dbg !54947

_RNvNvNtCs1K0wxfkMoe8_15spiral_protocol9handshake11parse_hello4take.exit177.1: ; preds = %bb6.i176.1, %bb12.i172.1, %bb11.i170.1
  %_37.sroa.6.2.1 = phi i64 [ %_37.sroa.6.8.insert.mask210.1, %bb6.i176.1 ], [ %_37.sroa.6.8.insert.insert.1, %bb12.i172.1 ], [ %.n.i169.1, %bb11.i170.1 ], !dbg !54949
  %_37.sroa.0.0.1 = phi ptr [ null, %bb6.i176.1 ], [ null, %bb12.i172.1 ], [ %_15.i.i.i171.1, %bb11.i170.1 ], !dbg !54949
  %i.sroa.0.7.1 = phi i64 [ %i.sroa.0.1291.1, %bb6.i176.1 ], [ %i.sroa.0.1291.1, %bb12.i172.1 ], [ %_4.0.i.i165.1, %bb11.i170.1 ], !dbg !54880
  %132 = icmp eq ptr %_37.sroa.0.0.1, null, !dbg !54950
  %133 = and i64 %_37.sroa.6.2.1, 65535, !dbg !54953
  %_36.sroa.6.2.1 = select i1 %132, i64 %133, i64 %_37.sroa.6.2.1, !dbg !54953
  %134 = icmp eq ptr %_37.sroa.0.0.1, null, !dbg !54954
  br i1 %134, label %_RNvNvNtCs1K0wxfkMoe8_15spiral_protocol9handshake11parse_hello4take.exit177.1.bb27_crit_edge, label %bb26.1, !dbg !54954

_RNvNvNtCs1K0wxfkMoe8_15spiral_protocol9handshake11parse_hello4take.exit177.1.bb27_crit_edge: ; preds = %_RNvNvNtCs1K0wxfkMoe8_15spiral_protocol9handshake11parse_hello4take.exit177.1
  %135 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 25), align 1, !dbg !54954, !nosanitize !4116
  %136 = add i8 %135, 1, !dbg !54954
  store i8 %136, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 25), align 1, !dbg !54954, !nosanitize !4116
  br label %bb27, !dbg !54954

bb26.1:                                           ; preds = %_RNvNvNtCs1K0wxfkMoe8_15spiral_protocol9handshake11parse_hello4take.exit177.1
  call void @__sanitizer_cov_trace_const_cmp8(i64 2, i64 %_36.sroa.6.2.1), !dbg !54955
  %_4.i.i184.not.1 = icmp eq i64 %_36.sroa.6.2.1, 2, !dbg !54955
  br i1 %_4.i.i184.not.1, label %bb1.i.i191.1, label %bb26.1.bb2.i_crit_edge, !dbg !54955

bb26.1.bb2.i_crit_edge:                           ; preds = %bb26.1
  %137 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 26), align 1, !dbg !54955, !nosanitize !4116
  %138 = add i8 %137, 1, !dbg !54955
  store i8 %138, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 26), align 1, !dbg !54955, !nosanitize !4116
  br label %bb2.i, !dbg !54955

bb1.i.i191.1:                                     ; preds = %bb26.1
  %139 = ptrtoint ptr %_37.sroa.0.0.1 to i64, !dbg !54963
  %140 = add i64 %139, 1, !dbg !54963
  %141 = inttoptr i64 %140 to ptr, !dbg !54963
  %142 = ptrtoint ptr %_37.sroa.0.0.1 to i64, !dbg !54963
  %143 = lshr i64 %142, 3, !dbg !54963
  %144 = add i64 %143, 2147450880, !dbg !54963
  %145 = inttoptr i64 %144 to ptr, !dbg !54963
  %146 = load i8, ptr %145, align 1, !dbg !54963
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %146), !dbg !54963
  %147 = icmp ne i8 %146, 0, !dbg !54963
  br i1 %147, label %150, label %bb1.i.i191.1._crit_edge, !dbg !54963, !prof !4264

bb1.i.i191.1._crit_edge:                          ; preds = %bb1.i.i191.1
  %148 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 27), align 1, !dbg !54963, !nosanitize !4116
  %149 = add i8 %148, 1, !dbg !54963
  store i8 %149, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 27), align 1, !dbg !54963, !nosanitize !4116
  br label %159, !dbg !54963

150:                                              ; preds = %bb1.i.i191.1
  %151 = and i64 %142, 7, !dbg !54963
  %152 = trunc i64 %151 to i8, !dbg !54963
  call void @__sanitizer_cov_trace_cmp1(i8 %152, i8 %146), !dbg !54963
  %153 = icmp sge i8 %152, %146, !dbg !54963
  br i1 %153, label %156, label %._crit_edge437, !dbg !54963

._crit_edge437:                                   ; preds = %150
  %154 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 28), align 1, !dbg !54963, !nosanitize !4116
  %155 = add i8 %154, 1, !dbg !54963
  store i8 %155, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 28), align 1, !dbg !54963, !nosanitize !4116
  br label %159, !dbg !54963

156:                                              ; preds = %150
  %157 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 29), align 1, !dbg !54963, !nosanitize !4116
  %158 = add i8 %157, 1, !dbg !54963
  store i8 %158, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 29), align 1, !dbg !54963, !nosanitize !4116
  call void @__asan_report_load_n(i64 %142, i64 2) #42, !dbg !54963
  unreachable

159:                                              ; preds = %._crit_edge437, %bb1.i.i191.1._crit_edge
  %160 = ptrtoint ptr %141 to i64, !dbg !54963
  %161 = lshr i64 %160, 3, !dbg !54963
  %162 = add i64 %161, 2147450880, !dbg !54963
  %163 = inttoptr i64 %162 to ptr, !dbg !54963
  %164 = load i8, ptr %163, align 1, !dbg !54963
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %164), !dbg !54963
  %165 = icmp ne i8 %164, 0, !dbg !54963
  br i1 %165, label %168, label %._crit_edge438, !dbg !54963, !prof !4264

._crit_edge438:                                   ; preds = %159
  %166 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 30), align 1, !dbg !54963, !nosanitize !4116
  %167 = add i8 %166, 1, !dbg !54963
  store i8 %167, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 30), align 1, !dbg !54963, !nosanitize !4116
  br label %177, !dbg !54963

168:                                              ; preds = %159
  %169 = and i64 %160, 7, !dbg !54963
  %170 = trunc i64 %169 to i8, !dbg !54963
  call void @__sanitizer_cov_trace_cmp1(i8 %170, i8 %164), !dbg !54963
  %171 = icmp sge i8 %170, %164, !dbg !54963
  br i1 %171, label %174, label %._crit_edge439, !dbg !54963

._crit_edge439:                                   ; preds = %168
  %172 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 31), align 1, !dbg !54963, !nosanitize !4116
  %173 = add i8 %172, 1, !dbg !54963
  store i8 %173, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 31), align 1, !dbg !54963, !nosanitize !4116
  br label %177, !dbg !54963

174:                                              ; preds = %168
  %175 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 32), align 1, !dbg !54963, !nosanitize !4116
  %176 = add i8 %175, 1, !dbg !54963
  store i8 %176, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 32), align 1, !dbg !54963, !nosanitize !4116
  call void @__asan_report_load_n(i64 %160, i64 2) #42, !dbg !54963
  unreachable

177:                                              ; preds = %._crit_edge439, %._crit_edge438
  %v.sroa.0.0.copyload.i.i192.1 = load i16, ptr %_37.sroa.0.0.1, align 1, !dbg !54963, !alias.scope !54965
  %178 = tail call i16 @llvm.bswap.i16(i16 %v.sroa.0.0.copyload.i.i192.1), !dbg !54970
  call void @__sanitizer_cov_trace_cmp2(i16 %178, i16 %last.sroa.0.0292.1), !dbg !54974
  %_42.not.1 = icmp ugt i16 %178, %last.sroa.0.0292.1, !dbg !54974
  br i1 %_42.not.1, label %bb33.1, label %.bb32_crit_edge, !dbg !54974

.bb32_crit_edge:                                  ; preds = %177
  %179 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 33), align 1, !dbg !54974, !nosanitize !4116
  %180 = add i8 %179, 1, !dbg !54974
  store i8 %180, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 33), align 1, !dbg !54974, !nosanitize !4116
  br label %bb32, !dbg !54974

bb33.1:                                           ; preds = %177
  call void @__sanitizer_cov_trace_const_cmp2(i16 496, i16 %v.sroa.0.0.copyload.i.i192.1), !dbg !54976
  %_43.1 = icmp eq i16 %v.sroa.0.0.copyload.i.i192.1, 496, !dbg !54976
  %181 = or i1 %found.sroa.0.0293.1, %_43.1, !dbg !54977
  call void @__sanitizer_cov_trace_cmp8(i64 %spec.select238294.1, i64 %120), !dbg !54916
  %_0.i.i.i162.1 = icmp samesign ult i64 %spec.select238294.1, %120, !dbg !54916
  %_0.i1.i.i.1 = zext i1 %_0.i.i.i162.1 to i64, !dbg !54978
  %spec.select238.1 = add nuw i64 %spec.select238294.1, %_0.i1.i.i.1, !dbg !54978
  br i1 %_0.i.i.i162.1, label %bb33.1.bb22.1_crit_edge, label %bb23.1, !dbg !54923

bb33.1.bb22.1_crit_edge:                          ; preds = %bb33.1
  %182 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 34), align 1, !dbg !54923, !nosanitize !4116
  %183 = add i8 %182, 1, !dbg !54923
  store i8 %183, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 34), align 1, !dbg !54923, !nosanitize !4116
  br label %bb22.1, !dbg !54923

bb23.1:                                           ; preds = %bb33.1
  br i1 %181, label %bb5.1, label %bb23.1.bb35_crit_edge, !dbg !54979

bb23.1.bb35_crit_edge:                            ; preds = %bb23.1
  %184 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 35), align 1, !dbg !54979, !nosanitize !4116
  %185 = add i8 %184, 1, !dbg !54979
  store i8 %185, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 35), align 1, !dbg !54979, !nosanitize !4116
  br label %bb35, !dbg !54979

bb5.1:                                            ; preds = %bb23.1
  %_4.0.i.i56 = add i64 %i.sroa.0.7.1, 2, !dbg !54980
  call void @__sanitizer_cov_trace_const_cmp8(i64 -3, i64 %i.sroa.0.7.1), !dbg !54980
  %_4.1.i.not.i57 = icmp ugt i64 %i.sroa.0.7.1, -3, !dbg !54980
  call void @__sanitizer_cov_trace_cmp8(i64 %_4.0.i.i56, i64 %p.1), !dbg !54983
  %_7.not.i.i.i59 = icmp ugt i64 %_4.0.i.i56, %p.1, !dbg !54983
  %_15.i.i.i62 = getelementptr inbounds nuw i8, ptr %p.0, i64 %i.sroa.0.7.1, !dbg !54983
  %186 = or i1 %_4.1.i.not.i57, %_7.not.i.i.i59, !dbg !54983
  %187 = or i1 %_4.1.i.not.i57, %_7.not.i.i.i59, !dbg !54983
  %188 = or i1 %_4.1.i.not.i57, %_7.not.i.i.i59, !dbg !54983
  %i.sroa.0.3 = select i1 %188, i64 %i.sroa.0.7.1, i64 %_4.0.i.i56, !dbg !54983
  br i1 %187, label %bb40, label %bb39, !dbg !54984

bb5.i:                                            ; preds = %19
  call void @__sanitizer_cov_trace_const_cmp8(i64 65, i64 %p.1), !dbg !54880
  %_7.not.i.i.i.not = icmp samesign ult i64 %p.1, 65
  %_15.i.i.i = getelementptr inbounds nuw i8, ptr %p.0, i64 64, !dbg !54899
  %_16.sroa.6.1 = select i1 %_7.not.i.i.i.not, i64 0, i64 1, !dbg !54899
  %_16.sroa.0.0 = select i1 %_7.not.i.i.i.not, ptr null, ptr %_15.i.i.i, !dbg !54899
  %i.sroa.0.2 = select i1 %_7.not.i.i.i.not, i64 64, i64 65, !dbg !54899
  %189 = icmp eq ptr %_16.sroa.0.0, null, !dbg !54985
  %190 = and i64 %_16.sroa.6.1, 65281, !dbg !54987
  %_15.sroa.6.1 = select i1 %189, i64 %190, i64 %_16.sroa.6.1, !dbg !54987
  %191 = icmp eq ptr %_16.sroa.0.0, null, !dbg !54910
  br i1 %191, label %bb5.i.bb13_crit_edge, label %bb12, !dbg !54910

bb5.i.bb13_crit_edge:                             ; preds = %bb5.i
  %192 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 36), align 1, !dbg !54910, !nosanitize !4116
  %193 = add i8 %192, 1, !dbg !54910
  store i8 %193, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 36), align 1, !dbg !54910, !nosanitize !4116
  br label %bb13, !dbg !54910

bb40:                                             ; preds = %bb5.1
  %_48.sroa.6.8.extract.trunc = select i1 %186, i8 0, i8 2, !dbg !54983
  %194 = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !54988
  %195 = ptrtoint ptr %194 to i64, !dbg !54988
  %196 = lshr i64 %195, 3, !dbg !54988
  %197 = add i64 %196, 2147450880, !dbg !54988
  %198 = inttoptr i64 %197 to ptr, !dbg !54988
  %199 = load i8, ptr %198, align 1, !dbg !54988
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %199), !dbg !54988
  %200 = icmp ne i8 %199, 0, !dbg !54988
  br i1 %200, label %203, label %bb40._crit_edge, !dbg !54988, !prof !4264

bb40._crit_edge:                                  ; preds = %bb40
  %201 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 37), align 1, !dbg !54988, !nosanitize !4116
  %202 = add i8 %201, 1, !dbg !54988
  store i8 %202, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 37), align 1, !dbg !54988, !nosanitize !4116
  br label %212, !dbg !54988

203:                                              ; preds = %bb40
  %204 = and i64 %195, 7, !dbg !54988
  %205 = trunc i64 %204 to i8, !dbg !54988
  call void @__sanitizer_cov_trace_cmp1(i8 %205, i8 %199), !dbg !54988
  %206 = icmp sge i8 %205, %199, !dbg !54988
  br i1 %206, label %209, label %._crit_edge440, !dbg !54988

._crit_edge440:                                   ; preds = %203
  %207 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 38), align 1, !dbg !54988, !nosanitize !4116
  %208 = add i8 %207, 1, !dbg !54988
  store i8 %208, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 38), align 1, !dbg !54988, !nosanitize !4116
  br label %212, !dbg !54988

209:                                              ; preds = %203
  %210 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 39), align 1, !dbg !54988, !nosanitize !4116
  %211 = add i8 %210, 1, !dbg !54988
  store i8 %211, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 39), align 1, !dbg !54988, !nosanitize !4116
  call void @__asan_report_store1(i64 %195) #42, !dbg !54988
  unreachable

212:                                              ; preds = %._crit_edge440, %bb40._crit_edge
  store i8 %_48.sroa.6.8.extract.trunc, ptr %194, align 8, !dbg !54988, !alias.scope !54993
  %213 = getelementptr inbounds nuw i8, ptr %_0, i64 9, !dbg !54988
  %214 = ptrtoint ptr %213 to i64, !dbg !54988
  %215 = lshr i64 %214, 3, !dbg !54988
  %216 = add i64 %215, 2147450880, !dbg !54988
  %217 = inttoptr i64 %216 to ptr, !dbg !54988
  %218 = load i8, ptr %217, align 1, !dbg !54988
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %218), !dbg !54988
  %219 = icmp ne i8 %218, 0, !dbg !54988
  br i1 %219, label %222, label %._crit_edge441, !dbg !54988, !prof !4264

._crit_edge441:                                   ; preds = %212
  %220 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 40), align 1, !dbg !54988, !nosanitize !4116
  %221 = add i8 %220, 1, !dbg !54988
  store i8 %221, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 40), align 1, !dbg !54988, !nosanitize !4116
  br label %231, !dbg !54988

222:                                              ; preds = %212
  %223 = and i64 %214, 7, !dbg !54988
  %224 = trunc i64 %223 to i8, !dbg !54988
  call void @__sanitizer_cov_trace_cmp1(i8 %224, i8 %218), !dbg !54988
  %225 = icmp sge i8 %224, %218, !dbg !54988
  br i1 %225, label %228, label %._crit_edge442, !dbg !54988

._crit_edge442:                                   ; preds = %222
  %226 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 41), align 1, !dbg !54988, !nosanitize !4116
  %227 = add i8 %226, 1, !dbg !54988
  store i8 %227, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 41), align 1, !dbg !54988, !nosanitize !4116
  br label %231, !dbg !54988

228:                                              ; preds = %222
  %229 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 42), align 1, !dbg !54988, !nosanitize !4116
  %230 = add i8 %229, 1, !dbg !54988
  store i8 %230, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 42), align 1, !dbg !54988, !nosanitize !4116
  call void @__asan_report_store1(i64 %214) #42, !dbg !54988
  unreachable

231:                                              ; preds = %._crit_edge442, %._crit_edge441
  store i8 0, ptr %213, align 1, !dbg !54988, !alias.scope !54993
  %232 = ptrtoint ptr %_0 to i64, !dbg !54988
  %233 = lshr i64 %232, 3, !dbg !54988
  %234 = add i64 %233, 2147450880, !dbg !54988
  %235 = inttoptr i64 %234 to ptr, !dbg !54988
  %236 = load i8, ptr %235, align 1, !dbg !54988
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %236), !dbg !54988
  %237 = icmp ne i8 %236, 0, !dbg !54988
  br i1 %237, label %238, label %241, !dbg !54988

238:                                              ; preds = %231
  %239 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 43), align 1, !dbg !54988, !nosanitize !4116
  %240 = add i8 %239, 1, !dbg !54988
  store i8 %240, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 43), align 1, !dbg !54988, !nosanitize !4116
  call void @__asan_report_store8(i64 %232) #42, !dbg !54988
  unreachable, !dbg !54988

241:                                              ; preds = %231
  %242 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 44), align 1, !dbg !54988, !nosanitize !4116
  %243 = add i8 %242, 1, !dbg !54988
  store i8 %243, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 44), align 1, !dbg !54988, !nosanitize !4116
  store ptr null, ptr %_0, align 8, !dbg !54988, !alias.scope !54993
  br label %bb89, !dbg !54996

bb39:                                             ; preds = %bb5.1
  br i1 %186, label %bb2.i51, label %bb1.i.i75, !dbg !54998

bb1.i.i75:                                        ; preds = %bb39
  %244 = ptrtoint ptr %_15.i.i.i62 to i64, !dbg !55003
  %245 = add i64 %244, 1, !dbg !55003
  %246 = inttoptr i64 %245 to ptr, !dbg !55003
  %247 = ptrtoint ptr %_15.i.i.i62 to i64, !dbg !55003
  %248 = lshr i64 %247, 3, !dbg !55003
  %249 = add i64 %248, 2147450880, !dbg !55003
  %250 = inttoptr i64 %249 to ptr, !dbg !55003
  %251 = load i8, ptr %250, align 1, !dbg !55003
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %251), !dbg !55003
  %252 = icmp ne i8 %251, 0, !dbg !55003
  br i1 %252, label %255, label %bb1.i.i75._crit_edge, !dbg !55003, !prof !4264

bb1.i.i75._crit_edge:                             ; preds = %bb1.i.i75
  %253 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 45), align 1, !dbg !55003, !nosanitize !4116
  %254 = add i8 %253, 1, !dbg !55003
  store i8 %254, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 45), align 1, !dbg !55003, !nosanitize !4116
  br label %264, !dbg !55003

255:                                              ; preds = %bb1.i.i75
  %256 = and i64 %247, 7, !dbg !55003
  %257 = trunc i64 %256 to i8, !dbg !55003
  call void @__sanitizer_cov_trace_cmp1(i8 %257, i8 %251), !dbg !55003
  %258 = icmp sge i8 %257, %251, !dbg !55003
  br i1 %258, label %261, label %._crit_edge443, !dbg !55003

._crit_edge443:                                   ; preds = %255
  %259 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 46), align 1, !dbg !55003, !nosanitize !4116
  %260 = add i8 %259, 1, !dbg !55003
  store i8 %260, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 46), align 1, !dbg !55003, !nosanitize !4116
  br label %264, !dbg !55003

261:                                              ; preds = %255
  %262 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 47), align 1, !dbg !55003, !nosanitize !4116
  %263 = add i8 %262, 1, !dbg !55003
  store i8 %263, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 47), align 1, !dbg !55003, !nosanitize !4116
  call void @__asan_report_load_n(i64 %247, i64 2) #42, !dbg !55003
  unreachable

264:                                              ; preds = %._crit_edge443, %bb1.i.i75._crit_edge
  %265 = ptrtoint ptr %246 to i64, !dbg !55003
  %266 = lshr i64 %265, 3, !dbg !55003
  %267 = add i64 %266, 2147450880, !dbg !55003
  %268 = inttoptr i64 %267 to ptr, !dbg !55003
  %269 = load i8, ptr %268, align 1, !dbg !55003
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %269), !dbg !55003
  %270 = icmp ne i8 %269, 0, !dbg !55003
  br i1 %270, label %273, label %._crit_edge444, !dbg !55003, !prof !4264

._crit_edge444:                                   ; preds = %264
  %271 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 48), align 1, !dbg !55003, !nosanitize !4116
  %272 = add i8 %271, 1, !dbg !55003
  store i8 %272, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 48), align 1, !dbg !55003, !nosanitize !4116
  br label %282, !dbg !55003

273:                                              ; preds = %264
  %274 = and i64 %265, 7, !dbg !55003
  %275 = trunc i64 %274 to i8, !dbg !55003
  call void @__sanitizer_cov_trace_cmp1(i8 %275, i8 %269), !dbg !55003
  %276 = icmp sge i8 %275, %269, !dbg !55003
  br i1 %276, label %279, label %._crit_edge445, !dbg !55003

._crit_edge445:                                   ; preds = %273
  %277 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 49), align 1, !dbg !55003, !nosanitize !4116
  %278 = add i8 %277, 1, !dbg !55003
  store i8 %278, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 49), align 1, !dbg !55003, !nosanitize !4116
  br label %282, !dbg !55003

279:                                              ; preds = %273
  %280 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 50), align 1, !dbg !55003, !nosanitize !4116
  %281 = add i8 %280, 1, !dbg !55003
  store i8 %281, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 50), align 1, !dbg !55003, !nosanitize !4116
  call void @__asan_report_load_n(i64 %265, i64 2) #42, !dbg !55003
  unreachable

282:                                              ; preds = %._crit_edge445, %._crit_edge444
  %v.sroa.0.0.copyload.i.i = load i16, ptr %_15.i.i.i62, align 1, !dbg !55003, !alias.scope !55005
  %283 = tail call i16 @llvm.bswap.i16(i16 %v.sroa.0.0.copyload.i.i), !dbg !55010
  %284 = zext i16 %283 to i64, !dbg !55014
  %285 = add i64 %27, 12, !dbg !55015
  %286 = inttoptr i64 %285 to ptr, !dbg !55015
  store i16 0, ptr %286, align 1, !dbg !55015
  %287 = add i64 %27, 14, !dbg !55015
  %288 = inttoptr i64 %287 to ptr, !dbg !55015
  store i8 0, ptr %288, align 1, !dbg !55015
  %_4.0.i.i77 = add i64 %i.sroa.0.3, %284, !dbg !55017
  call void @__sanitizer_cov_trace_cmp8(i64 %_4.0.i.i77, i64 %i.sroa.0.3), !dbg !55017
  %_4.1.i.not.i78 = icmp ult i64 %_4.0.i.i77, %i.sroa.0.3, !dbg !55017
  call void @__sanitizer_cov_trace_cmp8(i64 %_4.0.i.i77, i64 %p.1), !dbg !55020
  %_7.not.i.i.i80 = icmp ugt i64 %_4.0.i.i77, %p.1, !dbg !55020
  %289 = or i1 %_4.1.i.not.i78, %_7.not.i.i.i80, !dbg !55020
  %_58.sroa.6.0 = select i1 %289, i64 0, i64 %284, !dbg !55020
  %290 = or i1 %_4.1.i.not.i78, %_7.not.i.i.i80, !dbg !55020
  %291 = tail call i64 @llvm.umax.i64(i64 %_4.0.i.i77, i64 %i.sroa.0.3), !dbg !55020
  %i.sroa.0.4 = select i1 %_7.not.i.i.i80, i64 %i.sroa.0.3, i64 %291, !dbg !55020
  br i1 %290, label %bb48, label %bb47, !dbg !55021

bb2.i51:                                          ; preds = %bb39
  %292 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 51), align 1, !dbg !55022, !nosanitize !4116
  %293 = add i8 %292, 1, !dbg !55022
  store i8 %293, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 51), align 1, !dbg !55022, !nosanitize !4116
  call void @__asan_handle_no_return(), !dbg !55022
; call core::result::unwrap_failed::<core::array::TryFromSliceError>
  tail call void @_RINvNtCshZBO5P2NUJi_4core6result13unwrap_failedNtNtB4_5array17TryFromSliceErrorECs7jJvS58pafZ_4ring(ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) @alloc_00ae4b301f7fab8ac9617c03fcbd7274, i64 noundef 43, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_4ad12800010026e41c01b9765009d71f) #43, !dbg !55022
  unreachable, !dbg !55022

bb48:                                             ; preds = %282
  %_57.sroa.6.8.extract.trunc = trunc i64 %_58.sroa.6.0 to i8, !dbg !55026
  %_57.sroa.6.9.extract.shift = lshr i64 %_58.sroa.6.0, 8, !dbg !55026
  %_57.sroa.6.9.extract.trunc = trunc nuw i64 %_57.sroa.6.9.extract.shift to i8, !dbg !55026
  %294 = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !55027
  %295 = ptrtoint ptr %294 to i64, !dbg !55027
  %296 = lshr i64 %295, 3, !dbg !55027
  %297 = add i64 %296, 2147450880, !dbg !55027
  %298 = inttoptr i64 %297 to ptr, !dbg !55027
  %299 = load i8, ptr %298, align 1, !dbg !55027
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %299), !dbg !55027
  %300 = icmp ne i8 %299, 0, !dbg !55027
  br i1 %300, label %303, label %bb48._crit_edge, !dbg !55027, !prof !4264

bb48._crit_edge:                                  ; preds = %bb48
  %301 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 52), align 1, !dbg !55027, !nosanitize !4116
  %302 = add i8 %301, 1, !dbg !55027
  store i8 %302, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 52), align 1, !dbg !55027, !nosanitize !4116
  br label %312, !dbg !55027

303:                                              ; preds = %bb48
  %304 = and i64 %295, 7, !dbg !55027
  %305 = trunc i64 %304 to i8, !dbg !55027
  call void @__sanitizer_cov_trace_cmp1(i8 %305, i8 %299), !dbg !55027
  %306 = icmp sge i8 %305, %299, !dbg !55027
  br i1 %306, label %309, label %._crit_edge446, !dbg !55027

._crit_edge446:                                   ; preds = %303
  %307 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 53), align 1, !dbg !55027, !nosanitize !4116
  %308 = add i8 %307, 1, !dbg !55027
  store i8 %308, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 53), align 1, !dbg !55027, !nosanitize !4116
  br label %312, !dbg !55027

309:                                              ; preds = %303
  %310 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 54), align 1, !dbg !55027, !nosanitize !4116
  %311 = add i8 %310, 1, !dbg !55027
  store i8 %311, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 54), align 1, !dbg !55027, !nosanitize !4116
  call void @__asan_report_store1(i64 %295) #42, !dbg !55027
  unreachable

312:                                              ; preds = %._crit_edge446, %bb48._crit_edge
  store i8 %_57.sroa.6.8.extract.trunc, ptr %294, align 8, !dbg !55027, !alias.scope !55030
  %313 = getelementptr inbounds nuw i8, ptr %_0, i64 9, !dbg !55027
  %314 = ptrtoint ptr %313 to i64, !dbg !55027
  %315 = lshr i64 %314, 3, !dbg !55027
  %316 = add i64 %315, 2147450880, !dbg !55027
  %317 = inttoptr i64 %316 to ptr, !dbg !55027
  %318 = load i8, ptr %317, align 1, !dbg !55027
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %318), !dbg !55027
  %319 = icmp ne i8 %318, 0, !dbg !55027
  br i1 %319, label %322, label %._crit_edge447, !dbg !55027, !prof !4264

._crit_edge447:                                   ; preds = %312
  %320 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 55), align 1, !dbg !55027, !nosanitize !4116
  %321 = add i8 %320, 1, !dbg !55027
  store i8 %321, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 55), align 1, !dbg !55027, !nosanitize !4116
  br label %331, !dbg !55027

322:                                              ; preds = %312
  %323 = and i64 %314, 7, !dbg !55027
  %324 = trunc i64 %323 to i8, !dbg !55027
  call void @__sanitizer_cov_trace_cmp1(i8 %324, i8 %318), !dbg !55027
  %325 = icmp sge i8 %324, %318, !dbg !55027
  br i1 %325, label %328, label %._crit_edge448, !dbg !55027

._crit_edge448:                                   ; preds = %322
  %326 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 56), align 1, !dbg !55027, !nosanitize !4116
  %327 = add i8 %326, 1, !dbg !55027
  store i8 %327, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 56), align 1, !dbg !55027, !nosanitize !4116
  br label %331, !dbg !55027

328:                                              ; preds = %322
  %329 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 57), align 1, !dbg !55027, !nosanitize !4116
  %330 = add i8 %329, 1, !dbg !55027
  store i8 %330, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 57), align 1, !dbg !55027, !nosanitize !4116
  call void @__asan_report_store1(i64 %314) #42, !dbg !55027
  unreachable

331:                                              ; preds = %._crit_edge448, %._crit_edge447
  store i8 %_57.sroa.6.9.extract.trunc, ptr %313, align 1, !dbg !55027, !alias.scope !55030
  %332 = ptrtoint ptr %_0 to i64, !dbg !55027
  %333 = lshr i64 %332, 3, !dbg !55027
  %334 = add i64 %333, 2147450880, !dbg !55027
  %335 = inttoptr i64 %334 to ptr, !dbg !55027
  %336 = load i8, ptr %335, align 1, !dbg !55027
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %336), !dbg !55027
  %337 = icmp ne i8 %336, 0, !dbg !55027
  br i1 %337, label %338, label %341, !dbg !55027

338:                                              ; preds = %331
  %339 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 58), align 1, !dbg !55027, !nosanitize !4116
  %340 = add i8 %339, 1, !dbg !55027
  store i8 %340, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 58), align 1, !dbg !55027, !nosanitize !4116
  call void @__asan_report_store8(i64 %332) #42, !dbg !55027
  unreachable, !dbg !55027

341:                                              ; preds = %331
  %342 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 59), align 1, !dbg !55027, !nosanitize !4116
  %343 = add i8 %342, 1, !dbg !55027
  store i8 %343, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 59), align 1, !dbg !55027, !nosanitize !4116
  store ptr null, ptr %_0, align 8, !dbg !55027, !alias.scope !55030
  %344 = add i64 %27, 12, !dbg !55033
  %345 = inttoptr i64 %344 to ptr, !dbg !55033
  store i16 -1800, ptr %345, align 1, !dbg !55033
  %346 = add i64 %27, 14, !dbg !55033
  %347 = inttoptr i64 %346 to ptr, !dbg !55033
  store i8 -8, ptr %347, align 1, !dbg !55033
  br label %bb89, !dbg !55034

bb47:                                             ; preds = %282
  %_15.i.i.i83 = getelementptr inbounds nuw i8, ptr %p.0, i64 %i.sroa.0.3, !dbg !55020
; call core::str::converts::from_utf8
  call void @_RNvNtNtCshZBO5P2NUJi_4core3str8converts9from_utf8(ptr noalias nofree noundef sret([24 x i8]) align 8 captures(none) dereferenceable(24) %22, ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) %_15.i.i.i83, i64 noundef %_58.sroa.6.0) #35, !dbg !55015
  %_3.i = load i64, ptr %22, align 8, !dbg !55036, !range !4990, !alias.scope !55039, !noalias !55042, !noundef !4116
  %348 = trunc nuw i64 %_3.i to i1, !dbg !55044
  br i1 %348, label %bb47._RINvMNtCshZBO5P2NUJi_4core6resultINtB3_6ResultReNtNtNtB5_3str5error9Utf8ErrorE7map_errNtNtCs1K0wxfkMoe8_15spiral_protocol5error5ErrorNCNvNtB1q_9handshake11parse_hello0EB1q_.exit_crit_edge, label %bb3.i94, !dbg !55044

bb47._RINvMNtCshZBO5P2NUJi_4core6resultINtB3_6ResultReNtNtNtB5_3str5error9Utf8ErrorE7map_errNtNtCs1K0wxfkMoe8_15spiral_protocol5error5ErrorNCNvNtB1q_9handshake11parse_hello0EB1q_.exit_crit_edge: ; preds = %bb47
  %349 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 60), align 1, !dbg !55044, !nosanitize !4116
  %350 = add i8 %349, 1, !dbg !55044
  store i8 %350, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 60), align 1, !dbg !55044, !nosanitize !4116
  br label %_RINvMNtCshZBO5P2NUJi_4core6resultINtB3_6ResultReNtNtNtB5_3str5error9Utf8ErrorE7map_errNtNtCs1K0wxfkMoe8_15spiral_protocol5error5ErrorNCNvNtB1q_9handshake11parse_hello0EB1q_.exit, !dbg !55044

bb3.i94:                                          ; preds = %bb47
  %351 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 61), align 1, !dbg !55045, !nosanitize !4116
  %352 = add i8 %351, 1, !dbg !55045
  store i8 %352, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 61), align 1, !dbg !55045, !nosanitize !4116
  %353 = getelementptr inbounds nuw i8, ptr %22, i64 8, !dbg !55045
  %t.0.i = load ptr, ptr %353, align 8, !dbg !55045, !alias.scope !55039, !noalias !55042, !nonnull !4116, !noundef !4116
  %354 = getelementptr inbounds nuw i8, ptr %22, i64 16, !dbg !55045
  %t.1.i = load i64, ptr %354, align 8, !dbg !55045, !alias.scope !55039, !noalias !55042, !noundef !4116
  br label %_RINvMNtCshZBO5P2NUJi_4core6resultINtB3_6ResultReNtNtNtB5_3str5error9Utf8ErrorE7map_errNtNtCs1K0wxfkMoe8_15spiral_protocol5error5ErrorNCNvNtB1q_9handshake11parse_hello0EB1q_.exit, !dbg !55046

_RINvMNtCshZBO5P2NUJi_4core6resultINtB3_6ResultReNtNtNtB5_3str5error9Utf8ErrorE7map_errNtNtCs1K0wxfkMoe8_15spiral_protocol5error5ErrorNCNvNtB1q_9handshake11parse_hello0EB1q_.exit: ; preds = %bb47._RINvMNtCshZBO5P2NUJi_4core6resultINtB3_6ResultReNtNtNtB5_3str5error9Utf8ErrorE7map_errNtNtCs1K0wxfkMoe8_15spiral_protocol5error5ErrorNCNvNtB1q_9handshake11parse_hello0EB1q_.exit_crit_edge, %bb3.i94
  %_55.sroa.6.0 = phi i64 [ %t.1.i, %bb3.i94 ], [ 0, %bb47._RINvMNtCshZBO5P2NUJi_4core6resultINtB3_6ResultReNtNtNtB5_3str5error9Utf8ErrorE7map_errNtNtCs1K0wxfkMoe8_15spiral_protocol5error5ErrorNCNvNtB1q_9handshake11parse_hello0EB1q_.exit_crit_edge ], !dbg !55047
  %_55.sroa.0.0 = phi ptr [ %t.0.i, %bb3.i94 ], [ null, %bb47._RINvMNtCshZBO5P2NUJi_4core6resultINtB3_6ResultReNtNtNtB5_3str5error9Utf8ErrorE7map_errNtNtCs1K0wxfkMoe8_15spiral_protocol5error5ErrorNCNvNtB1q_9handshake11parse_hello0EB1q_.exit_crit_edge ], !dbg !55047
  %355 = add i64 %27, 12, !dbg !55033
  %356 = inttoptr i64 %355 to ptr, !dbg !55033
  store i16 -1800, ptr %356, align 1, !dbg !55033
  %357 = add i64 %27, 14, !dbg !55033
  %358 = inttoptr i64 %357 to ptr, !dbg !55033
  store i8 -8, ptr %358, align 1, !dbg !55033
  %359 = icmp eq ptr %_55.sroa.0.0, null, !dbg !55048
  %_54.sroa.6.9.insert.insert = and i64 %_55.sroa.6.0, 65535
  %spec.select243 = select i1 %359, i64 %_54.sroa.6.9.insert.insert, i64 %_55.sroa.6.0, !dbg !55051
  %360 = icmp eq ptr %_55.sroa.0.0, null, !dbg !55015
  br i1 %360, label %bb54, label %bb53, !dbg !55015

bb54:                                             ; preds = %_RINvMNtCshZBO5P2NUJi_4core6resultINtB3_6ResultReNtNtNtB5_3str5error9Utf8ErrorE7map_errNtNtCs1K0wxfkMoe8_15spiral_protocol5error5ErrorNCNvNtB1q_9handshake11parse_hello0EB1q_.exit
  %_54.sroa.6.8.extract.trunc = trunc i64 %spec.select243 to i8, !dbg !55052
  %_54.sroa.6.9.extract.shift = lshr i64 %spec.select243, 8, !dbg !55052
  %_54.sroa.6.9.extract.trunc = trunc i64 %_54.sroa.6.9.extract.shift to i8, !dbg !55052
  %361 = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !55053
  %362 = ptrtoint ptr %361 to i64, !dbg !55053
  %363 = lshr i64 %362, 3, !dbg !55053
  %364 = add i64 %363, 2147450880, !dbg !55053
  %365 = inttoptr i64 %364 to ptr, !dbg !55053
  %366 = load i8, ptr %365, align 1, !dbg !55053
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %366), !dbg !55053
  %367 = icmp ne i8 %366, 0, !dbg !55053
  br i1 %367, label %370, label %bb54._crit_edge, !dbg !55053, !prof !4264

bb54._crit_edge:                                  ; preds = %bb54
  %368 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 62), align 1, !dbg !55053, !nosanitize !4116
  %369 = add i8 %368, 1, !dbg !55053
  store i8 %369, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 62), align 1, !dbg !55053, !nosanitize !4116
  br label %379, !dbg !55053

370:                                              ; preds = %bb54
  %371 = and i64 %362, 7, !dbg !55053
  %372 = trunc i64 %371 to i8, !dbg !55053
  call void @__sanitizer_cov_trace_cmp1(i8 %372, i8 %366), !dbg !55053
  %373 = icmp sge i8 %372, %366, !dbg !55053
  br i1 %373, label %376, label %._crit_edge449, !dbg !55053

._crit_edge449:                                   ; preds = %370
  %374 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 63), align 1, !dbg !55053, !nosanitize !4116
  %375 = add i8 %374, 1, !dbg !55053
  store i8 %375, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 63), align 1, !dbg !55053, !nosanitize !4116
  br label %379, !dbg !55053

376:                                              ; preds = %370
  %377 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 64), align 1, !dbg !55053, !nosanitize !4116
  %378 = add i8 %377, 1, !dbg !55053
  store i8 %378, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 64), align 1, !dbg !55053, !nosanitize !4116
  call void @__asan_report_store1(i64 %362) #42, !dbg !55053
  unreachable

379:                                              ; preds = %._crit_edge449, %bb54._crit_edge
  store i8 %_54.sroa.6.8.extract.trunc, ptr %361, align 8, !dbg !55053, !alias.scope !55056
  %380 = getelementptr inbounds nuw i8, ptr %_0, i64 9, !dbg !55053
  %381 = ptrtoint ptr %380 to i64, !dbg !55053
  %382 = lshr i64 %381, 3, !dbg !55053
  %383 = add i64 %382, 2147450880, !dbg !55053
  %384 = inttoptr i64 %383 to ptr, !dbg !55053
  %385 = load i8, ptr %384, align 1, !dbg !55053
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %385), !dbg !55053
  %386 = icmp ne i8 %385, 0, !dbg !55053
  br i1 %386, label %389, label %._crit_edge450, !dbg !55053, !prof !4264

._crit_edge450:                                   ; preds = %379
  %387 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 65), align 1, !dbg !55053, !nosanitize !4116
  %388 = add i8 %387, 1, !dbg !55053
  store i8 %388, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 65), align 1, !dbg !55053, !nosanitize !4116
  br label %398, !dbg !55053

389:                                              ; preds = %379
  %390 = and i64 %381, 7, !dbg !55053
  %391 = trunc i64 %390 to i8, !dbg !55053
  call void @__sanitizer_cov_trace_cmp1(i8 %391, i8 %385), !dbg !55053
  %392 = icmp sge i8 %391, %385, !dbg !55053
  br i1 %392, label %395, label %._crit_edge451, !dbg !55053

._crit_edge451:                                   ; preds = %389
  %393 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 66), align 1, !dbg !55053, !nosanitize !4116
  %394 = add i8 %393, 1, !dbg !55053
  store i8 %394, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 66), align 1, !dbg !55053, !nosanitize !4116
  br label %398, !dbg !55053

395:                                              ; preds = %389
  %396 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 67), align 1, !dbg !55053, !nosanitize !4116
  %397 = add i8 %396, 1, !dbg !55053
  store i8 %397, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 67), align 1, !dbg !55053, !nosanitize !4116
  call void @__asan_report_store1(i64 %381) #42, !dbg !55053
  unreachable

398:                                              ; preds = %._crit_edge451, %._crit_edge450
  store i8 %_54.sroa.6.9.extract.trunc, ptr %380, align 1, !dbg !55053, !alias.scope !55056
  %399 = ptrtoint ptr %_0 to i64, !dbg !55053
  %400 = lshr i64 %399, 3, !dbg !55053
  %401 = add i64 %400, 2147450880, !dbg !55053
  %402 = inttoptr i64 %401 to ptr, !dbg !55053
  %403 = load i8, ptr %402, align 1, !dbg !55053
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %403), !dbg !55053
  %404 = icmp ne i8 %403, 0, !dbg !55053
  br i1 %404, label %405, label %408, !dbg !55053

405:                                              ; preds = %398
  %406 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 68), align 1, !dbg !55053, !nosanitize !4116
  %407 = add i8 %406, 1, !dbg !55053
  store i8 %407, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 68), align 1, !dbg !55053, !nosanitize !4116
  call void @__asan_report_store8(i64 %399) #42, !dbg !55053
  unreachable, !dbg !55053

408:                                              ; preds = %398
  %409 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 69), align 1, !dbg !55053, !nosanitize !4116
  %410 = add i8 %409, 1, !dbg !55053
  store i8 %410, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 69), align 1, !dbg !55053, !nosanitize !4116
  store ptr null, ptr %_0, align 8, !dbg !55053, !alias.scope !55056
  br label %bb89, !dbg !55034

bb53:                                             ; preds = %_RINvMNtCshZBO5P2NUJi_4core6resultINtB3_6ResultReNtNtNtB5_3str5error9Utf8ErrorE7map_errNtNtCs1K0wxfkMoe8_15spiral_protocol5error5ErrorNCNvNtB1q_9handshake11parse_hello0EB1q_.exit
  %_4.0.i.i103 = add i64 %i.sroa.0.4, 1, !dbg !55059
  call void @__sanitizer_cov_trace_const_cmp8(i64 -1, i64 %i.sroa.0.4), !dbg !55059
  %_4.1.i.not.i104 = icmp ne i64 %i.sroa.0.4, -1, !dbg !55059
  call void @__sanitizer_cov_trace_cmp8(i64 %_4.0.i.i103, i64 %p.1), !dbg !55063
  %_7.not.i.i.i106 = icmp ule i64 %_4.0.i.i103, %p.1, !dbg !55063
  %_15.i.i.i109 = getelementptr inbounds nuw i8, ptr %p.0, i64 %i.sroa.0.4, !dbg !55063
  %spec.select255 = select i1 %_7.not.i.i.i106, i64 %_4.0.i.i103, i64 %i.sroa.0.4, !dbg !55063
  %_69.sroa.6.0.shrunk = and i1 %_4.1.i.not.i104, %_7.not.i.i.i106, !dbg !55063
  %411 = and i1 %_4.1.i.not.i104, %_7.not.i.i.i106, !dbg !55063
  %i.sroa.0.5 = select i1 %_4.1.i.not.i104, i64 %spec.select255, i64 -1, !dbg !55063
  br i1 %411, label %bb58, label %bb59, !dbg !55064

bb59:                                             ; preds = %bb53
  %_68.sroa.6.8.extract.trunc = zext i1 %_69.sroa.6.0.shrunk to i8, !dbg !55065
  %412 = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !55066
  %413 = ptrtoint ptr %412 to i64, !dbg !55066
  %414 = lshr i64 %413, 3, !dbg !55066
  %415 = add i64 %414, 2147450880, !dbg !55066
  %416 = inttoptr i64 %415 to ptr, !dbg !55066
  %417 = load i8, ptr %416, align 1, !dbg !55066
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %417), !dbg !55066
  %418 = icmp ne i8 %417, 0, !dbg !55066
  br i1 %418, label %421, label %bb59._crit_edge, !dbg !55066, !prof !4264

bb59._crit_edge:                                  ; preds = %bb59
  %419 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 70), align 1, !dbg !55066, !nosanitize !4116
  %420 = add i8 %419, 1, !dbg !55066
  store i8 %420, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 70), align 1, !dbg !55066, !nosanitize !4116
  br label %430, !dbg !55066

421:                                              ; preds = %bb59
  %422 = and i64 %413, 7, !dbg !55066
  %423 = trunc i64 %422 to i8, !dbg !55066
  call void @__sanitizer_cov_trace_cmp1(i8 %423, i8 %417), !dbg !55066
  %424 = icmp sge i8 %423, %417, !dbg !55066
  br i1 %424, label %427, label %._crit_edge452, !dbg !55066

._crit_edge452:                                   ; preds = %421
  %425 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 71), align 1, !dbg !55066, !nosanitize !4116
  %426 = add i8 %425, 1, !dbg !55066
  store i8 %426, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 71), align 1, !dbg !55066, !nosanitize !4116
  br label %430, !dbg !55066

427:                                              ; preds = %421
  %428 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 72), align 1, !dbg !55066, !nosanitize !4116
  %429 = add i8 %428, 1, !dbg !55066
  store i8 %429, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 72), align 1, !dbg !55066, !nosanitize !4116
  call void @__asan_report_store1(i64 %413) #42, !dbg !55066
  unreachable

430:                                              ; preds = %._crit_edge452, %bb59._crit_edge
  store i8 %_68.sroa.6.8.extract.trunc, ptr %412, align 8, !dbg !55066, !alias.scope !55069
  %431 = getelementptr inbounds nuw i8, ptr %_0, i64 9, !dbg !55066
  %432 = ptrtoint ptr %431 to i64, !dbg !55066
  %433 = lshr i64 %432, 3, !dbg !55066
  %434 = add i64 %433, 2147450880, !dbg !55066
  %435 = inttoptr i64 %434 to ptr, !dbg !55066
  %436 = load i8, ptr %435, align 1, !dbg !55066
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %436), !dbg !55066
  %437 = icmp ne i8 %436, 0, !dbg !55066
  br i1 %437, label %440, label %._crit_edge453, !dbg !55066, !prof !4264

._crit_edge453:                                   ; preds = %430
  %438 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 73), align 1, !dbg !55066, !nosanitize !4116
  %439 = add i8 %438, 1, !dbg !55066
  store i8 %439, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 73), align 1, !dbg !55066, !nosanitize !4116
  br label %449, !dbg !55066

440:                                              ; preds = %430
  %441 = and i64 %432, 7, !dbg !55066
  %442 = trunc i64 %441 to i8, !dbg !55066
  call void @__sanitizer_cov_trace_cmp1(i8 %442, i8 %436), !dbg !55066
  %443 = icmp sge i8 %442, %436, !dbg !55066
  br i1 %443, label %446, label %._crit_edge454, !dbg !55066

._crit_edge454:                                   ; preds = %440
  %444 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 74), align 1, !dbg !55066, !nosanitize !4116
  %445 = add i8 %444, 1, !dbg !55066
  store i8 %445, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 74), align 1, !dbg !55066, !nosanitize !4116
  br label %449, !dbg !55066

446:                                              ; preds = %440
  %447 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 75), align 1, !dbg !55066, !nosanitize !4116
  %448 = add i8 %447, 1, !dbg !55066
  store i8 %448, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 75), align 1, !dbg !55066, !nosanitize !4116
  call void @__asan_report_store1(i64 %432) #42, !dbg !55066
  unreachable

449:                                              ; preds = %._crit_edge454, %._crit_edge453
  store i8 0, ptr %431, align 1, !dbg !55066, !alias.scope !55069
  %450 = ptrtoint ptr %_0 to i64, !dbg !55066
  %451 = lshr i64 %450, 3, !dbg !55066
  %452 = add i64 %451, 2147450880, !dbg !55066
  %453 = inttoptr i64 %452 to ptr, !dbg !55066
  %454 = load i8, ptr %453, align 1, !dbg !55066
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %454), !dbg !55066
  %455 = icmp ne i8 %454, 0, !dbg !55066
  br i1 %455, label %456, label %459, !dbg !55066

456:                                              ; preds = %449
  %457 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 76), align 1, !dbg !55066, !nosanitize !4116
  %458 = add i8 %457, 1, !dbg !55066
  store i8 %458, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 76), align 1, !dbg !55066, !nosanitize !4116
  call void @__asan_report_store8(i64 %450) #42, !dbg !55066
  unreachable, !dbg !55066

459:                                              ; preds = %449
  %460 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 77), align 1, !dbg !55066, !nosanitize !4116
  %461 = add i8 %460, 1, !dbg !55066
  store i8 %461, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 77), align 1, !dbg !55066, !nosanitize !4116
  store ptr null, ptr %_0, align 8, !dbg !55066, !alias.scope !55069
  br label %bb89, !dbg !55072

bb58:                                             ; preds = %bb53
  br i1 %_69.sroa.6.0.shrunk, label %bb61, label %panic, !dbg !55064

bb61:                                             ; preds = %bb58
  %462 = ptrtoint ptr %_15.i.i.i109 to i64, !dbg !55064
  %463 = lshr i64 %462, 3, !dbg !55064
  %464 = add i64 %463, 2147450880, !dbg !55064
  %465 = inttoptr i64 %464 to ptr, !dbg !55064
  %466 = load i8, ptr %465, align 1, !dbg !55064
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %466), !dbg !55064
  %467 = icmp ne i8 %466, 0, !dbg !55064
  br i1 %467, label %470, label %bb61._crit_edge, !dbg !55064, !prof !4264

bb61._crit_edge:                                  ; preds = %bb61
  %468 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 78), align 1, !dbg !55064, !nosanitize !4116
  %469 = add i8 %468, 1, !dbg !55064
  store i8 %469, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 78), align 1, !dbg !55064, !nosanitize !4116
  br label %479, !dbg !55064

470:                                              ; preds = %bb61
  %471 = and i64 %462, 7, !dbg !55064
  %472 = trunc i64 %471 to i8, !dbg !55064
  call void @__sanitizer_cov_trace_cmp1(i8 %472, i8 %466), !dbg !55064
  %473 = icmp sge i8 %472, %466, !dbg !55064
  br i1 %473, label %476, label %._crit_edge455, !dbg !55064

._crit_edge455:                                   ; preds = %470
  %474 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 79), align 1, !dbg !55064, !nosanitize !4116
  %475 = add i8 %474, 1, !dbg !55064
  store i8 %475, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 79), align 1, !dbg !55064, !nosanitize !4116
  br label %479, !dbg !55064

476:                                              ; preds = %470
  %477 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 80), align 1, !dbg !55064, !nosanitize !4116
  %478 = add i8 %477, 1, !dbg !55064
  store i8 %478, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 80), align 1, !dbg !55064, !nosanitize !4116
  call void @__asan_report_load1(i64 %462) #42, !dbg !55064
  unreachable

479:                                              ; preds = %._crit_edge455, %bb61._crit_edge
  %_67 = load i8, ptr %_15.i.i.i109, align 1, !dbg !55064, !noundef !4116
  %n7 = zext i8 %_67 to i64, !dbg !55064
  %480 = add i64 %27, 4, !dbg !55074
  %481 = inttoptr i64 %480 to ptr, !dbg !55074
  store i16 0, ptr %481, align 1, !dbg !55074
  %482 = add i64 %27, 6, !dbg !55074
  %483 = inttoptr i64 %482 to ptr, !dbg !55074
  store i8 0, ptr %483, align 1, !dbg !55074
  %_4.0.i.i123 = add i64 %i.sroa.0.5, %n7, !dbg !55076
  call void @__sanitizer_cov_trace_cmp8(i64 %_4.0.i.i123, i64 %i.sroa.0.5), !dbg !55076
  %_4.1.i.not.i124 = icmp ult i64 %_4.0.i.i123, %i.sroa.0.5, !dbg !55076
  call void @__sanitizer_cov_trace_cmp8(i64 %_4.0.i.i123, i64 %p.1), !dbg !55079
  %_7.not.i.i.i126 = icmp ugt i64 %_4.0.i.i123, %p.1, !dbg !55079
  %484 = or i1 %_4.1.i.not.i124, %_7.not.i.i.i126, !dbg !55079
  %485 = tail call i64 @llvm.umax.i64(i64 %_4.0.i.i123, i64 %i.sroa.0.5), !dbg !55079
  %i.sroa.0.6 = select i1 %_7.not.i.i.i126, i64 %i.sroa.0.5, i64 %485, !dbg !55079
  %486 = or i1 %_4.1.i.not.i124, %_7.not.i.i.i126, !dbg !55079
  %_80.sroa.6.0 = select i1 %486, i64 0, i64 %n7, !dbg !55079
  br i1 %484, label %bb65, label %bb64, !dbg !55080

panic:                                            ; preds = %bb58
  %487 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 81), align 1, !dbg !55064, !nosanitize !4116
  %488 = add i8 %487, 1, !dbg !55064
  store i8 %488, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 81), align 1, !dbg !55064, !nosanitize !4116
  call void @__asan_handle_no_return(), !dbg !55064
; call core::panicking::panic_bounds_check
  tail call void @_RNvNtCshZBO5P2NUJi_4core9panicking18panic_bounds_check(i64 noundef 0, i64 noundef 0, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_d6c74d069b8a320483cb2db8b70fcf58) #43, !dbg !55064
  unreachable, !dbg !55064

bb65:                                             ; preds = %479
  %_79.sroa.6.8.extract.trunc = trunc nuw i64 %_80.sroa.6.0 to i8, !dbg !55081
  %489 = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !55082
  %490 = ptrtoint ptr %489 to i64, !dbg !55082
  %491 = lshr i64 %490, 3, !dbg !55082
  %492 = add i64 %491, 2147450880, !dbg !55082
  %493 = inttoptr i64 %492 to ptr, !dbg !55082
  %494 = load i8, ptr %493, align 1, !dbg !55082
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %494), !dbg !55082
  %495 = icmp ne i8 %494, 0, !dbg !55082
  br i1 %495, label %498, label %bb65._crit_edge, !dbg !55082, !prof !4264

bb65._crit_edge:                                  ; preds = %bb65
  %496 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 82), align 1, !dbg !55082, !nosanitize !4116
  %497 = add i8 %496, 1, !dbg !55082
  store i8 %497, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 82), align 1, !dbg !55082, !nosanitize !4116
  br label %507, !dbg !55082

498:                                              ; preds = %bb65
  %499 = and i64 %490, 7, !dbg !55082
  %500 = trunc i64 %499 to i8, !dbg !55082
  call void @__sanitizer_cov_trace_cmp1(i8 %500, i8 %494), !dbg !55082
  %501 = icmp sge i8 %500, %494, !dbg !55082
  br i1 %501, label %504, label %._crit_edge456, !dbg !55082

._crit_edge456:                                   ; preds = %498
  %502 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 83), align 1, !dbg !55082, !nosanitize !4116
  %503 = add i8 %502, 1, !dbg !55082
  store i8 %503, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 83), align 1, !dbg !55082, !nosanitize !4116
  br label %507, !dbg !55082

504:                                              ; preds = %498
  %505 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 84), align 1, !dbg !55082, !nosanitize !4116
  %506 = add i8 %505, 1, !dbg !55082
  store i8 %506, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 84), align 1, !dbg !55082, !nosanitize !4116
  call void @__asan_report_store1(i64 %490) #42, !dbg !55082
  unreachable

507:                                              ; preds = %._crit_edge456, %bb65._crit_edge
  store i8 %_79.sroa.6.8.extract.trunc, ptr %489, align 8, !dbg !55082, !alias.scope !55085
  %508 = getelementptr inbounds nuw i8, ptr %_0, i64 9, !dbg !55082
  %509 = ptrtoint ptr %508 to i64, !dbg !55082
  %510 = lshr i64 %509, 3, !dbg !55082
  %511 = add i64 %510, 2147450880, !dbg !55082
  %512 = inttoptr i64 %511 to ptr, !dbg !55082
  %513 = load i8, ptr %512, align 1, !dbg !55082
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %513), !dbg !55082
  %514 = icmp ne i8 %513, 0, !dbg !55082
  br i1 %514, label %517, label %._crit_edge457, !dbg !55082, !prof !4264

._crit_edge457:                                   ; preds = %507
  %515 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 85), align 1, !dbg !55082, !nosanitize !4116
  %516 = add i8 %515, 1, !dbg !55082
  store i8 %516, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 85), align 1, !dbg !55082, !nosanitize !4116
  br label %526, !dbg !55082

517:                                              ; preds = %507
  %518 = and i64 %509, 7, !dbg !55082
  %519 = trunc i64 %518 to i8, !dbg !55082
  call void @__sanitizer_cov_trace_cmp1(i8 %519, i8 %513), !dbg !55082
  %520 = icmp sge i8 %519, %513, !dbg !55082
  br i1 %520, label %523, label %._crit_edge458, !dbg !55082

._crit_edge458:                                   ; preds = %517
  %521 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 86), align 1, !dbg !55082, !nosanitize !4116
  %522 = add i8 %521, 1, !dbg !55082
  store i8 %522, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 86), align 1, !dbg !55082, !nosanitize !4116
  br label %526, !dbg !55082

523:                                              ; preds = %517
  %524 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 87), align 1, !dbg !55082, !nosanitize !4116
  %525 = add i8 %524, 1, !dbg !55082
  store i8 %525, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 87), align 1, !dbg !55082, !nosanitize !4116
  call void @__asan_report_store1(i64 %509) #42, !dbg !55082
  unreachable

526:                                              ; preds = %._crit_edge458, %._crit_edge457
  store i8 0, ptr %508, align 1, !dbg !55082, !alias.scope !55085
  %527 = ptrtoint ptr %_0 to i64, !dbg !55082
  %528 = lshr i64 %527, 3, !dbg !55082
  %529 = add i64 %528, 2147450880, !dbg !55082
  %530 = inttoptr i64 %529 to ptr, !dbg !55082
  %531 = load i8, ptr %530, align 1, !dbg !55082
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %531), !dbg !55082
  %532 = icmp ne i8 %531, 0, !dbg !55082
  br i1 %532, label %533, label %536, !dbg !55082

533:                                              ; preds = %526
  %534 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 88), align 1, !dbg !55082, !nosanitize !4116
  %535 = add i8 %534, 1, !dbg !55082
  store i8 %535, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 88), align 1, !dbg !55082, !nosanitize !4116
  call void @__asan_report_store8(i64 %527) #42, !dbg !55082
  unreachable, !dbg !55082

536:                                              ; preds = %526
  %537 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 89), align 1, !dbg !55082, !nosanitize !4116
  %538 = add i8 %537, 1, !dbg !55082
  store i8 %538, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 89), align 1, !dbg !55082, !nosanitize !4116
  store ptr null, ptr %_0, align 8, !dbg !55082, !alias.scope !55085
  %539 = add i64 %27, 4, !dbg !55088
  %540 = inttoptr i64 %539 to ptr, !dbg !55088
  store i16 -1800, ptr %540, align 1, !dbg !55088
  %541 = add i64 %27, 6, !dbg !55088
  %542 = inttoptr i64 %541 to ptr, !dbg !55088
  store i8 -8, ptr %542, align 1, !dbg !55088
  br label %bb89, !dbg !55089

bb64:                                             ; preds = %479
  %_15.i.i.i129 = getelementptr inbounds nuw i8, ptr %p.0, i64 %i.sroa.0.5, !dbg !55079
; call core::str::converts::from_utf8
  call void @_RNvNtNtCshZBO5P2NUJi_4core3str8converts9from_utf8(ptr noalias nofree noundef sret([24 x i8]) align 8 captures(none) dereferenceable(24) %21, ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) %_15.i.i.i129, i64 noundef %_80.sroa.6.0) #35, !dbg !55074
  %_3.i142 = load i64, ptr %21, align 8, !dbg !55091, !range !4990, !alias.scope !55094, !noalias !55097, !noundef !4116
  %543 = trunc nuw i64 %_3.i142 to i1, !dbg !55099
  br i1 %543, label %bb64._RINvMNtCshZBO5P2NUJi_4core6resultINtB3_6ResultReNtNtNtB5_3str5error9Utf8ErrorE7map_errNtNtCs1K0wxfkMoe8_15spiral_protocol5error5ErrorNCNvNtB1q_9handshake11parse_hellos_0EB1q_.exit_crit_edge, label %bb3.i143, !dbg !55099

bb64._RINvMNtCshZBO5P2NUJi_4core6resultINtB3_6ResultReNtNtNtB5_3str5error9Utf8ErrorE7map_errNtNtCs1K0wxfkMoe8_15spiral_protocol5error5ErrorNCNvNtB1q_9handshake11parse_hellos_0EB1q_.exit_crit_edge: ; preds = %bb64
  %544 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 90), align 1, !dbg !55099, !nosanitize !4116
  %545 = add i8 %544, 1, !dbg !55099
  store i8 %545, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 90), align 1, !dbg !55099, !nosanitize !4116
  br label %_RINvMNtCshZBO5P2NUJi_4core6resultINtB3_6ResultReNtNtNtB5_3str5error9Utf8ErrorE7map_errNtNtCs1K0wxfkMoe8_15spiral_protocol5error5ErrorNCNvNtB1q_9handshake11parse_hellos_0EB1q_.exit, !dbg !55099

bb3.i143:                                         ; preds = %bb64
  %546 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 91), align 1, !dbg !55100, !nosanitize !4116
  %547 = add i8 %546, 1, !dbg !55100
  store i8 %547, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 91), align 1, !dbg !55100, !nosanitize !4116
  %548 = getelementptr inbounds nuw i8, ptr %21, i64 8, !dbg !55100
  %t.0.i144 = load ptr, ptr %548, align 8, !dbg !55100, !alias.scope !55094, !noalias !55097, !nonnull !4116, !noundef !4116
  %549 = getelementptr inbounds nuw i8, ptr %21, i64 16, !dbg !55100
  %t.1.i145 = load i64, ptr %549, align 8, !dbg !55100, !alias.scope !55094, !noalias !55097, !noundef !4116
  br label %_RINvMNtCshZBO5P2NUJi_4core6resultINtB3_6ResultReNtNtNtB5_3str5error9Utf8ErrorE7map_errNtNtCs1K0wxfkMoe8_15spiral_protocol5error5ErrorNCNvNtB1q_9handshake11parse_hellos_0EB1q_.exit, !dbg !55101

_RINvMNtCshZBO5P2NUJi_4core6resultINtB3_6ResultReNtNtNtB5_3str5error9Utf8ErrorE7map_errNtNtCs1K0wxfkMoe8_15spiral_protocol5error5ErrorNCNvNtB1q_9handshake11parse_hellos_0EB1q_.exit: ; preds = %bb64._RINvMNtCshZBO5P2NUJi_4core6resultINtB3_6ResultReNtNtNtB5_3str5error9Utf8ErrorE7map_errNtNtCs1K0wxfkMoe8_15spiral_protocol5error5ErrorNCNvNtB1q_9handshake11parse_hellos_0EB1q_.exit_crit_edge, %bb3.i143
  %_77.sroa.0.0 = phi ptr [ %t.0.i144, %bb3.i143 ], [ null, %bb64._RINvMNtCshZBO5P2NUJi_4core6resultINtB3_6ResultReNtNtNtB5_3str5error9Utf8ErrorE7map_errNtNtCs1K0wxfkMoe8_15spiral_protocol5error5ErrorNCNvNtB1q_9handshake11parse_hellos_0EB1q_.exit_crit_edge ], !dbg !55102
  %_77.sroa.6.0 = phi i64 [ %t.1.i145, %bb3.i143 ], [ 0, %bb64._RINvMNtCshZBO5P2NUJi_4core6resultINtB3_6ResultReNtNtNtB5_3str5error9Utf8ErrorE7map_errNtNtCs1K0wxfkMoe8_15spiral_protocol5error5ErrorNCNvNtB1q_9handshake11parse_hellos_0EB1q_.exit_crit_edge ], !dbg !55102
  %550 = add i64 %27, 4, !dbg !55088
  %551 = inttoptr i64 %550 to ptr, !dbg !55088
  store i16 -1800, ptr %551, align 1, !dbg !55088
  %552 = add i64 %27, 6, !dbg !55088
  %553 = inttoptr i64 %552 to ptr, !dbg !55088
  store i8 -8, ptr %553, align 1, !dbg !55088
  %554 = icmp eq ptr %_77.sroa.0.0, null, !dbg !55103
  %_76.sroa.6.9.insert.insert = and i64 %_77.sroa.6.0, 65535
  %spec.select249 = select i1 %554, i64 %_76.sroa.6.9.insert.insert, i64 %_77.sroa.6.0, !dbg !55105
  %555 = icmp eq ptr %_77.sroa.0.0, null, !dbg !55074
  br i1 %555, label %bb71, label %bb70, !dbg !55074

bb71:                                             ; preds = %_RINvMNtCshZBO5P2NUJi_4core6resultINtB3_6ResultReNtNtNtB5_3str5error9Utf8ErrorE7map_errNtNtCs1K0wxfkMoe8_15spiral_protocol5error5ErrorNCNvNtB1q_9handshake11parse_hellos_0EB1q_.exit
  %_76.sroa.6.8.extract.trunc = trunc i64 %spec.select249 to i8, !dbg !55106
  %_76.sroa.6.9.extract.shift = lshr i64 %spec.select249, 8, !dbg !55106
  %_76.sroa.6.9.extract.trunc = trunc i64 %_76.sroa.6.9.extract.shift to i8, !dbg !55106
  %556 = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !55107
  %557 = ptrtoint ptr %556 to i64, !dbg !55107
  %558 = lshr i64 %557, 3, !dbg !55107
  %559 = add i64 %558, 2147450880, !dbg !55107
  %560 = inttoptr i64 %559 to ptr, !dbg !55107
  %561 = load i8, ptr %560, align 1, !dbg !55107
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %561), !dbg !55107
  %562 = icmp ne i8 %561, 0, !dbg !55107
  br i1 %562, label %565, label %bb71._crit_edge, !dbg !55107, !prof !4264

bb71._crit_edge:                                  ; preds = %bb71
  %563 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 92), align 1, !dbg !55107, !nosanitize !4116
  %564 = add i8 %563, 1, !dbg !55107
  store i8 %564, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 92), align 1, !dbg !55107, !nosanitize !4116
  br label %574, !dbg !55107

565:                                              ; preds = %bb71
  %566 = and i64 %557, 7, !dbg !55107
  %567 = trunc i64 %566 to i8, !dbg !55107
  call void @__sanitizer_cov_trace_cmp1(i8 %567, i8 %561), !dbg !55107
  %568 = icmp sge i8 %567, %561, !dbg !55107
  br i1 %568, label %571, label %._crit_edge459, !dbg !55107

._crit_edge459:                                   ; preds = %565
  %569 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 93), align 1, !dbg !55107, !nosanitize !4116
  %570 = add i8 %569, 1, !dbg !55107
  store i8 %570, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 93), align 1, !dbg !55107, !nosanitize !4116
  br label %574, !dbg !55107

571:                                              ; preds = %565
  %572 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 94), align 1, !dbg !55107, !nosanitize !4116
  %573 = add i8 %572, 1, !dbg !55107
  store i8 %573, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 94), align 1, !dbg !55107, !nosanitize !4116
  call void @__asan_report_store1(i64 %557) #42, !dbg !55107
  unreachable

574:                                              ; preds = %._crit_edge459, %bb71._crit_edge
  store i8 %_76.sroa.6.8.extract.trunc, ptr %556, align 8, !dbg !55107, !alias.scope !55110
  %575 = getelementptr inbounds nuw i8, ptr %_0, i64 9, !dbg !55107
  %576 = ptrtoint ptr %575 to i64, !dbg !55107
  %577 = lshr i64 %576, 3, !dbg !55107
  %578 = add i64 %577, 2147450880, !dbg !55107
  %579 = inttoptr i64 %578 to ptr, !dbg !55107
  %580 = load i8, ptr %579, align 1, !dbg !55107
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %580), !dbg !55107
  %581 = icmp ne i8 %580, 0, !dbg !55107
  br i1 %581, label %584, label %._crit_edge460, !dbg !55107, !prof !4264

._crit_edge460:                                   ; preds = %574
  %582 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 95), align 1, !dbg !55107, !nosanitize !4116
  %583 = add i8 %582, 1, !dbg !55107
  store i8 %583, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 95), align 1, !dbg !55107, !nosanitize !4116
  br label %593, !dbg !55107

584:                                              ; preds = %574
  %585 = and i64 %576, 7, !dbg !55107
  %586 = trunc i64 %585 to i8, !dbg !55107
  call void @__sanitizer_cov_trace_cmp1(i8 %586, i8 %580), !dbg !55107
  %587 = icmp sge i8 %586, %580, !dbg !55107
  br i1 %587, label %590, label %._crit_edge461, !dbg !55107

._crit_edge461:                                   ; preds = %584
  %588 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 96), align 1, !dbg !55107, !nosanitize !4116
  %589 = add i8 %588, 1, !dbg !55107
  store i8 %589, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 96), align 1, !dbg !55107, !nosanitize !4116
  br label %593, !dbg !55107

590:                                              ; preds = %584
  %591 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 97), align 1, !dbg !55107, !nosanitize !4116
  %592 = add i8 %591, 1, !dbg !55107
  store i8 %592, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 97), align 1, !dbg !55107, !nosanitize !4116
  call void @__asan_report_store1(i64 %576) #42, !dbg !55107
  unreachable

593:                                              ; preds = %._crit_edge461, %._crit_edge460
  store i8 %_76.sroa.6.9.extract.trunc, ptr %575, align 1, !dbg !55107, !alias.scope !55110
  %594 = ptrtoint ptr %_0 to i64, !dbg !55107
  %595 = lshr i64 %594, 3, !dbg !55107
  %596 = add i64 %595, 2147450880, !dbg !55107
  %597 = inttoptr i64 %596 to ptr, !dbg !55107
  %598 = load i8, ptr %597, align 1, !dbg !55107
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %598), !dbg !55107
  %599 = icmp ne i8 %598, 0, !dbg !55107
  br i1 %599, label %600, label %603, !dbg !55107

600:                                              ; preds = %593
  %601 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 98), align 1, !dbg !55107, !nosanitize !4116
  %602 = add i8 %601, 1, !dbg !55107
  store i8 %602, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 98), align 1, !dbg !55107, !nosanitize !4116
  call void @__asan_report_store8(i64 %594) #42, !dbg !55107
  unreachable, !dbg !55107

603:                                              ; preds = %593
  %604 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 99), align 1, !dbg !55107, !nosanitize !4116
  %605 = add i8 %604, 1, !dbg !55107
  store i8 %605, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 99), align 1, !dbg !55107, !nosanitize !4116
  store ptr null, ptr %_0, align 8, !dbg !55107, !alias.scope !55110
  br label %bb89, !dbg !55089

bb70:                                             ; preds = %_RINvMNtCshZBO5P2NUJi_4core6resultINtB3_6ResultReNtNtNtB5_3str5error9Utf8ErrorE7map_errNtNtCs1K0wxfkMoe8_15spiral_protocol5error5ErrorNCNvNtB1q_9handshake11parse_hellos_0EB1q_.exit
  call void @__sanitizer_cov_trace_cmp8(i64 %p.1, i64 %i.sroa.0.6), !dbg !55113
  %_88.not = icmp eq i64 %p.1, %i.sroa.0.6, !dbg !55113
  br i1 %_88.not, label %bb74, label %bb73, !dbg !55113

bb74:                                             ; preds = %bb70
; call spiral_protocol::handshake::validate_identity
  %606 = tail call { i8, i8 } @_RNvNtCs1K0wxfkMoe8_15spiral_protocol9handshake17validate_identity(ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) %_55.sroa.0.0, i64 noundef %spec.select243, ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) %_77.sroa.0.0, i64 noundef %spec.select249) #35, !dbg !55115
  %607 = extractvalue { i8, i8 } %606, 0, !dbg !55115
  call void @__sanitizer_cov_trace_const_cmp1(i8 -1, i8 %607), !dbg !55115
  %.not = icmp eq i8 %607, -1, !dbg !55115
  br i1 %.not, label %bb77, label %bb78, !dbg !55115

bb73:                                             ; preds = %bb70
  %608 = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !55116
  %609 = ptrtoint ptr %608 to i64, !dbg !55116
  %610 = lshr i64 %609, 3, !dbg !55116
  %611 = add i64 %610, 2147450880, !dbg !55116
  %612 = inttoptr i64 %611 to ptr, !dbg !55116
  %613 = load i8, ptr %612, align 1, !dbg !55116
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %613), !dbg !55116
  %614 = icmp ne i8 %613, 0, !dbg !55116
  br i1 %614, label %617, label %bb73._crit_edge, !dbg !55116, !prof !4264

bb73._crit_edge:                                  ; preds = %bb73
  %615 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 100), align 1, !dbg !55116, !nosanitize !4116
  %616 = add i8 %615, 1, !dbg !55116
  store i8 %616, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 100), align 1, !dbg !55116, !nosanitize !4116
  br label %626, !dbg !55116

617:                                              ; preds = %bb73
  %618 = and i64 %609, 7, !dbg !55116
  %619 = trunc i64 %618 to i8, !dbg !55116
  call void @__sanitizer_cov_trace_cmp1(i8 %619, i8 %613), !dbg !55116
  %620 = icmp sge i8 %619, %613, !dbg !55116
  br i1 %620, label %623, label %._crit_edge462, !dbg !55116

._crit_edge462:                                   ; preds = %617
  %621 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 101), align 1, !dbg !55116, !nosanitize !4116
  %622 = add i8 %621, 1, !dbg !55116
  store i8 %622, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 101), align 1, !dbg !55116, !nosanitize !4116
  br label %626, !dbg !55116

623:                                              ; preds = %617
  %624 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 102), align 1, !dbg !55116, !nosanitize !4116
  %625 = add i8 %624, 1, !dbg !55116
  store i8 %625, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 102), align 1, !dbg !55116, !nosanitize !4116
  call void @__asan_report_store1(i64 %609) #42, !dbg !55116
  unreachable

626:                                              ; preds = %._crit_edge462, %bb73._crit_edge
  store i8 0, ptr %608, align 8, !dbg !55116
  %627 = ptrtoint ptr %_0 to i64, !dbg !55116
  %628 = lshr i64 %627, 3, !dbg !55116
  %629 = add i64 %628, 2147450880, !dbg !55116
  %630 = inttoptr i64 %629 to ptr, !dbg !55116
  %631 = load i8, ptr %630, align 1, !dbg !55116
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %631), !dbg !55116
  %632 = icmp ne i8 %631, 0, !dbg !55116
  br i1 %632, label %633, label %636, !dbg !55116

633:                                              ; preds = %626
  %634 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 103), align 1, !dbg !55116, !nosanitize !4116
  %635 = add i8 %634, 1, !dbg !55116
  store i8 %635, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 103), align 1, !dbg !55116, !nosanitize !4116
  call void @__asan_report_store8(i64 %627) #42, !dbg !55116
  unreachable, !dbg !55116

636:                                              ; preds = %626
  %637 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 104), align 1, !dbg !55116, !nosanitize !4116
  %638 = add i8 %637, 1, !dbg !55116
  store i8 %638, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 104), align 1, !dbg !55116, !nosanitize !4116
  store ptr null, ptr %_0, align 8, !dbg !55116
  br label %bb89, !dbg !55117

bb78:                                             ; preds = %bb74
  %639 = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !55119
  %640 = ptrtoint ptr %639 to i64, !dbg !55119
  %641 = lshr i64 %640, 3, !dbg !55119
  %642 = add i64 %641, 2147450880, !dbg !55119
  %643 = inttoptr i64 %642 to ptr, !dbg !55119
  %644 = load i8, ptr %643, align 1, !dbg !55119
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %644), !dbg !55119
  %645 = icmp ne i8 %644, 0, !dbg !55119
  br i1 %645, label %648, label %bb78._crit_edge, !dbg !55119, !prof !4264

bb78._crit_edge:                                  ; preds = %bb78
  %646 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 105), align 1, !dbg !55119, !nosanitize !4116
  %647 = add i8 %646, 1, !dbg !55119
  store i8 %647, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 105), align 1, !dbg !55119, !nosanitize !4116
  br label %657, !dbg !55119

648:                                              ; preds = %bb78
  %649 = and i64 %640, 7, !dbg !55119
  %650 = trunc i64 %649 to i8, !dbg !55119
  call void @__sanitizer_cov_trace_cmp1(i8 %650, i8 %644), !dbg !55119
  %651 = icmp sge i8 %650, %644, !dbg !55119
  br i1 %651, label %654, label %._crit_edge463, !dbg !55119

._crit_edge463:                                   ; preds = %648
  %652 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 106), align 1, !dbg !55119, !nosanitize !4116
  %653 = add i8 %652, 1, !dbg !55119
  store i8 %653, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 106), align 1, !dbg !55119, !nosanitize !4116
  br label %657, !dbg !55119

654:                                              ; preds = %648
  %655 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 107), align 1, !dbg !55119, !nosanitize !4116
  %656 = add i8 %655, 1, !dbg !55119
  store i8 %656, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 107), align 1, !dbg !55119, !nosanitize !4116
  call void @__asan_report_store1(i64 %640) #42, !dbg !55119
  unreachable

657:                                              ; preds = %._crit_edge463, %bb78._crit_edge
  store i8 %607, ptr %639, align 8, !dbg !55119, !alias.scope !55122
  %658 = ptrtoint ptr %_0 to i64, !dbg !55119
  %659 = lshr i64 %658, 3, !dbg !55119
  %660 = add i64 %659, 2147450880, !dbg !55119
  %661 = inttoptr i64 %660 to ptr, !dbg !55119
  %662 = load i8, ptr %661, align 1, !dbg !55119
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %662), !dbg !55119
  %663 = icmp ne i8 %662, 0, !dbg !55119
  br i1 %663, label %664, label %667, !dbg !55119

664:                                              ; preds = %657
  %665 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 108), align 1, !dbg !55119, !nosanitize !4116
  %666 = add i8 %665, 1, !dbg !55119
  store i8 %666, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 108), align 1, !dbg !55119, !nosanitize !4116
  call void @__asan_report_store8(i64 %658) #42, !dbg !55119
  unreachable, !dbg !55119

667:                                              ; preds = %657
  %668 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 109), align 1, !dbg !55119, !nosanitize !4116
  %669 = add i8 %668, 1, !dbg !55119
  store i8 %669, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 109), align 1, !dbg !55119, !nosanitize !4116
  store ptr null, ptr %_0, align 8, !dbg !55119, !alias.scope !55122
  br label %bb89, !dbg !55117

bb77:                                             ; preds = %bb74
  %670 = ptrtoint ptr %_0 to i64, !dbg !55125
  %671 = lshr i64 %670, 3, !dbg !55125
  %672 = add i64 %671, 2147450880, !dbg !55125
  %673 = inttoptr i64 %672 to ptr, !dbg !55125
  %674 = load i8, ptr %673, align 1, !dbg !55125
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %674), !dbg !55125
  %675 = icmp ne i8 %674, 0, !dbg !55125
  br i1 %675, label %676, label %679, !dbg !55125

676:                                              ; preds = %bb77
  %677 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 110), align 1, !dbg !55125, !nosanitize !4116
  %678 = add i8 %677, 1, !dbg !55125
  store i8 %678, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 110), align 1, !dbg !55125, !nosanitize !4116
  call void @__asan_report_store8(i64 %670) #42, !dbg !55125
  unreachable, !dbg !55125

679:                                              ; preds = %bb77
  store ptr %_55.sroa.0.0, ptr %_0, align 8, !dbg !55125
  %_94.sroa.4.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !55125
  %680 = ptrtoint ptr %_94.sroa.4.0._0.sroa_idx to i64, !dbg !55125
  %681 = lshr i64 %680, 3, !dbg !55125
  %682 = add i64 %681, 2147450880, !dbg !55125
  %683 = inttoptr i64 %682 to ptr, !dbg !55125
  %684 = load i8, ptr %683, align 1, !dbg !55125
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %684), !dbg !55125
  %685 = icmp ne i8 %684, 0, !dbg !55125
  br i1 %685, label %686, label %689, !dbg !55125

686:                                              ; preds = %679
  %687 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 111), align 1, !dbg !55125, !nosanitize !4116
  %688 = add i8 %687, 1, !dbg !55125
  store i8 %688, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 111), align 1, !dbg !55125, !nosanitize !4116
  call void @__asan_report_store8(i64 %680) #42, !dbg !55125
  unreachable, !dbg !55125

689:                                              ; preds = %679
  store i64 %spec.select243, ptr %_94.sroa.4.0._0.sroa_idx, align 8, !dbg !55125
  %_94.sroa.5.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !55125
  %690 = ptrtoint ptr %_94.sroa.5.0._0.sroa_idx to i64, !dbg !55125
  %691 = lshr i64 %690, 3, !dbg !55125
  %692 = add i64 %691, 2147450880, !dbg !55125
  %693 = inttoptr i64 %692 to ptr, !dbg !55125
  %694 = load i8, ptr %693, align 1, !dbg !55125
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %694), !dbg !55125
  %695 = icmp ne i8 %694, 0, !dbg !55125
  br i1 %695, label %696, label %699, !dbg !55125

696:                                              ; preds = %689
  %697 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 112), align 1, !dbg !55125, !nosanitize !4116
  %698 = add i8 %697, 1, !dbg !55125
  store i8 %698, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 112), align 1, !dbg !55125, !nosanitize !4116
  call void @__asan_report_store8(i64 %690) #42, !dbg !55125
  unreachable, !dbg !55125

699:                                              ; preds = %689
  store ptr %_77.sroa.0.0, ptr %_94.sroa.5.0._0.sroa_idx, align 8, !dbg !55125
  %_94.sroa.6.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 24, !dbg !55125
  %700 = ptrtoint ptr %_94.sroa.6.0._0.sroa_idx to i64, !dbg !55125
  %701 = lshr i64 %700, 3, !dbg !55125
  %702 = add i64 %701, 2147450880, !dbg !55125
  %703 = inttoptr i64 %702 to ptr, !dbg !55125
  %704 = load i8, ptr %703, align 1, !dbg !55125
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %704), !dbg !55125
  %705 = icmp ne i8 %704, 0, !dbg !55125
  br i1 %705, label %706, label %709, !dbg !55125

706:                                              ; preds = %699
  %707 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 113), align 1, !dbg !55125, !nosanitize !4116
  %708 = add i8 %707, 1, !dbg !55125
  store i8 %708, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 113), align 1, !dbg !55125, !nosanitize !4116
  call void @__asan_report_store8(i64 %700) #42, !dbg !55125
  unreachable, !dbg !55125

709:                                              ; preds = %699
  %710 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 114), align 1, !dbg !55125, !nosanitize !4116
  %711 = add i8 %710, 1, !dbg !55125
  store i8 %711, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 114), align 1, !dbg !55125, !nosanitize !4116
  store i64 %spec.select249, ptr %_94.sroa.6.0._0.sroa_idx, align 8, !dbg !55125
  br label %bb89, !dbg !54888

bb13:                                             ; preds = %bb5.i.bb13_crit_edge, %_RNvNvNtCs1K0wxfkMoe8_15spiral_protocol9handshake11parse_hello4take.exit.1.bb13_crit_edge
  %_15.sroa.6.1.lcssa = phi i64 [ %_15.sroa.6.1, %bb5.i.bb13_crit_edge ], [ %_16.sroa.6.1.1, %_RNvNvNtCs1K0wxfkMoe8_15spiral_protocol9handshake11parse_hello4take.exit.1.bb13_crit_edge ], !dbg !54987
  %_15.sroa.6.8.extract.trunc = trunc i64 %_15.sroa.6.1.lcssa to i8, !dbg !55126
  %_15.sroa.6.9.extract.shift = lshr i64 %_15.sroa.6.1.lcssa, 8, !dbg !55126
  %_15.sroa.6.9.extract.trunc = trunc i64 %_15.sroa.6.9.extract.shift to i8, !dbg !55126
  %712 = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !55127
  %713 = ptrtoint ptr %712 to i64, !dbg !55127
  %714 = lshr i64 %713, 3, !dbg !55127
  %715 = add i64 %714, 2147450880, !dbg !55127
  %716 = inttoptr i64 %715 to ptr, !dbg !55127
  %717 = load i8, ptr %716, align 1, !dbg !55127
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %717), !dbg !55127
  %718 = icmp ne i8 %717, 0, !dbg !55127
  br i1 %718, label %721, label %bb13._crit_edge, !dbg !55127, !prof !4264

bb13._crit_edge:                                  ; preds = %bb13
  %719 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 115), align 1, !dbg !55127, !nosanitize !4116
  %720 = add i8 %719, 1, !dbg !55127
  store i8 %720, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 115), align 1, !dbg !55127, !nosanitize !4116
  br label %730, !dbg !55127

721:                                              ; preds = %bb13
  %722 = and i64 %713, 7, !dbg !55127
  %723 = trunc i64 %722 to i8, !dbg !55127
  call void @__sanitizer_cov_trace_cmp1(i8 %723, i8 %717), !dbg !55127
  %724 = icmp sge i8 %723, %717, !dbg !55127
  br i1 %724, label %727, label %._crit_edge464, !dbg !55127

._crit_edge464:                                   ; preds = %721
  %725 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 116), align 1, !dbg !55127, !nosanitize !4116
  %726 = add i8 %725, 1, !dbg !55127
  store i8 %726, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 116), align 1, !dbg !55127, !nosanitize !4116
  br label %730, !dbg !55127

727:                                              ; preds = %721
  %728 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 117), align 1, !dbg !55127, !nosanitize !4116
  %729 = add i8 %728, 1, !dbg !55127
  store i8 %729, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 117), align 1, !dbg !55127, !nosanitize !4116
  call void @__asan_report_store1(i64 %713) #42, !dbg !55127
  unreachable

730:                                              ; preds = %._crit_edge464, %bb13._crit_edge
  store i8 %_15.sroa.6.8.extract.trunc, ptr %712, align 8, !dbg !55127, !alias.scope !55130
  %731 = getelementptr inbounds nuw i8, ptr %_0, i64 9, !dbg !55127
  %732 = ptrtoint ptr %731 to i64, !dbg !55127
  %733 = lshr i64 %732, 3, !dbg !55127
  %734 = add i64 %733, 2147450880, !dbg !55127
  %735 = inttoptr i64 %734 to ptr, !dbg !55127
  %736 = load i8, ptr %735, align 1, !dbg !55127
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %736), !dbg !55127
  %737 = icmp ne i8 %736, 0, !dbg !55127
  br i1 %737, label %740, label %._crit_edge465, !dbg !55127, !prof !4264

._crit_edge465:                                   ; preds = %730
  %738 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 118), align 1, !dbg !55127, !nosanitize !4116
  %739 = add i8 %738, 1, !dbg !55127
  store i8 %739, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 118), align 1, !dbg !55127, !nosanitize !4116
  br label %749, !dbg !55127

740:                                              ; preds = %730
  %741 = and i64 %732, 7, !dbg !55127
  %742 = trunc i64 %741 to i8, !dbg !55127
  call void @__sanitizer_cov_trace_cmp1(i8 %742, i8 %736), !dbg !55127
  %743 = icmp sge i8 %742, %736, !dbg !55127
  br i1 %743, label %746, label %._crit_edge466, !dbg !55127

._crit_edge466:                                   ; preds = %740
  %744 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 119), align 1, !dbg !55127, !nosanitize !4116
  %745 = add i8 %744, 1, !dbg !55127
  store i8 %745, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 119), align 1, !dbg !55127, !nosanitize !4116
  br label %749, !dbg !55127

746:                                              ; preds = %740
  %747 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 120), align 1, !dbg !55127, !nosanitize !4116
  %748 = add i8 %747, 1, !dbg !55127
  store i8 %748, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 120), align 1, !dbg !55127, !nosanitize !4116
  call void @__asan_report_store1(i64 %732) #42, !dbg !55127
  unreachable

749:                                              ; preds = %._crit_edge466, %._crit_edge465
  store i8 %_15.sroa.6.9.extract.trunc, ptr %731, align 1, !dbg !55127, !alias.scope !55130
  br label %bb86, !dbg !55133

bb12:                                             ; preds = %bb5.i
  call void @__sanitizer_cov_trace_const_cmp8(i64 0, i64 %_15.sroa.6.1), !dbg !54910
  %_22.not = icmp eq i64 %_15.sroa.6.1, 0, !dbg !54910
  br i1 %_22.not, label %bb12.panic24_crit_edge, label %bb15, !dbg !54910

bb12.panic24_crit_edge:                           ; preds = %bb12
  %750 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 121), align 1, !dbg !54910, !nosanitize !4116
  %751 = add i8 %750, 1, !dbg !54910
  store i8 %751, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 121), align 1, !dbg !54910, !nosanitize !4116
  br label %panic24, !dbg !54910

bb15:                                             ; preds = %bb12
  %752 = ptrtoint ptr %_16.sroa.0.0 to i64, !dbg !54910
  %753 = lshr i64 %752, 3, !dbg !54910
  %754 = add i64 %753, 2147450880, !dbg !54910
  %755 = inttoptr i64 %754 to ptr, !dbg !54910
  %756 = load i8, ptr %755, align 1, !dbg !54910
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %756), !dbg !54910
  %757 = icmp ne i8 %756, 0, !dbg !54910
  br i1 %757, label %760, label %bb15._crit_edge, !dbg !54910, !prof !4264

bb15._crit_edge:                                  ; preds = %bb15
  %758 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 122), align 1, !dbg !54910, !nosanitize !4116
  %759 = add i8 %758, 1, !dbg !54910
  store i8 %759, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 122), align 1, !dbg !54910, !nosanitize !4116
  br label %769, !dbg !54910

760:                                              ; preds = %bb15
  %761 = and i64 %752, 7, !dbg !54910
  %762 = trunc i64 %761 to i8, !dbg !54910
  call void @__sanitizer_cov_trace_cmp1(i8 %762, i8 %756), !dbg !54910
  %763 = icmp sge i8 %762, %756, !dbg !54910
  br i1 %763, label %766, label %._crit_edge467, !dbg !54910

._crit_edge467:                                   ; preds = %760
  %764 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 123), align 1, !dbg !54910, !nosanitize !4116
  %765 = add i8 %764, 1, !dbg !54910
  store i8 %765, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 123), align 1, !dbg !54910, !nosanitize !4116
  br label %769, !dbg !54910

766:                                              ; preds = %760
  %767 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 124), align 1, !dbg !54910, !nosanitize !4116
  %768 = add i8 %767, 1, !dbg !54910
  store i8 %768, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 124), align 1, !dbg !54910, !nosanitize !4116
  call void @__asan_report_load1(i64 %752) #42, !dbg !54910
  unreachable

769:                                              ; preds = %._crit_edge467, %bb15._crit_edge
  %_14 = load i8, ptr %_16.sroa.0.0, align 1, !dbg !54910, !noundef !4116
  %770 = zext i8 %_14 to i64, !dbg !54910
  %771 = add i8 %_14, -1, !dbg !54911
  call void @__sanitizer_cov_trace_const_cmp1(i8 8, i8 %771), !dbg !54911
  %spec.select237 = icmp ult i8 %771, 8, !dbg !54911
  br i1 %spec.select237, label %bb20.preheader, label %.bb18_crit_edge468, !dbg !54915

.bb18_crit_edge468:                               ; preds = %769
  %772 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 125), align 1, !dbg !54915, !nosanitize !4116
  %773 = add i8 %772, 1, !dbg !54915
  store i8 %773, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 125), align 1, !dbg !54915, !nosanitize !4116
  br label %bb18, !dbg !54915

bb20.preheader:                                   ; preds = %769
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %_14), !dbg !54916
  %_0.i.i.i162287.not = icmp eq i8 %_14, 0, !dbg !54916
  br i1 %_0.i.i.i162287.not, label %bb20.preheader.bb35_crit_edge, label %bb20.preheader.bb22_crit_edge, !dbg !54923

bb20.preheader.bb22_crit_edge:                    ; preds = %bb20.preheader
  br label %bb22, !dbg !54923

bb20.preheader.bb35_crit_edge:                    ; preds = %bb20.preheader
  %774 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 126), align 1, !dbg !54923, !nosanitize !4116
  %775 = add i8 %774, 1, !dbg !54923
  store i8 %775, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 126), align 1, !dbg !54923, !nosanitize !4116
  br label %bb35, !dbg !54923

panic24:                                          ; preds = %bb12.panic24_crit_edge, %bb12.1.panic24_crit_edge
  call void @__asan_handle_no_return(), !dbg !54910
; call core::panicking::panic_bounds_check
  tail call void @_RNvNtCshZBO5P2NUJi_4core9panicking18panic_bounds_check(i64 noundef 0, i64 noundef 0, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_c3e3cea0368c35de63434fc4b0d26070) #43, !dbg !54910
  unreachable, !dbg !54910

bb18:                                             ; preds = %.bb18_crit_edge468, %.bb18_crit_edge
  %776 = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !55135
  %777 = ptrtoint ptr %776 to i64, !dbg !55135
  %778 = lshr i64 %777, 3, !dbg !55135
  %779 = add i64 %778, 2147450880, !dbg !55135
  %780 = inttoptr i64 %779 to ptr, !dbg !55135
  %781 = load i8, ptr %780, align 1, !dbg !55135
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %781), !dbg !55135
  %782 = icmp ne i8 %781, 0, !dbg !55135
  br i1 %782, label %785, label %bb18._crit_edge, !dbg !55135, !prof !4264

bb18._crit_edge:                                  ; preds = %bb18
  %783 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 127), align 1, !dbg !55135, !nosanitize !4116
  %784 = add i8 %783, 1, !dbg !55135
  store i8 %784, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 127), align 1, !dbg !55135, !nosanitize !4116
  br label %794, !dbg !55135

785:                                              ; preds = %bb18
  %786 = and i64 %777, 7, !dbg !55135
  %787 = trunc i64 %786 to i8, !dbg !55135
  call void @__sanitizer_cov_trace_cmp1(i8 %787, i8 %781), !dbg !55135
  %788 = icmp sge i8 %787, %781, !dbg !55135
  br i1 %788, label %791, label %._crit_edge469, !dbg !55135

._crit_edge469:                                   ; preds = %785
  %789 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 128), align 1, !dbg !55135, !nosanitize !4116
  %790 = add i8 %789, 1, !dbg !55135
  store i8 %790, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 128), align 1, !dbg !55135, !nosanitize !4116
  br label %794, !dbg !55135

791:                                              ; preds = %785
  %792 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 129), align 1, !dbg !55135, !nosanitize !4116
  %793 = add i8 %792, 1, !dbg !55135
  store i8 %793, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 129), align 1, !dbg !55135, !nosanitize !4116
  call void @__asan_report_store1(i64 %777) #42, !dbg !55135
  unreachable

794:                                              ; preds = %._crit_edge469, %bb18._crit_edge
  store i8 0, ptr %776, align 8, !dbg !55135
  br label %bb86, !dbg !55136

bb86:                                             ; preds = %942, %876, %838, %749, %794
  %795 = ptrtoint ptr %_0 to i64, !dbg !55138
  %796 = lshr i64 %795, 3, !dbg !55138
  %797 = add i64 %796, 2147450880, !dbg !55138
  %798 = inttoptr i64 %797 to ptr, !dbg !55138
  %799 = load i8, ptr %798, align 1, !dbg !55138
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %799), !dbg !55138
  %800 = icmp ne i8 %799, 0, !dbg !55138
  br i1 %800, label %801, label %804, !dbg !55138

801:                                              ; preds = %bb86
  %802 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 130), align 1, !dbg !55138, !nosanitize !4116
  %803 = add i8 %802, 1, !dbg !55138
  store i8 %803, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 130), align 1, !dbg !55138, !nosanitize !4116
  call void @__asan_report_store8(i64 %795) #42, !dbg !55138
  unreachable, !dbg !55138

804:                                              ; preds = %bb86
  %805 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 131), align 1, !dbg !55138, !nosanitize !4116
  %806 = add i8 %805, 1, !dbg !55138
  store i8 %806, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 131), align 1, !dbg !55138, !nosanitize !4116
  store ptr null, ptr %_0, align 8, !dbg !55138
  br label %bb89, !dbg !54996

bb22:                                             ; preds = %bb33.bb22_crit_edge, %bb20.preheader.bb22_crit_edge
  %spec.select238294 = phi i64 [ %spec.select238, %bb33.bb22_crit_edge ], [ 1, %bb20.preheader.bb22_crit_edge ]
  %found.sroa.0.0293 = phi i1 [ %921, %bb33.bb22_crit_edge ], [ false, %bb20.preheader.bb22_crit_edge ]
  %last.sroa.0.0292 = phi i16 [ %918, %bb33.bb22_crit_edge ], [ 0, %bb20.preheader.bb22_crit_edge ]
  %i.sroa.0.1291 = phi i64 [ %i.sroa.0.7, %bb33.bb22_crit_edge ], [ %i.sroa.0.2, %bb20.preheader.bb22_crit_edge ]
  %_37.sroa.6.1289 = phi i64 [ %_37.sroa.6.2, %bb33.bb22_crit_edge ], [ undef, %bb20.preheader.bb22_crit_edge ]
  %_4.0.i.i165 = add i64 %i.sroa.0.1291, 2, !dbg !54924
  call void @__sanitizer_cov_trace_const_cmp8(i64 -3, i64 %i.sroa.0.1291), !dbg !54924
  %_4.1.i.not.i166 = icmp ugt i64 %i.sroa.0.1291, -3, !dbg !54924
  br i1 %_4.1.i.not.i166, label %bb6.i176, label %bb5.i167, !dbg !54927

bb6.i176:                                         ; preds = %bb22
  %807 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 132), align 1, !dbg !54944, !nosanitize !4116
  %808 = add i8 %807, 1, !dbg !54944
  store i8 %808, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 132), align 1, !dbg !54944, !nosanitize !4116
  %_37.sroa.6.8.insert.mask210 = and i64 %_37.sroa.6.1289, -256, !dbg !54944
  br label %_RNvNvNtCs1K0wxfkMoe8_15spiral_protocol9handshake11parse_hello4take.exit177, !dbg !54947

bb5.i167:                                         ; preds = %bb22
  call void @__sanitizer_cov_trace_cmp8(i64 %_4.0.i.i165, i64 %p.1), !dbg !54880
  %_7.not.i.i.i168 = icmp ugt i64 %_4.0.i.i165, %p.1
  %.n.i169 = select i1 %_7.not.i.i.i168, i64 0, i64 2, !dbg !54928
  br i1 %_7.not.i.i.i168, label %bb12.i172, label %bb11.i170, !dbg !54931

bb12.i172:                                        ; preds = %bb5.i167
  %809 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 133), align 1, !dbg !54937, !nosanitize !4116
  %810 = add i8 %809, 1, !dbg !54937
  store i8 %810, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 133), align 1, !dbg !54937, !nosanitize !4116
  %_37.sroa.6.8.insert.mask = and i64 %_37.sroa.6.1289, -65536, !dbg !54937
  %_37.sroa.6.8.insert.insert = or disjoint i64 %.n.i169, %_37.sroa.6.8.insert.mask, !dbg !54937
  br label %_RNvNvNtCs1K0wxfkMoe8_15spiral_protocol9handshake11parse_hello4take.exit177, !dbg !54942

bb11.i170:                                        ; preds = %bb5.i167
  %811 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 134), align 1, !dbg !54932, !nosanitize !4116
  %812 = add i8 %811, 1, !dbg !54932
  store i8 %812, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 134), align 1, !dbg !54932, !nosanitize !4116
  %_15.i.i.i171 = getelementptr inbounds nuw i8, ptr %p.0, i64 %i.sroa.0.1291, !dbg !54932
  br label %_RNvNvNtCs1K0wxfkMoe8_15spiral_protocol9handshake11parse_hello4take.exit177, !dbg !54936

_RNvNvNtCs1K0wxfkMoe8_15spiral_protocol9handshake11parse_hello4take.exit177: ; preds = %bb6.i176, %bb12.i172, %bb11.i170
  %_37.sroa.6.2 = phi i64 [ %_37.sroa.6.8.insert.mask210, %bb6.i176 ], [ %_37.sroa.6.8.insert.insert, %bb12.i172 ], [ %.n.i169, %bb11.i170 ], !dbg !54949
  %_37.sroa.0.0 = phi ptr [ null, %bb6.i176 ], [ null, %bb12.i172 ], [ %_15.i.i.i171, %bb11.i170 ], !dbg !54949
  %i.sroa.0.7 = phi i64 [ %i.sroa.0.1291, %bb6.i176 ], [ %i.sroa.0.1291, %bb12.i172 ], [ %_4.0.i.i165, %bb11.i170 ], !dbg !54880
  %813 = icmp eq ptr %_37.sroa.0.0, null, !dbg !54950
  %814 = and i64 %_37.sroa.6.2, 65535, !dbg !54953
  %_36.sroa.6.2 = select i1 %813, i64 %814, i64 %_37.sroa.6.2, !dbg !54953
  %815 = icmp eq ptr %_37.sroa.0.0, null, !dbg !54954
  br i1 %815, label %_RNvNvNtCs1K0wxfkMoe8_15spiral_protocol9handshake11parse_hello4take.exit177.bb27_crit_edge, label %bb26, !dbg !54954

_RNvNvNtCs1K0wxfkMoe8_15spiral_protocol9handshake11parse_hello4take.exit177.bb27_crit_edge: ; preds = %_RNvNvNtCs1K0wxfkMoe8_15spiral_protocol9handshake11parse_hello4take.exit177
  %816 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 135), align 1, !dbg !54954, !nosanitize !4116
  %817 = add i8 %816, 1, !dbg !54954
  store i8 %817, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 135), align 1, !dbg !54954, !nosanitize !4116
  br label %bb27, !dbg !54954

bb23:                                             ; preds = %bb33
  br i1 %921, label %bb5, label %bb23.bb35_crit_edge, !dbg !54979

bb23.bb35_crit_edge:                              ; preds = %bb23
  %818 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 136), align 1, !dbg !54979, !nosanitize !4116
  %819 = add i8 %818, 1, !dbg !54979
  store i8 %819, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 136), align 1, !dbg !54979, !nosanitize !4116
  br label %bb35, !dbg !54979

bb35:                                             ; preds = %bb23.bb35_crit_edge, %bb20.preheader.bb35_crit_edge, %bb23.1.bb35_crit_edge, %bb20.preheader.1.bb35_crit_edge
  %820 = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !55139
  %821 = ptrtoint ptr %820 to i64, !dbg !55139
  %822 = lshr i64 %821, 3, !dbg !55139
  %823 = add i64 %822, 2147450880, !dbg !55139
  %824 = inttoptr i64 %823 to ptr, !dbg !55139
  %825 = load i8, ptr %824, align 1, !dbg !55139
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %825), !dbg !55139
  %826 = icmp ne i8 %825, 0, !dbg !55139
  br i1 %826, label %829, label %bb35._crit_edge, !dbg !55139, !prof !4264

bb35._crit_edge:                                  ; preds = %bb35
  %827 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 137), align 1, !dbg !55139, !nosanitize !4116
  %828 = add i8 %827, 1, !dbg !55139
  store i8 %828, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 137), align 1, !dbg !55139, !nosanitize !4116
  br label %838, !dbg !55139

829:                                              ; preds = %bb35
  %830 = and i64 %821, 7, !dbg !55139
  %831 = trunc i64 %830 to i8, !dbg !55139
  call void @__sanitizer_cov_trace_cmp1(i8 %831, i8 %825), !dbg !55139
  %832 = icmp sge i8 %831, %825, !dbg !55139
  br i1 %832, label %835, label %._crit_edge470, !dbg !55139

._crit_edge470:                                   ; preds = %829
  %833 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 138), align 1, !dbg !55139, !nosanitize !4116
  %834 = add i8 %833, 1, !dbg !55139
  store i8 %834, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 138), align 1, !dbg !55139, !nosanitize !4116
  br label %838, !dbg !55139

835:                                              ; preds = %829
  %836 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 139), align 1, !dbg !55139, !nosanitize !4116
  %837 = add i8 %836, 1, !dbg !55139
  store i8 %837, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 139), align 1, !dbg !55139, !nosanitize !4116
  call void @__asan_report_store1(i64 %821) #42, !dbg !55139
  unreachable

838:                                              ; preds = %._crit_edge470, %bb35._crit_edge
  store i8 0, ptr %820, align 8, !dbg !55139
  br label %bb86, !dbg !55140

bb27:                                             ; preds = %_RNvNvNtCs1K0wxfkMoe8_15spiral_protocol9handshake11parse_hello4take.exit177.bb27_crit_edge, %_RNvNvNtCs1K0wxfkMoe8_15spiral_protocol9handshake11parse_hello4take.exit177.1.bb27_crit_edge
  %_36.sroa.6.2.lcssa = phi i64 [ %_36.sroa.6.2, %_RNvNvNtCs1K0wxfkMoe8_15spiral_protocol9handshake11parse_hello4take.exit177.bb27_crit_edge ], [ %_36.sroa.6.2.1, %_RNvNvNtCs1K0wxfkMoe8_15spiral_protocol9handshake11parse_hello4take.exit177.1.bb27_crit_edge ], !dbg !54953
  %_36.sroa.6.8.extract.trunc = trunc i64 %_36.sroa.6.2.lcssa to i8, !dbg !55142
  %_36.sroa.6.9.extract.shift = lshr i64 %_36.sroa.6.2.lcssa, 8, !dbg !55142
  %_36.sroa.6.9.extract.trunc = trunc i64 %_36.sroa.6.9.extract.shift to i8, !dbg !55142
  %839 = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !55143
  %840 = ptrtoint ptr %839 to i64, !dbg !55143
  %841 = lshr i64 %840, 3, !dbg !55143
  %842 = add i64 %841, 2147450880, !dbg !55143
  %843 = inttoptr i64 %842 to ptr, !dbg !55143
  %844 = load i8, ptr %843, align 1, !dbg !55143
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %844), !dbg !55143
  %845 = icmp ne i8 %844, 0, !dbg !55143
  br i1 %845, label %848, label %bb27._crit_edge, !dbg !55143, !prof !4264

bb27._crit_edge:                                  ; preds = %bb27
  %846 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 140), align 1, !dbg !55143, !nosanitize !4116
  %847 = add i8 %846, 1, !dbg !55143
  store i8 %847, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 140), align 1, !dbg !55143, !nosanitize !4116
  br label %857, !dbg !55143

848:                                              ; preds = %bb27
  %849 = and i64 %840, 7, !dbg !55143
  %850 = trunc i64 %849 to i8, !dbg !55143
  call void @__sanitizer_cov_trace_cmp1(i8 %850, i8 %844), !dbg !55143
  %851 = icmp sge i8 %850, %844, !dbg !55143
  br i1 %851, label %854, label %._crit_edge471, !dbg !55143

._crit_edge471:                                   ; preds = %848
  %852 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 141), align 1, !dbg !55143, !nosanitize !4116
  %853 = add i8 %852, 1, !dbg !55143
  store i8 %853, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 141), align 1, !dbg !55143, !nosanitize !4116
  br label %857, !dbg !55143

854:                                              ; preds = %848
  %855 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 142), align 1, !dbg !55143, !nosanitize !4116
  %856 = add i8 %855, 1, !dbg !55143
  store i8 %856, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 142), align 1, !dbg !55143, !nosanitize !4116
  call void @__asan_report_store1(i64 %840) #42, !dbg !55143
  unreachable

857:                                              ; preds = %._crit_edge471, %bb27._crit_edge
  store i8 %_36.sroa.6.8.extract.trunc, ptr %839, align 8, !dbg !55143, !alias.scope !55146
  %858 = getelementptr inbounds nuw i8, ptr %_0, i64 9, !dbg !55143
  %859 = ptrtoint ptr %858 to i64, !dbg !55143
  %860 = lshr i64 %859, 3, !dbg !55143
  %861 = add i64 %860, 2147450880, !dbg !55143
  %862 = inttoptr i64 %861 to ptr, !dbg !55143
  %863 = load i8, ptr %862, align 1, !dbg !55143
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %863), !dbg !55143
  %864 = icmp ne i8 %863, 0, !dbg !55143
  br i1 %864, label %867, label %._crit_edge472, !dbg !55143, !prof !4264

._crit_edge472:                                   ; preds = %857
  %865 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 143), align 1, !dbg !55143, !nosanitize !4116
  %866 = add i8 %865, 1, !dbg !55143
  store i8 %866, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 143), align 1, !dbg !55143, !nosanitize !4116
  br label %876, !dbg !55143

867:                                              ; preds = %857
  %868 = and i64 %859, 7, !dbg !55143
  %869 = trunc i64 %868 to i8, !dbg !55143
  call void @__sanitizer_cov_trace_cmp1(i8 %869, i8 %863), !dbg !55143
  %870 = icmp sge i8 %869, %863, !dbg !55143
  br i1 %870, label %873, label %._crit_edge473, !dbg !55143

._crit_edge473:                                   ; preds = %867
  %871 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 144), align 1, !dbg !55143, !nosanitize !4116
  %872 = add i8 %871, 1, !dbg !55143
  store i8 %872, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 144), align 1, !dbg !55143, !nosanitize !4116
  br label %876, !dbg !55143

873:                                              ; preds = %867
  %874 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 145), align 1, !dbg !55143, !nosanitize !4116
  %875 = add i8 %874, 1, !dbg !55143
  store i8 %875, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 145), align 1, !dbg !55143, !nosanitize !4116
  call void @__asan_report_store1(i64 %859) #42, !dbg !55143
  unreachable

876:                                              ; preds = %._crit_edge473, %._crit_edge472
  store i8 %_36.sroa.6.9.extract.trunc, ptr %858, align 1, !dbg !55143, !alias.scope !55146
  br label %bb86, !dbg !55149

bb26:                                             ; preds = %_RNvNvNtCs1K0wxfkMoe8_15spiral_protocol9handshake11parse_hello4take.exit177
  call void @__sanitizer_cov_trace_const_cmp8(i64 2, i64 %_36.sroa.6.2), !dbg !54955
  %_4.i.i184.not = icmp eq i64 %_36.sroa.6.2, 2, !dbg !54955
  br i1 %_4.i.i184.not, label %bb1.i.i191, label %bb26.bb2.i_crit_edge, !dbg !54955

bb26.bb2.i_crit_edge:                             ; preds = %bb26
  %877 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 146), align 1, !dbg !54955, !nosanitize !4116
  %878 = add i8 %877, 1, !dbg !54955
  store i8 %878, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 146), align 1, !dbg !54955, !nosanitize !4116
  br label %bb2.i, !dbg !54955

bb1.i.i191:                                       ; preds = %bb26
  %879 = ptrtoint ptr %_37.sroa.0.0 to i64, !dbg !54963
  %880 = add i64 %879, 1, !dbg !54963
  %881 = inttoptr i64 %880 to ptr, !dbg !54963
  %882 = ptrtoint ptr %_37.sroa.0.0 to i64, !dbg !54963
  %883 = lshr i64 %882, 3, !dbg !54963
  %884 = add i64 %883, 2147450880, !dbg !54963
  %885 = inttoptr i64 %884 to ptr, !dbg !54963
  %886 = load i8, ptr %885, align 1, !dbg !54963
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %886), !dbg !54963
  %887 = icmp ne i8 %886, 0, !dbg !54963
  br i1 %887, label %890, label %bb1.i.i191._crit_edge, !dbg !54963, !prof !4264

bb1.i.i191._crit_edge:                            ; preds = %bb1.i.i191
  %888 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 147), align 1, !dbg !54963, !nosanitize !4116
  %889 = add i8 %888, 1, !dbg !54963
  store i8 %889, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 147), align 1, !dbg !54963, !nosanitize !4116
  br label %899, !dbg !54963

890:                                              ; preds = %bb1.i.i191
  %891 = and i64 %882, 7, !dbg !54963
  %892 = trunc i64 %891 to i8, !dbg !54963
  call void @__sanitizer_cov_trace_cmp1(i8 %892, i8 %886), !dbg !54963
  %893 = icmp sge i8 %892, %886, !dbg !54963
  br i1 %893, label %896, label %._crit_edge474, !dbg !54963

._crit_edge474:                                   ; preds = %890
  %894 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 148), align 1, !dbg !54963, !nosanitize !4116
  %895 = add i8 %894, 1, !dbg !54963
  store i8 %895, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 148), align 1, !dbg !54963, !nosanitize !4116
  br label %899, !dbg !54963

896:                                              ; preds = %890
  %897 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 149), align 1, !dbg !54963, !nosanitize !4116
  %898 = add i8 %897, 1, !dbg !54963
  store i8 %898, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 149), align 1, !dbg !54963, !nosanitize !4116
  call void @__asan_report_load_n(i64 %882, i64 2) #42, !dbg !54963
  unreachable

899:                                              ; preds = %._crit_edge474, %bb1.i.i191._crit_edge
  %900 = ptrtoint ptr %881 to i64, !dbg !54963
  %901 = lshr i64 %900, 3, !dbg !54963
  %902 = add i64 %901, 2147450880, !dbg !54963
  %903 = inttoptr i64 %902 to ptr, !dbg !54963
  %904 = load i8, ptr %903, align 1, !dbg !54963
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %904), !dbg !54963
  %905 = icmp ne i8 %904, 0, !dbg !54963
  br i1 %905, label %908, label %._crit_edge475, !dbg !54963, !prof !4264

._crit_edge475:                                   ; preds = %899
  %906 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 150), align 1, !dbg !54963, !nosanitize !4116
  %907 = add i8 %906, 1, !dbg !54963
  store i8 %907, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 150), align 1, !dbg !54963, !nosanitize !4116
  br label %917, !dbg !54963

908:                                              ; preds = %899
  %909 = and i64 %900, 7, !dbg !54963
  %910 = trunc i64 %909 to i8, !dbg !54963
  call void @__sanitizer_cov_trace_cmp1(i8 %910, i8 %904), !dbg !54963
  %911 = icmp sge i8 %910, %904, !dbg !54963
  br i1 %911, label %914, label %._crit_edge476, !dbg !54963

._crit_edge476:                                   ; preds = %908
  %912 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 151), align 1, !dbg !54963, !nosanitize !4116
  %913 = add i8 %912, 1, !dbg !54963
  store i8 %913, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 151), align 1, !dbg !54963, !nosanitize !4116
  br label %917, !dbg !54963

914:                                              ; preds = %908
  %915 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 152), align 1, !dbg !54963, !nosanitize !4116
  %916 = add i8 %915, 1, !dbg !54963
  store i8 %916, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 152), align 1, !dbg !54963, !nosanitize !4116
  call void @__asan_report_load_n(i64 %900, i64 2) #42, !dbg !54963
  unreachable

917:                                              ; preds = %._crit_edge476, %._crit_edge475
  %v.sroa.0.0.copyload.i.i192 = load i16, ptr %_37.sroa.0.0, align 1, !dbg !54963, !alias.scope !54965
  %918 = tail call i16 @llvm.bswap.i16(i16 %v.sroa.0.0.copyload.i.i192), !dbg !54970
  call void @__sanitizer_cov_trace_cmp2(i16 %918, i16 %last.sroa.0.0292), !dbg !54974
  %_42.not = icmp ugt i16 %918, %last.sroa.0.0292, !dbg !54974
  br i1 %_42.not, label %bb33, label %.bb32_crit_edge477, !dbg !54974

.bb32_crit_edge477:                               ; preds = %917
  %919 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 153), align 1, !dbg !54974, !nosanitize !4116
  %920 = add i8 %919, 1, !dbg !54974
  store i8 %920, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 153), align 1, !dbg !54974, !nosanitize !4116
  br label %bb32, !dbg !54974

bb2.i:                                            ; preds = %bb26.bb2.i_crit_edge, %bb26.1.bb2.i_crit_edge
  call void @__asan_handle_no_return(), !dbg !55151
; call core::result::unwrap_failed::<core::array::TryFromSliceError>
  tail call void @_RINvNtCshZBO5P2NUJi_4core6result13unwrap_failedNtNtB4_5array17TryFromSliceErrorECs7jJvS58pafZ_4ring(ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) @alloc_00ae4b301f7fab8ac9617c03fcbd7274, i64 noundef 43, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_6ee38266fea7fbf6f1f069493332811d) #43, !dbg !55151
  unreachable, !dbg !55151

bb33:                                             ; preds = %917
  call void @__sanitizer_cov_trace_const_cmp2(i16 256, i16 %v.sroa.0.0.copyload.i.i192), !dbg !54976
  %_43 = icmp eq i16 %v.sroa.0.0.copyload.i.i192, 256, !dbg !54976
  %921 = or i1 %found.sroa.0.0293, %_43, !dbg !54977
  call void @__sanitizer_cov_trace_cmp8(i64 %spec.select238294, i64 %770), !dbg !54916
  %_0.i.i.i162 = icmp samesign ult i64 %spec.select238294, %770, !dbg !54916
  %_0.i1.i.i = zext i1 %_0.i.i.i162 to i64, !dbg !54978
  %spec.select238 = add nuw i64 %spec.select238294, %_0.i1.i.i, !dbg !54978
  br i1 %_0.i.i.i162, label %bb33.bb22_crit_edge, label %bb23, !dbg !54923

bb33.bb22_crit_edge:                              ; preds = %bb33
  %922 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 154), align 1, !dbg !54923, !nosanitize !4116
  %923 = add i8 %922, 1, !dbg !54923
  store i8 %923, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 154), align 1, !dbg !54923, !nosanitize !4116
  br label %bb22, !dbg !54923

bb32:                                             ; preds = %.bb32_crit_edge477, %.bb32_crit_edge
  %924 = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !55153
  %925 = ptrtoint ptr %924 to i64, !dbg !55153
  %926 = lshr i64 %925, 3, !dbg !55153
  %927 = add i64 %926, 2147450880, !dbg !55153
  %928 = inttoptr i64 %927 to ptr, !dbg !55153
  %929 = load i8, ptr %928, align 1, !dbg !55153
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %929), !dbg !55153
  %930 = icmp ne i8 %929, 0, !dbg !55153
  br i1 %930, label %933, label %bb32._crit_edge, !dbg !55153, !prof !4264

bb32._crit_edge:                                  ; preds = %bb32
  %931 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 155), align 1, !dbg !55153, !nosanitize !4116
  %932 = add i8 %931, 1, !dbg !55153
  store i8 %932, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 155), align 1, !dbg !55153, !nosanitize !4116
  br label %942, !dbg !55153

933:                                              ; preds = %bb32
  %934 = and i64 %925, 7, !dbg !55153
  %935 = trunc i64 %934 to i8, !dbg !55153
  call void @__sanitizer_cov_trace_cmp1(i8 %935, i8 %929), !dbg !55153
  %936 = icmp sge i8 %935, %929, !dbg !55153
  br i1 %936, label %939, label %._crit_edge478, !dbg !55153

._crit_edge478:                                   ; preds = %933
  %937 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 156), align 1, !dbg !55153, !nosanitize !4116
  %938 = add i8 %937, 1, !dbg !55153
  store i8 %938, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 156), align 1, !dbg !55153, !nosanitize !4116
  br label %942, !dbg !55153

939:                                              ; preds = %933
  %940 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 157), align 1, !dbg !55153, !nosanitize !4116
  %941 = add i8 %940, 1, !dbg !55153
  store i8 %941, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2156, i64 0, i64 157), align 1, !dbg !55153, !nosanitize !4116
  call void @__asan_report_store1(i64 %925) #42, !dbg !55153
  unreachable

942:                                              ; preds = %._crit_edge478, %bb32._crit_edge
  store i8 0, ptr %924, align 8, !dbg !55153
  br label %bb86, !dbg !55154
}

; Verified production function: validate_identity
define { i8, i8 } @_RNvNtCs1K0wxfkMoe8_15spiral_protocol9handshake17validate_identity(ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) %name.0, i64 noundef %name.1, ptr noalias nofree noundef nonnull readonly captures(address) %service.0, i64 noundef %service.1) unnamed_addr #0 comdat personality ptr @rust_eh_personality !dbg !55207 !guid !55208 {
start:
  %dst.i19.i.i.i = alloca [16 x i8], align 16
  %dst.i10.i.i.i = alloca [16 x i8], align 16
  %dst.i1.i.i.i = alloca [16 x i8], align 16
  %dst.i.i.i.i = alloca [16 x i8], align 16
  %asan_local_stack_base = alloca i64, align 8
  %0 = load i8, ptr @__sancov_gen_.2162, align 1, !dbg !55209, !nosanitize !4116
  %1 = add i8 %0, 1, !dbg !55209
  store i8 %1, ptr @__sancov_gen_.2162, align 1, !dbg !55209, !nosanitize !4116
  %2 = load i32, ptr @__asan_option_detect_stack_use_after_return, align 4
  call void @__sanitizer_cov_trace_const_cmp4(i32 0, i32 %2), !dbg !55210
  %3 = icmp ne i32 %2, 0
  br i1 %3, label %6, label %start._crit_edge

start._crit_edge:                                 ; preds = %start
  %4 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 1), align 1, !dbg !55210, !nosanitize !4116
  %5 = add i8 %4, 1, !dbg !55210
  store i8 %5, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 1), align 1, !dbg !55210, !nosanitize !4116
  br label %10

6:                                                ; preds = %start
  %7 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 2), align 1, !dbg !55210, !nosanitize !4116
  %8 = add i8 %7, 1, !dbg !55210
  store i8 %8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 2), align 1, !dbg !55210, !nosanitize !4116
  %9 = call i64 @__asan_stack_malloc_1(i64 96)
  br label %10

10:                                               ; preds = %start._crit_edge, %6
  %11 = phi i64 [ 0, %start._crit_edge ], [ %9, %6 ]
  %12 = inttoptr i64 %11 to ptr
  call void @__sanitizer_cov_trace_const_cmp8(i64 0, i64 %11), !dbg !55210
  %13 = icmp eq i64 %11, 0
  br i1 %13, label %16, label %._crit_edge

._crit_edge:                                      ; preds = %10
  %14 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 3), align 1, !dbg !55210, !nosanitize !4116
  %15 = add i8 %14, 1, !dbg !55210
  store i8 %15, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 3), align 1, !dbg !55210, !nosanitize !4116
  br label %19

16:                                               ; preds = %10
  %17 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 4), align 1, !dbg !55210, !nosanitize !4116
  %18 = add i8 %17, 1, !dbg !55210
  store i8 %18, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 4), align 1, !dbg !55210, !nosanitize !4116
  %MyAlloca = alloca i8, i64 96, align 32
  br label %19

19:                                               ; preds = %._crit_edge, %16
  %20 = phi ptr [ %12, %._crit_edge ], [ %MyAlloca, %16 ]
  store ptr %20, ptr %asan_local_stack_base, align 8
  %21 = getelementptr i8, ptr %20, i64 32
  store i64 1102416563, ptr %20, align 8
  %22 = getelementptr i8, ptr %20, i64 8
  store i64 ptrtoint (ptr @___asan_gen_stack.245 to i64), ptr %22, align 8
  %23 = getelementptr i8, ptr %20, i64 16
  store i64 ptrtoint (ptr @_RNvNtCs1K0wxfkMoe8_15spiral_protocol9handshake17validate_identity to i64), ptr %23, align 8
  %24 = ptrtoint ptr %20 to i64
  %25 = lshr i64 %24, 3
  %26 = add i64 %25, 2147450880
  %27 = add i64 %26, 0
  %28 = inttoptr i64 %27 to ptr
  store i64 -866669180174077455, ptr %28, align 1
  %29 = add i64 %26, 8
  %30 = inttoptr i64 %29 to ptr
  store i32 -202116109, ptr %30, align 1
  %31 = add i64 %name.1, -254, !dbg !55211
  call void @__sanitizer_cov_trace_const_cmp8(i64 -253, i64 %31), !dbg !55211
  %or.cond = icmp ult i64 %31, -253, !dbg !55211
  br i1 %or.cond, label %.bb32_crit_edge, label %bb5, !dbg !55211

.bb32_crit_edge:                                  ; preds = %19
  %32 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 5), align 1, !dbg !55211, !nosanitize !4116
  %33 = add i8 %32, 1, !dbg !55211
  store i8 %33, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 5), align 1, !dbg !55211, !nosanitize !4116
  br label %bb32, !dbg !55211

bb5:                                              ; preds = %19
  tail call void @llvm.experimental.noalias.scope.decl(metadata !55213), !dbg !55216
  tail call void @llvm.experimental.noalias.scope.decl(metadata !55217), !dbg !55220
  call void @__sanitizer_cov_trace_const_cmp8(i64 64, i64 %name.1), !dbg !55231
  %_2.i.i = icmp samesign ult i64 %name.1, 64, !dbg !55231
  br i1 %_2.i.i, label %bb1.i.i, label %bb7.i.i, !dbg !55231

bb7.i.i:                                          ; preds = %bb5
  tail call void @llvm.experimental.noalias.scope.decl(metadata !55236), !dbg !55239
  %new_len2.i.i.i.i = and i64 %name.1, 192, !dbg !55240
  %data.i.i.i.i.i = getelementptr inbounds nuw i8, ptr %name.0, i64 %new_len2.i.i.i.i, !dbg !55254
  %len.i.i.i.i.i = and i64 %name.1, 63, !dbg !55264
  %_7.i6.i.i.i.i.i = ptrtoint ptr %dst.i.i.i.i to i64
  %_7.i6.i.i3.i.i.i = ptrtoint ptr %dst.i1.i.i.i to i64
  %_7.i6.i.i12.i.i.i = ptrtoint ptr %dst.i10.i.i.i to i64
  %_7.i6.i.i21.i.i.i = ptrtoint ptr %dst.i19.i.i.i to i64
  br label %bb16.i.i.i, !dbg !55265

bb2.i.i.i:                                        ; preds = %_RNvNtNtNtCshZBO5P2NUJi_4core9core_arch3x864sse215__mm_loadu_si128.exit27.i.i.i
  %_50.i.i.i = getelementptr inbounds nuw i8, ptr %iter.sroa.0.034.i.i.i, i64 64, !dbg !55272
  %_41.i.i.i = icmp eq ptr %_50.i.i.i, %data.i.i.i.i.i, !dbg !55275
  br i1 %_41.i.i.i, label %bb15.i.i.i, label %bb2.i.i.i.bb16.i.i.i_crit_edge, !dbg !55265

bb2.i.i.i.bb16.i.i.i_crit_edge:                   ; preds = %bb2.i.i.i
  %34 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 6), align 1, !dbg !55265, !nosanitize !4116
  %35 = add i8 %34, 1, !dbg !55265
  store i8 %35, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 6), align 1, !dbg !55265, !nosanitize !4116
  br label %bb16.i.i.i, !dbg !55265

bb16.i.i.i:                                       ; preds = %bb2.i.i.i.bb16.i.i.i_crit_edge, %bb7.i.i
  %iter.sroa.0.034.i.i.i = phi ptr [ %name.0, %bb7.i.i ], [ %_50.i.i.i, %bb2.i.i.i.bb16.i.i.i_crit_edge ]
  call void @llvm.lifetime.start.p0(ptr nonnull %dst.i.i.i.i), !dbg !55278, !noalias !55282
  store <2 x i64> zeroinitializer, ptr %dst.i.i.i.i, align 16, !dbg !55283, !noalias !55282
  %_7.i.i.i.i.i.i = ptrtoint ptr %iter.sroa.0.034.i.i.i to i64, !dbg !55285
  %_21.i.i.i.i.i.i = icmp ult ptr %iter.sroa.0.034.i.i.i, %dst.i.i.i.i, !dbg !55293
  %36 = sub i64 %_7.i6.i.i.i.i.i, %_7.i.i.i.i.i.i, !dbg !55293
  %37 = sub i64 %_7.i.i.i.i.i.i, %_7.i6.i.i.i.i.i, !dbg !55293
  %diff.sroa.0.0.i.i.i.i.i.i = select i1 %_21.i.i.i.i.i.i, i64 %36, i64 %37, !dbg !55293
  call void @__sanitizer_cov_trace_const_cmp8(i64 16, i64 %diff.sroa.0.0.i.i.i.i.i.i), !dbg !55297
  %_0.i11.not.i.i.i.i.i = icmp ult i64 %diff.sroa.0.0.i.i.i.i.i.i, 16, !dbg !55297
  br i1 %_0.i11.not.i.i.i.i.i, label %bb9.i.i.i.i.i, label %_RNvNtNtNtCshZBO5P2NUJi_4core9core_arch3x864sse215__mm_loadu_si128.exit.i.i.i, !dbg !55298, !prof !4490

bb9.i.i.i.i.i:                                    ; preds = %bb16.i.i.i
  %38 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 7), align 1, !dbg !55299, !nosanitize !4116
  %39 = add i8 %38, 1, !dbg !55299
  store i8 %39, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 7), align 1, !dbg !55299, !nosanitize !4116
  call void @__asan_handle_no_return(), !dbg !55299
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCshZBO5P2NUJi_4core9panicking18panic_nounwind_fmt(ptr noundef nonnull @alloc_bd3468a7b96187f70c1ce98a3e7a63bf, ptr noundef nonnull inttoptr (i64 567 to ptr), i1 noundef zeroext false, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_3491298c4f655629580c883b9f38e7e3) #43, !dbg !55299
  unreachable, !dbg !55299

_RNvNtNtNtCshZBO5P2NUJi_4core9core_arch3x864sse215__mm_loadu_si128.exit.i.i.i: ; preds = %bb16.i.i.i
  %40 = call ptr @__asan_memcpy(ptr %dst.i.i.i.i, ptr %iter.sroa.0.034.i.i.i, i64 16), !dbg !55300
  %_0.i.i.i.i = load <2 x i64>, ptr %dst.i.i.i.i, align 16, !dbg !55301, !noalias !55282
  call void @llvm.lifetime.end.p0(ptr nonnull %dst.i.i.i.i), !dbg !55302, !noalias !55282
  %_16.i.i.i = getelementptr inbounds nuw i8, ptr %iter.sroa.0.034.i.i.i, i64 16, !dbg !55303
  call void @llvm.lifetime.start.p0(ptr nonnull %dst.i1.i.i.i), !dbg !55307, !noalias !55282
  store <2 x i64> zeroinitializer, ptr %dst.i1.i.i.i, align 16, !dbg !55309, !noalias !55282
  %_7.i.i.i2.i.i.i = ptrtoint ptr %_16.i.i.i to i64, !dbg !55311
  %_21.i.i.i4.i.i.i = icmp ult ptr %_16.i.i.i, %dst.i1.i.i.i, !dbg !55319
  %41 = sub i64 %_7.i6.i.i3.i.i.i, %_7.i.i.i2.i.i.i, !dbg !55319
  %42 = sub i64 %_7.i.i.i2.i.i.i, %_7.i6.i.i3.i.i.i, !dbg !55319
  %diff.sroa.0.0.i.i.i5.i.i.i = select i1 %_21.i.i.i4.i.i.i, i64 %41, i64 %42, !dbg !55319
  call void @__sanitizer_cov_trace_const_cmp8(i64 16, i64 %diff.sroa.0.0.i.i.i5.i.i.i), !dbg !55323
  %_0.i11.not.i.i6.i.i.i = icmp ult i64 %diff.sroa.0.0.i.i.i5.i.i.i, 16, !dbg !55323
  br i1 %_0.i11.not.i.i6.i.i.i, label %bb9.i.i8.i.i.i, label %_RNvNtNtNtCshZBO5P2NUJi_4core9core_arch3x864sse215__mm_loadu_si128.exit9.i.i.i, !dbg !55324, !prof !4490

bb9.i.i8.i.i.i:                                   ; preds = %_RNvNtNtNtCshZBO5P2NUJi_4core9core_arch3x864sse215__mm_loadu_si128.exit.i.i.i
  %43 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 8), align 1, !dbg !55325, !nosanitize !4116
  %44 = add i8 %43, 1, !dbg !55325
  store i8 %44, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 8), align 1, !dbg !55325, !nosanitize !4116
  call void @__asan_handle_no_return(), !dbg !55325
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCshZBO5P2NUJi_4core9panicking18panic_nounwind_fmt(ptr noundef nonnull @alloc_bd3468a7b96187f70c1ce98a3e7a63bf, ptr noundef nonnull inttoptr (i64 567 to ptr), i1 noundef zeroext false, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_3491298c4f655629580c883b9f38e7e3) #43, !dbg !55325
  unreachable, !dbg !55325

_RNvNtNtNtCshZBO5P2NUJi_4core9core_arch3x864sse215__mm_loadu_si128.exit9.i.i.i: ; preds = %_RNvNtNtNtCshZBO5P2NUJi_4core9core_arch3x864sse215__mm_loadu_si128.exit.i.i.i
  %45 = call ptr @__asan_memcpy(ptr %dst.i1.i.i.i, ptr %_16.i.i.i, i64 16), !dbg !55326
  %_0.i7.i.i.i = load <2 x i64>, ptr %dst.i1.i.i.i, align 16, !dbg !55327, !noalias !55282
  call void @llvm.lifetime.end.p0(ptr nonnull %dst.i1.i.i.i), !dbg !55328, !noalias !55282
  %_19.i.i.i = getelementptr inbounds nuw i8, ptr %iter.sroa.0.034.i.i.i, i64 32, !dbg !55329
  call void @llvm.lifetime.start.p0(ptr nonnull %dst.i10.i.i.i), !dbg !55332, !noalias !55282
  store <2 x i64> zeroinitializer, ptr %dst.i10.i.i.i, align 16, !dbg !55334, !noalias !55282
  %_7.i.i.i11.i.i.i = ptrtoint ptr %_19.i.i.i to i64, !dbg !55336
  %_21.i.i.i13.i.i.i = icmp ult ptr %_19.i.i.i, %dst.i10.i.i.i, !dbg !55344
  %46 = sub i64 %_7.i6.i.i12.i.i.i, %_7.i.i.i11.i.i.i, !dbg !55344
  %47 = sub i64 %_7.i.i.i11.i.i.i, %_7.i6.i.i12.i.i.i, !dbg !55344
  %diff.sroa.0.0.i.i.i14.i.i.i = select i1 %_21.i.i.i13.i.i.i, i64 %46, i64 %47, !dbg !55344
  call void @__sanitizer_cov_trace_const_cmp8(i64 16, i64 %diff.sroa.0.0.i.i.i14.i.i.i), !dbg !55348
  %_0.i11.not.i.i15.i.i.i = icmp ult i64 %diff.sroa.0.0.i.i.i14.i.i.i, 16, !dbg !55348
  br i1 %_0.i11.not.i.i15.i.i.i, label %bb9.i.i17.i.i.i, label %_RNvNtNtNtCshZBO5P2NUJi_4core9core_arch3x864sse215__mm_loadu_si128.exit18.i.i.i, !dbg !55349, !prof !4490

bb9.i.i17.i.i.i:                                  ; preds = %_RNvNtNtNtCshZBO5P2NUJi_4core9core_arch3x864sse215__mm_loadu_si128.exit9.i.i.i
  %48 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 9), align 1, !dbg !55350, !nosanitize !4116
  %49 = add i8 %48, 1, !dbg !55350
  store i8 %49, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 9), align 1, !dbg !55350, !nosanitize !4116
  call void @__asan_handle_no_return(), !dbg !55350
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCshZBO5P2NUJi_4core9panicking18panic_nounwind_fmt(ptr noundef nonnull @alloc_bd3468a7b96187f70c1ce98a3e7a63bf, ptr noundef nonnull inttoptr (i64 567 to ptr), i1 noundef zeroext false, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_3491298c4f655629580c883b9f38e7e3) #43, !dbg !55350
  unreachable, !dbg !55350

_RNvNtNtNtCshZBO5P2NUJi_4core9core_arch3x864sse215__mm_loadu_si128.exit18.i.i.i: ; preds = %_RNvNtNtNtCshZBO5P2NUJi_4core9core_arch3x864sse215__mm_loadu_si128.exit9.i.i.i
  %50 = call ptr @__asan_memcpy(ptr %dst.i10.i.i.i, ptr %_19.i.i.i, i64 16), !dbg !55351
  %_0.i16.i.i.i = load <2 x i64>, ptr %dst.i10.i.i.i, align 16, !dbg !55352, !noalias !55282
  call void @llvm.lifetime.end.p0(ptr nonnull %dst.i10.i.i.i), !dbg !55353, !noalias !55282
  %_22.i.i.i = getelementptr inbounds nuw i8, ptr %iter.sroa.0.034.i.i.i, i64 48, !dbg !55354
  call void @llvm.lifetime.start.p0(ptr nonnull %dst.i19.i.i.i), !dbg !55357, !noalias !55282
  store <2 x i64> zeroinitializer, ptr %dst.i19.i.i.i, align 16, !dbg !55359, !noalias !55282
  %_7.i.i.i20.i.i.i = ptrtoint ptr %_22.i.i.i to i64, !dbg !55361
  %_21.i.i.i22.i.i.i = icmp ult ptr %_22.i.i.i, %dst.i19.i.i.i, !dbg !55369
  %51 = sub i64 %_7.i6.i.i21.i.i.i, %_7.i.i.i20.i.i.i, !dbg !55369
  %52 = sub i64 %_7.i.i.i20.i.i.i, %_7.i6.i.i21.i.i.i, !dbg !55369
  %diff.sroa.0.0.i.i.i23.i.i.i = select i1 %_21.i.i.i22.i.i.i, i64 %51, i64 %52, !dbg !55369
  call void @__sanitizer_cov_trace_const_cmp8(i64 16, i64 %diff.sroa.0.0.i.i.i23.i.i.i), !dbg !55373
  %_0.i11.not.i.i24.i.i.i = icmp ult i64 %diff.sroa.0.0.i.i.i23.i.i.i, 16, !dbg !55373
  br i1 %_0.i11.not.i.i24.i.i.i, label %bb9.i.i26.i.i.i, label %_RNvNtNtNtCshZBO5P2NUJi_4core9core_arch3x864sse215__mm_loadu_si128.exit27.i.i.i, !dbg !55374, !prof !4490

bb9.i.i26.i.i.i:                                  ; preds = %_RNvNtNtNtCshZBO5P2NUJi_4core9core_arch3x864sse215__mm_loadu_si128.exit18.i.i.i
  %53 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 10), align 1, !dbg !55375, !nosanitize !4116
  %54 = add i8 %53, 1, !dbg !55375
  store i8 %54, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 10), align 1, !dbg !55375, !nosanitize !4116
  call void @__asan_handle_no_return(), !dbg !55375
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCshZBO5P2NUJi_4core9panicking18panic_nounwind_fmt(ptr noundef nonnull @alloc_bd3468a7b96187f70c1ce98a3e7a63bf, ptr noundef nonnull inttoptr (i64 567 to ptr), i1 noundef zeroext false, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_3491298c4f655629580c883b9f38e7e3) #43, !dbg !55375
  unreachable, !dbg !55375

_RNvNtNtNtCshZBO5P2NUJi_4core9core_arch3x864sse215__mm_loadu_si128.exit27.i.i.i: ; preds = %_RNvNtNtNtCshZBO5P2NUJi_4core9core_arch3x864sse215__mm_loadu_si128.exit18.i.i.i
  %55 = call ptr @__asan_memcpy(ptr %dst.i19.i.i.i, ptr %_22.i.i.i, i64 16), !dbg !55376
  %_0.i25.i.i.i = load <2 x i64>, ptr %dst.i19.i.i.i, align 16, !dbg !55377, !noalias !55282
  call void @llvm.lifetime.end.p0(ptr nonnull %dst.i19.i.i.i), !dbg !55378, !noalias !55282
  %_0.i29.i.i.i = or <2 x i64> %_0.i7.i.i.i, %_0.i.i.i.i, !dbg !55379
  %_0.i28.i.i.i = or <2 x i64> %_0.i29.i.i.i, %_0.i16.i.i.i, !dbg !55382
  %_0.i30.i.i.i = or <2 x i64> %_0.i28.i.i.i, %_0.i25.i.i.i, !dbg !55384
  %_0.i.i.i.i.i = bitcast <2 x i64> %_0.i30.i.i.i to <16 x i8>, !dbg !55386
  %56 = icmp slt <16 x i8> %_0.i.i.i.i.i, zeroinitializer, !dbg !55391
  %_5.i.i.i.i = bitcast <16 x i1> %56 to i16, !dbg !55391
  call void @__sanitizer_cov_trace_const_cmp2(i16 0, i16 %_5.i.i.i.i), !dbg !55392
  %57 = icmp eq i16 %_5.i.i.i.i, 0, !dbg !55392
  br i1 %57, label %bb2.i.i.i, label %_RNvNtNtNtCshZBO5P2NUJi_4core9core_arch3x864sse215__mm_loadu_si128.exit27.i.i.i.bb32_crit_edge, !dbg !55392

_RNvNtNtNtCshZBO5P2NUJi_4core9core_arch3x864sse215__mm_loadu_si128.exit27.i.i.i.bb32_crit_edge: ; preds = %_RNvNtNtNtCshZBO5P2NUJi_4core9core_arch3x864sse215__mm_loadu_si128.exit27.i.i.i
  %58 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 11), align 1, !dbg !55392, !nosanitize !4116
  %59 = add i8 %58, 1, !dbg !55392
  store i8 %59, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 11), align 1, !dbg !55392, !nosanitize !4116
  br label %bb32, !dbg !55392

bb15.i.i.i:                                       ; preds = %bb2.i.i.i
  %_57.i.i.i = getelementptr inbounds nuw i8, ptr %data.i.i.i.i.i, i64 %len.i.i.i.i.i, !dbg !55394
  call void @__sanitizer_cov_trace_const_cmp8(i64 0, i64 %len.i.i.i.i.i), !dbg !55405
  %_12.i.i.i.i99 = icmp samesign eq i64 %len.i.i.i.i.i, 0, !dbg !55405
  br i1 %_12.i.i.i.i99, label %bb15.i.i.i.bb1.i.i1.preheader_crit_edge, label %bb15.i.i.i.bb13.i.i.i.i_crit_edge, !dbg !55415

bb15.i.i.i.bb13.i.i.i.i_crit_edge:                ; preds = %bb15.i.i.i
  br label %bb13.i.i.i.i, !dbg !55415

bb15.i.i.i.bb1.i.i1.preheader_crit_edge:          ; preds = %bb15.i.i.i
  %60 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 12), align 1, !dbg !55415, !nosanitize !4116
  %61 = add i8 %60, 1, !dbg !55415
  store i8 %61, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 12), align 1, !dbg !55415, !nosanitize !4116
  br label %bb1.i.i1.preheader, !dbg !55415

bb1.i.i.i.i:                                      ; preds = %83
  %_22.i.i.i.i = getelementptr inbounds nuw i8, ptr %_221.i.i.i.i100, i64 1, !dbg !55416
  %_12.i.i.i.i = icmp eq ptr %_22.i.i.i.i, %_57.i.i.i, !dbg !55405
  br i1 %_12.i.i.i.i, label %bb1.i.i.i.i.bb1.i.i1.preheader_crit_edge, label %bb1.i.i.i.i.bb13.i.i.i.i_crit_edge, !dbg !55415

bb1.i.i.i.i.bb13.i.i.i.i_crit_edge:               ; preds = %bb1.i.i.i.i
  %62 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 13), align 1, !dbg !55415, !nosanitize !4116
  %63 = add i8 %62, 1, !dbg !55415
  store i8 %63, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 13), align 1, !dbg !55415, !nosanitize !4116
  br label %bb13.i.i.i.i, !dbg !55415

bb1.i.i.i.i.bb1.i.i1.preheader_crit_edge:         ; preds = %bb1.i.i.i.i
  %64 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 14), align 1, !dbg !55415, !nosanitize !4116
  %65 = add i8 %64, 1, !dbg !55415
  store i8 %65, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 14), align 1, !dbg !55415, !nosanitize !4116
  br label %bb1.i.i1.preheader, !dbg !55415

bb13.i.i.i.i:                                     ; preds = %bb1.i.i.i.i.bb13.i.i.i.i_crit_edge, %bb15.i.i.i.bb13.i.i.i.i_crit_edge
  %_221.i.i.i.i100 = phi ptr [ %_22.i.i.i.i, %bb1.i.i.i.i.bb13.i.i.i.i_crit_edge ], [ %data.i.i.i.i.i, %bb15.i.i.i.bb13.i.i.i.i_crit_edge ]
  %66 = ptrtoint ptr %_221.i.i.i.i100 to i64, !dbg !55419
  %67 = lshr i64 %66, 3, !dbg !55419
  %68 = add i64 %67, 2147450880, !dbg !55419
  %69 = inttoptr i64 %68 to ptr, !dbg !55419
  %70 = load i8, ptr %69, align 1, !dbg !55419
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %70), !dbg !55419
  %71 = icmp ne i8 %70, 0, !dbg !55419
  br i1 %71, label %74, label %bb13.i.i.i.i._crit_edge, !dbg !55419, !prof !4264

bb13.i.i.i.i._crit_edge:                          ; preds = %bb13.i.i.i.i
  %72 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 15), align 1, !dbg !55419, !nosanitize !4116
  %73 = add i8 %72, 1, !dbg !55419
  store i8 %73, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 15), align 1, !dbg !55419, !nosanitize !4116
  br label %83, !dbg !55419

74:                                               ; preds = %bb13.i.i.i.i
  %75 = and i64 %66, 7, !dbg !55419
  %76 = trunc i64 %75 to i8, !dbg !55419
  call void @__sanitizer_cov_trace_cmp1(i8 %76, i8 %70), !dbg !55419
  %77 = icmp sge i8 %76, %70, !dbg !55419
  br i1 %77, label %80, label %._crit_edge119, !dbg !55419

._crit_edge119:                                   ; preds = %74
  %78 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 16), align 1, !dbg !55419, !nosanitize !4116
  %79 = add i8 %78, 1, !dbg !55419
  store i8 %79, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 16), align 1, !dbg !55419, !nosanitize !4116
  br label %83, !dbg !55419

80:                                               ; preds = %74
  %81 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 17), align 1, !dbg !55419, !nosanitize !4116
  %82 = add i8 %81, 1, !dbg !55419
  store i8 %82, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 17), align 1, !dbg !55419, !nosanitize !4116
  call void @__asan_report_load1(i64 %66) #42, !dbg !55419
  unreachable

83:                                               ; preds = %._crit_edge119, %bb13.i.i.i.i._crit_edge
  %_3.i.i.i.i.i = load i8, ptr %_221.i.i.i.i100, align 1, !dbg !55419, !alias.scope !55425, !noalias !55428, !noundef !4116
  call void @__sanitizer_cov_trace_const_cmp1(i8 -1, i8 %_3.i.i.i.i.i), !dbg !55419
  %_0.i.i31.i.i.i = icmp sgt i8 %_3.i.i.i.i.i, -1, !dbg !55419
  br i1 %_0.i.i31.i.i.i, label %bb1.i.i.i.i, label %.bb32_crit_edge120, !dbg !55431

.bb32_crit_edge120:                               ; preds = %83
  %84 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 18), align 1, !dbg !55431, !nosanitize !4116
  %85 = add i8 %84, 1, !dbg !55431
  store i8 %85, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 18), align 1, !dbg !55431, !nosanitize !4116
  br label %bb32, !dbg !55431

bb1.i.i:                                          ; preds = %bb5
  %new_len2.i.i.i = and i64 %name.1, 56, !dbg !55432
  %data.i.i.i.i = getelementptr inbounds nuw i8, ptr %name.0, i64 %new_len2.i.i.i, !dbg !55444
  %len.i.i.i.i = and i64 %name.1, 7, !dbg !55450
  call void @__sanitizer_cov_trace_const_cmp8(i64 0, i64 %new_len2.i.i.i), !dbg !55451
  %_297.i.i = icmp samesign eq i64 %new_len2.i.i.i, 0, !dbg !55451
  br i1 %_297.i.i, label %bb1.i.i.bb10.i.i_crit_edge, label %bb1.i.i.bb11.i.i_crit_edge, !dbg !55460

bb1.i.i.bb11.i.i_crit_edge:                       ; preds = %bb1.i.i
  br label %bb11.i.i, !dbg !55460

bb1.i.i.bb10.i.i_crit_edge:                       ; preds = %bb1.i.i
  %86 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 19), align 1, !dbg !55460, !nosanitize !4116
  %87 = add i8 %86, 1, !dbg !55460
  store i8 %87, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 19), align 1, !dbg !55460, !nosanitize !4116
  br label %bb10.i.i, !dbg !55460

bb3.i.i:                                          ; preds = %130
  %_38.i.i = getelementptr inbounds nuw i8, ptr %iter.sroa.0.08.i.i, i64 8, !dbg !55461
  %_29.i.i = icmp eq ptr %_38.i.i, %data.i.i.i.i, !dbg !55451
  br i1 %_29.i.i, label %bb3.i.i.bb10.i.i_crit_edge, label %bb3.i.i.bb11.i.i_crit_edge, !dbg !55460

bb3.i.i.bb11.i.i_crit_edge:                       ; preds = %bb3.i.i
  %88 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 20), align 1, !dbg !55460, !nosanitize !4116
  %89 = add i8 %88, 1, !dbg !55460
  store i8 %89, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 20), align 1, !dbg !55460, !nosanitize !4116
  br label %bb11.i.i, !dbg !55460

bb3.i.i.bb10.i.i_crit_edge:                       ; preds = %bb3.i.i
  %90 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 21), align 1, !dbg !55460, !nosanitize !4116
  %91 = add i8 %90, 1, !dbg !55460
  store i8 %91, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 21), align 1, !dbg !55460, !nosanitize !4116
  br label %bb10.i.i, !dbg !55460

bb11.i.i:                                         ; preds = %bb3.i.i.bb11.i.i_crit_edge, %bb1.i.i.bb11.i.i_crit_edge
  %iter.sroa.0.08.i.i = phi ptr [ %_38.i.i, %bb3.i.i.bb11.i.i_crit_edge ], [ %name.0, %bb1.i.i.bb11.i.i_crit_edge ]
  %92 = ptrtoint ptr %iter.sroa.0.08.i.i to i64, !dbg !55464
  %93 = add i64 %92, 7, !dbg !55464
  %94 = inttoptr i64 %93 to ptr, !dbg !55464
  %95 = ptrtoint ptr %iter.sroa.0.08.i.i to i64, !dbg !55464
  %96 = lshr i64 %95, 3, !dbg !55464
  %97 = add i64 %96, 2147450880, !dbg !55464
  %98 = inttoptr i64 %97 to ptr, !dbg !55464
  %99 = load i8, ptr %98, align 1, !dbg !55464
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %99), !dbg !55464
  %100 = icmp ne i8 %99, 0, !dbg !55464
  br i1 %100, label %103, label %bb11.i.i._crit_edge, !dbg !55464, !prof !4264

bb11.i.i._crit_edge:                              ; preds = %bb11.i.i
  %101 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 22), align 1, !dbg !55464, !nosanitize !4116
  %102 = add i8 %101, 1, !dbg !55464
  store i8 %102, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 22), align 1, !dbg !55464, !nosanitize !4116
  br label %112, !dbg !55464

103:                                              ; preds = %bb11.i.i
  %104 = and i64 %95, 7, !dbg !55464
  %105 = trunc i64 %104 to i8, !dbg !55464
  call void @__sanitizer_cov_trace_cmp1(i8 %105, i8 %99), !dbg !55464
  %106 = icmp sge i8 %105, %99, !dbg !55464
  br i1 %106, label %109, label %._crit_edge121, !dbg !55464

._crit_edge121:                                   ; preds = %103
  %107 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 23), align 1, !dbg !55464, !nosanitize !4116
  %108 = add i8 %107, 1, !dbg !55464
  store i8 %108, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 23), align 1, !dbg !55464, !nosanitize !4116
  br label %112, !dbg !55464

109:                                              ; preds = %103
  %110 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 24), align 1, !dbg !55464, !nosanitize !4116
  %111 = add i8 %110, 1, !dbg !55464
  store i8 %111, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 24), align 1, !dbg !55464, !nosanitize !4116
  call void @__asan_report_load_n(i64 %95, i64 8) #42, !dbg !55464
  unreachable

112:                                              ; preds = %._crit_edge121, %bb11.i.i._crit_edge
  %113 = ptrtoint ptr %94 to i64, !dbg !55464
  %114 = lshr i64 %113, 3, !dbg !55464
  %115 = add i64 %114, 2147450880, !dbg !55464
  %116 = inttoptr i64 %115 to ptr, !dbg !55464
  %117 = load i8, ptr %116, align 1, !dbg !55464
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %117), !dbg !55464
  %118 = icmp ne i8 %117, 0, !dbg !55464
  br i1 %118, label %121, label %._crit_edge122, !dbg !55464, !prof !4264

._crit_edge122:                                   ; preds = %112
  %119 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 25), align 1, !dbg !55464, !nosanitize !4116
  %120 = add i8 %119, 1, !dbg !55464
  store i8 %120, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 25), align 1, !dbg !55464, !nosanitize !4116
  br label %130, !dbg !55464

121:                                              ; preds = %112
  %122 = and i64 %113, 7, !dbg !55464
  %123 = trunc i64 %122 to i8, !dbg !55464
  call void @__sanitizer_cov_trace_cmp1(i8 %123, i8 %117), !dbg !55464
  %124 = icmp sge i8 %123, %117, !dbg !55464
  br i1 %124, label %127, label %._crit_edge123, !dbg !55464

._crit_edge123:                                   ; preds = %121
  %125 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 26), align 1, !dbg !55464, !nosanitize !4116
  %126 = add i8 %125, 1, !dbg !55464
  store i8 %126, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 26), align 1, !dbg !55464, !nosanitize !4116
  br label %130, !dbg !55464

127:                                              ; preds = %121
  %128 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 27), align 1, !dbg !55464, !nosanitize !4116
  %129 = add i8 %128, 1, !dbg !55464
  store i8 %129, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 27), align 1, !dbg !55464, !nosanitize !4116
  call void @__asan_report_load_n(i64 %113, i64 8) #42, !dbg !55464
  unreachable

130:                                              ; preds = %._crit_edge123, %._crit_edge122
  %bytes.sroa.0.0.copyload.i.i = load i64, ptr %iter.sroa.0.08.i.i, align 1, !dbg !55464, !alias.scope !55466
  %_13.i.i = and i64 %bytes.sroa.0.0.copyload.i.i, -9187201950435737472, !dbg !55467
  call void @__sanitizer_cov_trace_const_cmp8(i64 0, i64 %_13.i.i), !dbg !55467
  %131 = icmp eq i64 %_13.i.i, 0, !dbg !55467
  br i1 %131, label %bb3.i.i, label %.bb32_crit_edge124, !dbg !55467

.bb32_crit_edge124:                               ; preds = %130
  %132 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 28), align 1, !dbg !55467, !nosanitize !4116
  %133 = add i8 %132, 1, !dbg !55467
  store i8 %133, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 28), align 1, !dbg !55467, !nosanitize !4116
  br label %bb32, !dbg !55467

bb10.i.i:                                         ; preds = %bb3.i.i.bb10.i.i_crit_edge, %bb1.i.i.bb10.i.i_crit_edge
  call void @__sanitizer_cov_trace_const_cmp8(i64 0, i64 %len.i.i.i.i), !dbg !55469
  %_12.i.i.i101 = icmp samesign eq i64 %len.i.i.i.i, 0, !dbg !55469
  br i1 %_12.i.i.i101, label %bb10.i.i.bb1.i.i1.preheader_crit_edge, label %bb13.i.i.i, !dbg !55479

bb10.i.i.bb1.i.i1.preheader_crit_edge:            ; preds = %bb10.i.i
  %134 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 29), align 1, !dbg !55479, !nosanitize !4116
  %135 = add i8 %134, 1, !dbg !55479
  store i8 %135, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 29), align 1, !dbg !55479, !nosanitize !4116
  br label %bb1.i.i1.preheader, !dbg !55479

bb1.i.i.i:                                        ; preds = %287
  call void @__sanitizer_cov_trace_const_cmp8(i64 1, i64 %len.i.i.i.i), !dbg !55469
  %_12.i.i.i = icmp samesign eq i64 %len.i.i.i.i, 1, !dbg !55469
  br i1 %_12.i.i.i, label %bb1.i.i.i.bb1.i.i1.preheader_crit_edge, label %bb13.i.i.i.1, !dbg !55479

bb1.i.i.i.bb1.i.i1.preheader_crit_edge:           ; preds = %bb1.i.i.i
  %136 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 30), align 1, !dbg !55479, !nosanitize !4116
  %137 = add i8 %136, 1, !dbg !55479
  store i8 %137, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 30), align 1, !dbg !55479, !nosanitize !4116
  br label %bb1.i.i1.preheader, !dbg !55479

bb13.i.i.i.1:                                     ; preds = %bb1.i.i.i
  %_22.i1.i.i = getelementptr inbounds nuw i8, ptr %data.i.i.i.i, i64 1, !dbg !55480
  %138 = ptrtoint ptr %_22.i1.i.i to i64, !dbg !55483
  %139 = lshr i64 %138, 3, !dbg !55483
  %140 = add i64 %139, 2147450880, !dbg !55483
  %141 = inttoptr i64 %140 to ptr, !dbg !55483
  %142 = load i8, ptr %141, align 1, !dbg !55483
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %142), !dbg !55483
  %143 = icmp ne i8 %142, 0, !dbg !55483
  br i1 %143, label %146, label %bb13.i.i.i.1._crit_edge, !dbg !55483, !prof !4264

bb13.i.i.i.1._crit_edge:                          ; preds = %bb13.i.i.i.1
  %144 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 31), align 1, !dbg !55483, !nosanitize !4116
  %145 = add i8 %144, 1, !dbg !55483
  store i8 %145, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 31), align 1, !dbg !55483, !nosanitize !4116
  br label %155, !dbg !55483

146:                                              ; preds = %bb13.i.i.i.1
  %147 = and i64 %138, 7, !dbg !55483
  %148 = trunc i64 %147 to i8, !dbg !55483
  call void @__sanitizer_cov_trace_cmp1(i8 %148, i8 %142), !dbg !55483
  %149 = icmp sge i8 %148, %142, !dbg !55483
  br i1 %149, label %152, label %._crit_edge125, !dbg !55483

._crit_edge125:                                   ; preds = %146
  %150 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 32), align 1, !dbg !55483, !nosanitize !4116
  %151 = add i8 %150, 1, !dbg !55483
  store i8 %151, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 32), align 1, !dbg !55483, !nosanitize !4116
  br label %155, !dbg !55483

152:                                              ; preds = %146
  %153 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 33), align 1, !dbg !55483, !nosanitize !4116
  %154 = add i8 %153, 1, !dbg !55483
  store i8 %154, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 33), align 1, !dbg !55483, !nosanitize !4116
  call void @__asan_report_load1(i64 %138) #42, !dbg !55483
  unreachable

155:                                              ; preds = %._crit_edge125, %bb13.i.i.i.1._crit_edge
  %_3.i.i.i.i.1 = load i8, ptr %_22.i1.i.i, align 1, !dbg !55483, !alias.scope !55489, !noalias !55492, !noundef !4116
  call void @__sanitizer_cov_trace_const_cmp1(i8 -1, i8 %_3.i.i.i.i.1), !dbg !55483
  %_0.i.i2.i.i.1 = icmp sgt i8 %_3.i.i.i.i.1, -1, !dbg !55483
  br i1 %_0.i.i2.i.i.1, label %bb1.i.i.i.1, label %.bb32_crit_edge126, !dbg !55495

.bb32_crit_edge126:                               ; preds = %155
  %156 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 34), align 1, !dbg !55495, !nosanitize !4116
  %157 = add i8 %156, 1, !dbg !55495
  store i8 %157, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 34), align 1, !dbg !55495, !nosanitize !4116
  br label %bb32, !dbg !55495

bb1.i.i.i.1:                                      ; preds = %155
  call void @__sanitizer_cov_trace_const_cmp8(i64 2, i64 %len.i.i.i.i), !dbg !55469
  %_12.i.i.i.1 = icmp samesign eq i64 %len.i.i.i.i, 2, !dbg !55469
  br i1 %_12.i.i.i.1, label %bb1.i.i.i.1.bb1.i.i1.preheader_crit_edge, label %bb13.i.i.i.2, !dbg !55479

bb1.i.i.i.1.bb1.i.i1.preheader_crit_edge:         ; preds = %bb1.i.i.i.1
  %158 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 35), align 1, !dbg !55479, !nosanitize !4116
  %159 = add i8 %158, 1, !dbg !55479
  store i8 %159, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 35), align 1, !dbg !55479, !nosanitize !4116
  br label %bb1.i.i1.preheader, !dbg !55479

bb13.i.i.i.2:                                     ; preds = %bb1.i.i.i.1
  %_22.i1.i.i.1 = getelementptr inbounds nuw i8, ptr %data.i.i.i.i, i64 2, !dbg !55480
  %160 = ptrtoint ptr %_22.i1.i.i.1 to i64, !dbg !55483
  %161 = lshr i64 %160, 3, !dbg !55483
  %162 = add i64 %161, 2147450880, !dbg !55483
  %163 = inttoptr i64 %162 to ptr, !dbg !55483
  %164 = load i8, ptr %163, align 1, !dbg !55483
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %164), !dbg !55483
  %165 = icmp ne i8 %164, 0, !dbg !55483
  br i1 %165, label %168, label %bb13.i.i.i.2._crit_edge, !dbg !55483, !prof !4264

bb13.i.i.i.2._crit_edge:                          ; preds = %bb13.i.i.i.2
  %166 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 36), align 1, !dbg !55483, !nosanitize !4116
  %167 = add i8 %166, 1, !dbg !55483
  store i8 %167, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 36), align 1, !dbg !55483, !nosanitize !4116
  br label %177, !dbg !55483

168:                                              ; preds = %bb13.i.i.i.2
  %169 = and i64 %160, 7, !dbg !55483
  %170 = trunc i64 %169 to i8, !dbg !55483
  call void @__sanitizer_cov_trace_cmp1(i8 %170, i8 %164), !dbg !55483
  %171 = icmp sge i8 %170, %164, !dbg !55483
  br i1 %171, label %174, label %._crit_edge127, !dbg !55483

._crit_edge127:                                   ; preds = %168
  %172 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 37), align 1, !dbg !55483, !nosanitize !4116
  %173 = add i8 %172, 1, !dbg !55483
  store i8 %173, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 37), align 1, !dbg !55483, !nosanitize !4116
  br label %177, !dbg !55483

174:                                              ; preds = %168
  %175 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 38), align 1, !dbg !55483, !nosanitize !4116
  %176 = add i8 %175, 1, !dbg !55483
  store i8 %176, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 38), align 1, !dbg !55483, !nosanitize !4116
  call void @__asan_report_load1(i64 %160) #42, !dbg !55483
  unreachable

177:                                              ; preds = %._crit_edge127, %bb13.i.i.i.2._crit_edge
  %_3.i.i.i.i.2 = load i8, ptr %_22.i1.i.i.1, align 1, !dbg !55483, !alias.scope !55489, !noalias !55492, !noundef !4116
  call void @__sanitizer_cov_trace_const_cmp1(i8 -1, i8 %_3.i.i.i.i.2), !dbg !55483
  %_0.i.i2.i.i.2 = icmp sgt i8 %_3.i.i.i.i.2, -1, !dbg !55483
  br i1 %_0.i.i2.i.i.2, label %bb1.i.i.i.2, label %.bb32_crit_edge128, !dbg !55495

.bb32_crit_edge128:                               ; preds = %177
  %178 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 39), align 1, !dbg !55495, !nosanitize !4116
  %179 = add i8 %178, 1, !dbg !55495
  store i8 %179, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 39), align 1, !dbg !55495, !nosanitize !4116
  br label %bb32, !dbg !55495

bb1.i.i.i.2:                                      ; preds = %177
  call void @__sanitizer_cov_trace_const_cmp8(i64 3, i64 %len.i.i.i.i), !dbg !55469
  %_12.i.i.i.2 = icmp samesign eq i64 %len.i.i.i.i, 3, !dbg !55469
  br i1 %_12.i.i.i.2, label %bb1.i.i.i.2.bb1.i.i1.preheader_crit_edge, label %bb13.i.i.i.3, !dbg !55479

bb1.i.i.i.2.bb1.i.i1.preheader_crit_edge:         ; preds = %bb1.i.i.i.2
  %180 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 40), align 1, !dbg !55479, !nosanitize !4116
  %181 = add i8 %180, 1, !dbg !55479
  store i8 %181, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 40), align 1, !dbg !55479, !nosanitize !4116
  br label %bb1.i.i1.preheader, !dbg !55479

bb13.i.i.i.3:                                     ; preds = %bb1.i.i.i.2
  %_22.i1.i.i.2 = getelementptr inbounds nuw i8, ptr %data.i.i.i.i, i64 3, !dbg !55480
  %182 = ptrtoint ptr %_22.i1.i.i.2 to i64, !dbg !55483
  %183 = lshr i64 %182, 3, !dbg !55483
  %184 = add i64 %183, 2147450880, !dbg !55483
  %185 = inttoptr i64 %184 to ptr, !dbg !55483
  %186 = load i8, ptr %185, align 1, !dbg !55483
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %186), !dbg !55483
  %187 = icmp ne i8 %186, 0, !dbg !55483
  br i1 %187, label %190, label %bb13.i.i.i.3._crit_edge, !dbg !55483, !prof !4264

bb13.i.i.i.3._crit_edge:                          ; preds = %bb13.i.i.i.3
  %188 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 41), align 1, !dbg !55483, !nosanitize !4116
  %189 = add i8 %188, 1, !dbg !55483
  store i8 %189, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 41), align 1, !dbg !55483, !nosanitize !4116
  br label %199, !dbg !55483

190:                                              ; preds = %bb13.i.i.i.3
  %191 = and i64 %182, 7, !dbg !55483
  %192 = trunc i64 %191 to i8, !dbg !55483
  call void @__sanitizer_cov_trace_cmp1(i8 %192, i8 %186), !dbg !55483
  %193 = icmp sge i8 %192, %186, !dbg !55483
  br i1 %193, label %196, label %._crit_edge129, !dbg !55483

._crit_edge129:                                   ; preds = %190
  %194 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 42), align 1, !dbg !55483, !nosanitize !4116
  %195 = add i8 %194, 1, !dbg !55483
  store i8 %195, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 42), align 1, !dbg !55483, !nosanitize !4116
  br label %199, !dbg !55483

196:                                              ; preds = %190
  %197 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 43), align 1, !dbg !55483, !nosanitize !4116
  %198 = add i8 %197, 1, !dbg !55483
  store i8 %198, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 43), align 1, !dbg !55483, !nosanitize !4116
  call void @__asan_report_load1(i64 %182) #42, !dbg !55483
  unreachable

199:                                              ; preds = %._crit_edge129, %bb13.i.i.i.3._crit_edge
  %_3.i.i.i.i.3 = load i8, ptr %_22.i1.i.i.2, align 1, !dbg !55483, !alias.scope !55489, !noalias !55492, !noundef !4116
  call void @__sanitizer_cov_trace_const_cmp1(i8 -1, i8 %_3.i.i.i.i.3), !dbg !55483
  %_0.i.i2.i.i.3 = icmp sgt i8 %_3.i.i.i.i.3, -1, !dbg !55483
  br i1 %_0.i.i2.i.i.3, label %bb1.i.i.i.3, label %.bb32_crit_edge130, !dbg !55495

.bb32_crit_edge130:                               ; preds = %199
  %200 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 44), align 1, !dbg !55495, !nosanitize !4116
  %201 = add i8 %200, 1, !dbg !55495
  store i8 %201, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 44), align 1, !dbg !55495, !nosanitize !4116
  br label %bb32, !dbg !55495

bb1.i.i.i.3:                                      ; preds = %199
  call void @__sanitizer_cov_trace_const_cmp8(i64 4, i64 %len.i.i.i.i), !dbg !55469
  %_12.i.i.i.3 = icmp samesign eq i64 %len.i.i.i.i, 4, !dbg !55469
  br i1 %_12.i.i.i.3, label %bb1.i.i.i.3.bb1.i.i1.preheader_crit_edge, label %bb13.i.i.i.4, !dbg !55479

bb1.i.i.i.3.bb1.i.i1.preheader_crit_edge:         ; preds = %bb1.i.i.i.3
  %202 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 45), align 1, !dbg !55479, !nosanitize !4116
  %203 = add i8 %202, 1, !dbg !55479
  store i8 %203, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 45), align 1, !dbg !55479, !nosanitize !4116
  br label %bb1.i.i1.preheader, !dbg !55479

bb13.i.i.i.4:                                     ; preds = %bb1.i.i.i.3
  %_22.i1.i.i.3 = getelementptr inbounds nuw i8, ptr %data.i.i.i.i, i64 4, !dbg !55480
  %204 = ptrtoint ptr %_22.i1.i.i.3 to i64, !dbg !55483
  %205 = lshr i64 %204, 3, !dbg !55483
  %206 = add i64 %205, 2147450880, !dbg !55483
  %207 = inttoptr i64 %206 to ptr, !dbg !55483
  %208 = load i8, ptr %207, align 1, !dbg !55483
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %208), !dbg !55483
  %209 = icmp ne i8 %208, 0, !dbg !55483
  br i1 %209, label %212, label %bb13.i.i.i.4._crit_edge, !dbg !55483, !prof !4264

bb13.i.i.i.4._crit_edge:                          ; preds = %bb13.i.i.i.4
  %210 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 46), align 1, !dbg !55483, !nosanitize !4116
  %211 = add i8 %210, 1, !dbg !55483
  store i8 %211, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 46), align 1, !dbg !55483, !nosanitize !4116
  br label %221, !dbg !55483

212:                                              ; preds = %bb13.i.i.i.4
  %213 = and i64 %204, 7, !dbg !55483
  %214 = trunc i64 %213 to i8, !dbg !55483
  call void @__sanitizer_cov_trace_cmp1(i8 %214, i8 %208), !dbg !55483
  %215 = icmp sge i8 %214, %208, !dbg !55483
  br i1 %215, label %218, label %._crit_edge131, !dbg !55483

._crit_edge131:                                   ; preds = %212
  %216 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 47), align 1, !dbg !55483, !nosanitize !4116
  %217 = add i8 %216, 1, !dbg !55483
  store i8 %217, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 47), align 1, !dbg !55483, !nosanitize !4116
  br label %221, !dbg !55483

218:                                              ; preds = %212
  %219 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 48), align 1, !dbg !55483, !nosanitize !4116
  %220 = add i8 %219, 1, !dbg !55483
  store i8 %220, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 48), align 1, !dbg !55483, !nosanitize !4116
  call void @__asan_report_load1(i64 %204) #42, !dbg !55483
  unreachable

221:                                              ; preds = %._crit_edge131, %bb13.i.i.i.4._crit_edge
  %_3.i.i.i.i.4 = load i8, ptr %_22.i1.i.i.3, align 1, !dbg !55483, !alias.scope !55489, !noalias !55492, !noundef !4116
  call void @__sanitizer_cov_trace_const_cmp1(i8 -1, i8 %_3.i.i.i.i.4), !dbg !55483
  %_0.i.i2.i.i.4 = icmp sgt i8 %_3.i.i.i.i.4, -1, !dbg !55483
  br i1 %_0.i.i2.i.i.4, label %bb1.i.i.i.4, label %.bb32_crit_edge132, !dbg !55495

.bb32_crit_edge132:                               ; preds = %221
  %222 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 49), align 1, !dbg !55495, !nosanitize !4116
  %223 = add i8 %222, 1, !dbg !55495
  store i8 %223, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 49), align 1, !dbg !55495, !nosanitize !4116
  br label %bb32, !dbg !55495

bb1.i.i.i.4:                                      ; preds = %221
  call void @__sanitizer_cov_trace_const_cmp8(i64 5, i64 %len.i.i.i.i), !dbg !55469
  %_12.i.i.i.4 = icmp samesign eq i64 %len.i.i.i.i, 5, !dbg !55469
  br i1 %_12.i.i.i.4, label %bb1.i.i.i.4.bb1.i.i1.preheader_crit_edge, label %bb13.i.i.i.5, !dbg !55479

bb1.i.i.i.4.bb1.i.i1.preheader_crit_edge:         ; preds = %bb1.i.i.i.4
  %224 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 50), align 1, !dbg !55479, !nosanitize !4116
  %225 = add i8 %224, 1, !dbg !55479
  store i8 %225, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 50), align 1, !dbg !55479, !nosanitize !4116
  br label %bb1.i.i1.preheader, !dbg !55479

bb13.i.i.i.5:                                     ; preds = %bb1.i.i.i.4
  %_22.i1.i.i.4 = getelementptr inbounds nuw i8, ptr %data.i.i.i.i, i64 5, !dbg !55480
  %226 = ptrtoint ptr %_22.i1.i.i.4 to i64, !dbg !55483
  %227 = lshr i64 %226, 3, !dbg !55483
  %228 = add i64 %227, 2147450880, !dbg !55483
  %229 = inttoptr i64 %228 to ptr, !dbg !55483
  %230 = load i8, ptr %229, align 1, !dbg !55483
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %230), !dbg !55483
  %231 = icmp ne i8 %230, 0, !dbg !55483
  br i1 %231, label %234, label %bb13.i.i.i.5._crit_edge, !dbg !55483, !prof !4264

bb13.i.i.i.5._crit_edge:                          ; preds = %bb13.i.i.i.5
  %232 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 51), align 1, !dbg !55483, !nosanitize !4116
  %233 = add i8 %232, 1, !dbg !55483
  store i8 %233, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 51), align 1, !dbg !55483, !nosanitize !4116
  br label %243, !dbg !55483

234:                                              ; preds = %bb13.i.i.i.5
  %235 = and i64 %226, 7, !dbg !55483
  %236 = trunc i64 %235 to i8, !dbg !55483
  call void @__sanitizer_cov_trace_cmp1(i8 %236, i8 %230), !dbg !55483
  %237 = icmp sge i8 %236, %230, !dbg !55483
  br i1 %237, label %240, label %._crit_edge133, !dbg !55483

._crit_edge133:                                   ; preds = %234
  %238 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 52), align 1, !dbg !55483, !nosanitize !4116
  %239 = add i8 %238, 1, !dbg !55483
  store i8 %239, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 52), align 1, !dbg !55483, !nosanitize !4116
  br label %243, !dbg !55483

240:                                              ; preds = %234
  %241 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 53), align 1, !dbg !55483, !nosanitize !4116
  %242 = add i8 %241, 1, !dbg !55483
  store i8 %242, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 53), align 1, !dbg !55483, !nosanitize !4116
  call void @__asan_report_load1(i64 %226) #42, !dbg !55483
  unreachable

243:                                              ; preds = %._crit_edge133, %bb13.i.i.i.5._crit_edge
  %_3.i.i.i.i.5 = load i8, ptr %_22.i1.i.i.4, align 1, !dbg !55483, !alias.scope !55489, !noalias !55492, !noundef !4116
  call void @__sanitizer_cov_trace_const_cmp1(i8 -1, i8 %_3.i.i.i.i.5), !dbg !55483
  %_0.i.i2.i.i.5 = icmp sgt i8 %_3.i.i.i.i.5, -1, !dbg !55483
  br i1 %_0.i.i2.i.i.5, label %bb1.i.i.i.5, label %.bb32_crit_edge134, !dbg !55495

.bb32_crit_edge134:                               ; preds = %243
  %244 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 54), align 1, !dbg !55495, !nosanitize !4116
  %245 = add i8 %244, 1, !dbg !55495
  store i8 %245, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 54), align 1, !dbg !55495, !nosanitize !4116
  br label %bb32, !dbg !55495

bb1.i.i.i.5:                                      ; preds = %243
  call void @__sanitizer_cov_trace_const_cmp8(i64 6, i64 %len.i.i.i.i), !dbg !55469
  %_12.i.i.i.5 = icmp samesign eq i64 %len.i.i.i.i, 6, !dbg !55469
  br i1 %_12.i.i.i.5, label %bb1.i.i.i.5.bb1.i.i1.preheader_crit_edge, label %bb13.i.i.i.6, !dbg !55479

bb1.i.i.i.5.bb1.i.i1.preheader_crit_edge:         ; preds = %bb1.i.i.i.5
  %246 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 55), align 1, !dbg !55479, !nosanitize !4116
  %247 = add i8 %246, 1, !dbg !55479
  store i8 %247, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 55), align 1, !dbg !55479, !nosanitize !4116
  br label %bb1.i.i1.preheader, !dbg !55479

bb13.i.i.i.6:                                     ; preds = %bb1.i.i.i.5
  %_22.i1.i.i.5 = getelementptr inbounds nuw i8, ptr %data.i.i.i.i, i64 6, !dbg !55480
  %248 = ptrtoint ptr %_22.i1.i.i.5 to i64, !dbg !55483
  %249 = lshr i64 %248, 3, !dbg !55483
  %250 = add i64 %249, 2147450880, !dbg !55483
  %251 = inttoptr i64 %250 to ptr, !dbg !55483
  %252 = load i8, ptr %251, align 1, !dbg !55483
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %252), !dbg !55483
  %253 = icmp ne i8 %252, 0, !dbg !55483
  br i1 %253, label %256, label %bb13.i.i.i.6._crit_edge, !dbg !55483, !prof !4264

bb13.i.i.i.6._crit_edge:                          ; preds = %bb13.i.i.i.6
  %254 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 56), align 1, !dbg !55483, !nosanitize !4116
  %255 = add i8 %254, 1, !dbg !55483
  store i8 %255, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 56), align 1, !dbg !55483, !nosanitize !4116
  br label %265, !dbg !55483

256:                                              ; preds = %bb13.i.i.i.6
  %257 = and i64 %248, 7, !dbg !55483
  %258 = trunc i64 %257 to i8, !dbg !55483
  call void @__sanitizer_cov_trace_cmp1(i8 %258, i8 %252), !dbg !55483
  %259 = icmp sge i8 %258, %252, !dbg !55483
  br i1 %259, label %262, label %._crit_edge135, !dbg !55483

._crit_edge135:                                   ; preds = %256
  %260 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 57), align 1, !dbg !55483, !nosanitize !4116
  %261 = add i8 %260, 1, !dbg !55483
  store i8 %261, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 57), align 1, !dbg !55483, !nosanitize !4116
  br label %265, !dbg !55483

262:                                              ; preds = %256
  %263 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 58), align 1, !dbg !55483, !nosanitize !4116
  %264 = add i8 %263, 1, !dbg !55483
  store i8 %264, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 58), align 1, !dbg !55483, !nosanitize !4116
  call void @__asan_report_load1(i64 %248) #42, !dbg !55483
  unreachable

265:                                              ; preds = %._crit_edge135, %bb13.i.i.i.6._crit_edge
  %_3.i.i.i.i.6 = load i8, ptr %_22.i1.i.i.5, align 1, !dbg !55483, !alias.scope !55489, !noalias !55492, !noundef !4116
  call void @__sanitizer_cov_trace_const_cmp1(i8 -1, i8 %_3.i.i.i.i.6), !dbg !55483
  %_0.i.i2.i.i.6 = icmp sgt i8 %_3.i.i.i.i.6, -1, !dbg !55483
  br i1 %_0.i.i2.i.i.6, label %.bb1.i.i1.preheader_crit_edge, label %.bb32_crit_edge136, !dbg !55495

.bb32_crit_edge136:                               ; preds = %265
  %266 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 59), align 1, !dbg !55495, !nosanitize !4116
  %267 = add i8 %266, 1, !dbg !55495
  store i8 %267, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 59), align 1, !dbg !55495, !nosanitize !4116
  br label %bb32, !dbg !55495

.bb1.i.i1.preheader_crit_edge:                    ; preds = %265
  %268 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 60), align 1, !dbg !55495, !nosanitize !4116
  %269 = add i8 %268, 1, !dbg !55495
  store i8 %269, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 60), align 1, !dbg !55495, !nosanitize !4116
  br label %bb1.i.i1.preheader, !dbg !55495

bb1.i.i1.preheader:                               ; preds = %.bb1.i.i1.preheader_crit_edge, %bb1.i.i.i.5.bb1.i.i1.preheader_crit_edge, %bb1.i.i.i.4.bb1.i.i1.preheader_crit_edge, %bb1.i.i.i.3.bb1.i.i1.preheader_crit_edge, %bb1.i.i.i.2.bb1.i.i1.preheader_crit_edge, %bb1.i.i.i.1.bb1.i.i1.preheader_crit_edge, %bb1.i.i.i.bb1.i.i1.preheader_crit_edge, %bb10.i.i.bb1.i.i1.preheader_crit_edge, %bb1.i.i.i.i.bb1.i.i1.preheader_crit_edge, %bb15.i.i.i.bb1.i.i1.preheader_crit_edge
  br label %bb1.i.i1, !dbg !55496

bb13.i.i.i:                                       ; preds = %bb10.i.i
  %270 = ptrtoint ptr %data.i.i.i.i to i64, !dbg !55483
  %271 = lshr i64 %270, 3, !dbg !55483
  %272 = add i64 %271, 2147450880, !dbg !55483
  %273 = inttoptr i64 %272 to ptr, !dbg !55483
  %274 = load i8, ptr %273, align 1, !dbg !55483
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %274), !dbg !55483
  %275 = icmp ne i8 %274, 0, !dbg !55483
  br i1 %275, label %278, label %bb13.i.i.i._crit_edge, !dbg !55483, !prof !4264

bb13.i.i.i._crit_edge:                            ; preds = %bb13.i.i.i
  %276 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 61), align 1, !dbg !55483, !nosanitize !4116
  %277 = add i8 %276, 1, !dbg !55483
  store i8 %277, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 61), align 1, !dbg !55483, !nosanitize !4116
  br label %287, !dbg !55483

278:                                              ; preds = %bb13.i.i.i
  %279 = and i64 %270, 7, !dbg !55483
  %280 = trunc i64 %279 to i8, !dbg !55483
  call void @__sanitizer_cov_trace_cmp1(i8 %280, i8 %274), !dbg !55483
  %281 = icmp sge i8 %280, %274, !dbg !55483
  br i1 %281, label %284, label %._crit_edge137, !dbg !55483

._crit_edge137:                                   ; preds = %278
  %282 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 62), align 1, !dbg !55483, !nosanitize !4116
  %283 = add i8 %282, 1, !dbg !55483
  store i8 %283, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 62), align 1, !dbg !55483, !nosanitize !4116
  br label %287, !dbg !55483

284:                                              ; preds = %278
  %285 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 63), align 1, !dbg !55483, !nosanitize !4116
  %286 = add i8 %285, 1, !dbg !55483
  store i8 %286, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 63), align 1, !dbg !55483, !nosanitize !4116
  call void @__asan_report_load1(i64 %270) #42, !dbg !55483
  unreachable

287:                                              ; preds = %._crit_edge137, %bb13.i.i.i._crit_edge
  %_3.i.i.i.i = load i8, ptr %data.i.i.i.i, align 1, !dbg !55483, !alias.scope !55489, !noalias !55492, !noundef !4116
  call void @__sanitizer_cov_trace_const_cmp1(i8 -1, i8 %_3.i.i.i.i), !dbg !55483
  %_0.i.i2.i.i = icmp sgt i8 %_3.i.i.i.i, -1, !dbg !55483
  br i1 %_0.i.i2.i.i, label %bb1.i.i.i, label %.bb32_crit_edge138, !dbg !55495

.bb32_crit_edge138:                               ; preds = %287
  %288 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 64), align 1, !dbg !55495, !nosanitize !4116
  %289 = add i8 %288, 1, !dbg !55495
  store i8 %289, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 64), align 1, !dbg !55495, !nosanitize !4116
  br label %bb32, !dbg !55495

bb1.i.i1:                                         ; preds = %bb1.i.i1.backedge, %bb1.i.i1.preheader
  %290 = phi i64 [ 0, %bb1.i.i1.preheader ], [ %376, %bb1.i.i1.backedge ]
  %.lcssa513.i.i = phi i64 [ 0, %bb1.i.i1.preheader ], [ %.lcssa512.i.i, %bb1.i.i1.backedge ]
  %_2.i.i.i.i = phi i1 [ false, %bb1.i.i1.preheader ], [ %377, %bb1.i.i1.backedge ]
  br i1 %_2.i.i.i.i, label %bb1.i.i1._RNvXsY_NtNtCshZBO5P2NUJi_4core3str4iterINtB5_5SplitcENtNtNtNtB9_4iter6traits8iterator8Iterator4nextCs1K0wxfkMoe8_15spiral_protocol.exit.i.i_crit_edge, label %bb2.i.i.i.i, !dbg !55496

bb1.i.i1._RNvXsY_NtNtCshZBO5P2NUJi_4core3str4iterINtB5_5SplitcENtNtNtNtB9_4iter6traits8iterator8Iterator4nextCs1K0wxfkMoe8_15spiral_protocol.exit.i.i_crit_edge: ; preds = %bb1.i.i1
  %291 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 65), align 1, !dbg !55496, !nosanitize !4116
  %292 = add i8 %291, 1, !dbg !55496
  store i8 %292, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 65), align 1, !dbg !55496, !nosanitize !4116
  br label %_RNvXsY_NtNtCshZBO5P2NUJi_4core3str4iterINtB5_5SplitcENtNtNtNtB9_4iter6traits8iterator8Iterator4nextCs1K0wxfkMoe8_15spiral_protocol.exit.i.i, !dbg !55496

bb2.i.i.i.i:                                      ; preds = %bb1.i.i1
  call void @__sanitizer_cov_trace_cmp8(i64 %name.1, i64 %290), !dbg !55511
  %_4232.i.i.i.i.i = icmp ult i64 %name.1, %290, !dbg !55511
  br i1 %_4232.i.i.i.i.i, label %bb2.i.i.i.i.bb6.i.i.i.i_crit_edge, label %bb2.i.i.i.i.bb18.i.i.i.i.i_crit_edge, !dbg !55511

bb2.i.i.i.i.bb18.i.i.i.i.i_crit_edge:             ; preds = %bb2.i.i.i.i
  br label %bb18.i.i.i.i.i, !dbg !55511

bb2.i.i.i.i.bb6.i.i.i.i_crit_edge:                ; preds = %bb2.i.i.i.i
  %293 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 66), align 1, !dbg !55511, !nosanitize !4116
  %294 = add i8 %293, 1, !dbg !55511
  store i8 %294, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 66), align 1, !dbg !55511, !nosanitize !4116
  br label %bb6.i.i.i.i, !dbg !55511

bb18.i.i.i.i.i:                                   ; preds = %bb10.i.i.i.i.i.bb18.i.i.i.i.i_crit_edge, %bb2.i.i.i.i.bb18.i.i.i.i.i_crit_edge
  %295 = phi i64 [ %339, %bb10.i.i.i.i.i.bb18.i.i.i.i.i_crit_edge ], [ %290, %bb2.i.i.i.i.bb18.i.i.i.i.i_crit_edge ]
  %new_len.i.i.i.i.i = sub nuw i64 %name.1, %295, !dbg !55524
  %_45.i.i.i.i.i = getelementptr inbounds nuw i8, ptr %name.0, i64 %295, !dbg !55525
  call void @__sanitizer_cov_trace_const_cmp8(i64 16, i64 %new_len.i.i.i.i.i), !dbg !55529
  %_3.i12.i.i.i.i.i = icmp samesign ult i64 %new_len.i.i.i.i.i, 16, !dbg !55529
  br i1 %_3.i12.i.i.i.i.i, label %bb6.preheader.i.i.i.i.i.i, label %bb2.i13.i.i.i.i.i, !dbg !55529

bb6.preheader.i.i.i.i.i.i:                        ; preds = %bb18.i.i.i.i.i
  call void @__sanitizer_cov_trace_cmp8(i64 %name.1, i64 %295), !dbg !55534
  %_98.not.i.i.i.i.i.i = icmp eq i64 %name.1, %295, !dbg !55534
  br i1 %_98.not.i.i.i.i.i.i, label %bb6.preheader.i.i.i.i.i.i._RNvNtNtCshZBO5P2NUJi_4core5slice6memchr6memchr.exit.i.i.i.i.i_crit_edge, label %bb6.preheader.i.i.i.i.i.i.bb8.i.i.i.i.i.i_crit_edge, !dbg !55534

bb6.preheader.i.i.i.i.i.i.bb8.i.i.i.i.i.i_crit_edge: ; preds = %bb6.preheader.i.i.i.i.i.i
  br label %bb8.i.i.i.i.i.i, !dbg !55534

bb6.preheader.i.i.i.i.i.i._RNvNtNtCshZBO5P2NUJi_4core5slice6memchr6memchr.exit.i.i.i.i.i_crit_edge: ; preds = %bb6.preheader.i.i.i.i.i.i
  %296 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 67), align 1, !dbg !55534, !nosanitize !4116
  %297 = add i8 %296, 1, !dbg !55534
  store i8 %297, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 67), align 1, !dbg !55534, !nosanitize !4116
  br label %_RNvNtNtCshZBO5P2NUJi_4core5slice6memchr6memchr.exit.i.i.i.i.i, !dbg !55534

bb2.i13.i.i.i.i.i:                                ; preds = %bb18.i.i.i.i.i
; call core::slice::memchr::memchr_aligned
  %298 = call { i64, i64 } @_RNvNtNtCshZBO5P2NUJi_4core5slice6memchr14memchr_aligned(i8 noundef 46, ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) %_45.i.i.i.i.i, i64 noundef range(i64 0, -9223372036854775808) %new_len.i.i.i.i.i) #35, !dbg !55536, !noalias !55537
  %299 = extractvalue { i64, i64 } %298, 0, !dbg !55536
  %300 = extractvalue { i64, i64 } %298, 1, !dbg !55536
  %301 = trunc nuw i64 %299 to i1, !dbg !55549
  br i1 %301, label %bb2.i13.i.i.i.i.i.bb4.i.i.i.i.i.i_crit_edge, label %bb2.i13.i.i.i.i.i._RNvNtNtCshZBO5P2NUJi_4core5slice6memchr6memchr.exit.i.i.i.i.i_crit_edge, !dbg !55549

bb2.i13.i.i.i.i.i._RNvNtNtCshZBO5P2NUJi_4core5slice6memchr6memchr.exit.i.i.i.i.i_crit_edge: ; preds = %bb2.i13.i.i.i.i.i
  %302 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 68), align 1, !dbg !55549, !nosanitize !4116
  %303 = add i8 %302, 1, !dbg !55549
  store i8 %303, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 68), align 1, !dbg !55549, !nosanitize !4116
  br label %_RNvNtNtCshZBO5P2NUJi_4core5slice6memchr6memchr.exit.i.i.i.i.i, !dbg !55549

bb2.i13.i.i.i.i.i.bb4.i.i.i.i.i.i_crit_edge:      ; preds = %bb2.i13.i.i.i.i.i
  %304 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 69), align 1, !dbg !55549, !nosanitize !4116
  %305 = add i8 %304, 1, !dbg !55549
  store i8 %305, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 69), align 1, !dbg !55549, !nosanitize !4116
  br label %bb4.i.i.i.i.i.i, !dbg !55549

bb4.i.i.i.i.i.i:                                  ; preds = %.bb4.i.i.i.i.i.i_crit_edge, %bb2.i13.i.i.i.i.i.bb4.i.i.i.i.i.i_crit_edge
  %result.sroa.5.0.i.i.i.i.i.i = phi i64 [ %300, %bb2.i13.i.i.i.i.i.bb4.i.i.i.i.i.i_crit_edge ], [ %i.sroa.0.09.i.i.i.i.i.i, %.bb4.i.i.i.i.i.i_crit_edge ], !dbg !55550
  %result.sroa.0.0.i.i.i.i.i.i = phi i64 [ %299, %bb2.i13.i.i.i.i.i.bb4.i.i.i.i.i.i_crit_edge ], [ 1, %.bb4.i.i.i.i.i.i_crit_edge ], !dbg !55550
  call void @__sanitizer_cov_trace_cmp8(i64 %result.sroa.5.0.i.i.i.i.i.i, i64 %new_len.i.i.i.i.i), !dbg !55551
  %cond.i.i.i.i.i.i = icmp ult i64 %result.sroa.5.0.i.i.i.i.i.i, %new_len.i.i.i.i.i, !dbg !55551
  br i1 %cond.i.i.i.i.i.i, label %bb4.i.i.i.i.i.i._RNvNtNtCshZBO5P2NUJi_4core5slice6memchr6memchr.exit.i.i.i.i.i_crit_edge, label %bb1.i.i.i.i.i.i.i, !dbg !55552, !prof !4269

bb4.i.i.i.i.i.i._RNvNtNtCshZBO5P2NUJi_4core5slice6memchr6memchr.exit.i.i.i.i.i_crit_edge: ; preds = %bb4.i.i.i.i.i.i
  %306 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 70), align 1, !dbg !55552, !nosanitize !4116
  %307 = add i8 %306, 1, !dbg !55552
  store i8 %307, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 70), align 1, !dbg !55552, !nosanitize !4116
  br label %_RNvNtNtCshZBO5P2NUJi_4core5slice6memchr6memchr.exit.i.i.i.i.i, !dbg !55552

bb1.i.i.i.i.i.i.i:                                ; preds = %bb4.i.i.i.i.i.i
  %308 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 71), align 1, !dbg !55555, !nosanitize !4116
  %309 = add i8 %308, 1, !dbg !55555
  store i8 %309, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 71), align 1, !dbg !55555, !nosanitize !4116
  call void @__asan_handle_no_return(), !dbg !55555
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCshZBO5P2NUJi_4core9panicking18panic_nounwind_fmt(ptr noundef nonnull @alloc_64e308ef4babfeb8b6220184de794a17, ptr noundef nonnull inttoptr (i64 443 to ptr), i1 noundef zeroext false, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_ac8fce308ee1f106aaa4bc0c23b74cc5) #43, !dbg !55555, !noalias !55537
  unreachable, !dbg !55555

bb8.i.i.i.i.i.i:                                  ; preds = %bb10.i.i.i.i.i.i.bb8.i.i.i.i.i.i_crit_edge, %bb6.preheader.i.i.i.i.i.i.bb8.i.i.i.i.i.i_crit_edge
  %i.sroa.0.09.i.i.i.i.i.i = phi i64 [ %331, %bb10.i.i.i.i.i.i.bb8.i.i.i.i.i.i_crit_edge ], [ 0, %bb6.preheader.i.i.i.i.i.i.bb8.i.i.i.i.i.i_crit_edge ]
  %310 = getelementptr inbounds nuw i8, ptr %_45.i.i.i.i.i, i64 %i.sroa.0.09.i.i.i.i.i.i, !dbg !55556
  %311 = ptrtoint ptr %310 to i64, !dbg !55556
  %312 = lshr i64 %311, 3, !dbg !55556
  %313 = add i64 %312, 2147450880, !dbg !55556
  %314 = inttoptr i64 %313 to ptr, !dbg !55556
  %315 = load i8, ptr %314, align 1, !dbg !55556
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %315), !dbg !55556
  %316 = icmp ne i8 %315, 0, !dbg !55556
  br i1 %316, label %319, label %bb8.i.i.i.i.i.i._crit_edge, !dbg !55556, !prof !4264

bb8.i.i.i.i.i.i._crit_edge:                       ; preds = %bb8.i.i.i.i.i.i
  %317 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 72), align 1, !dbg !55556, !nosanitize !4116
  %318 = add i8 %317, 1, !dbg !55556
  store i8 %318, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 72), align 1, !dbg !55556, !nosanitize !4116
  br label %328, !dbg !55556

319:                                              ; preds = %bb8.i.i.i.i.i.i
  %320 = and i64 %311, 7, !dbg !55556
  %321 = trunc i64 %320 to i8, !dbg !55556
  call void @__sanitizer_cov_trace_cmp1(i8 %321, i8 %315), !dbg !55556
  %322 = icmp sge i8 %321, %315, !dbg !55556
  br i1 %322, label %325, label %._crit_edge139, !dbg !55556

._crit_edge139:                                   ; preds = %319
  %323 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 73), align 1, !dbg !55556, !nosanitize !4116
  %324 = add i8 %323, 1, !dbg !55556
  store i8 %324, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 73), align 1, !dbg !55556, !nosanitize !4116
  br label %328, !dbg !55556

325:                                              ; preds = %319
  %326 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 74), align 1, !dbg !55556, !nosanitize !4116
  %327 = add i8 %326, 1, !dbg !55556
  store i8 %327, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 74), align 1, !dbg !55556, !nosanitize !4116
  call void @__asan_report_load1(i64 %311) #42, !dbg !55556
  unreachable

328:                                              ; preds = %._crit_edge139, %bb8.i.i.i.i.i.i._crit_edge
  %_12.i.i.i.i.i.i = load i8, ptr %310, align 1, !dbg !55556, !alias.scope !55557, !noalias !55537, !noundef !4116
  call void @__sanitizer_cov_trace_const_cmp1(i8 46, i8 %_12.i.i.i.i.i.i), !dbg !55556
  %_11.i.i.i.i.i.i = icmp eq i8 %_12.i.i.i.i.i.i, 46, !dbg !55556
  br i1 %_11.i.i.i.i.i.i, label %.bb4.i.i.i.i.i.i_crit_edge, label %bb10.i.i.i.i.i.i, !dbg !55556

.bb4.i.i.i.i.i.i_crit_edge:                       ; preds = %328
  %329 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 75), align 1, !dbg !55556, !nosanitize !4116
  %330 = add i8 %329, 1, !dbg !55556
  store i8 %330, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 75), align 1, !dbg !55556, !nosanitize !4116
  br label %bb4.i.i.i.i.i.i, !dbg !55556

bb10.i.i.i.i.i.i:                                 ; preds = %328
  %331 = add nuw nsw i64 %i.sroa.0.09.i.i.i.i.i.i, 1, !dbg !55560
  %exitcond.not.i.i.i.i.i.i = icmp eq i64 %331, %new_len.i.i.i.i.i, !dbg !55534
  br i1 %exitcond.not.i.i.i.i.i.i, label %bb10.i.i.i.i.i.i._RNvNtNtCshZBO5P2NUJi_4core5slice6memchr6memchr.exit.i.i.i.i.i_crit_edge, label %bb10.i.i.i.i.i.i.bb8.i.i.i.i.i.i_crit_edge, !dbg !55534

bb10.i.i.i.i.i.i.bb8.i.i.i.i.i.i_crit_edge:       ; preds = %bb10.i.i.i.i.i.i
  %332 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 76), align 1, !dbg !55534, !nosanitize !4116
  %333 = add i8 %332, 1, !dbg !55534
  store i8 %333, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 76), align 1, !dbg !55534, !nosanitize !4116
  br label %bb8.i.i.i.i.i.i, !dbg !55534

bb10.i.i.i.i.i.i._RNvNtNtCshZBO5P2NUJi_4core5slice6memchr6memchr.exit.i.i.i.i.i_crit_edge: ; preds = %bb10.i.i.i.i.i.i
  %334 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 77), align 1, !dbg !55534, !nosanitize !4116
  %335 = add i8 %334, 1, !dbg !55534
  store i8 %335, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 77), align 1, !dbg !55534, !nosanitize !4116
  br label %_RNvNtNtCshZBO5P2NUJi_4core5slice6memchr6memchr.exit.i.i.i.i.i, !dbg !55534

_RNvNtNtCshZBO5P2NUJi_4core5slice6memchr6memchr.exit.i.i.i.i.i: ; preds = %bb10.i.i.i.i.i.i._RNvNtNtCshZBO5P2NUJi_4core5slice6memchr6memchr.exit.i.i.i.i.i_crit_edge, %bb4.i.i.i.i.i.i._RNvNtNtCshZBO5P2NUJi_4core5slice6memchr6memchr.exit.i.i.i.i.i_crit_edge, %bb2.i13.i.i.i.i.i._RNvNtNtCshZBO5P2NUJi_4core5slice6memchr6memchr.exit.i.i.i.i.i_crit_edge, %bb6.preheader.i.i.i.i.i.i._RNvNtNtCshZBO5P2NUJi_4core5slice6memchr6memchr.exit.i.i.i.i.i_crit_edge
  %result.sroa.5.1.i.i.i.i.i.i = phi i64 [ %result.sroa.5.0.i.i.i.i.i.i, %bb4.i.i.i.i.i.i._RNvNtNtCshZBO5P2NUJi_4core5slice6memchr6memchr.exit.i.i.i.i.i_crit_edge ], [ %300, %bb2.i13.i.i.i.i.i._RNvNtNtCshZBO5P2NUJi_4core5slice6memchr6memchr.exit.i.i.i.i.i_crit_edge ], [ undef, %bb6.preheader.i.i.i.i.i.i._RNvNtNtCshZBO5P2NUJi_4core5slice6memchr6memchr.exit.i.i.i.i.i_crit_edge ], [ undef, %bb10.i.i.i.i.i.i._RNvNtNtCshZBO5P2NUJi_4core5slice6memchr6memchr.exit.i.i.i.i.i_crit_edge ], !dbg !55550
  %result.sroa.0.1.i.i.i.i.i.i = phi i64 [ %result.sroa.0.0.i.i.i.i.i.i, %bb4.i.i.i.i.i.i._RNvNtNtCshZBO5P2NUJi_4core5slice6memchr6memchr.exit.i.i.i.i.i_crit_edge ], [ 0, %bb2.i13.i.i.i.i.i._RNvNtNtCshZBO5P2NUJi_4core5slice6memchr6memchr.exit.i.i.i.i.i_crit_edge ], [ 0, %bb6.preheader.i.i.i.i.i.i._RNvNtNtCshZBO5P2NUJi_4core5slice6memchr6memchr.exit.i.i.i.i.i_crit_edge ], [ 0, %bb10.i.i.i.i.i.i._RNvNtNtCshZBO5P2NUJi_4core5slice6memchr6memchr.exit.i.i.i.i.i_crit_edge ], !dbg !55550
  %336 = trunc nuw i64 %result.sroa.0.1.i.i.i.i.i.i to i1, !dbg !55561
  br i1 %336, label %bb4.i.i.i.i.i, label %_RNvNtNtCshZBO5P2NUJi_4core5slice6memchr6memchr.exit.i.i.i.i.i.bb6.i.i.i.i_crit_edge, !dbg !55561

_RNvNtNtCshZBO5P2NUJi_4core5slice6memchr6memchr.exit.i.i.i.i.i.bb6.i.i.i.i_crit_edge: ; preds = %_RNvNtNtCshZBO5P2NUJi_4core5slice6memchr6memchr.exit.i.i.i.i.i
  %337 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 78), align 1, !dbg !55561, !nosanitize !4116
  %338 = add i8 %337, 1, !dbg !55561
  store i8 %338, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 78), align 1, !dbg !55561, !nosanitize !4116
  br label %bb6.i.i.i.i, !dbg !55561

bb4.i.i.i.i.i:                                    ; preds = %_RNvNtNtCshZBO5P2NUJi_4core5slice6memchr6memchr.exit.i.i.i.i.i
  %_16.i.i.i.i.i = add i64 %295, 1, !dbg !55562
  %339 = add i64 %_16.i.i.i.i.i, %result.sroa.5.1.i.i.i.i.i.i, !dbg !55563
  %340 = add i64 %295, %result.sroa.5.1.i.i.i.i.i.i, !dbg !55564
  call void @__sanitizer_cov_trace_cmp8(i64 %340, i64 %name.1), !dbg !55564
  %or.cond88.not = icmp ult i64 %340, %name.1, !dbg !55564
  br i1 %or.cond88.not, label %bb31.i.i.i.i.i, label %bb4.i.i.i.i.i.bb10.i.i.i.i.i_crit_edge, !dbg !55564

bb4.i.i.i.i.i.bb10.i.i.i.i.i_crit_edge:           ; preds = %bb4.i.i.i.i.i
  %341 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 79), align 1, !dbg !55564, !nosanitize !4116
  %342 = add i8 %341, 1, !dbg !55564
  store i8 %342, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 79), align 1, !dbg !55564, !nosanitize !4116
  br label %bb10.i.i.i.i.i, !dbg !55564

bb10.i.i.i.i.i:                                   ; preds = %.bb10.i.i.i.i.i_crit_edge, %bb4.i.i.i.i.i.bb10.i.i.i.i.i_crit_edge
  %_42.i.i.i.i.i = icmp ult i64 %name.1, %339, !dbg !55511
  br i1 %_42.i.i.i.i.i, label %bb10.i.i.i.i.i.bb6.i.i.i.i_crit_edge, label %bb10.i.i.i.i.i.bb18.i.i.i.i.i_crit_edge, !dbg !55511

bb10.i.i.i.i.i.bb18.i.i.i.i.i_crit_edge:          ; preds = %bb10.i.i.i.i.i
  %343 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 80), align 1, !dbg !55511, !nosanitize !4116
  %344 = add i8 %343, 1, !dbg !55511
  store i8 %344, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 80), align 1, !dbg !55511, !nosanitize !4116
  br label %bb18.i.i.i.i.i, !dbg !55511

bb10.i.i.i.i.i.bb6.i.i.i.i_crit_edge:             ; preds = %bb10.i.i.i.i.i
  %345 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 81), align 1, !dbg !55511, !nosanitize !4116
  %346 = add i8 %345, 1, !dbg !55511
  store i8 %346, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 81), align 1, !dbg !55511, !nosanitize !4116
  br label %bb6.i.i.i.i, !dbg !55511

bb31.i.i.i.i.i:                                   ; preds = %bb4.i.i.i.i.i
  %found_char.i.i.i.i.i = add i64 %result.sroa.5.1.i.i.i.i.i.i, %295, !dbg !55565
  %_61.i.i.i.i.i = getelementptr inbounds nuw i8, ptr %name.0, i64 %found_char.i.i.i.i.i, !dbg !55566
  %347 = ptrtoint ptr %_61.i.i.i.i.i to i64, !dbg !55575
  %348 = lshr i64 %347, 3, !dbg !55575
  %349 = add i64 %348, 2147450880, !dbg !55575
  %350 = inttoptr i64 %349 to ptr, !dbg !55575
  %351 = load i8, ptr %350, align 1, !dbg !55575
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %351), !dbg !55575
  %352 = icmp ne i8 %351, 0, !dbg !55575
  br i1 %352, label %355, label %bb31.i.i.i.i.i._crit_edge, !dbg !55575, !prof !4264

bb31.i.i.i.i.i._crit_edge:                        ; preds = %bb31.i.i.i.i.i
  %353 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 82), align 1, !dbg !55575, !nosanitize !4116
  %354 = add i8 %353, 1, !dbg !55575
  store i8 %354, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 82), align 1, !dbg !55575, !nosanitize !4116
  br label %364, !dbg !55575

355:                                              ; preds = %bb31.i.i.i.i.i
  %356 = and i64 %347, 7, !dbg !55575
  %357 = trunc i64 %356 to i8, !dbg !55575
  call void @__sanitizer_cov_trace_cmp1(i8 %357, i8 %351), !dbg !55575
  %358 = icmp sge i8 %357, %351, !dbg !55575
  br i1 %358, label %361, label %._crit_edge140, !dbg !55575

._crit_edge140:                                   ; preds = %355
  %359 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 83), align 1, !dbg !55575, !nosanitize !4116
  %360 = add i8 %359, 1, !dbg !55575
  store i8 %360, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 83), align 1, !dbg !55575, !nosanitize !4116
  br label %364, !dbg !55575

361:                                              ; preds = %355
  %362 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 84), align 1, !dbg !55575, !nosanitize !4116
  %363 = add i8 %362, 1, !dbg !55575
  store i8 %363, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 84), align 1, !dbg !55575, !nosanitize !4116
  call void @__asan_report_load1(i64 %347) #42, !dbg !55575
  unreachable

364:                                              ; preds = %._crit_edge140, %bb31.i.i.i.i.i._crit_edge
  %lhsc = load i8, ptr %_61.i.i.i.i.i, align 1, !dbg !55575
  call void @__sanitizer_cov_trace_const_cmp1(i8 46, i8 %lhsc), !dbg !55575
  %_27.i.i.i.i.i = icmp eq i8 %lhsc, 46, !dbg !55575
  br i1 %_27.i.i.i.i.i, label %bb7.i.i.i.i, label %.bb10.i.i.i.i.i_crit_edge, !dbg !55584

.bb10.i.i.i.i.i_crit_edge:                        ; preds = %364
  %365 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 85), align 1, !dbg !55584, !nosanitize !4116
  %366 = add i8 %365, 1, !dbg !55584
  store i8 %366, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 85), align 1, !dbg !55584, !nosanitize !4116
  br label %bb10.i.i.i.i.i, !dbg !55584

bb7.i.i.i.i:                                      ; preds = %364
  call void @__sanitizer_cov_trace_cmp8(i64 %found_char.i.i.i.i.i, i64 %.lcssa513.i.i), !dbg !55585
  %_4.i.i.i.i.i = icmp uge i64 %found_char.i.i.i.i.i, %.lcssa513.i.i, !dbg !55585
  call void @__sanitizer_cov_trace_cmp8(i64 %found_char.i.i.i.i.i, i64 %name.1), !dbg !55210
  %_5.i.i.i.i.i = icmp ule i64 %found_char.i.i.i.i.i, %name.1
  %or.cond.i.i.i.i.i = and i1 %_5.i.i.i.i.i, %_4.i.i.i.i.i, !dbg !55585
  br i1 %or.cond.i.i.i.i.i, label %_RNvNvXs5_NtNtCshZBO5P2NUJi_4core3str6traitsINtNtNtBb_3ops5range5RangejEINtNtNtBb_5slice5index10SliceIndexeE13get_unchecked18precondition_check.exit.i.i.i.i, label %bb3.i.i.i.i.i, !dbg !55585, !prof !7431

bb3.i.i.i.i.i:                                    ; preds = %bb7.i.i.i.i
  %367 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 86), align 1, !dbg !55600, !nosanitize !4116
  %368 = add i8 %367, 1, !dbg !55600
  store i8 %368, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 86), align 1, !dbg !55600, !nosanitize !4116
  call void @__asan_handle_no_return(), !dbg !55600
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCshZBO5P2NUJi_4core9panicking18panic_nounwind_fmt(ptr noundef nonnull @alloc_91f2a00ff2cd9cdc4bb205a66832e2bb, ptr noundef nonnull inttoptr (i64 439 to ptr), i1 noundef zeroext false, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_801dfecfd438b8fcd7a121f4442d14bb) #43, !dbg !55600, !noalias !55602
  unreachable, !dbg !55600

_RNvNvXs5_NtNtCshZBO5P2NUJi_4core3str6traitsINtNtNtBb_3ops5range5RangejEINtNtNtBb_5slice5index10SliceIndexeE13get_unchecked18precondition_check.exit.i.i.i.i: ; preds = %bb7.i.i.i.i
  %369 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 87), align 1, !dbg !55603, !nosanitize !4116
  %370 = add i8 %369, 1, !dbg !55603
  store i8 %370, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 87), align 1, !dbg !55603, !nosanitize !4116
  %new_len.i.i.i.i = sub nuw i64 %found_char.i.i.i.i.i, %.lcssa513.i.i, !dbg !55603
  %self1.i.i.i.i = getelementptr inbounds nuw i8, ptr %name.0, i64 %.lcssa513.i.i, !dbg !55604
  br label %_RNvXsY_NtNtCshZBO5P2NUJi_4core3str4iterINtB5_5SplitcENtNtNtNtB9_4iter6traits8iterator8Iterator4nextCs1K0wxfkMoe8_15spiral_protocol.exit.i.i, !dbg !55608

bb6.i.i.i.i:                                      ; preds = %bb10.i.i.i.i.i.bb6.i.i.i.i_crit_edge, %_RNvNtNtCshZBO5P2NUJi_4core5slice6memchr6memchr.exit.i.i.i.i.i.bb6.i.i.i.i_crit_edge, %bb2.i.i.i.i.bb6.i.i.i.i_crit_edge
  %371 = phi i64 [ %290, %bb2.i.i.i.i.bb6.i.i.i.i_crit_edge ], [ %339, %bb10.i.i.i.i.i.bb6.i.i.i.i_crit_edge ], [ %name.1, %_RNvNtNtCshZBO5P2NUJi_4core5slice6memchr6memchr.exit.i.i.i.i.i.bb6.i.i.i.i_crit_edge ]
  call void @__sanitizer_cov_trace_cmp8(i64 %name.1, i64 %.lcssa513.i.i), !dbg !55609
  %_4.i.i.i.i.i.i.not = icmp ult i64 %name.1, %.lcssa513.i.i, !dbg !55609
  br i1 %_4.i.i.i.i.i.i.not, label %bb3.i.i.i.i.i.i, label %_RNvNvXs5_NtNtCshZBO5P2NUJi_4core3str6traitsINtNtNtBb_3ops5range5RangejEINtNtNtBb_5slice5index10SliceIndexeE13get_unchecked18precondition_check.exit.i.i.i.i.i, !dbg !55609, !prof !15885

bb3.i.i.i.i.i.i:                                  ; preds = %bb6.i.i.i.i
  %372 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 88), align 1, !dbg !55619, !nosanitize !4116
  %373 = add i8 %372, 1, !dbg !55619
  store i8 %373, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 88), align 1, !dbg !55619, !nosanitize !4116
  call void @__asan_handle_no_return(), !dbg !55619
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCshZBO5P2NUJi_4core9panicking18panic_nounwind_fmt(ptr noundef nonnull @alloc_91f2a00ff2cd9cdc4bb205a66832e2bb, ptr noundef nonnull inttoptr (i64 439 to ptr), i1 noundef zeroext false, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_801dfecfd438b8fcd7a121f4442d14bb) #43, !dbg !55619, !noalias !55620
  unreachable, !dbg !55619

_RNvNvXs5_NtNtCshZBO5P2NUJi_4core3str6traitsINtNtNtBb_3ops5range5RangejEINtNtNtBb_5slice5index10SliceIndexeE13get_unchecked18precondition_check.exit.i.i.i.i.i: ; preds = %bb6.i.i.i.i
  %374 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 89), align 1, !dbg !55623, !nosanitize !4116
  %375 = add i8 %374, 1, !dbg !55623
  store i8 %375, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 89), align 1, !dbg !55623, !nosanitize !4116
  %new_len.i4.i.i.i.i = sub nuw i64 %name.1, %.lcssa513.i.i, !dbg !55623
  %self2.i.i.i.i.i = getelementptr inbounds nuw i8, ptr %name.0, i64 %.lcssa513.i.i, !dbg !55624
  br label %_RNvXsY_NtNtCshZBO5P2NUJi_4core3str4iterINtB5_5SplitcENtNtNtNtB9_4iter6traits8iterator8Iterator4nextCs1K0wxfkMoe8_15spiral_protocol.exit.i.i, !dbg !55628

_RNvXsY_NtNtCshZBO5P2NUJi_4core3str4iterINtB5_5SplitcENtNtNtNtB9_4iter6traits8iterator8Iterator4nextCs1K0wxfkMoe8_15spiral_protocol.exit.i.i: ; preds = %bb1.i.i1._RNvXsY_NtNtCshZBO5P2NUJi_4core3str4iterINtB5_5SplitcENtNtNtNtB9_4iter6traits8iterator8Iterator4nextCs1K0wxfkMoe8_15spiral_protocol.exit.i.i_crit_edge, %_RNvNvXs5_NtNtCshZBO5P2NUJi_4core3str6traitsINtNtNtBb_3ops5range5RangejEINtNtNtBb_5slice5index10SliceIndexeE13get_unchecked18precondition_check.exit.i.i.i.i.i, %_RNvNvXs5_NtNtCshZBO5P2NUJi_4core3str6traitsINtNtNtBb_3ops5range5RangejEINtNtNtBb_5slice5index10SliceIndexeE13get_unchecked18precondition_check.exit.i.i.i.i
  %376 = phi i64 [ %290, %bb1.i.i1._RNvXsY_NtNtCshZBO5P2NUJi_4core3str4iterINtB5_5SplitcENtNtNtNtB9_4iter6traits8iterator8Iterator4nextCs1K0wxfkMoe8_15spiral_protocol.exit.i.i_crit_edge ], [ %339, %_RNvNvXs5_NtNtCshZBO5P2NUJi_4core3str6traitsINtNtNtBb_3ops5range5RangejEINtNtNtBb_5slice5index10SliceIndexeE13get_unchecked18precondition_check.exit.i.i.i.i ], [ %371, %_RNvNvXs5_NtNtCshZBO5P2NUJi_4core3str6traitsINtNtNtBb_3ops5range5RangejEINtNtNtBb_5slice5index10SliceIndexeE13get_unchecked18precondition_check.exit.i.i.i.i.i ]
  %.lcssa512.i.i = phi i64 [ %.lcssa513.i.i, %bb1.i.i1._RNvXsY_NtNtCshZBO5P2NUJi_4core3str4iterINtB5_5SplitcENtNtNtNtB9_4iter6traits8iterator8Iterator4nextCs1K0wxfkMoe8_15spiral_protocol.exit.i.i_crit_edge ], [ %339, %_RNvNvXs5_NtNtCshZBO5P2NUJi_4core3str6traitsINtNtNtBb_3ops5range5RangejEINtNtNtBb_5slice5index10SliceIndexeE13get_unchecked18precondition_check.exit.i.i.i.i ], [ %.lcssa513.i.i, %_RNvNvXs5_NtNtCshZBO5P2NUJi_4core3str6traitsINtNtNtBb_3ops5range5RangejEINtNtNtBb_5slice5index10SliceIndexeE13get_unchecked18precondition_check.exit.i.i.i.i.i ]
  %377 = phi i1 [ true, %bb1.i.i1._RNvXsY_NtNtCshZBO5P2NUJi_4core3str4iterINtB5_5SplitcENtNtNtNtB9_4iter6traits8iterator8Iterator4nextCs1K0wxfkMoe8_15spiral_protocol.exit.i.i_crit_edge ], [ false, %_RNvNvXs5_NtNtCshZBO5P2NUJi_4core3str6traitsINtNtNtBb_3ops5range5RangejEINtNtNtBb_5slice5index10SliceIndexeE13get_unchecked18precondition_check.exit.i.i.i.i ], [ true, %_RNvNvXs5_NtNtCshZBO5P2NUJi_4core3str6traitsINtNtNtBb_3ops5range5RangejEINtNtNtBb_5slice5index10SliceIndexeE13get_unchecked18precondition_check.exit.i.i.i.i.i ]
  %_0.sroa.4.1.i.i.i.i = phi i64 [ undef, %bb1.i.i1._RNvXsY_NtNtCshZBO5P2NUJi_4core3str4iterINtB5_5SplitcENtNtNtNtB9_4iter6traits8iterator8Iterator4nextCs1K0wxfkMoe8_15spiral_protocol.exit.i.i_crit_edge ], [ %new_len.i.i.i.i, %_RNvNvXs5_NtNtCshZBO5P2NUJi_4core3str6traitsINtNtNtBb_3ops5range5RangejEINtNtNtBb_5slice5index10SliceIndexeE13get_unchecked18precondition_check.exit.i.i.i.i ], [ %new_len.i4.i.i.i.i, %_RNvNvXs5_NtNtCshZBO5P2NUJi_4core3str6traitsINtNtNtBb_3ops5range5RangejEINtNtNtBb_5slice5index10SliceIndexeE13get_unchecked18precondition_check.exit.i.i.i.i.i ], !dbg !55629
  %_0.sroa.0.1.i.i.i.i = phi ptr [ null, %bb1.i.i1._RNvXsY_NtNtCshZBO5P2NUJi_4core3str4iterINtB5_5SplitcENtNtNtNtB9_4iter6traits8iterator8Iterator4nextCs1K0wxfkMoe8_15spiral_protocol.exit.i.i_crit_edge ], [ %self1.i.i.i.i, %_RNvNvXs5_NtNtCshZBO5P2NUJi_4core3str6traitsINtNtNtBb_3ops5range5RangejEINtNtNtBb_5slice5index10SliceIndexeE13get_unchecked18precondition_check.exit.i.i.i.i ], [ %self2.i.i.i.i.i, %_RNvNvXs5_NtNtCshZBO5P2NUJi_4core3str6traitsINtNtNtBb_3ops5range5RangejEINtNtNtBb_5slice5index10SliceIndexeE13get_unchecked18precondition_check.exit.i.i.i.i.i ], !dbg !55629
  %.not.i.i = icmp ne ptr %_0.sroa.0.1.i.i.i.i, null, !dbg !55630
  %378 = add i64 %_0.sroa.4.1.i.i.i.i, -1
  call void @__sanitizer_cov_trace_const_cmp8(i64 63, i64 %378), !dbg !55210
  %or.cond.i.i.i.i = icmp ult i64 %378, 63
  %or.cond.i.i = select i1 %.not.i.i, i1 %or.cond.i.i.i.i, i1 false, !dbg !55631
  br i1 %or.cond.i.i, label %bb4.i.i.i.i, label %_RINvYINtNtNtCshZBO5P2NUJi_4core3str4iter5SplitcENtNtNtNtBa_4iter6traits8iterator8Iterator8try_folduNCINvNvBK_3all5checkReNCNvNtCs1K0wxfkMoe8_15spiral_protocol9handshake17validate_identity0E0INtNtNtBa_3ops12control_flow11ControlFlowuEEB21_.exit.loopexit9.i, !dbg !55631

bb4.i.i.i.i:                                      ; preds = %_RNvXsY_NtNtCshZBO5P2NUJi_4core3str4iterINtB5_5SplitcENtNtNtNtB9_4iter6traits8iterator8Iterator4nextCs1K0wxfkMoe8_15spiral_protocol.exit.i.i
  %379 = ptrtoint ptr %_0.sroa.0.1.i.i.i.i to i64, !dbg !55632
  %380 = lshr i64 %379, 3, !dbg !55632
  %381 = add i64 %380, 2147450880, !dbg !55632
  %382 = inttoptr i64 %381 to ptr, !dbg !55632
  %383 = load i8, ptr %382, align 1, !dbg !55632
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %383), !dbg !55632
  %384 = icmp ne i8 %383, 0, !dbg !55632
  br i1 %384, label %387, label %bb4.i.i.i.i._crit_edge, !dbg !55632, !prof !4264

bb4.i.i.i.i._crit_edge:                           ; preds = %bb4.i.i.i.i
  %385 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 90), align 1, !dbg !55632, !nosanitize !4116
  %386 = add i8 %385, 1, !dbg !55632
  store i8 %386, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 90), align 1, !dbg !55632, !nosanitize !4116
  br label %396, !dbg !55632

387:                                              ; preds = %bb4.i.i.i.i
  %388 = and i64 %379, 7, !dbg !55632
  %389 = trunc i64 %388 to i8, !dbg !55632
  call void @__sanitizer_cov_trace_cmp1(i8 %389, i8 %383), !dbg !55632
  %390 = icmp sge i8 %389, %383, !dbg !55632
  br i1 %390, label %393, label %._crit_edge141, !dbg !55632

._crit_edge141:                                   ; preds = %387
  %391 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 91), align 1, !dbg !55632, !nosanitize !4116
  %392 = add i8 %391, 1, !dbg !55632
  store i8 %392, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 91), align 1, !dbg !55632, !nosanitize !4116
  br label %396, !dbg !55632

393:                                              ; preds = %387
  %394 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 92), align 1, !dbg !55632, !nosanitize !4116
  %395 = add i8 %394, 1, !dbg !55632
  store i8 %395, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 92), align 1, !dbg !55632, !nosanitize !4116
  call void @__asan_report_load1(i64 %379) #42, !dbg !55632
  unreachable

396:                                              ; preds = %._crit_edge141, %bb4.i.i.i.i._crit_edge
  %397 = load i8, ptr %_0.sroa.0.1.i.i.i.i, align 1, !dbg !55632, !alias.scope !55649, !noalias !55660, !noundef !4116
  %398 = add i8 %397, -48, !dbg !55632
  call void @__sanitizer_cov_trace_const_cmp1(i8 10, i8 %398), !dbg !55632
  %_3.sroa.0.0.i.i.i.i.i.i.i = icmp ult i8 %398, 10, !dbg !55632
  call void @__sanitizer_cov_trace_const_cmp1(i8 64, i8 %397), !dbg !55661
  %_7.i.i.i.i.i.i.i = icmp ugt i8 %397, 64, !dbg !55661
  call void @__sanitizer_cov_trace_const_cmp1(i8 91, i8 %397), !dbg !55661
  %_8.i.i.i.i.i.i.i = icmp ult i8 %397, 91, !dbg !55661
  %_6.sroa.0.0.i.i.i.i.i.i.i = select i1 %_7.i.i.i.i.i.i.i, i1 %_8.i.i.i.i.i.i.i, i1 %_3.sroa.0.0.i.i.i.i.i.i.i, !dbg !55661
  call void @__sanitizer_cov_trace_const_cmp1(i8 96, i8 %397), !dbg !55664
  %_10.i.i.i.i.i.i.i = icmp ugt i8 %397, 96, !dbg !55664
  call void @__sanitizer_cov_trace_const_cmp1(i8 123, i8 %397), !dbg !55664
  %_11.i.i.i.i.i.i.i = icmp ult i8 %397, 123, !dbg !55664
  %_9.sroa.0.0.i.i.i.i.i.i.i = select i1 %_10.i.i.i.i.i.i.i, i1 %_11.i.i.i.i.i.i.i, i1 %_6.sroa.0.0.i.i.i.i.i.i.i, !dbg !55664
  br i1 %_9.sroa.0.0.i.i.i.i.i.i.i, label %bb8.i.i.i.i, label %.bb32_crit_edge142, !dbg !55667

.bb32_crit_edge142:                               ; preds = %396
  %399 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 93), align 1, !dbg !55667, !nosanitize !4116
  %400 = add i8 %399, 1, !dbg !55667
  store i8 %400, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 93), align 1, !dbg !55667, !nosanitize !4116
  br label %bb32, !dbg !55667

bb8.i.i.i.i:                                      ; preds = %396
  %401 = getelementptr i8, ptr %_0.sroa.0.1.i.i.i.i, i64 %_0.sroa.4.1.i.i.i.i, !dbg !55668
  %last.i.i.i.i.i = getelementptr i8, ptr %401, i64 -1, !dbg !55668
  %.not.i3.i.i.i.i = icmp eq ptr %last.i.i.i.i.i, null, !dbg !55672
  br i1 %.not.i3.i.i.i.i, label %bb8.i.i.i.i.bb32_crit_edge, label %bb2.i4.i.i.i.i, !dbg !55674

bb8.i.i.i.i.bb32_crit_edge:                       ; preds = %bb8.i.i.i.i
  %402 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 94), align 1, !dbg !55674, !nosanitize !4116
  %403 = add i8 %402, 1, !dbg !55674
  store i8 %403, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 94), align 1, !dbg !55674, !nosanitize !4116
  br label %bb32, !dbg !55674

bb2.i4.i.i.i.i:                                   ; preds = %bb8.i.i.i.i
  %404 = ptrtoint ptr %last.i.i.i.i.i to i64, !dbg !55675
  %405 = lshr i64 %404, 3, !dbg !55675
  %406 = add i64 %405, 2147450880, !dbg !55675
  %407 = inttoptr i64 %406 to ptr, !dbg !55675
  %408 = load i8, ptr %407, align 1, !dbg !55675
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %408), !dbg !55675
  %409 = icmp ne i8 %408, 0, !dbg !55675
  br i1 %409, label %412, label %bb2.i4.i.i.i.i._crit_edge, !dbg !55675, !prof !4264

bb2.i4.i.i.i.i._crit_edge:                        ; preds = %bb2.i4.i.i.i.i
  %410 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 95), align 1, !dbg !55675, !nosanitize !4116
  %411 = add i8 %410, 1, !dbg !55675
  store i8 %411, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 95), align 1, !dbg !55675, !nosanitize !4116
  br label %421, !dbg !55675

412:                                              ; preds = %bb2.i4.i.i.i.i
  %413 = and i64 %404, 7, !dbg !55675
  %414 = trunc i64 %413 to i8, !dbg !55675
  call void @__sanitizer_cov_trace_cmp1(i8 %414, i8 %408), !dbg !55675
  %415 = icmp sge i8 %414, %408, !dbg !55675
  br i1 %415, label %418, label %._crit_edge143, !dbg !55675

._crit_edge143:                                   ; preds = %412
  %416 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 96), align 1, !dbg !55675, !nosanitize !4116
  %417 = add i8 %416, 1, !dbg !55675
  store i8 %417, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 96), align 1, !dbg !55675, !nosanitize !4116
  br label %421, !dbg !55675

418:                                              ; preds = %412
  %419 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 97), align 1, !dbg !55675, !nosanitize !4116
  %420 = add i8 %419, 1, !dbg !55675
  store i8 %420, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 97), align 1, !dbg !55675, !nosanitize !4116
  call void @__asan_report_load1(i64 %404) #42, !dbg !55675
  unreachable

421:                                              ; preds = %._crit_edge143, %bb2.i4.i.i.i.i._crit_edge
  %422 = load i8, ptr %last.i.i.i.i.i, align 1, !dbg !55675, !alias.scope !55678, !noalias !55660, !noundef !4116
  %423 = add i8 %422, -48, !dbg !55675
  call void @__sanitizer_cov_trace_const_cmp1(i8 10, i8 %423), !dbg !55675
  %_3.sroa.0.0.i.i.i5.i.i.i.i = icmp ult i8 %423, 10, !dbg !55675
  call void @__sanitizer_cov_trace_const_cmp1(i8 64, i8 %422), !dbg !55685
  %_7.i.i.i6.i.i.i.i = icmp ugt i8 %422, 64, !dbg !55685
  call void @__sanitizer_cov_trace_const_cmp1(i8 91, i8 %422), !dbg !55685
  %_8.i.i.i7.i.i.i.i = icmp ult i8 %422, 91, !dbg !55685
  %_6.sroa.0.0.i.i.i8.i.i.i.i = select i1 %_7.i.i.i6.i.i.i.i, i1 %_8.i.i.i7.i.i.i.i, i1 %_3.sroa.0.0.i.i.i5.i.i.i.i, !dbg !55685
  call void @__sanitizer_cov_trace_const_cmp1(i8 96, i8 %422), !dbg !55686
  %_10.i.i.i9.i.i.i.i = icmp ugt i8 %422, 96, !dbg !55686
  call void @__sanitizer_cov_trace_const_cmp1(i8 123, i8 %422), !dbg !55686
  %_11.i.i.i10.i.i.i.i = icmp ult i8 %422, 123, !dbg !55686
  %_9.sroa.0.0.i.i.i11.i.i.i.i = select i1 %_10.i.i.i9.i.i.i.i, i1 %_11.i.i.i10.i.i.i.i, i1 %_6.sroa.0.0.i.i.i8.i.i.i.i, !dbg !55686
  br i1 %_9.sroa.0.0.i.i.i11.i.i.i.i, label %bb12.i.i.i.i, label %.bb32_crit_edge144, !dbg !55687

.bb32_crit_edge144:                               ; preds = %421
  %424 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 98), align 1, !dbg !55687, !nosanitize !4116
  %425 = add i8 %424, 1, !dbg !55687
  store i8 %425, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 98), align 1, !dbg !55687, !nosanitize !4116
  br label %bb32, !dbg !55687

bb12.i.i.i.i:                                     ; preds = %421
  call void @llvm.assume(i1 true) [ "nonnull"(ptr %401) ]
  call void @__sanitizer_cov_trace_const_cmp8(i64 0, i64 %_0.sroa.4.1.i.i.i.i), !dbg !55688
  %_6.i.i.i.i.i.not.i.not.i.i.i103 = icmp eq i64 %_0.sroa.4.1.i.i.i.i, 0, !dbg !55688
  br i1 %_6.i.i.i.i.i.not.i.not.i.i.i103, label %bb12.i.i.i.i.bb1.i.i1.backedge_crit_edge, label %bb12.i.i.i.i.bb3.i.i.i.i.i.i.i.i_crit_edge, !dbg !55705

bb12.i.i.i.i.bb3.i.i.i.i.i.i.i.i_crit_edge:       ; preds = %bb12.i.i.i.i
  br label %bb3.i.i.i.i.i.i.i.i, !dbg !55705

bb12.i.i.i.i.bb1.i.i1.backedge_crit_edge:         ; preds = %bb12.i.i.i.i
  %426 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 99), align 1, !dbg !55705, !nosanitize !4116
  %427 = add i8 %426, 1, !dbg !55705
  store i8 %427, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 99), align 1, !dbg !55705, !nosanitize !4116
  br label %bb1.i.i1.backedge, !dbg !55705

bb1.i.i1.backedge:                                ; preds = %bb1.i.i.i.i.i.i.i.i.bb1.i.i1.backedge_crit_edge, %bb12.i.i.i.i.bb1.i.i1.backedge_crit_edge
  br label %bb1.i.i1, !dbg !55496

bb1.i.i.i.i.i.i.i.i:                              ; preds = %449
  %spec.select.i.i.i.i = getelementptr inbounds nuw i8, ptr %_16.i2.i.i.i.i.i.i.i.i104, i64 1, !dbg !55706
  %_6.i.i.i.i.i.not.i.not.i.i.i = icmp eq ptr %spec.select.i.i.i.i, %401, !dbg !55688
  br i1 %_6.i.i.i.i.i.not.i.not.i.i.i, label %bb1.i.i.i.i.i.i.i.i.bb1.i.i1.backedge_crit_edge, label %bb1.i.i.i.i.i.i.i.i.bb3.i.i.i.i.i.i.i.i_crit_edge, !dbg !55705

bb1.i.i.i.i.i.i.i.i.bb3.i.i.i.i.i.i.i.i_crit_edge: ; preds = %bb1.i.i.i.i.i.i.i.i
  %428 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 100), align 1, !dbg !55705, !nosanitize !4116
  %429 = add i8 %428, 1, !dbg !55705
  store i8 %429, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 100), align 1, !dbg !55705, !nosanitize !4116
  br label %bb3.i.i.i.i.i.i.i.i, !dbg !55705

bb1.i.i.i.i.i.i.i.i.bb1.i.i1.backedge_crit_edge:  ; preds = %bb1.i.i.i.i.i.i.i.i
  %430 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 101), align 1, !dbg !55705, !nosanitize !4116
  %431 = add i8 %430, 1, !dbg !55705
  store i8 %431, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 101), align 1, !dbg !55705, !nosanitize !4116
  br label %bb1.i.i1.backedge, !dbg !55705

bb3.i.i.i.i.i.i.i.i:                              ; preds = %bb1.i.i.i.i.i.i.i.i.bb3.i.i.i.i.i.i.i.i_crit_edge, %bb12.i.i.i.i.bb3.i.i.i.i.i.i.i.i_crit_edge
  %_16.i2.i.i.i.i.i.i.i.i104 = phi ptr [ %spec.select.i.i.i.i, %bb1.i.i.i.i.i.i.i.i.bb3.i.i.i.i.i.i.i.i_crit_edge ], [ %_0.sroa.0.1.i.i.i.i, %bb12.i.i.i.i.bb3.i.i.i.i.i.i.i.i_crit_edge ]
  %432 = ptrtoint ptr %_16.i2.i.i.i.i.i.i.i.i104 to i64, !dbg !55707
  %433 = lshr i64 %432, 3, !dbg !55707
  %434 = add i64 %433, 2147450880, !dbg !55707
  %435 = inttoptr i64 %434 to ptr, !dbg !55707
  %436 = load i8, ptr %435, align 1, !dbg !55707
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %436), !dbg !55707
  %437 = icmp ne i8 %436, 0, !dbg !55707
  br i1 %437, label %440, label %bb3.i.i.i.i.i.i.i.i._crit_edge, !dbg !55707, !prof !4264

bb3.i.i.i.i.i.i.i.i._crit_edge:                   ; preds = %bb3.i.i.i.i.i.i.i.i
  %438 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 102), align 1, !dbg !55707, !nosanitize !4116
  %439 = add i8 %438, 1, !dbg !55707
  store i8 %439, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 102), align 1, !dbg !55707, !nosanitize !4116
  br label %449, !dbg !55707

440:                                              ; preds = %bb3.i.i.i.i.i.i.i.i
  %441 = and i64 %432, 7, !dbg !55707
  %442 = trunc i64 %441 to i8, !dbg !55707
  call void @__sanitizer_cov_trace_cmp1(i8 %442, i8 %436), !dbg !55707
  %443 = icmp sge i8 %442, %436, !dbg !55707
  br i1 %443, label %446, label %._crit_edge145, !dbg !55707

._crit_edge145:                                   ; preds = %440
  %444 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 103), align 1, !dbg !55707, !nosanitize !4116
  %445 = add i8 %444, 1, !dbg !55707
  store i8 %445, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 103), align 1, !dbg !55707, !nosanitize !4116
  br label %449, !dbg !55707

446:                                              ; preds = %440
  %447 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 104), align 1, !dbg !55707, !nosanitize !4116
  %448 = add i8 %447, 1, !dbg !55707
  store i8 %448, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 104), align 1, !dbg !55707, !nosanitize !4116
  call void @__asan_report_load1(i64 %432) #42, !dbg !55707
  unreachable

449:                                              ; preds = %._crit_edge145, %bb3.i.i.i.i.i.i.i.i._crit_edge
  %elt.i.i.i.i.i.i.i.i.i = load i8, ptr %_16.i2.i.i.i.i.i.i.i.i104, align 1, !dbg !55707, !alias.scope !55711, !noalias !55714, !noundef !4116
  %450 = add i8 %elt.i.i.i.i.i.i.i.i.i, -123, !dbg !55723
  call void @__sanitizer_cov_trace_const_cmp1(i8 -26, i8 %450), !dbg !55723
  %_0.sroa.0.0.i.i.i.i.i.i.i.i.i.i.i.i = icmp ult i8 %450, -26, !dbg !55723
  %451 = add i8 %elt.i.i.i.i.i.i.i.i.i, -58, !dbg !55734
  call void @__sanitizer_cov_trace_const_cmp1(i8 -10, i8 %451), !dbg !55734
  %_0.sroa.0.0.i1.i.i.i.i.i.i.i.i.i.i.i = icmp ult i8 %451, -10, !dbg !55734
  call void @__sanitizer_cov_trace_const_cmp1(i8 45, i8 %elt.i.i.i.i.i.i.i.i.i), !dbg !55734
  %452 = icmp ne i8 %elt.i.i.i.i.i.i.i.i.i, 45, !dbg !55734
  %spec.select.i.not1.i.i.i.i.i.i.i.i.i.i = and i1 %452, %_0.sroa.0.0.i1.i.i.i.i.i.i.i.i.i.i.i, !dbg !55734
  %_0.sroa.0.0.i.not.i.i.i.i.i.i.i.i.i.i = and i1 %_0.sroa.0.0.i.i.i.i.i.i.i.i.i.i.i.i, %spec.select.i.not1.i.i.i.i.i.i.i.i.i.i, !dbg !55735
  br i1 %_0.sroa.0.0.i.not.i.i.i.i.i.i.i.i.i.i, label %.bb32_crit_edge146, label %bb1.i.i.i.i.i.i.i.i, !dbg !55736

.bb32_crit_edge146:                               ; preds = %449
  %453 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 105), align 1, !dbg !55736, !nosanitize !4116
  %454 = add i8 %453, 1, !dbg !55736
  store i8 %454, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 105), align 1, !dbg !55736, !nosanitize !4116
  br label %bb32, !dbg !55736

_RINvYINtNtNtCshZBO5P2NUJi_4core3str4iter5SplitcENtNtNtNtBa_4iter6traits8iterator8Iterator8try_folduNCINvNvBK_3all5checkReNCNvNtCs1K0wxfkMoe8_15spiral_protocol9handshake17validate_identity0E0INtNtNtBa_3ops12control_flow11ControlFlowuEEB21_.exit.loopexit9.i: ; preds = %_RNvXsY_NtNtCshZBO5P2NUJi_4core3str4iterINtB5_5SplitcENtNtNtNtB9_4iter6traits8iterator8Iterator4nextCs1K0wxfkMoe8_15spiral_protocol.exit.i.i
  br i1 %.not.i.i, label %_RINvYINtNtNtCshZBO5P2NUJi_4core3str4iter5SplitcENtNtNtNtBa_4iter6traits8iterator8Iterator8try_folduNCINvNvBK_3all5checkReNCNvNtCs1K0wxfkMoe8_15spiral_protocol9handshake17validate_identity0E0INtNtNtBa_3ops12control_flow11ControlFlowuEEB21_.exit.loopexit9.i.bb32_crit_edge, label %bb10, !dbg !55737

_RINvYINtNtNtCshZBO5P2NUJi_4core3str4iter5SplitcENtNtNtNtBa_4iter6traits8iterator8Iterator8try_folduNCINvNvBK_3all5checkReNCNvNtCs1K0wxfkMoe8_15spiral_protocol9handshake17validate_identity0E0INtNtNtBa_3ops12control_flow11ControlFlowuEEB21_.exit.loopexit9.i.bb32_crit_edge: ; preds = %_RINvYINtNtNtCshZBO5P2NUJi_4core3str4iter5SplitcENtNtNtNtBa_4iter6traits8iterator8Iterator8try_folduNCINvNvBK_3all5checkReNCNvNtCs1K0wxfkMoe8_15spiral_protocol9handshake17validate_identity0E0INtNtNtBa_3ops12control_flow11ControlFlowuEEB21_.exit.loopexit9.i
  %455 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 106), align 1, !dbg !55737, !nosanitize !4116
  %456 = add i8 %455, 1, !dbg !55737
  store i8 %456, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 106), align 1, !dbg !55737, !nosanitize !4116
  br label %bb32, !dbg !55737

bb10:                                             ; preds = %_RINvYINtNtNtCshZBO5P2NUJi_4core3str4iter5SplitcENtNtNtNtBa_4iter6traits8iterator8Iterator8try_folduNCINvNvBK_3all5checkReNCNvNtCs1K0wxfkMoe8_15spiral_protocol9handshake17validate_identity0E0INtNtNtBa_3ops12control_flow11ControlFlowuEEB21_.exit.loopexit9.i
  %457 = add i64 %26, 4, !dbg !55738
  %458 = inttoptr i64 %457 to ptr, !dbg !55738
  store i16 0, ptr %458, align 1, !dbg !55738
  %459 = add i64 %26, 6, !dbg !55738
  %460 = inttoptr i64 %459 to ptr, !dbg !55738
  store i8 1, ptr %460, align 1, !dbg !55738
; call <core::net::ip_addr::IpAddr as core::str::traits::FromStr>::from_str
  call void @_RNvXs0_NtNtCshZBO5P2NUJi_4core3net6parserNtNtB7_7ip_addr6IpAddrNtNtNtB9_3str6traits7FromStr8from_str(ptr noalias nofree noundef nonnull sret([17 x i8]) align 1 captures(address) dereferenceable(17) %21, ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) %name.0, i64 noundef %name.1) #35, !dbg !55739
  %461 = load i8, ptr %21, align 1, !dbg !55742, !range !6046, !alias.scope !55747, !noundef !4116
  call void @__sanitizer_cov_trace_const_cmp1(i8 2, i8 %461), !dbg !55742
  %.not = icmp ne i8 %461, 2, !dbg !55742
  %462 = add i64 %26, 4, !dbg !55750
  %463 = inttoptr i64 %462 to ptr, !dbg !55750
  store i16 -1800, ptr %463, align 1, !dbg !55750
  %464 = add i64 %26, 6, !dbg !55750
  %465 = inttoptr i64 %464 to ptr, !dbg !55750
  store i8 -8, ptr %465, align 1, !dbg !55750
  %466 = add i64 %service.1, -65
  call void @__sanitizer_cov_trace_const_cmp8(i64 -64, i64 %466), !dbg !55210
  %or.cond7 = icmp ult i64 %466, -64
  %or.cond105 = or i1 %.not, %or.cond7, !dbg !55738
  br i1 %or.cond105, label %bb10.bb32_crit_edge, label %bb21, !dbg !55738

bb10.bb32_crit_edge:                              ; preds = %bb10
  %467 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 107), align 1, !dbg !55738, !nosanitize !4116
  %468 = add i8 %467, 1, !dbg !55738
  store i8 %468, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 107), align 1, !dbg !55738, !nosanitize !4116
  br label %bb32, !dbg !55738

bb21:                                             ; preds = %bb10
  %469 = ptrtoint ptr %service.0 to i64, !dbg !55751
  %470 = lshr i64 %469, 3, !dbg !55751
  %471 = add i64 %470, 2147450880, !dbg !55751
  %472 = inttoptr i64 %471 to ptr, !dbg !55751
  %473 = load i8, ptr %472, align 1, !dbg !55751
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %473), !dbg !55751
  %474 = icmp ne i8 %473, 0, !dbg !55751
  br i1 %474, label %477, label %bb21._crit_edge, !dbg !55751, !prof !4264

bb21._crit_edge:                                  ; preds = %bb21
  %475 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 108), align 1, !dbg !55751, !nosanitize !4116
  %476 = add i8 %475, 1, !dbg !55751
  store i8 %476, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 108), align 1, !dbg !55751, !nosanitize !4116
  br label %486, !dbg !55751

477:                                              ; preds = %bb21
  %478 = and i64 %469, 7, !dbg !55751
  %479 = trunc i64 %478 to i8, !dbg !55751
  call void @__sanitizer_cov_trace_cmp1(i8 %479, i8 %473), !dbg !55751
  %480 = icmp sge i8 %479, %473, !dbg !55751
  br i1 %480, label %483, label %._crit_edge147, !dbg !55751

._crit_edge147:                                   ; preds = %477
  %481 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 109), align 1, !dbg !55751, !nosanitize !4116
  %482 = add i8 %481, 1, !dbg !55751
  store i8 %482, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 109), align 1, !dbg !55751, !nosanitize !4116
  br label %486, !dbg !55751

483:                                              ; preds = %477
  %484 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 110), align 1, !dbg !55751, !nosanitize !4116
  %485 = add i8 %484, 1, !dbg !55751
  store i8 %485, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 110), align 1, !dbg !55751, !nosanitize !4116
  call void @__asan_report_load1(i64 %469) #42, !dbg !55751
  unreachable

486:                                              ; preds = %._crit_edge147, %bb21._crit_edge
  %487 = load i8, ptr %service.0, align 1, !dbg !55751, !alias.scope !55753, !noundef !4116
  %488 = add i8 %487, -48, !dbg !55751
  call void @__sanitizer_cov_trace_const_cmp1(i8 10, i8 %488), !dbg !55751
  %_3.sroa.0.0.i = icmp ult i8 %488, 10, !dbg !55751
  call void @__sanitizer_cov_trace_const_cmp1(i8 64, i8 %487), !dbg !55756
  %_7.i = icmp ugt i8 %487, 64, !dbg !55756
  call void @__sanitizer_cov_trace_const_cmp1(i8 91, i8 %487), !dbg !55756
  %_8.i = icmp ult i8 %487, 91, !dbg !55756
  %_6.sroa.0.0.i = select i1 %_7.i, i1 %_8.i, i1 %_3.sroa.0.0.i, !dbg !55756
  call void @__sanitizer_cov_trace_const_cmp1(i8 96, i8 %487), !dbg !55757
  %_10.i = icmp ugt i8 %487, 96, !dbg !55757
  call void @__sanitizer_cov_trace_const_cmp1(i8 123, i8 %487), !dbg !55757
  %_11.i = icmp ult i8 %487, 123, !dbg !55757
  %_9.sroa.0.0.i = select i1 %_10.i, i1 %_11.i, i1 %_6.sroa.0.0.i, !dbg !55757
  br i1 %_9.sroa.0.0.i, label %bb25, label %.bb32_crit_edge148, !dbg !55758

.bb32_crit_edge148:                               ; preds = %486
  %489 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 111), align 1, !dbg !55758, !nosanitize !4116
  %490 = add i8 %489, 1, !dbg !55758
  store i8 %490, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 111), align 1, !dbg !55758, !nosanitize !4116
  br label %bb32, !dbg !55758

bb25:                                             ; preds = %486
  %_9.i = getelementptr inbounds nuw i8, ptr %service.0, i64 %service.1, !dbg !55759
  call void @__sanitizer_cov_trace_const_cmp8(i64 0, i64 %service.1), !dbg !55770
  %_6.i.i.i.i.i540.not = icmp samesign eq i64 %service.1, 0, !dbg !55770
  br i1 %_6.i.i.i.i.i540.not, label %bb25.bb32_crit_edge, label %bb3.i.i.i.i.preheader, !dbg !55783

bb25.bb32_crit_edge:                              ; preds = %bb25
  %491 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 112), align 1, !dbg !55783, !nosanitize !4116
  %492 = add i8 %491, 1, !dbg !55783
  store i8 %492, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 112), align 1, !dbg !55783, !nosanitize !4116
  br label %bb32, !dbg !55783

bb3.i.i.i.i.preheader:                            ; preds = %bb25
  %spec.select42 = getelementptr inbounds nuw i8, ptr %service.0, i64 1, !dbg !55784
  br label %bb3.i.i.i.i, !dbg !55785

bb1.critedge.i.i.i.i:                             ; preds = %bb7.i.i.i.i.i.i.i.bb1.critedge.i.i.i.i_crit_edge152, %bb7.i.i.i.i.i.i.i.bb1.critedge.i.i.i.i_crit_edge151, %bb7.i.i.i.i.i.i.i.bb1.critedge.i.i.i.i_crit_edge150, %bb7.i.i.i.i.i.i.i.bb1.critedge.i.i.i.i_crit_edge, %.bb1.critedge.i.i.i.i_crit_edge
  %_6.i.i.i.i.i5 = icmp ne ptr %spec.select45, %_9.i, !dbg !55770
  %spec.select.idx = zext i1 %_6.i.i.i.i.i5 to i64, !dbg !55784
  %spec.select = getelementptr inbounds nuw i8, ptr %spec.select45, i64 %spec.select.idx, !dbg !55784
  br i1 %_6.i.i.i.i.i5, label %bb1.critedge.i.i.i.i.bb3.i.i.i.i_crit_edge, label %bb1.critedge.i.i.i.i.bb32_crit_edge, !dbg !55783

bb1.critedge.i.i.i.i.bb32_crit_edge:              ; preds = %bb1.critedge.i.i.i.i
  %493 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 113), align 1, !dbg !55783, !nosanitize !4116
  %494 = add i8 %493, 1, !dbg !55783
  store i8 %494, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 113), align 1, !dbg !55783, !nosanitize !4116
  br label %bb32, !dbg !55783

bb1.critedge.i.i.i.i.bb3.i.i.i.i_crit_edge:       ; preds = %bb1.critedge.i.i.i.i
  %495 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 114), align 1, !dbg !55783, !nosanitize !4116
  %496 = add i8 %495, 1, !dbg !55783
  store i8 %496, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 114), align 1, !dbg !55783, !nosanitize !4116
  br label %bb3.i.i.i.i, !dbg !55783

bb3.i.i.i.i:                                      ; preds = %bb1.critedge.i.i.i.i.bb3.i.i.i.i_crit_edge, %bb3.i.i.i.i.preheader
  %spec.select45 = phi ptr [ %spec.select, %bb1.critedge.i.i.i.i.bb3.i.i.i.i_crit_edge ], [ %spec.select42, %bb3.i.i.i.i.preheader ]
  %_16.i2.i.i.i.i43 = phi ptr [ %spec.select45, %bb1.critedge.i.i.i.i.bb3.i.i.i.i_crit_edge ], [ %service.0, %bb3.i.i.i.i.preheader ]
  %497 = ptrtoint ptr %_16.i2.i.i.i.i43 to i64, !dbg !55793
  %498 = lshr i64 %497, 3, !dbg !55793
  %499 = add i64 %498, 2147450880, !dbg !55793
  %500 = inttoptr i64 %499 to ptr, !dbg !55793
  %501 = load i8, ptr %500, align 1, !dbg !55793
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %501), !dbg !55793
  %502 = icmp ne i8 %501, 0, !dbg !55793
  br i1 %502, label %505, label %bb3.i.i.i.i._crit_edge, !dbg !55793, !prof !4264

bb3.i.i.i.i._crit_edge:                           ; preds = %bb3.i.i.i.i
  %503 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 115), align 1, !dbg !55793, !nosanitize !4116
  %504 = add i8 %503, 1, !dbg !55793
  store i8 %504, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 115), align 1, !dbg !55793, !nosanitize !4116
  br label %514, !dbg !55793

505:                                              ; preds = %bb3.i.i.i.i
  %506 = and i64 %497, 7, !dbg !55793
  %507 = trunc i64 %506 to i8, !dbg !55793
  call void @__sanitizer_cov_trace_cmp1(i8 %507, i8 %501), !dbg !55793
  %508 = icmp sge i8 %507, %501, !dbg !55793
  br i1 %508, label %511, label %._crit_edge149, !dbg !55793

._crit_edge149:                                   ; preds = %505
  %509 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 116), align 1, !dbg !55793, !nosanitize !4116
  %510 = add i8 %509, 1, !dbg !55793
  store i8 %510, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 116), align 1, !dbg !55793, !nosanitize !4116
  br label %514, !dbg !55793

511:                                              ; preds = %505
  %512 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 117), align 1, !dbg !55793, !nosanitize !4116
  %513 = add i8 %512, 1, !dbg !55793
  store i8 %513, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 117), align 1, !dbg !55793, !nosanitize !4116
  call void @__asan_report_load1(i64 %497) #42, !dbg !55793
  unreachable

514:                                              ; preds = %._crit_edge149, %bb3.i.i.i.i._crit_edge
  %elt.i.i.i.i.i = load i8, ptr %_16.i2.i.i.i.i43, align 1, !dbg !55793, !alias.scope !55794, !noalias !55797, !noundef !4116
  %515 = add i8 %elt.i.i.i.i.i, -97, !dbg !55806
  call void @__sanitizer_cov_trace_const_cmp1(i8 26, i8 %515), !dbg !55806
  %_0.sroa.0.0.i.i.i.i.i.i.i.i = icmp ult i8 %515, 26, !dbg !55806
  %516 = add i8 %elt.i.i.i.i.i, -48
  call void @__sanitizer_cov_trace_const_cmp1(i8 10, i8 %516), !dbg !55210
  %_0.sroa.0.0.i1.i.i.i.i.i.i.i = icmp ult i8 %516, 10
  %or.cond.i.i.i.i.i.i.i = or i1 %_0.sroa.0.0.i.i.i.i.i.i.i.i, %_0.sroa.0.0.i1.i.i.i.i.i.i.i, !dbg !55785
  br i1 %or.cond.i.i.i.i.i.i.i, label %.bb1.critedge.i.i.i.i_crit_edge, label %bb7.i.i.i.i.i.i.i, !dbg !55785

.bb1.critedge.i.i.i.i_crit_edge:                  ; preds = %514
  %517 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 118), align 1, !dbg !55785, !nosanitize !4116
  %518 = add i8 %517, 1, !dbg !55785
  store i8 %518, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 118), align 1, !dbg !55785, !nosanitize !4116
  br label %bb1.critedge.i.i.i.i, !dbg !55785

bb7.i.i.i.i.i.i.i:                                ; preds = %514
  %519 = zext i8 %elt.i.i.i.i.i to i64, !dbg !55808
  call void @__sanitizer_cov_trace_switch(i64 %519, ptr @__sancov_gen_cov_switch_values.2164), !dbg !55808
  switch i8 %elt.i.i.i.i.i, label %bb7.i.i.i.i.i.i.i.bb32_crit_edge [
    i8 46, label %bb7.i.i.i.i.i.i.i.bb1.critedge.i.i.i.i_crit_edge
    i8 95, label %bb7.i.i.i.i.i.i.i.bb1.critedge.i.i.i.i_crit_edge150
    i8 47, label %bb7.i.i.i.i.i.i.i.bb1.critedge.i.i.i.i_crit_edge151
    i8 45, label %bb7.i.i.i.i.i.i.i.bb1.critedge.i.i.i.i_crit_edge152
  ], !dbg !55808

bb7.i.i.i.i.i.i.i.bb1.critedge.i.i.i.i_crit_edge152: ; preds = %bb7.i.i.i.i.i.i.i
  %520 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 119), align 1, !dbg !55808, !nosanitize !4116
  %521 = add i8 %520, 1, !dbg !55808
  store i8 %521, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 119), align 1, !dbg !55808, !nosanitize !4116
  br label %bb1.critedge.i.i.i.i, !dbg !55808

bb7.i.i.i.i.i.i.i.bb1.critedge.i.i.i.i_crit_edge151: ; preds = %bb7.i.i.i.i.i.i.i
  %522 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 120), align 1, !dbg !55808, !nosanitize !4116
  %523 = add i8 %522, 1, !dbg !55808
  store i8 %523, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 120), align 1, !dbg !55808, !nosanitize !4116
  br label %bb1.critedge.i.i.i.i, !dbg !55808

bb7.i.i.i.i.i.i.i.bb1.critedge.i.i.i.i_crit_edge150: ; preds = %bb7.i.i.i.i.i.i.i
  %524 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 121), align 1, !dbg !55808, !nosanitize !4116
  %525 = add i8 %524, 1, !dbg !55808
  store i8 %525, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 121), align 1, !dbg !55808, !nosanitize !4116
  br label %bb1.critedge.i.i.i.i, !dbg !55808

bb7.i.i.i.i.i.i.i.bb1.critedge.i.i.i.i_crit_edge: ; preds = %bb7.i.i.i.i.i.i.i
  %526 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 122), align 1, !dbg !55808, !nosanitize !4116
  %527 = add i8 %526, 1, !dbg !55808
  store i8 %527, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 122), align 1, !dbg !55808, !nosanitize !4116
  br label %bb1.critedge.i.i.i.i, !dbg !55808

bb7.i.i.i.i.i.i.i.bb32_crit_edge:                 ; preds = %bb7.i.i.i.i.i.i.i
  %528 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 123), align 1, !dbg !55808, !nosanitize !4116
  %529 = add i8 %528, 1, !dbg !55808
  store i8 %529, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 123), align 1, !dbg !55808, !nosanitize !4116
  br label %bb32, !dbg !55808

bb32:                                             ; preds = %bb7.i.i.i.i.i.i.i.bb32_crit_edge, %bb1.critedge.i.i.i.i.bb32_crit_edge, %bb25.bb32_crit_edge, %.bb32_crit_edge148, %bb10.bb32_crit_edge, %_RINvYINtNtNtCshZBO5P2NUJi_4core3str4iter5SplitcENtNtNtNtBa_4iter6traits8iterator8Iterator8try_folduNCINvNvBK_3all5checkReNCNvNtCs1K0wxfkMoe8_15spiral_protocol9handshake17validate_identity0E0INtNtNtBa_3ops12control_flow11ControlFlowuEEB21_.exit.loopexit9.i.bb32_crit_edge, %.bb32_crit_edge146, %.bb32_crit_edge144, %bb8.i.i.i.i.bb32_crit_edge, %.bb32_crit_edge142, %.bb32_crit_edge138, %.bb32_crit_edge136, %.bb32_crit_edge134, %.bb32_crit_edge132, %.bb32_crit_edge130, %.bb32_crit_edge128, %.bb32_crit_edge126, %.bb32_crit_edge124, %.bb32_crit_edge120, %_RNvNtNtNtCshZBO5P2NUJi_4core9core_arch3x864sse215__mm_loadu_si128.exit27.i.i.i.bb32_crit_edge, %.bb32_crit_edge
  %_0.sroa.0.0 = phi i8 [ 0, %.bb32_crit_edge124 ], [ 0, %.bb32_crit_edge ], [ 0, %_RINvYINtNtNtCshZBO5P2NUJi_4core3str4iter5SplitcENtNtNtNtBa_4iter6traits8iterator8Iterator8try_folduNCINvNvBK_3all5checkReNCNvNtCs1K0wxfkMoe8_15spiral_protocol9handshake17validate_identity0E0INtNtNtBa_3ops12control_flow11ControlFlowuEEB21_.exit.loopexit9.i.bb32_crit_edge ], [ 0, %.bb32_crit_edge138 ], [ 0, %.bb32_crit_edge146 ], [ 0, %.bb32_crit_edge120 ], [ 0, %.bb32_crit_edge148 ], [ 0, %.bb32_crit_edge142 ], [ -1, %bb1.critedge.i.i.i.i.bb32_crit_edge ], [ 0, %bb10.bb32_crit_edge ], [ -1, %bb25.bb32_crit_edge ], [ 0, %bb7.i.i.i.i.i.i.i.bb32_crit_edge ], [ 0, %bb8.i.i.i.i.bb32_crit_edge ], [ 0, %.bb32_crit_edge144 ], [ 0, %.bb32_crit_edge136 ], [ 0, %.bb32_crit_edge134 ], [ 0, %.bb32_crit_edge132 ], [ 0, %.bb32_crit_edge130 ], [ 0, %.bb32_crit_edge128 ], [ 0, %.bb32_crit_edge126 ], [ 0, %_RNvNtNtNtCshZBO5P2NUJi_4core9core_arch3x864sse215__mm_loadu_si128.exit27.i.i.i.bb32_crit_edge ], !dbg !55817
  %530 = insertvalue { i8, i8 } poison, i8 %_0.sroa.0.0, 0, !dbg !55818
  %531 = insertvalue { i8, i8 } %530, i8 undef, 1, !dbg !55818
  store i64 1172321806, ptr %20, align 8, !dbg !55818
  call void @__sanitizer_cov_trace_const_cmp8(i64 0, i64 %11), !dbg !55818
  %532 = icmp ne i64 %11, 0, !dbg !55818
  br i1 %532, label %533, label %543, !dbg !55818

533:                                              ; preds = %bb32
  %534 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 124), align 1, !dbg !55818, !nosanitize !4116
  %535 = add i8 %534, 1, !dbg !55818
  store i8 %535, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 124), align 1, !dbg !55818, !nosanitize !4116
  %536 = add i64 %26, 0, !dbg !55818
  %537 = inttoptr i64 %536 to ptr, !dbg !55818
  store i64 -723401728380766731, ptr %537, align 1, !dbg !55818
  %538 = add i64 %26, 8, !dbg !55818
  %539 = inttoptr i64 %538 to ptr, !dbg !55818
  store i64 -723401728380766731, ptr %539, align 1, !dbg !55818
  %540 = getelementptr i8, ptr %12, i64 120, !dbg !55818
  %541 = load i64, ptr %540, align 8, !dbg !55818
  %542 = inttoptr i64 %541 to ptr, !dbg !55818
  store i8 0, ptr %542, align 1, !dbg !55818
  br label %550, !dbg !55818

543:                                              ; preds = %bb32
  %544 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 125), align 1, !dbg !55818, !nosanitize !4116
  %545 = add i8 %544, 1, !dbg !55818
  store i8 %545, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2162, i64 0, i64 125), align 1, !dbg !55818, !nosanitize !4116
  %546 = add i64 %26, 0, !dbg !55818
  %547 = inttoptr i64 %546 to ptr, !dbg !55818
  store i64 0, ptr %547, align 1, !dbg !55818
  %548 = add i64 %26, 8, !dbg !55818
  %549 = inttoptr i64 %548 to ptr, !dbg !55818
  store i32 0, ptr %549, align 1, !dbg !55818
  br label %550, !dbg !55818

550:                                              ; preds = %543, %533
  ret { i8, i8 } %531, !dbg !55818
}

