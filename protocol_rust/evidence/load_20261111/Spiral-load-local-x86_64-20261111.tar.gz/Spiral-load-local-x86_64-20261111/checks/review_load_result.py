"""Read-only checks of completed finite load evidence; does not execute probe code."""
from pathlib import Path
import hashlib,json,math,statistics,sys

def sha(data):return hashlib.sha256(data).hexdigest()
def load(path):return json.loads(path.read_text())
def review(folder):
 result=load(folder/'result.json');final=result['probe_final'];errors=[]
 def check(condition,message):
  if not condition:errors.append(message)
 manifest=load(folder/'SHA256.json')
 check(all((folder/name).is_file() and sha((folder/name).read_bytes())==digest for name,digest in manifest.items()),'evidence digest mismatch')
 check(set(manifest)=={p.name for p in folder.iterdir() if p.is_file() and p.name!='SHA256.json'},'manifest file coverage differs')
 check(result['status']=='passed' and result['probe_exit_code']==0,'campaign did not pass')
 check(final['requested_duration_seconds']==1800 and final['traffic_epoch_elapsed_seconds']>=1800,'30-minute traffic duration missing')
 check(final['soak_elapsed_seconds']>=1800,'soak duration missing')
 check(final['peak_authenticated_connections']==64,'64 authenticated connections missing')
 check(final['limit_checks']=={'global':True,'pending':True,'per_ip':True},'admission cases incomplete')
 epochs=final['completed_epochs'];pairs=final['authenticated_pairs_total'];messages=final['total_messages'];payload=result['payload_bytes']
 check(epochs>=8 and pairs==6+epochs*64,'session rotation accounting mismatch')
 check(final['authenticated_pair_closes']==pairs and final['successful_endpoint_handshakes']==pairs*2,'handshake/closure accounting mismatch')
 check(final['kem']['executed_jobs']==pairs*3 and final['kem']['rejected_jobs']==0 and final['kem']['live_keys']==0,'KEM ownership/accounting mismatch')
 check(final['active']==final['pending']==0 and final['admission_released'] and final['auth_key_closed'],'final ownership not released')
 check(final['authenticated_close_for_all_completed_pairs'] and final['errors']==[],'authenticated close or execution failed')
 check(final['echoed_bytes']==messages*payload and final['bidirectional_payload_bytes']==2*messages*payload,'payload accounting mismatch')
 check(final['final_resources']['fd_count']<=final['resource_baseline']['fd_count']-1,'descriptor count did not recover beyond closed listener')
 check(result['source_unchanged'] and result['binary_unchanged'],'input provenance changed')
 before=load(folder/'source-before.json');after=load(folder/'source-after.json')
 check(before['files']==after['files'],'source file hashes differ')
 for snap in (before,after):
  check(sha(json.dumps(snap['files'],sort_keys=True,separators=(',',':')).encode())==snap['source_tree_sha256'],'canonical source digest differs')
 check(sha((folder/'collector-source.py').read_bytes())==before['files']['protocol_rust/validation/load_campaign.py'],'used collector source copy differs')
 check(sha((folder/'probe-source.rs').read_bytes())==before['files']['protocol_rust/examples/load_probe.rs'],'used probe source copy differs')
 events=[json.loads(line) for line in (folder/'probe.stdout.jsonl').read_text().splitlines()]
 finals=[e for e in events if e.get('event')=='final'];check(finals==[final],'raw/final summary mismatch')
 cases=[e for e in events if e.get('event')=='limit_case'];check(len(cases)==3 and all(e['status']=='passed' for e in cases),'raw admission cases differ')
 samples=[e for e in events if e.get('event')=='sample'];check(len(samples)>=1700,'too few live traffic samples')
 check(all(0<=s['pending']<=s['active']<=64 for s in samples),'admission count out of bounds')
 check(all(b['total_messages']>=a['total_messages'] and b['soak_elapsed_seconds']>=a['soak_elapsed_seconds'] for a,b in zip(samples,samples[1:])),'nonmonotonic traffic samples')
 resources=[json.loads(line) for line in (folder/'resources.jsonl').read_text().splitlines()]
 check(len(resources)==result['resource_samples'],'resource sample count differs')
 limits=result['resource_limits']
 check(all(r['peak_rss_kib']<=limits['rss_mib']*1024 and r['fd_count']<=limits['fds'] and r['threads']<=limits['threads'] for r in resources),'process guard exceeded')
 check(not any(p.suffix in ('.pem','.key','.bin','.crt','.der') for p in folder.iterdir()),'credential/binary file in evidence')
 return {'schema':'spiral-load-evidence-review/v1','status':'passed' if not errors else 'failed','errors':errors,'traffic_seconds':final['traffic_epoch_elapsed_seconds'],'wall_seconds':result['wall_elapsed_seconds'],'connections':64,'verified_roundtrips':messages,'payload_bytes':payload,'payload_GiB_bidirectional':final['bidirectional_payload_bytes']/1024**3,'completed_epochs':epochs,'authenticated_pairs':pairs,'fd_baseline_including_listener':final['resource_baseline']['fd_count'],'fd_final':final['final_resources']['fd_count'],'peak_rss_mib':max(r['peak_rss_kib'] for r in resources)/1024,'sampled_peak_fds':max(r['fd_count'] for r in resources),'sampled_peak_threads':max(r['threads'] for r in resources),'source_files_verified':len(before['files']),'traffic_samples':len(samples),'resource_samples':len(resources),'scope':'Local combined-endpoint Linux experiment; stronger final FD check accounts for the closed listener; no production capacity, memory-erasure or constant-time approval.'}
if __name__=='__main__':
 r=review(Path(sys.argv[1]));Path(sys.argv[2]).write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2));raise SystemExit(0 if r['status']=='passed' else 1)
