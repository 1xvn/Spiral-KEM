"""One short local real-TLS cut and normal recovery; no SSH or external host."""
from contextlib import ExitStack
import json
from pathlib import Path
import selectors
import socket
import subprocess
import sys
import tempfile
import time

REPO=Path('/workspace/Spiral-KEM-public-release')
OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(REPO/'protocol_rust/validation'))
sys.path.insert(0,str(REPO/'protocol_rust'))
import cross_host_smoke as base
import inflight_disconnect as fault
from interop import identities

base.BINARY=Path('/workspace/spiral-load-build/release/spiral-lab')
RELAY=r'''
import asyncio,json,sys
async def pipe(reader,writer):
    while data:=await reader.read(65536):
        writer.write(data);await writer.drain()
async def handle(reader,writer):
    peer,remote=await asyncio.open_connection('127.0.0.1',int(sys.argv[1]))
    try:await asyncio.gather(pipe(reader,remote),pipe(peer,writer))
    finally:writer.close();remote.close()
async def main():
    server=await asyncio.start_server(handle,'127.0.0.1',0)
    print(json.dumps({'port':server.sockets[0].getsockname()[1]}),flush=True)
    async with server:await server.serve_forever()
asyncio.run(main())
'''

def line(process):
    data=b''
    with selectors.DefaultSelector() as selector:
        selector.register(process.stdout,selectors.EVENT_READ)
        deadline=time.monotonic()+5
        while time.monotonic()<deadline:
            for key,_ in selector.select(.1):
                chunk=__import__('os').read(key.fd,65536)
                if not chunk:raise ValueError('early readiness EOF')
                data+=chunk
                if b'\n' in data:return data
    raise TimeoutError('local readiness')

def server_args(private,port,checkpoint):
    args=[str(base.BINARY),'server','--name',base.NAME,'--service',base.SERVICE,
          '--port',str(port),'--connections','1','--messages','10','--workers','1',
          '--cert',str(private/'cert.pem'),'--key',str(private/'key.pem'),'--auth',str(private/'auth.bin')]
    return args+(['--fault-checkpoint','3'] if checkpoint else [])

def run():
    started=time.monotonic();before=base.source();processes=[]
    try:
        with tempfile.TemporaryDirectory(prefix='spiral-inflight-private-') as temp,ExitStack() as stack:
            private=Path(temp);identities(private)
            files={name:stack.enter_context((OUT/name).open('wb')) for name in
                   ('server.jsonl','client.jsonl','server.stderr.log','client.stderr.log','relay.stderr.log')}
            server=subprocess.Popen(server_args(private,0,True),stdout=subprocess.PIPE,stderr=files['server.stderr.log']);processes.append(server)
            ready=line(server);files['server.jsonl'].write(ready)
            port=base.campaign.strict_json(ready)['listening']
            relay=subprocess.Popen([sys.executable,'-B','-u','-c',RELAY,str(port)],stdout=subprocess.PIPE,stderr=files['relay.stderr.log']);processes.append(relay)
            relay_port=base.campaign.strict_json(line(relay))['port']
            client=subprocess.Popen(base.client_command(relay_port,private)+['--fault-checkpoint','3'],stdout=subprocess.PIPE,stderr=files['client.stderr.log']);processes.append(client)
            controller=stack.enter_context((OUT/'controller.jsonl').open('w'))
            tracker,codes,events=fault.monitor(client,server,relay,relay_port,
                {'server':files['server.jsonl'],'client':files['client.jsonl']},controller)
        errors={role:(OUT/(role+'.stderr.log')).read_bytes() for role in ('server','client')}
        tracker.validate(codes,errors)
        result={'status':'passed','scope':'Local real loopback TLS through a disposable TCP relay; no SSH or OCI/WSL execution.',
                'fault_checkpoints':tracker.pending,'fault_finals':tracker.finals,'fault_cleanup':tracker.cleanup,
                'fault_exit_codes':codes,'fault_events':events,'authenticated_protocol_close_claimed_for_cut':False}
        # Separate temporary fixtures stay private and are removed after recovery.
        with tempfile.TemporaryDirectory(prefix='spiral-recovery-private-') as temp:
            private=Path(temp);identities(private)
            with (OUT/'recovery-server.stderr.log').open('wb') as errors:
                server=subprocess.Popen(server_args(private,0,False),stdout=subprocess.PIPE,stderr=errors);processes.append(server)
                ready=line(server);port=base.campaign.strict_json(ready)['listening']
                client=subprocess.run(base.client_command(port,private),capture_output=True,timeout=10)
                rest,_=server.communicate(timeout=5)
                (OUT/'recovery-server.jsonl').write_bytes(ready+rest)
                (OUT/'recovery-client.jsonl').write_bytes(client.stdout)
                (OUT/'recovery-client.stderr.log').write_bytes(client.stderr)
                left=base.final_report(ready+rest);right=base.final_report(client.stdout)
                assert client.returncode==server.returncode==0
                base.validate_pair(left,right)
                assert right['sessions'][0]['session_id']!=tracker.pending['client']['session_id']
                result['recovery']={'server':left,'client':right}
        result['source_before']=before;result['source_after']=base.source()
        assert result['source_before']['source']['files']==result['source_after']['source']['files']
        assert result['source_before']['binary_sha256']==result['source_after']['binary_sha256']
        result['wall_seconds']=time.monotonic()-started
        result['private_fixtures_removed']=True
        (OUT/'result.json').write_text(json.dumps(result,indent=2)+'\n')
        print(json.dumps({'status':result['status'],'wall_seconds':result['wall_seconds'],
                          'active':tracker.cleanup['active'],'pending':tracker.cleanup['pending'],
                          'native_live_keys':[tracker.finals[r]['kem']['live_keys'] for r in ('client','server')]}))
    finally:
        for process in processes:base.stop(process)

if __name__=='__main__':run()
