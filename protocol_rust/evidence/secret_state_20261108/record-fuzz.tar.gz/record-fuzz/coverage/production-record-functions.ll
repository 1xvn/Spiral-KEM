; Verified production function: header_parse
define void @_RNvMNtCs4oicsBtN6nJ_15spiral_protocol4wireNtB2_6Header5parse(ptr dead_on_unwind noalias nofree noundef writable writeonly sret([48 x i8]) align 8 captures(none) dereferenceable(48) initializes((0, 1)) %_0, ptr noalias nofree noundef nonnull readonly captures(none) %raw.0, i64 noundef range(i64 0, -9223372036854775808) %raw.1) unnamed_addr #15 comdat !dbg !29562 !guid !29564 {
start:
  %0 = load i8, ptr @__sancov_gen_.1452, align 1, !dbg !29565, !nosanitize !4110
  %1 = add i8 %0, 1, !dbg !29565
  store i8 %1, ptr @__sancov_gen_.1452, align 1, !dbg !29565, !nosanitize !4110
  call void @__sanitizer_cov_trace_const_cmp8(i64 40, i64 %raw.1), !dbg !29566
  %2 = icmp eq i64 %raw.1, 40, !dbg !29566
  br i1 %2, label %bb1, label %start.bb98_crit_edge, !dbg !29566

start.bb98_crit_edge:                             ; preds = %start
  %3 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 1), align 1, !dbg !29566, !nosanitize !4110
  %4 = add i8 %3, 1, !dbg !29566
  store i8 %4, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 1), align 1, !dbg !29566, !nosanitize !4110
  br label %bb98, !dbg !29566

bb1:                                              ; preds = %start
  %5 = ptrtoint ptr %raw.0 to i64, !dbg !29567
  %6 = add i64 %5, 3, !dbg !29567
  %7 = inttoptr i64 %6 to ptr, !dbg !29567
  %8 = ptrtoint ptr %raw.0 to i64, !dbg !29567
  %9 = lshr i64 %8, 3, !dbg !29567
  %10 = add i64 %9, 2147450880, !dbg !29567
  %11 = inttoptr i64 %10 to ptr, !dbg !29567
  %12 = load i8, ptr %11, align 1, !dbg !29567
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %12), !dbg !29567
  %13 = icmp ne i8 %12, 0, !dbg !29567
  br i1 %13, label %16, label %bb1._crit_edge, !dbg !29567, !prof !4181

bb1._crit_edge:                                   ; preds = %bb1
  %14 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 2), align 1, !dbg !29567, !nosanitize !4110
  %15 = add i8 %14, 1, !dbg !29567
  store i8 %15, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 2), align 1, !dbg !29567, !nosanitize !4110
  br label %25, !dbg !29567

16:                                               ; preds = %bb1
  %17 = and i64 %8, 7, !dbg !29567
  %18 = trunc i64 %17 to i8, !dbg !29567
  call void @__sanitizer_cov_trace_cmp1(i8 %18, i8 %12), !dbg !29567
  %19 = icmp sge i8 %18, %12, !dbg !29567
  br i1 %19, label %22, label %._crit_edge, !dbg !29567

._crit_edge:                                      ; preds = %16
  %20 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 3), align 1, !dbg !29567, !nosanitize !4110
  %21 = add i8 %20, 1, !dbg !29567
  store i8 %21, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 3), align 1, !dbg !29567, !nosanitize !4110
  br label %25, !dbg !29567

22:                                               ; preds = %16
  %23 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 4), align 1, !dbg !29567, !nosanitize !4110
  %24 = add i8 %23, 1, !dbg !29567
  store i8 %24, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 4), align 1, !dbg !29567, !nosanitize !4110
  call void @__asan_report_load_n(i64 %8, i64 4) #42, !dbg !29567
  unreachable

25:                                               ; preds = %._crit_edge, %bb1._crit_edge
  %26 = ptrtoint ptr %7 to i64, !dbg !29567
  %27 = lshr i64 %26, 3, !dbg !29567
  %28 = add i64 %27, 2147450880, !dbg !29567
  %29 = inttoptr i64 %28 to ptr, !dbg !29567
  %30 = load i8, ptr %29, align 1, !dbg !29567
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %30), !dbg !29567
  %31 = icmp ne i8 %30, 0, !dbg !29567
  br i1 %31, label %34, label %._crit_edge70, !dbg !29567, !prof !4181

._crit_edge70:                                    ; preds = %25
  %32 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 5), align 1, !dbg !29567, !nosanitize !4110
  %33 = add i8 %32, 1, !dbg !29567
  store i8 %33, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 5), align 1, !dbg !29567, !nosanitize !4110
  br label %43, !dbg !29567

34:                                               ; preds = %25
  %35 = and i64 %26, 7, !dbg !29567
  %36 = trunc i64 %35 to i8, !dbg !29567
  call void @__sanitizer_cov_trace_cmp1(i8 %36, i8 %30), !dbg !29567
  %37 = icmp sge i8 %36, %30, !dbg !29567
  br i1 %37, label %40, label %._crit_edge71, !dbg !29567

._crit_edge71:                                    ; preds = %34
  %38 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 6), align 1, !dbg !29567, !nosanitize !4110
  %39 = add i8 %38, 1, !dbg !29567
  store i8 %39, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 6), align 1, !dbg !29567, !nosanitize !4110
  br label %43, !dbg !29567

40:                                               ; preds = %34
  %41 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 7), align 1, !dbg !29567, !nosanitize !4110
  %42 = add i8 %41, 1, !dbg !29567
  store i8 %42, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 7), align 1, !dbg !29567, !nosanitize !4110
  call void @__asan_report_load_n(i64 %26, i64 4) #42, !dbg !29567
  unreachable

43:                                               ; preds = %._crit_edge71, %._crit_edge70
  %44 = load i32, ptr %raw.0, align 1, !dbg !29567, !alias.scope !29580, !noalias !29585
  call void @__sanitizer_cov_trace_const_cmp4(i32 827019347, i32 %44), !dbg !29567
  %_3.i.i.i.not = icmp eq i32 %44, 827019347, !dbg !29567
  br i1 %_3.i.i.i.not, label %bb5, label %.bb98_crit_edge, !dbg !29588

.bb98_crit_edge:                                  ; preds = %43
  %45 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 8), align 1, !dbg !29588, !nosanitize !4110
  %46 = add i8 %45, 1, !dbg !29588
  store i8 %46, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 8), align 1, !dbg !29588, !nosanitize !4110
  br label %bb98, !dbg !29588

bb5:                                              ; preds = %43
  %_16.i = getelementptr inbounds nuw i8, ptr %raw.0, i64 4, !dbg !29589
  %47 = ptrtoint ptr %_16.i to i64, !dbg !29597
  %48 = add i64 %47, 1, !dbg !29597
  %49 = inttoptr i64 %48 to ptr, !dbg !29597
  %50 = ptrtoint ptr %_16.i to i64, !dbg !29597
  %51 = lshr i64 %50, 3, !dbg !29597
  %52 = add i64 %51, 2147450880, !dbg !29597
  %53 = inttoptr i64 %52 to ptr, !dbg !29597
  %54 = load i8, ptr %53, align 1, !dbg !29597
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %54), !dbg !29597
  %55 = icmp ne i8 %54, 0, !dbg !29597
  br i1 %55, label %58, label %bb5._crit_edge, !dbg !29597, !prof !4181

bb5._crit_edge:                                   ; preds = %bb5
  %56 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 9), align 1, !dbg !29597, !nosanitize !4110
  %57 = add i8 %56, 1, !dbg !29597
  store i8 %57, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 9), align 1, !dbg !29597, !nosanitize !4110
  br label %67, !dbg !29597

58:                                               ; preds = %bb5
  %59 = and i64 %50, 7, !dbg !29597
  %60 = trunc i64 %59 to i8, !dbg !29597
  call void @__sanitizer_cov_trace_cmp1(i8 %60, i8 %54), !dbg !29597
  %61 = icmp sge i8 %60, %54, !dbg !29597
  br i1 %61, label %64, label %._crit_edge72, !dbg !29597

._crit_edge72:                                    ; preds = %58
  %62 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 10), align 1, !dbg !29597, !nosanitize !4110
  %63 = add i8 %62, 1, !dbg !29597
  store i8 %63, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 10), align 1, !dbg !29597, !nosanitize !4110
  br label %67, !dbg !29597

64:                                               ; preds = %58
  %65 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 11), align 1, !dbg !29597, !nosanitize !4110
  %66 = add i8 %65, 1, !dbg !29597
  store i8 %66, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 11), align 1, !dbg !29597, !nosanitize !4110
  call void @__asan_report_load_n(i64 %50, i64 2) #42, !dbg !29597
  unreachable

67:                                               ; preds = %._crit_edge72, %bb5._crit_edge
  %68 = ptrtoint ptr %49 to i64, !dbg !29597
  %69 = lshr i64 %68, 3, !dbg !29597
  %70 = add i64 %69, 2147450880, !dbg !29597
  %71 = inttoptr i64 %70 to ptr, !dbg !29597
  %72 = load i8, ptr %71, align 1, !dbg !29597
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %72), !dbg !29597
  %73 = icmp ne i8 %72, 0, !dbg !29597
  br i1 %73, label %76, label %._crit_edge73, !dbg !29597, !prof !4181

._crit_edge73:                                    ; preds = %67
  %74 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 12), align 1, !dbg !29597, !nosanitize !4110
  %75 = add i8 %74, 1, !dbg !29597
  store i8 %75, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 12), align 1, !dbg !29597, !nosanitize !4110
  br label %85, !dbg !29597

76:                                               ; preds = %67
  %77 = and i64 %68, 7, !dbg !29597
  %78 = trunc i64 %77 to i8, !dbg !29597
  call void @__sanitizer_cov_trace_cmp1(i8 %78, i8 %72), !dbg !29597
  %79 = icmp sge i8 %78, %72, !dbg !29597
  br i1 %79, label %82, label %._crit_edge74, !dbg !29597

._crit_edge74:                                    ; preds = %76
  %80 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 13), align 1, !dbg !29597, !nosanitize !4110
  %81 = add i8 %80, 1, !dbg !29597
  store i8 %81, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 13), align 1, !dbg !29597, !nosanitize !4110
  br label %85, !dbg !29597

82:                                               ; preds = %76
  %83 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 14), align 1, !dbg !29597, !nosanitize !4110
  %84 = add i8 %83, 1, !dbg !29597
  store i8 %84, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 14), align 1, !dbg !29597, !nosanitize !4110
  call void @__asan_report_load_n(i64 %68, i64 2) #42, !dbg !29597
  unreachable

85:                                               ; preds = %._crit_edge74, %._crit_edge73
  %86 = load i16, ptr %_16.i, align 1, !dbg !29597, !alias.scope !29607, !noalias !29612
  call void @__sanitizer_cov_trace_const_cmp2(i16 256, i16 %86), !dbg !29597
  %_3.i.i.not = icmp eq i16 %86, 256, !dbg !29597
  br i1 %_3.i.i.not, label %bb9, label %.bb98_crit_edge75, !dbg !29615

.bb98_crit_edge75:                                ; preds = %85
  %87 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 15), align 1, !dbg !29615, !nosanitize !4110
  %88 = add i8 %87, 1, !dbg !29615
  store i8 %88, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 15), align 1, !dbg !29615, !nosanitize !4110
  br label %bb98, !dbg !29615

bb9:                                              ; preds = %85
  %_16.i26 = getelementptr inbounds nuw i8, ptr %raw.0, i64 10, !dbg !29616
  %89 = ptrtoint ptr %_16.i26 to i64, !dbg !29620
  %90 = add i64 %89, 1, !dbg !29620
  %91 = inttoptr i64 %90 to ptr, !dbg !29620
  %92 = ptrtoint ptr %_16.i26 to i64, !dbg !29620
  %93 = lshr i64 %92, 3, !dbg !29620
  %94 = add i64 %93, 2147450880, !dbg !29620
  %95 = inttoptr i64 %94 to ptr, !dbg !29620
  %96 = load i8, ptr %95, align 1, !dbg !29620
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %96), !dbg !29620
  %97 = icmp ne i8 %96, 0, !dbg !29620
  br i1 %97, label %100, label %bb9._crit_edge, !dbg !29620, !prof !4181

bb9._crit_edge:                                   ; preds = %bb9
  %98 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 16), align 1, !dbg !29620, !nosanitize !4110
  %99 = add i8 %98, 1, !dbg !29620
  store i8 %99, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 16), align 1, !dbg !29620, !nosanitize !4110
  br label %109, !dbg !29620

100:                                              ; preds = %bb9
  %101 = and i64 %92, 7, !dbg !29620
  %102 = trunc i64 %101 to i8, !dbg !29620
  call void @__sanitizer_cov_trace_cmp1(i8 %102, i8 %96), !dbg !29620
  %103 = icmp sge i8 %102, %96, !dbg !29620
  br i1 %103, label %106, label %._crit_edge76, !dbg !29620

._crit_edge76:                                    ; preds = %100
  %104 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 17), align 1, !dbg !29620, !nosanitize !4110
  %105 = add i8 %104, 1, !dbg !29620
  store i8 %105, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 17), align 1, !dbg !29620, !nosanitize !4110
  br label %109, !dbg !29620

106:                                              ; preds = %100
  %107 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 18), align 1, !dbg !29620, !nosanitize !4110
  %108 = add i8 %107, 1, !dbg !29620
  store i8 %108, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 18), align 1, !dbg !29620, !nosanitize !4110
  call void @__asan_report_load_n(i64 %92, i64 2) #42, !dbg !29620
  unreachable

109:                                              ; preds = %._crit_edge76, %bb9._crit_edge
  %110 = ptrtoint ptr %91 to i64, !dbg !29620
  %111 = lshr i64 %110, 3, !dbg !29620
  %112 = add i64 %111, 2147450880, !dbg !29620
  %113 = inttoptr i64 %112 to ptr, !dbg !29620
  %114 = load i8, ptr %113, align 1, !dbg !29620
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %114), !dbg !29620
  %115 = icmp ne i8 %114, 0, !dbg !29620
  br i1 %115, label %118, label %._crit_edge77, !dbg !29620, !prof !4181

._crit_edge77:                                    ; preds = %109
  %116 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 19), align 1, !dbg !29620, !nosanitize !4110
  %117 = add i8 %116, 1, !dbg !29620
  store i8 %117, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 19), align 1, !dbg !29620, !nosanitize !4110
  br label %127, !dbg !29620

118:                                              ; preds = %109
  %119 = and i64 %110, 7, !dbg !29620
  %120 = trunc i64 %119 to i8, !dbg !29620
  call void @__sanitizer_cov_trace_cmp1(i8 %120, i8 %114), !dbg !29620
  %121 = icmp sge i8 %120, %114, !dbg !29620
  br i1 %121, label %124, label %._crit_edge78, !dbg !29620

._crit_edge78:                                    ; preds = %118
  %122 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 20), align 1, !dbg !29620, !nosanitize !4110
  %123 = add i8 %122, 1, !dbg !29620
  store i8 %123, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 20), align 1, !dbg !29620, !nosanitize !4110
  br label %127, !dbg !29620

124:                                              ; preds = %118
  %125 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 21), align 1, !dbg !29620, !nosanitize !4110
  %126 = add i8 %125, 1, !dbg !29620
  store i8 %126, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 21), align 1, !dbg !29620, !nosanitize !4110
  call void @__asan_report_load_n(i64 %110, i64 2) #42, !dbg !29620
  unreachable

127:                                              ; preds = %._crit_edge78, %._crit_edge77
  %128 = load i16, ptr %_16.i26, align 1, !dbg !29620, !alias.scope !29625, !noalias !29630
  call void @__sanitizer_cov_trace_const_cmp2(i16 0, i16 %128), !dbg !29620
  %_3.i.i35.not = icmp eq i16 %128, 0, !dbg !29620
  br i1 %_3.i.i35.not, label %bb14, label %.bb98_crit_edge79, !dbg !29633

.bb98_crit_edge79:                                ; preds = %127
  %129 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 22), align 1, !dbg !29633, !nosanitize !4110
  %130 = add i8 %129, 1, !dbg !29633
  store i8 %130, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 22), align 1, !dbg !29633, !nosanitize !4110
  br label %bb98, !dbg !29633

bb14:                                             ; preds = %127
  %131 = getelementptr inbounds nuw i8, ptr %raw.0, i64 6, !dbg !29634
  %132 = ptrtoint ptr %131 to i64, !dbg !29634
  %133 = lshr i64 %132, 3, !dbg !29634
  %134 = add i64 %133, 2147450880, !dbg !29634
  %135 = inttoptr i64 %134 to ptr, !dbg !29634
  %136 = load i8, ptr %135, align 1, !dbg !29634
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %136), !dbg !29634
  %137 = icmp ne i8 %136, 0, !dbg !29634
  br i1 %137, label %140, label %bb14._crit_edge, !dbg !29634, !prof !4181

bb14._crit_edge:                                  ; preds = %bb14
  %138 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 23), align 1, !dbg !29634, !nosanitize !4110
  %139 = add i8 %138, 1, !dbg !29634
  store i8 %139, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 23), align 1, !dbg !29634, !nosanitize !4110
  br label %149, !dbg !29634

140:                                              ; preds = %bb14
  %141 = and i64 %132, 7, !dbg !29634
  %142 = trunc i64 %141 to i8, !dbg !29634
  call void @__sanitizer_cov_trace_cmp1(i8 %142, i8 %136), !dbg !29634
  %143 = icmp sge i8 %142, %136, !dbg !29634
  br i1 %143, label %146, label %._crit_edge80, !dbg !29634

._crit_edge80:                                    ; preds = %140
  %144 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 24), align 1, !dbg !29634, !nosanitize !4110
  %145 = add i8 %144, 1, !dbg !29634
  store i8 %145, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 24), align 1, !dbg !29634, !nosanitize !4110
  br label %149, !dbg !29634

146:                                              ; preds = %140
  %147 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 25), align 1, !dbg !29634, !nosanitize !4110
  %148 = add i8 %147, 1, !dbg !29634
  store i8 %148, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 25), align 1, !dbg !29634, !nosanitize !4110
  call void @__asan_report_load1(i64 %132) #42, !dbg !29634
  unreachable

149:                                              ; preds = %._crit_edge80, %bb14._crit_edge
  %_12 = load i8, ptr %131, align 1, !dbg !29634, !noundef !4110
  %150 = getelementptr inbounds nuw i8, ptr %raw.0, i64 7, !dbg !29635
  %151 = ptrtoint ptr %150 to i64, !dbg !29635
  %152 = lshr i64 %151, 3, !dbg !29635
  %153 = add i64 %152, 2147450880, !dbg !29635
  %154 = inttoptr i64 %153 to ptr, !dbg !29635
  %155 = load i8, ptr %154, align 1, !dbg !29635
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %155), !dbg !29635
  %156 = icmp ne i8 %155, 0, !dbg !29635
  br i1 %156, label %159, label %._crit_edge81, !dbg !29635, !prof !4181

._crit_edge81:                                    ; preds = %149
  %157 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 26), align 1, !dbg !29635, !nosanitize !4110
  %158 = add i8 %157, 1, !dbg !29635
  store i8 %158, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 26), align 1, !dbg !29635, !nosanitize !4110
  br label %168, !dbg !29635

159:                                              ; preds = %149
  %160 = and i64 %151, 7, !dbg !29635
  %161 = trunc i64 %160 to i8, !dbg !29635
  call void @__sanitizer_cov_trace_cmp1(i8 %161, i8 %155), !dbg !29635
  %162 = icmp sge i8 %161, %155, !dbg !29635
  br i1 %162, label %165, label %._crit_edge82, !dbg !29635

._crit_edge82:                                    ; preds = %159
  %163 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 27), align 1, !dbg !29635, !nosanitize !4110
  %164 = add i8 %163, 1, !dbg !29635
  store i8 %164, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 27), align 1, !dbg !29635, !nosanitize !4110
  br label %168, !dbg !29635

165:                                              ; preds = %159
  %166 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 28), align 1, !dbg !29635, !nosanitize !4110
  %167 = add i8 %166, 1, !dbg !29635
  store i8 %167, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 28), align 1, !dbg !29635, !nosanitize !4110
  call void @__asan_report_load1(i64 %151) #42, !dbg !29635
  unreachable

168:                                              ; preds = %._crit_edge82, %._crit_edge81
  %_14 = load i8, ptr %150, align 1, !dbg !29635, !noundef !4110
  %_16.i27 = getelementptr inbounds nuw i8, ptr %raw.0, i64 12, !dbg !29636
  %169 = ptrtoint ptr %_16.i27 to i64, !dbg !29640
  %170 = add i64 %169, 15, !dbg !29640
  %171 = inttoptr i64 %170 to ptr, !dbg !29640
  %172 = ptrtoint ptr %_16.i27 to i64, !dbg !29640
  %173 = lshr i64 %172, 3, !dbg !29640
  %174 = add i64 %173, 2147450880, !dbg !29640
  %175 = inttoptr i64 %174 to ptr, !dbg !29640
  %176 = load i8, ptr %175, align 1, !dbg !29640
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %176), !dbg !29640
  %177 = icmp ne i8 %176, 0, !dbg !29640
  br i1 %177, label %180, label %._crit_edge83, !dbg !29640, !prof !4181

._crit_edge83:                                    ; preds = %168
  %178 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 29), align 1, !dbg !29640, !nosanitize !4110
  %179 = add i8 %178, 1, !dbg !29640
  store i8 %179, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 29), align 1, !dbg !29640, !nosanitize !4110
  br label %189, !dbg !29640

180:                                              ; preds = %168
  %181 = and i64 %172, 7, !dbg !29640
  %182 = trunc i64 %181 to i8, !dbg !29640
  call void @__sanitizer_cov_trace_cmp1(i8 %182, i8 %176), !dbg !29640
  %183 = icmp sge i8 %182, %176, !dbg !29640
  br i1 %183, label %186, label %._crit_edge84, !dbg !29640

._crit_edge84:                                    ; preds = %180
  %184 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 30), align 1, !dbg !29640, !nosanitize !4110
  %185 = add i8 %184, 1, !dbg !29640
  store i8 %185, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 30), align 1, !dbg !29640, !nosanitize !4110
  br label %189, !dbg !29640

186:                                              ; preds = %180
  %187 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 31), align 1, !dbg !29640, !nosanitize !4110
  %188 = add i8 %187, 1, !dbg !29640
  store i8 %188, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 31), align 1, !dbg !29640, !nosanitize !4110
  call void @__asan_report_load_n(i64 %172, i64 16) #42, !dbg !29640
  unreachable

189:                                              ; preds = %._crit_edge84, %._crit_edge83
  %190 = ptrtoint ptr %171 to i64, !dbg !29640
  %191 = lshr i64 %190, 3, !dbg !29640
  %192 = add i64 %191, 2147450880, !dbg !29640
  %193 = inttoptr i64 %192 to ptr, !dbg !29640
  %194 = load i8, ptr %193, align 1, !dbg !29640
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %194), !dbg !29640
  %195 = icmp ne i8 %194, 0, !dbg !29640
  br i1 %195, label %198, label %._crit_edge85, !dbg !29640, !prof !4181

._crit_edge85:                                    ; preds = %189
  %196 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 32), align 1, !dbg !29640, !nosanitize !4110
  %197 = add i8 %196, 1, !dbg !29640
  store i8 %197, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 32), align 1, !dbg !29640, !nosanitize !4110
  br label %207, !dbg !29640

198:                                              ; preds = %189
  %199 = and i64 %190, 7, !dbg !29640
  %200 = trunc i64 %199 to i8, !dbg !29640
  call void @__sanitizer_cov_trace_cmp1(i8 %200, i8 %194), !dbg !29640
  %201 = icmp sge i8 %200, %194, !dbg !29640
  br i1 %201, label %204, label %._crit_edge86, !dbg !29640

._crit_edge86:                                    ; preds = %198
  %202 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 33), align 1, !dbg !29640, !nosanitize !4110
  %203 = add i8 %202, 1, !dbg !29640
  store i8 %203, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 33), align 1, !dbg !29640, !nosanitize !4110
  br label %207, !dbg !29640

204:                                              ; preds = %198
  %205 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 34), align 1, !dbg !29640, !nosanitize !4110
  %206 = add i8 %205, 1, !dbg !29640
  store i8 %206, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 34), align 1, !dbg !29640, !nosanitize !4110
  call void @__asan_report_load_n(i64 %190, i64 16) #42, !dbg !29640
  unreachable

207:                                              ; preds = %._crit_edge86, %._crit_edge85
  %_17.sroa.4.1.copyload = load i128, ptr %_16.i27, align 1, !dbg !29640, !alias.scope !29648
  %_16.i28 = getelementptr inbounds nuw i8, ptr %raw.0, i64 28, !dbg !29655
  %208 = ptrtoint ptr %_16.i28 to i64, !dbg !29659
  %209 = add i64 %208, 7, !dbg !29659
  %210 = inttoptr i64 %209 to ptr, !dbg !29659
  %211 = ptrtoint ptr %_16.i28 to i64, !dbg !29659
  %212 = lshr i64 %211, 3, !dbg !29659
  %213 = add i64 %212, 2147450880, !dbg !29659
  %214 = inttoptr i64 %213 to ptr, !dbg !29659
  %215 = load i8, ptr %214, align 1, !dbg !29659
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %215), !dbg !29659
  %216 = icmp ne i8 %215, 0, !dbg !29659
  br i1 %216, label %219, label %._crit_edge87, !dbg !29659, !prof !4181

._crit_edge87:                                    ; preds = %207
  %217 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 35), align 1, !dbg !29659, !nosanitize !4110
  %218 = add i8 %217, 1, !dbg !29659
  store i8 %218, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 35), align 1, !dbg !29659, !nosanitize !4110
  br label %228, !dbg !29659

219:                                              ; preds = %207
  %220 = and i64 %211, 7, !dbg !29659
  %221 = trunc i64 %220 to i8, !dbg !29659
  call void @__sanitizer_cov_trace_cmp1(i8 %221, i8 %215), !dbg !29659
  %222 = icmp sge i8 %221, %215, !dbg !29659
  br i1 %222, label %225, label %._crit_edge88, !dbg !29659

._crit_edge88:                                    ; preds = %219
  %223 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 36), align 1, !dbg !29659, !nosanitize !4110
  %224 = add i8 %223, 1, !dbg !29659
  store i8 %224, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 36), align 1, !dbg !29659, !nosanitize !4110
  br label %228, !dbg !29659

225:                                              ; preds = %219
  %226 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 37), align 1, !dbg !29659, !nosanitize !4110
  %227 = add i8 %226, 1, !dbg !29659
  store i8 %227, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 37), align 1, !dbg !29659, !nosanitize !4110
  call void @__asan_report_load_n(i64 %211, i64 8) #42, !dbg !29659
  unreachable

228:                                              ; preds = %._crit_edge88, %._crit_edge87
  %229 = ptrtoint ptr %210 to i64, !dbg !29659
  %230 = lshr i64 %229, 3, !dbg !29659
  %231 = add i64 %230, 2147450880, !dbg !29659
  %232 = inttoptr i64 %231 to ptr, !dbg !29659
  %233 = load i8, ptr %232, align 1, !dbg !29659
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %233), !dbg !29659
  %234 = icmp ne i8 %233, 0, !dbg !29659
  br i1 %234, label %237, label %._crit_edge89, !dbg !29659, !prof !4181

._crit_edge89:                                    ; preds = %228
  %235 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 38), align 1, !dbg !29659, !nosanitize !4110
  %236 = add i8 %235, 1, !dbg !29659
  store i8 %236, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 38), align 1, !dbg !29659, !nosanitize !4110
  br label %246, !dbg !29659

237:                                              ; preds = %228
  %238 = and i64 %229, 7, !dbg !29659
  %239 = trunc i64 %238 to i8, !dbg !29659
  call void @__sanitizer_cov_trace_cmp1(i8 %239, i8 %233), !dbg !29659
  %240 = icmp sge i8 %239, %233, !dbg !29659
  br i1 %240, label %243, label %._crit_edge90, !dbg !29659

._crit_edge90:                                    ; preds = %237
  %241 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 39), align 1, !dbg !29659, !nosanitize !4110
  %242 = add i8 %241, 1, !dbg !29659
  store i8 %242, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 39), align 1, !dbg !29659, !nosanitize !4110
  br label %246, !dbg !29659

243:                                              ; preds = %237
  %244 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 40), align 1, !dbg !29659, !nosanitize !4110
  %245 = add i8 %244, 1, !dbg !29659
  store i8 %245, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 40), align 1, !dbg !29659, !nosanitize !4110
  call void @__asan_report_load_n(i64 %229, i64 8) #42, !dbg !29659
  unreachable

246:                                              ; preds = %._crit_edge90, %._crit_edge89
  %v.sroa.0.0.copyload.i.i = load i64, ptr %_16.i28, align 1, !dbg !29659, !alias.scope !29666, !noalias !29671
  %_0.i = tail call noundef i64 @llvm.bswap.i64(i64 %v.sroa.0.0.copyload.i.i), !dbg !29674
  %_16.i29 = getelementptr inbounds nuw i8, ptr %raw.0, i64 36, !dbg !29681
  %247 = ptrtoint ptr %_16.i29 to i64, !dbg !29685
  %248 = add i64 %247, 3, !dbg !29685
  %249 = inttoptr i64 %248 to ptr, !dbg !29685
  %250 = ptrtoint ptr %_16.i29 to i64, !dbg !29685
  %251 = lshr i64 %250, 3, !dbg !29685
  %252 = add i64 %251, 2147450880, !dbg !29685
  %253 = inttoptr i64 %252 to ptr, !dbg !29685
  %254 = load i8, ptr %253, align 1, !dbg !29685
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %254), !dbg !29685
  %255 = icmp ne i8 %254, 0, !dbg !29685
  br i1 %255, label %258, label %._crit_edge91, !dbg !29685, !prof !4181

._crit_edge91:                                    ; preds = %246
  %256 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 41), align 1, !dbg !29685, !nosanitize !4110
  %257 = add i8 %256, 1, !dbg !29685
  store i8 %257, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 41), align 1, !dbg !29685, !nosanitize !4110
  br label %267, !dbg !29685

258:                                              ; preds = %246
  %259 = and i64 %250, 7, !dbg !29685
  %260 = trunc i64 %259 to i8, !dbg !29685
  call void @__sanitizer_cov_trace_cmp1(i8 %260, i8 %254), !dbg !29685
  %261 = icmp sge i8 %260, %254, !dbg !29685
  br i1 %261, label %264, label %._crit_edge92, !dbg !29685

._crit_edge92:                                    ; preds = %258
  %262 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 42), align 1, !dbg !29685, !nosanitize !4110
  %263 = add i8 %262, 1, !dbg !29685
  store i8 %263, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 42), align 1, !dbg !29685, !nosanitize !4110
  br label %267, !dbg !29685

264:                                              ; preds = %258
  %265 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 43), align 1, !dbg !29685, !nosanitize !4110
  %266 = add i8 %265, 1, !dbg !29685
  store i8 %266, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 43), align 1, !dbg !29685, !nosanitize !4110
  call void @__asan_report_load_n(i64 %250, i64 4) #42, !dbg !29685
  unreachable

267:                                              ; preds = %._crit_edge92, %._crit_edge91
  %268 = ptrtoint ptr %249 to i64, !dbg !29685
  %269 = lshr i64 %268, 3, !dbg !29685
  %270 = add i64 %269, 2147450880, !dbg !29685
  %271 = inttoptr i64 %270 to ptr, !dbg !29685
  %272 = load i8, ptr %271, align 1, !dbg !29685
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %272), !dbg !29685
  %273 = icmp ne i8 %272, 0, !dbg !29685
  br i1 %273, label %276, label %._crit_edge93, !dbg !29685, !prof !4181

._crit_edge93:                                    ; preds = %267
  %274 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 44), align 1, !dbg !29685, !nosanitize !4110
  %275 = add i8 %274, 1, !dbg !29685
  store i8 %275, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 44), align 1, !dbg !29685, !nosanitize !4110
  br label %285, !dbg !29685

276:                                              ; preds = %267
  %277 = and i64 %268, 7, !dbg !29685
  %278 = trunc i64 %277 to i8, !dbg !29685
  call void @__sanitizer_cov_trace_cmp1(i8 %278, i8 %272), !dbg !29685
  %279 = icmp sge i8 %278, %272, !dbg !29685
  br i1 %279, label %282, label %._crit_edge94, !dbg !29685

._crit_edge94:                                    ; preds = %276
  %280 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 45), align 1, !dbg !29685, !nosanitize !4110
  %281 = add i8 %280, 1, !dbg !29685
  store i8 %281, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 45), align 1, !dbg !29685, !nosanitize !4110
  br label %285, !dbg !29685

282:                                              ; preds = %276
  %283 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 46), align 1, !dbg !29685, !nosanitize !4110
  %284 = add i8 %283, 1, !dbg !29685
  store i8 %284, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 46), align 1, !dbg !29685, !nosanitize !4110
  call void @__asan_report_load_n(i64 %268, i64 4) #42, !dbg !29685
  unreachable

285:                                              ; preds = %._crit_edge94, %._crit_edge93
  %v.sroa.0.0.copyload.i.i43 = load i32, ptr %_16.i29, align 1, !dbg !29685, !alias.scope !29692
  %_0.i44 = tail call noundef i32 @llvm.bswap.i32(i32 %v.sroa.0.0.copyload.i.i43), !dbg !29697
  %_23 = zext i32 %_0.i44 to i64, !dbg !29704
  %switch.tableidx = add i8 %_12, -1, !dbg !29705
  call void @__sanitizer_cov_trace_const_cmp1(i8 17, i8 %switch.tableidx), !dbg !29705
  %286 = icmp ult i8 %switch.tableidx, 17, !dbg !29705
  br i1 %286, label %switch.hole_check, label %.bb98_crit_edge95, !dbg !29705

.bb98_crit_edge95:                                ; preds = %285
  %287 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 47), align 1, !dbg !29705, !nosanitize !4110
  %288 = add i8 %287, 1, !dbg !29705
  store i8 %288, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 47), align 1, !dbg !29705, !nosanitize !4110
  br label %bb98, !dbg !29705

switch.hole_check:                                ; preds = %285
  %switch.maskindex = zext nneg i8 %switch.tableidx to i32, !dbg !29705
  %switch.shifted = lshr i32 98319, %switch.maskindex, !dbg !29705
  %switch.lobit = trunc i32 %switch.shifted to i1, !dbg !29705
  %switch.lobit.not = xor i1 %switch.lobit, true, !dbg !29705
  call void @__sanitizer_cov_trace_const_cmp1(i8 1, i8 %_14), !dbg !29707
  %_28 = icmp ugt i8 %_14, 1
  %or.cond69 = or i1 %switch.lobit.not, %_28, !dbg !29705
  br i1 %or.cond69, label %switch.hole_check.bb98_crit_edge, label %bb36, !dbg !29705

switch.hole_check.bb98_crit_edge:                 ; preds = %switch.hole_check
  %289 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 48), align 1, !dbg !29705, !nosanitize !4110
  %290 = add i8 %289, 1, !dbg !29705
  store i8 %290, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 48), align 1, !dbg !29705, !nosanitize !4110
  br label %bb98, !dbg !29705

bb36:                                             ; preds = %switch.hole_check
  %291 = zext nneg i8 %switch.tableidx to i64, !dbg !29705
  %switch.gep62 = getelementptr inbounds nuw [2 x i8], ptr @switch.table._RNvMNtCs4oicsBtN6nJ_15spiral_protocol4wireNtB2_6Header5parse.1, i64 %291, !dbg !29705
  %292 = ptrtoint ptr %switch.gep62 to i64, !dbg !29705
  %293 = lshr i64 %292, 3, !dbg !29705
  %294 = add i64 %293, 2147450880, !dbg !29705
  %295 = inttoptr i64 %294 to ptr, !dbg !29705
  %296 = load i8, ptr %295, align 1, !dbg !29705
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %296), !dbg !29705
  %297 = icmp ne i8 %296, 0, !dbg !29705
  br i1 %297, label %300, label %bb36._crit_edge, !dbg !29705, !prof !4181

bb36._crit_edge:                                  ; preds = %bb36
  %298 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 49), align 1, !dbg !29705, !nosanitize !4110
  %299 = add i8 %298, 1, !dbg !29705
  store i8 %299, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 49), align 1, !dbg !29705, !nosanitize !4110
  br label %310, !dbg !29705

300:                                              ; preds = %bb36
  %301 = and i64 %292, 7, !dbg !29705
  %302 = add i64 %301, 1, !dbg !29705
  %303 = trunc i64 %302 to i8, !dbg !29705
  call void @__sanitizer_cov_trace_cmp1(i8 %303, i8 %296), !dbg !29705
  %304 = icmp sge i8 %303, %296, !dbg !29705
  br i1 %304, label %307, label %._crit_edge96, !dbg !29705

._crit_edge96:                                    ; preds = %300
  %305 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 50), align 1, !dbg !29705, !nosanitize !4110
  %306 = add i8 %305, 1, !dbg !29705
  store i8 %306, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 50), align 1, !dbg !29705, !nosanitize !4110
  br label %310, !dbg !29705

307:                                              ; preds = %300
  %308 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 51), align 1, !dbg !29705, !nosanitize !4110
  %309 = add i8 %308, 1, !dbg !29705
  store i8 %309, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 51), align 1, !dbg !29705, !nosanitize !4110
  call void @__asan_report_load2(i64 %292) #42, !dbg !29705
  unreachable

310:                                              ; preds = %._crit_edge96, %bb36._crit_edge
  %switch.load63 = load i16, ptr %switch.gep62, align 2, !dbg !29705
  %311 = zext nneg i8 %switch.tableidx to i64, !dbg !29705
  %switch.gep = getelementptr inbounds nuw [2 x i8], ptr @switch.table._RNvMNtCs4oicsBtN6nJ_15spiral_protocol4wireNtB2_6Header5parse, i64 %311, !dbg !29705
  %312 = ptrtoint ptr %switch.gep to i64, !dbg !29705
  %313 = lshr i64 %312, 3, !dbg !29705
  %314 = add i64 %313, 2147450880, !dbg !29705
  %315 = inttoptr i64 %314 to ptr, !dbg !29705
  %316 = load i8, ptr %315, align 1, !dbg !29705
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %316), !dbg !29705
  %317 = icmp ne i8 %316, 0, !dbg !29705
  br i1 %317, label %320, label %._crit_edge97, !dbg !29705, !prof !4181

._crit_edge97:                                    ; preds = %310
  %318 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 52), align 1, !dbg !29705, !nosanitize !4110
  %319 = add i8 %318, 1, !dbg !29705
  store i8 %319, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 52), align 1, !dbg !29705, !nosanitize !4110
  br label %330, !dbg !29705

320:                                              ; preds = %310
  %321 = and i64 %312, 7, !dbg !29705
  %322 = add i64 %321, 1, !dbg !29705
  %323 = trunc i64 %322 to i8, !dbg !29705
  call void @__sanitizer_cov_trace_cmp1(i8 %323, i8 %316), !dbg !29705
  %324 = icmp sge i8 %323, %316, !dbg !29705
  br i1 %324, label %327, label %._crit_edge98, !dbg !29705

._crit_edge98:                                    ; preds = %320
  %325 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 53), align 1, !dbg !29705, !nosanitize !4110
  %326 = add i8 %325, 1, !dbg !29705
  store i8 %326, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 53), align 1, !dbg !29705, !nosanitize !4110
  br label %330, !dbg !29705

327:                                              ; preds = %320
  %328 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 54), align 1, !dbg !29705, !nosanitize !4110
  %329 = add i8 %328, 1, !dbg !29705
  store i8 %329, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 54), align 1, !dbg !29705, !nosanitize !4110
  call void @__asan_report_load2(i64 %312) #42, !dbg !29705
  unreachable

330:                                              ; preds = %._crit_edge98, %._crit_edge97
  %switch.load = load i16, ptr %switch.gep, align 2, !dbg !29705
  %331 = zext i16 %switch.load to i32, !dbg !29708
  call void @__sanitizer_cov_trace_cmp4(i32 %_0.i44, i32 %331), !dbg !29708
  %_0.i6.not.i.i = icmp uge i32 %_0.i44, %331, !dbg !29708
  %332 = zext i16 %switch.load63 to i32, !dbg !29724
  call void @__sanitizer_cov_trace_cmp4(i32 %_0.i44, i32 %332), !dbg !29724
  %_0.i.i.i = icmp ule i32 %_0.i44, %332, !dbg !29724
  %_0.sroa.0.0.i.i45 = select i1 %_0.i6.not.i.i, i1 %_0.i.i.i, i1 false, !dbg !29724
  br i1 %_0.sroa.0.0.i.i45, label %_RNvMNtCshZBO5P2NUJi_4core6resultINtB2_6ResultAhj2_NtNtB4_5array17TryFromSliceErrorE6unwrapCs4oicsBtN6nJ_15spiral_protocol.exit, label %.bb98_crit_edge99, !dbg !29725

.bb98_crit_edge99:                                ; preds = %330
  %333 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 55), align 1, !dbg !29725, !nosanitize !4110
  %334 = add i8 %333, 1, !dbg !29725
  store i8 %334, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 55), align 1, !dbg !29725, !nosanitize !4110
  br label %bb98, !dbg !29725

_RNvMNtCshZBO5P2NUJi_4core6resultINtB2_6ResultAhj2_NtNtB4_5array17TryFromSliceErrorE6unwrapCs4oicsBtN6nJ_15spiral_protocol.exit: ; preds = %330
  %_16.i30 = getelementptr inbounds nuw i8, ptr %raw.0, i64 8, !dbg !29726
  %335 = ptrtoint ptr %_16.i30 to i64, !dbg !29730
  %336 = add i64 %335, 1, !dbg !29730
  %337 = inttoptr i64 %336 to ptr, !dbg !29730
  %338 = ptrtoint ptr %_16.i30 to i64, !dbg !29730
  %339 = lshr i64 %338, 3, !dbg !29730
  %340 = add i64 %339, 2147450880, !dbg !29730
  %341 = inttoptr i64 %340 to ptr, !dbg !29730
  %342 = load i8, ptr %341, align 1, !dbg !29730
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %342), !dbg !29730
  %343 = icmp ne i8 %342, 0, !dbg !29730
  br i1 %343, label %346, label %_RNvMNtCshZBO5P2NUJi_4core6resultINtB2_6ResultAhj2_NtNtB4_5array17TryFromSliceErrorE6unwrapCs4oicsBtN6nJ_15spiral_protocol.exit._crit_edge, !dbg !29730, !prof !4181

_RNvMNtCshZBO5P2NUJi_4core6resultINtB2_6ResultAhj2_NtNtB4_5array17TryFromSliceErrorE6unwrapCs4oicsBtN6nJ_15spiral_protocol.exit._crit_edge: ; preds = %_RNvMNtCshZBO5P2NUJi_4core6resultINtB2_6ResultAhj2_NtNtB4_5array17TryFromSliceErrorE6unwrapCs4oicsBtN6nJ_15spiral_protocol.exit
  %344 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 56), align 1, !dbg !29730, !nosanitize !4110
  %345 = add i8 %344, 1, !dbg !29730
  store i8 %345, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 56), align 1, !dbg !29730, !nosanitize !4110
  br label %355, !dbg !29730

346:                                              ; preds = %_RNvMNtCshZBO5P2NUJi_4core6resultINtB2_6ResultAhj2_NtNtB4_5array17TryFromSliceErrorE6unwrapCs4oicsBtN6nJ_15spiral_protocol.exit
  %347 = and i64 %338, 7, !dbg !29730
  %348 = trunc i64 %347 to i8, !dbg !29730
  call void @__sanitizer_cov_trace_cmp1(i8 %348, i8 %342), !dbg !29730
  %349 = icmp sge i8 %348, %342, !dbg !29730
  br i1 %349, label %352, label %._crit_edge100, !dbg !29730

._crit_edge100:                                   ; preds = %346
  %350 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 57), align 1, !dbg !29730, !nosanitize !4110
  %351 = add i8 %350, 1, !dbg !29730
  store i8 %351, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 57), align 1, !dbg !29730, !nosanitize !4110
  br label %355, !dbg !29730

352:                                              ; preds = %346
  %353 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 58), align 1, !dbg !29730, !nosanitize !4110
  %354 = add i8 %353, 1, !dbg !29730
  store i8 %354, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 58), align 1, !dbg !29730, !nosanitize !4110
  call void @__asan_report_load_n(i64 %338, i64 2) #42, !dbg !29730
  unreachable

355:                                              ; preds = %._crit_edge100, %_RNvMNtCshZBO5P2NUJi_4core6resultINtB2_6ResultAhj2_NtNtB4_5array17TryFromSliceErrorE6unwrapCs4oicsBtN6nJ_15spiral_protocol.exit._crit_edge
  %356 = ptrtoint ptr %337 to i64, !dbg !29730
  %357 = lshr i64 %356, 3, !dbg !29730
  %358 = add i64 %357, 2147450880, !dbg !29730
  %359 = inttoptr i64 %358 to ptr, !dbg !29730
  %360 = load i8, ptr %359, align 1, !dbg !29730
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %360), !dbg !29730
  %361 = icmp ne i8 %360, 0, !dbg !29730
  br i1 %361, label %364, label %._crit_edge101, !dbg !29730, !prof !4181

._crit_edge101:                                   ; preds = %355
  %362 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 59), align 1, !dbg !29730, !nosanitize !4110
  %363 = add i8 %362, 1, !dbg !29730
  store i8 %363, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 59), align 1, !dbg !29730, !nosanitize !4110
  br label %373, !dbg !29730

364:                                              ; preds = %355
  %365 = and i64 %356, 7, !dbg !29730
  %366 = trunc i64 %365 to i8, !dbg !29730
  call void @__sanitizer_cov_trace_cmp1(i8 %366, i8 %360), !dbg !29730
  %367 = icmp sge i8 %366, %360, !dbg !29730
  br i1 %367, label %370, label %._crit_edge102, !dbg !29730

._crit_edge102:                                   ; preds = %364
  %368 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 60), align 1, !dbg !29730, !nosanitize !4110
  %369 = add i8 %368, 1, !dbg !29730
  store i8 %369, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 60), align 1, !dbg !29730, !nosanitize !4110
  br label %373, !dbg !29730

370:                                              ; preds = %364
  %371 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 61), align 1, !dbg !29730, !nosanitize !4110
  %372 = add i8 %371, 1, !dbg !29730
  store i8 %372, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 61), align 1, !dbg !29730, !nosanitize !4110
  call void @__asan_report_load_n(i64 %356, i64 2) #42, !dbg !29730
  unreachable

373:                                              ; preds = %._crit_edge102, %._crit_edge101
  %v.sroa.0.0.copyload.i.i54 = load i16, ptr %_16.i30, align 1, !dbg !29730, !alias.scope !29737
  %_0.i55 = tail call noundef i16 @llvm.bswap.i16(i16 %v.sroa.0.0.copyload.i.i54), !dbg !29742
  call void @__sanitizer_cov_trace_const_cmp1(i8 1, i8 %_12), !dbg !29749
  %_39 = icmp eq i8 %_12, 1, !dbg !29749
  %. = select i1 %_39, i16 0, i16 -4095, !dbg !29750
  call void @__sanitizer_cov_trace_cmp2(i16 %_0.i55, i16 %.), !dbg !29751
  %_33.not = icmp eq i16 %_0.i55, %., !dbg !29751
  %_3.i.i56 = icmp ne i128 %_17.sroa.4.1.copyload, 0
  %374 = xor i1 %_39, %_3.i.i56
  %or.cond68 = select i1 %_33.not, i1 %374, i1 false, !dbg !29751
  br i1 %or.cond68, label %bb53, label %.bb98_crit_edge103, !dbg !29751

.bb98_crit_edge103:                               ; preds = %373
  %375 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 62), align 1, !dbg !29751, !nosanitize !4110
  %376 = add i8 %375, 1, !dbg !29751
  store i8 %376, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 62), align 1, !dbg !29751, !nosanitize !4110
  br label %bb98, !dbg !29751

bb53:                                             ; preds = %373
  %377 = zext i8 %_12 to i64, !dbg !29752
  call void @__sanitizer_cov_trace_switch(i64 %377, ptr @__sancov_gen_cov_switch_values.1454), !dbg !29752
  switch i8 %_12, label %bb53.bb54_crit_edge [
    i8 1, label %bb60
    i8 2, label %bb59
    i8 3, label %bb58
    i8 4, label %bb57
    i8 16, label %bb56
    i8 17, label %bb55
  ], !dbg !29752

bb53.bb54_crit_edge:                              ; preds = %bb53
  %378 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 63), align 1, !dbg !29752, !nosanitize !4110
  %379 = add i8 %378, 1, !dbg !29752
  store i8 %379, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 63), align 1, !dbg !29752, !nosanitize !4110
  br label %bb54, !dbg !29752

bb54:                                             ; preds = %bb55.bb54_crit_edge, %bb56.bb54_crit_edge, %bb57.bb54_crit_edge, %bb58.bb54_crit_edge, %bb59.bb54_crit_edge, %bb60.bb54_crit_edge, %bb53.bb54_crit_edge
  %380 = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !29753
  %381 = ptrtoint ptr %380 to i64, !dbg !29753
  %382 = lshr i64 %381, 3, !dbg !29753
  %383 = add i64 %382, 2147450880, !dbg !29753
  %384 = inttoptr i64 %383 to ptr, !dbg !29753
  %385 = load i16, ptr %384, align 1, !dbg !29753
  call void @__sanitizer_cov_trace_const_cmp2(i16 0, i16 %385), !dbg !29753
  %386 = icmp ne i16 %385, 0, !dbg !29753
  br i1 %386, label %387, label %390, !dbg !29753

387:                                              ; preds = %bb54
  %388 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 64), align 1, !dbg !29753, !nosanitize !4110
  %389 = add i8 %388, 1, !dbg !29753
  store i8 %389, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 64), align 1, !dbg !29753, !nosanitize !4110
  call void @__asan_report_store16(i64 %381) #42, !dbg !29753
  unreachable, !dbg !29753

390:                                              ; preds = %bb54
  store i128 %_17.sroa.4.1.copyload, ptr %380, align 8, !dbg !29753
  %h.sroa.6.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 24, !dbg !29753
  %391 = ptrtoint ptr %h.sroa.6.0..sroa_idx to i64, !dbg !29753
  %392 = lshr i64 %391, 3, !dbg !29753
  %393 = add i64 %392, 2147450880, !dbg !29753
  %394 = inttoptr i64 %393 to ptr, !dbg !29753
  %395 = load i8, ptr %394, align 1, !dbg !29753
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %395), !dbg !29753
  %396 = icmp ne i8 %395, 0, !dbg !29753
  br i1 %396, label %397, label %400, !dbg !29753

397:                                              ; preds = %390
  %398 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 65), align 1, !dbg !29753, !nosanitize !4110
  %399 = add i8 %398, 1, !dbg !29753
  store i8 %399, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 65), align 1, !dbg !29753, !nosanitize !4110
  call void @__asan_report_store8(i64 %391) #42, !dbg !29753
  unreachable, !dbg !29753

400:                                              ; preds = %390
  store i64 %_0.i, ptr %h.sroa.6.0..sroa_idx, align 8, !dbg !29753
  %h.sroa.7.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 32, !dbg !29753
  %401 = ptrtoint ptr %h.sroa.7.0..sroa_idx to i64, !dbg !29753
  %402 = lshr i64 %401, 3, !dbg !29753
  %403 = add i64 %402, 2147450880, !dbg !29753
  %404 = inttoptr i64 %403 to ptr, !dbg !29753
  %405 = load i8, ptr %404, align 1, !dbg !29753
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %405), !dbg !29753
  %406 = icmp ne i8 %405, 0, !dbg !29753
  br i1 %406, label %407, label %410, !dbg !29753

407:                                              ; preds = %400
  %408 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 66), align 1, !dbg !29753, !nosanitize !4110
  %409 = add i8 %408, 1, !dbg !29753
  store i8 %409, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 66), align 1, !dbg !29753, !nosanitize !4110
  call void @__asan_report_store8(i64 %401) #42, !dbg !29753
  unreachable, !dbg !29753

410:                                              ; preds = %400
  store i64 %_23, ptr %h.sroa.7.0..sroa_idx, align 8, !dbg !29753
  %h.sroa.9.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 40, !dbg !29753
  %411 = ptrtoint ptr %h.sroa.9.0..sroa_idx to i64, !dbg !29753
  %412 = lshr i64 %411, 3, !dbg !29753
  %413 = add i64 %412, 2147450880, !dbg !29753
  %414 = inttoptr i64 %413 to ptr, !dbg !29753
  %415 = load i8, ptr %414, align 1, !dbg !29753
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %415), !dbg !29753
  %416 = icmp ne i8 %415, 0, !dbg !29753
  br i1 %416, label %419, label %._crit_edge104, !dbg !29753, !prof !4181

._crit_edge104:                                   ; preds = %410
  %417 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 67), align 1, !dbg !29753, !nosanitize !4110
  %418 = add i8 %417, 1, !dbg !29753
  store i8 %418, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 67), align 1, !dbg !29753, !nosanitize !4110
  br label %428, !dbg !29753

419:                                              ; preds = %410
  %420 = and i64 %411, 7, !dbg !29753
  %421 = trunc i64 %420 to i8, !dbg !29753
  call void @__sanitizer_cov_trace_cmp1(i8 %421, i8 %415), !dbg !29753
  %422 = icmp sge i8 %421, %415, !dbg !29753
  br i1 %422, label %425, label %._crit_edge105, !dbg !29753

._crit_edge105:                                   ; preds = %419
  %423 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 68), align 1, !dbg !29753, !nosanitize !4110
  %424 = add i8 %423, 1, !dbg !29753
  store i8 %424, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 68), align 1, !dbg !29753, !nosanitize !4110
  br label %428, !dbg !29753

425:                                              ; preds = %419
  %426 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 69), align 1, !dbg !29753, !nosanitize !4110
  %427 = add i8 %426, 1, !dbg !29753
  store i8 %427, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 69), align 1, !dbg !29753, !nosanitize !4110
  call void @__asan_report_store1(i64 %411) #42, !dbg !29753
  unreachable

428:                                              ; preds = %._crit_edge105, %._crit_edge104
  store i8 %_12, ptr %h.sroa.9.0..sroa_idx, align 8, !dbg !29753
  br label %bb98, !dbg !29754

bb60:                                             ; preds = %bb53
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %_14), !dbg !29755
  %_46 = icmp eq i8 %_14, 0, !dbg !29755
  call void @__sanitizer_cov_trace_const_cmp8(i64 0, i64 %v.sroa.0.0.copyload.i.i), !dbg !29707
  %429 = icmp eq i64 %v.sroa.0.0.copyload.i.i, 0
  %or.cond = and i1 %_46, %429, !dbg !29755
  br i1 %or.cond, label %bb60.bb54_crit_edge, label %bb60.bb98_crit_edge, !dbg !29755

bb60.bb98_crit_edge:                              ; preds = %bb60
  %430 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 70), align 1, !dbg !29755, !nosanitize !4110
  %431 = add i8 %430, 1, !dbg !29755
  store i8 %431, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 70), align 1, !dbg !29755, !nosanitize !4110
  br label %bb98, !dbg !29755

bb60.bb54_crit_edge:                              ; preds = %bb60
  %432 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 71), align 1, !dbg !29755, !nosanitize !4110
  %433 = add i8 %432, 1, !dbg !29755
  store i8 %433, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 71), align 1, !dbg !29755, !nosanitize !4110
  br label %bb54, !dbg !29755

bb59:                                             ; preds = %bb53
  call void @__sanitizer_cov_trace_const_cmp1(i8 1, i8 %_14), !dbg !29755
  %_43 = icmp eq i8 %_14, 1, !dbg !29755
  call void @__sanitizer_cov_trace_const_cmp8(i64 0, i64 %v.sroa.0.0.copyload.i.i), !dbg !29707
  %434 = icmp eq i64 %v.sroa.0.0.copyload.i.i, 0
  %or.cond2 = and i1 %_43, %434, !dbg !29755
  br i1 %or.cond2, label %bb59.bb54_crit_edge, label %bb59.bb98_crit_edge, !dbg !29755

bb59.bb98_crit_edge:                              ; preds = %bb59
  %435 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 72), align 1, !dbg !29755, !nosanitize !4110
  %436 = add i8 %435, 1, !dbg !29755
  store i8 %436, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 72), align 1, !dbg !29755, !nosanitize !4110
  br label %bb98, !dbg !29755

bb59.bb54_crit_edge:                              ; preds = %bb59
  %437 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 73), align 1, !dbg !29755, !nosanitize !4110
  %438 = add i8 %437, 1, !dbg !29755
  store i8 %438, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 73), align 1, !dbg !29755, !nosanitize !4110
  br label %bb54, !dbg !29755

bb58:                                             ; preds = %bb53
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %_14), !dbg !29756
  %_52 = icmp eq i8 %_14, 0, !dbg !29756
  call void @__sanitizer_cov_trace_const_cmp8(i64 72057594037927936, i64 %v.sroa.0.0.copyload.i.i), !dbg !29707
  %439 = icmp eq i64 %v.sroa.0.0.copyload.i.i, 72057594037927936
  %or.cond3 = and i1 %_52, %439, !dbg !29756
  br i1 %or.cond3, label %bb58.bb54_crit_edge, label %bb58.bb98_crit_edge, !dbg !29756

bb58.bb98_crit_edge:                              ; preds = %bb58
  %440 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 74), align 1, !dbg !29756, !nosanitize !4110
  %441 = add i8 %440, 1, !dbg !29756
  store i8 %441, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 74), align 1, !dbg !29756, !nosanitize !4110
  br label %bb98, !dbg !29756

bb58.bb54_crit_edge:                              ; preds = %bb58
  %442 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 75), align 1, !dbg !29756, !nosanitize !4110
  %443 = add i8 %442, 1, !dbg !29756
  store i8 %443, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 75), align 1, !dbg !29756, !nosanitize !4110
  br label %bb54, !dbg !29756

bb57:                                             ; preds = %bb53
  call void @__sanitizer_cov_trace_const_cmp1(i8 1, i8 %_14), !dbg !29756
  %_49 = icmp eq i8 %_14, 1, !dbg !29756
  call void @__sanitizer_cov_trace_const_cmp8(i64 72057594037927936, i64 %v.sroa.0.0.copyload.i.i), !dbg !29707
  %444 = icmp eq i64 %v.sroa.0.0.copyload.i.i, 72057594037927936
  %or.cond4 = and i1 %_49, %444, !dbg !29756
  br i1 %or.cond4, label %bb57.bb54_crit_edge, label %bb57.bb98_crit_edge, !dbg !29756

bb57.bb98_crit_edge:                              ; preds = %bb57
  %445 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 76), align 1, !dbg !29756, !nosanitize !4110
  %446 = add i8 %445, 1, !dbg !29756
  store i8 %446, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 76), align 1, !dbg !29756, !nosanitize !4110
  br label %bb98, !dbg !29756

bb57.bb54_crit_edge:                              ; preds = %bb57
  %447 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 77), align 1, !dbg !29756, !nosanitize !4110
  %448 = add i8 %447, 1, !dbg !29756
  store i8 %448, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 77), align 1, !dbg !29756, !nosanitize !4110
  br label %bb54, !dbg !29756

bb56:                                             ; preds = %bb53
  call void @__sanitizer_cov_trace_const_cmp8(i64 1048574, i64 %_0.i), !dbg !29757
  %or.cond5 = icmp ugt i64 %_0.i, 1048574, !dbg !29757
  br i1 %or.cond5, label %bb56.bb98_crit_edge, label %bb56.bb54_crit_edge, !dbg !29757

bb56.bb54_crit_edge:                              ; preds = %bb56
  %449 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 78), align 1, !dbg !29757, !nosanitize !4110
  %450 = add i8 %449, 1, !dbg !29757
  store i8 %450, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 78), align 1, !dbg !29757, !nosanitize !4110
  br label %bb54, !dbg !29757

bb56.bb98_crit_edge:                              ; preds = %bb56
  %451 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 79), align 1, !dbg !29757, !nosanitize !4110
  %452 = add i8 %451, 1, !dbg !29757
  store i8 %452, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 79), align 1, !dbg !29757, !nosanitize !4110
  br label %bb98, !dbg !29757

bb55:                                             ; preds = %bb53
  call void @__sanitizer_cov_trace_const_cmp8(i64 1048575, i64 %_0.i), !dbg !29757
  %_55 = icmp ugt i64 %_0.i, 1048575, !dbg !29757
  br i1 %_55, label %bb55.bb98_crit_edge, label %bb55.bb54_crit_edge, !dbg !29757

bb55.bb54_crit_edge:                              ; preds = %bb55
  %453 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 80), align 1, !dbg !29757, !nosanitize !4110
  %454 = add i8 %453, 1, !dbg !29757
  store i8 %454, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 80), align 1, !dbg !29757, !nosanitize !4110
  br label %bb54, !dbg !29757

bb55.bb98_crit_edge:                              ; preds = %bb55
  %455 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 81), align 1, !dbg !29757, !nosanitize !4110
  %456 = add i8 %455, 1, !dbg !29757
  store i8 %456, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 81), align 1, !dbg !29757, !nosanitize !4110
  br label %bb98, !dbg !29757

bb98:                                             ; preds = %bb55.bb98_crit_edge, %bb56.bb98_crit_edge, %bb57.bb98_crit_edge, %bb58.bb98_crit_edge, %bb59.bb98_crit_edge, %bb60.bb98_crit_edge, %.bb98_crit_edge103, %.bb98_crit_edge99, %switch.hole_check.bb98_crit_edge, %.bb98_crit_edge95, %.bb98_crit_edge79, %.bb98_crit_edge75, %.bb98_crit_edge, %start.bb98_crit_edge, %428
  %.sink67 = phi i64 [ 1, %start.bb98_crit_edge ], [ 1, %.bb98_crit_edge95 ], [ 1, %bb55.bb98_crit_edge ], [ 1, %bb58.bb98_crit_edge ], [ 1, %bb60.bb98_crit_edge ], [ 1, %bb56.bb98_crit_edge ], [ 41, %428 ], [ 1, %.bb98_crit_edge ], [ 1, %.bb98_crit_edge79 ], [ 1, %.bb98_crit_edge75 ], [ 1, %switch.hole_check.bb98_crit_edge ], [ 1, %.bb98_crit_edge99 ], [ 1, %.bb98_crit_edge103 ], [ 1, %bb59.bb98_crit_edge ], [ 1, %bb57.bb98_crit_edge ]
  %.sink65 = phi i8 [ 0, %start.bb98_crit_edge ], [ 0, %.bb98_crit_edge95 ], [ 0, %bb55.bb98_crit_edge ], [ 0, %bb58.bb98_crit_edge ], [ 0, %bb60.bb98_crit_edge ], [ 0, %bb56.bb98_crit_edge ], [ %_14, %428 ], [ 0, %.bb98_crit_edge ], [ 0, %.bb98_crit_edge79 ], [ 0, %.bb98_crit_edge75 ], [ 0, %switch.hole_check.bb98_crit_edge ], [ 0, %.bb98_crit_edge99 ], [ 0, %.bb98_crit_edge103 ], [ 0, %bb59.bb98_crit_edge ], [ 0, %bb57.bb98_crit_edge ]
  %.sink = phi i8 [ 1, %start.bb98_crit_edge ], [ 1, %.bb98_crit_edge95 ], [ 1, %bb55.bb98_crit_edge ], [ 1, %bb58.bb98_crit_edge ], [ 1, %bb60.bb98_crit_edge ], [ 1, %bb56.bb98_crit_edge ], [ 0, %428 ], [ 1, %.bb98_crit_edge ], [ 1, %.bb98_crit_edge79 ], [ 1, %.bb98_crit_edge75 ], [ 1, %switch.hole_check.bb98_crit_edge ], [ 1, %.bb98_crit_edge99 ], [ 1, %.bb98_crit_edge103 ], [ 1, %bb59.bb98_crit_edge ], [ 1, %bb57.bb98_crit_edge ]
  %457 = getelementptr inbounds nuw i8, ptr %_0, i64 %.sink67, !dbg !29707
  %458 = ptrtoint ptr %457 to i64, !dbg !29707
  %459 = lshr i64 %458, 3, !dbg !29707
  %460 = add i64 %459, 2147450880, !dbg !29707
  %461 = inttoptr i64 %460 to ptr, !dbg !29707
  %462 = load i8, ptr %461, align 1, !dbg !29707
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %462), !dbg !29707
  %463 = icmp ne i8 %462, 0, !dbg !29707
  br i1 %463, label %466, label %bb98._crit_edge, !dbg !29707, !prof !4181

bb98._crit_edge:                                  ; preds = %bb98
  %464 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 82), align 1, !dbg !29707, !nosanitize !4110
  %465 = add i8 %464, 1, !dbg !29707
  store i8 %465, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 82), align 1, !dbg !29707, !nosanitize !4110
  br label %475, !dbg !29707

466:                                              ; preds = %bb98
  %467 = and i64 %458, 7, !dbg !29707
  %468 = trunc i64 %467 to i8, !dbg !29707
  call void @__sanitizer_cov_trace_cmp1(i8 %468, i8 %462), !dbg !29707
  %469 = icmp sge i8 %468, %462, !dbg !29707
  br i1 %469, label %472, label %._crit_edge106, !dbg !29707

._crit_edge106:                                   ; preds = %466
  %470 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 83), align 1, !dbg !29707, !nosanitize !4110
  %471 = add i8 %470, 1, !dbg !29707
  store i8 %471, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 83), align 1, !dbg !29707, !nosanitize !4110
  br label %475, !dbg !29707

472:                                              ; preds = %466
  %473 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 84), align 1, !dbg !29707, !nosanitize !4110
  %474 = add i8 %473, 1, !dbg !29707
  store i8 %474, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 84), align 1, !dbg !29707, !nosanitize !4110
  call void @__asan_report_store1(i64 %458) #42, !dbg !29707
  unreachable

475:                                              ; preds = %._crit_edge106, %bb98._crit_edge
  store i8 %.sink65, ptr %457, align 1, !dbg !29707
  %476 = ptrtoint ptr %_0 to i64, !dbg !29707
  %477 = lshr i64 %476, 3, !dbg !29707
  %478 = add i64 %477, 2147450880, !dbg !29707
  %479 = inttoptr i64 %478 to ptr, !dbg !29707
  %480 = load i8, ptr %479, align 1, !dbg !29707
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %480), !dbg !29707
  %481 = icmp ne i8 %480, 0, !dbg !29707
  br i1 %481, label %484, label %._crit_edge107, !dbg !29707, !prof !4181

._crit_edge107:                                   ; preds = %475
  %482 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 85), align 1, !dbg !29707, !nosanitize !4110
  %483 = add i8 %482, 1, !dbg !29707
  store i8 %483, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 85), align 1, !dbg !29707, !nosanitize !4110
  br label %493, !dbg !29707

484:                                              ; preds = %475
  %485 = and i64 %476, 7, !dbg !29707
  %486 = trunc i64 %485 to i8, !dbg !29707
  call void @__sanitizer_cov_trace_cmp1(i8 %486, i8 %480), !dbg !29707
  %487 = icmp sge i8 %486, %480, !dbg !29707
  br i1 %487, label %490, label %._crit_edge108, !dbg !29707

._crit_edge108:                                   ; preds = %484
  %488 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 86), align 1, !dbg !29707, !nosanitize !4110
  %489 = add i8 %488, 1, !dbg !29707
  store i8 %489, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 86), align 1, !dbg !29707, !nosanitize !4110
  br label %493, !dbg !29707

490:                                              ; preds = %484
  %491 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 87), align 1, !dbg !29707, !nosanitize !4110
  %492 = add i8 %491, 1, !dbg !29707
  store i8 %492, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1452, i64 0, i64 87), align 1, !dbg !29707, !nosanitize !4110
  call void @__asan_report_store1(i64 %476) #42, !dbg !29707
  unreachable

493:                                              ; preds = %._crit_edge108, %._crit_edge107
  store i8 %.sink, ptr %_0, align 8, !dbg !29707
  ret void, !dbg !29754
}

; Verified production function: wire_parse
define void @_RNvNtCs4oicsBtN6nJ_15spiral_protocol4wire5parse(ptr dead_on_unwind noalias nofree noundef writable writeonly sret([56 x i8]) align 8 captures(none) dereferenceable(56) %_0, ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) %raw.0, i64 noundef range(i64 0, -9223372036854775808) %raw.1) unnamed_addr #0 comdat !dbg !28853 !guid !54446 {
start:
  %h.sroa.0 = alloca [24 x i8], align 8
  %_4.sroa.9 = alloca [29 x i8], align 1
  %asan_local_stack_base = alloca i64, align 8
  %0 = load i8, ptr @__sancov_gen_.2167, align 1, !dbg !54447, !nosanitize !4110
  %1 = add i8 %0, 1, !dbg !54447
  store i8 %1, ptr @__sancov_gen_.2167, align 1, !dbg !54447, !nosanitize !4110
  %2 = load i32, ptr @__asan_option_detect_stack_use_after_return, align 4
  call void @__sanitizer_cov_trace_const_cmp4(i32 0, i32 %2), !dbg !54448
  %3 = icmp ne i32 %2, 0
  br i1 %3, label %6, label %start._crit_edge

start._crit_edge:                                 ; preds = %start
  %4 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2167, i64 0, i64 1), align 1, !dbg !54448, !nosanitize !4110
  %5 = add i8 %4, 1, !dbg !54448
  store i8 %5, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2167, i64 0, i64 1), align 1, !dbg !54448, !nosanitize !4110
  br label %10

6:                                                ; preds = %start
  %7 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2167, i64 0, i64 2), align 1, !dbg !54448, !nosanitize !4110
  %8 = add i8 %7, 1, !dbg !54448
  store i8 %8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2167, i64 0, i64 2), align 1, !dbg !54448, !nosanitize !4110
  %9 = call i64 @__asan_stack_malloc_1(i64 128)
  br label %10

10:                                               ; preds = %start._crit_edge, %6
  %11 = phi i64 [ 0, %start._crit_edge ], [ %9, %6 ]
  %12 = inttoptr i64 %11 to ptr
  call void @__sanitizer_cov_trace_const_cmp8(i64 0, i64 %11), !dbg !54448
  %13 = icmp eq i64 %11, 0
  br i1 %13, label %16, label %._crit_edge

._crit_edge:                                      ; preds = %10
  %14 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2167, i64 0, i64 3), align 1, !dbg !54448, !nosanitize !4110
  %15 = add i8 %14, 1, !dbg !54448
  store i8 %15, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2167, i64 0, i64 3), align 1, !dbg !54448, !nosanitize !4110
  br label %19

16:                                               ; preds = %10
  %17 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2167, i64 0, i64 4), align 1, !dbg !54448, !nosanitize !4110
  %18 = add i8 %17, 1, !dbg !54448
  store i8 %18, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2167, i64 0, i64 4), align 1, !dbg !54448, !nosanitize !4110
  %MyAlloca = alloca i8, i64 128, align 32
  br label %19

19:                                               ; preds = %._crit_edge, %16
  %20 = phi ptr [ %12, %._crit_edge ], [ %MyAlloca, %16 ]
  store ptr %20, ptr %asan_local_stack_base, align 8
  %21 = getelementptr i8, ptr %20, i64 32
  store i64 1102416563, ptr %20, align 8
  %22 = getelementptr i8, ptr %20, i64 8
  store i64 ptrtoint (ptr @___asan_gen_stack.239 to i64), ptr %22, align 8
  %23 = getelementptr i8, ptr %20, i64 16
  store i64 ptrtoint (ptr @_RNvNtCs4oicsBtN6nJ_15spiral_protocol4wire5parse to i64), ptr %23, align 8
  %24 = ptrtoint ptr %20 to i64
  %25 = lshr i64 %24, 3
  %26 = add i64 %25, 2147450880
  %27 = add i64 %26, 0
  %28 = inttoptr i64 %27 to ptr
  store i64 -506381209984437775, ptr %28, align 1
  %29 = add i64 %26, 8
  %30 = inttoptr i64 %29 to ptr
  store i64 -868082074056918792, ptr %30, align 1
  call void @__sanitizer_cov_trace_const_cmp8(i64 40, i64 %raw.1), !dbg !54449
  %_2 = icmp samesign ult i64 %raw.1, 40, !dbg !54449
  br i1 %_2, label %bb1, label %bb2, !dbg !54449

bb2:                                              ; preds = %19
  call void @llvm.lifetime.start.p0(ptr nonnull %_4.sroa.9), !dbg !54450
  %31 = add i64 %26, 4, !dbg !54450
  %32 = inttoptr i64 %31 to ptr, !dbg !54450
  store i32 0, ptr %32, align 1, !dbg !54450
  %33 = add i64 %26, 8, !dbg !54450
  %34 = inttoptr i64 %33 to ptr, !dbg !54450
  store i16 0, ptr %34, align 1, !dbg !54450
; call <spiral_protocol::wire::Header>::parse
  call void @_RNvMNtCs4oicsBtN6nJ_15spiral_protocol4wireNtB2_6Header5parse(ptr noalias nofree noundef sret([48 x i8]) align 8 captures(none) dereferenceable(48) %21, ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) %raw.0, i64 noundef 40) #35, !dbg !54450
  tail call void @llvm.experimental.noalias.scope.decl(metadata !54451), !dbg !54450
  %35 = load i8, ptr %21, align 8, !dbg !54454, !range !4348, !alias.scope !54456, !noalias !54451, !noundef !4110
  %36 = trunc nuw i8 %35 to i1, !dbg !54454
  br i1 %36, label %bb2.i, label %bb3.i, !dbg !54458

bb2.i:                                            ; preds = %bb2
  %37 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2167, i64 0, i64 5), align 1, !dbg !54459, !nosanitize !4110
  %38 = add i8 %37, 1, !dbg !54459
  store i8 %38, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2167, i64 0, i64 5), align 1, !dbg !54459, !nosanitize !4110
  %39 = getelementptr inbounds nuw i8, ptr %21, i64 1, !dbg !54459
  %e.0.i = load i8, ptr %39, align 1, !dbg !54459, !range !18504, !alias.scope !54456, !noalias !54451, !noundef !4110
  %40 = getelementptr inbounds nuw i8, ptr %21, i64 2, !dbg !54459
  %e.1.i = load i8, ptr %40, align 2, !dbg !54459, !alias.scope !54456, !noalias !54451
  br label %_RNvXsp_NtCshZBO5P2NUJi_4core6resultINtB5_6ResultNtNtCs4oicsBtN6nJ_15spiral_protocol4wire6HeaderNtNtBO_5error5ErrorENtNtNtB7_3ops9try_trait3Try6branchBO_.exit, !dbg !54460

bb3.i:                                            ; preds = %bb2
  %41 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2167, i64 0, i64 6), align 1, !dbg !54461, !nosanitize !4110
  %42 = add i8 %41, 1, !dbg !54461
  store i8 %42, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2167, i64 0, i64 6), align 1, !dbg !54461, !nosanitize !4110
  %43 = getelementptr inbounds nuw i8, ptr %21, i64 8, !dbg !54461
  %_4.sroa.9.8..sroa_idx = getelementptr inbounds nuw i8, ptr %_4.sroa.9, i64 5, !dbg !54461
  %44 = call ptr @__asan_memcpy(ptr %_4.sroa.9.8..sroa_idx, ptr %43, i64 24), !dbg !54461
  %_4.sroa.11.8..sroa_idx = getelementptr inbounds nuw i8, ptr %21, i64 32, !dbg !54461
  %_4.sroa.11.8.copyload = load i64, ptr %_4.sroa.11.8..sroa_idx, align 8, !dbg !54461, !alias.scope !54462
  %_4.sroa.12.8..sroa_idx = getelementptr inbounds nuw i8, ptr %21, i64 40, !dbg !54461
  %_4.sroa.12.8.copyload = load i64, ptr %_4.sroa.12.8..sroa_idx, align 8, !dbg !54461, !alias.scope !54462
  br label %_RNvXsp_NtCshZBO5P2NUJi_4core6resultINtB5_6ResultNtNtCs4oicsBtN6nJ_15spiral_protocol4wire6HeaderNtNtBO_5error5ErrorENtNtNtB7_3ops9try_trait3Try6branchBO_.exit, !dbg !54463

_RNvXsp_NtCshZBO5P2NUJi_4core6resultINtB5_6ResultNtNtCs4oicsBtN6nJ_15spiral_protocol4wire6HeaderNtNtBO_5error5ErrorENtNtNtB7_3ops9try_trait3Try6branchBO_.exit: ; preds = %bb2.i, %bb3.i
  %_4.sroa.11.0 = phi i64 [ undef, %bb2.i ], [ %_4.sroa.11.8.copyload, %bb3.i ]
  %_4.sroa.7.0 = phi i8 [ %e.1.i, %bb2.i ], [ undef, %bb3.i ]
  %_4.sroa.5.0 = phi i8 [ %e.0.i, %bb2.i ], [ undef, %bb3.i ]
  %_4.sroa.12.0 = phi i64 [ undef, %bb2.i ], [ %_4.sroa.12.8.copyload, %bb3.i ]
  %45 = add i64 %26, 4, !dbg !54464
  %46 = inttoptr i64 %45 to ptr, !dbg !54464
  store i32 -117901064, ptr %46, align 1, !dbg !54464
  %47 = add i64 %26, 8, !dbg !54464
  %48 = inttoptr i64 %47 to ptr, !dbg !54464
  store i16 -1800, ptr %48, align 1, !dbg !54464
  br i1 %36, label %bb8, label %bb7, !dbg !54450

bb1:                                              ; preds = %19
  %49 = ptrtoint ptr %_0 to i64, !dbg !54465
  %50 = lshr i64 %49, 3, !dbg !54465
  %51 = add i64 %50, 2147450880, !dbg !54465
  %52 = inttoptr i64 %51 to ptr, !dbg !54465
  %53 = load i8, ptr %52, align 1, !dbg !54465
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %53), !dbg !54465
  %54 = icmp ne i8 %53, 0, !dbg !54465
  br i1 %54, label %57, label %bb1._crit_edge, !dbg !54465, !prof !4181

bb1._crit_edge:                                   ; preds = %bb1
  %55 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2167, i64 0, i64 7), align 1, !dbg !54465, !nosanitize !4110
  %56 = add i8 %55, 1, !dbg !54465
  store i8 %56, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2167, i64 0, i64 7), align 1, !dbg !54465, !nosanitize !4110
  br label %66, !dbg !54465

57:                                               ; preds = %bb1
  %58 = and i64 %49, 7, !dbg !54465
  %59 = trunc i64 %58 to i8, !dbg !54465
  call void @__sanitizer_cov_trace_cmp1(i8 %59, i8 %53), !dbg !54465
  %60 = icmp sge i8 %59, %53, !dbg !54465
  br i1 %60, label %63, label %._crit_edge5, !dbg !54465

._crit_edge5:                                     ; preds = %57
  %61 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2167, i64 0, i64 8), align 1, !dbg !54465, !nosanitize !4110
  %62 = add i8 %61, 1, !dbg !54465
  store i8 %62, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2167, i64 0, i64 8), align 1, !dbg !54465, !nosanitize !4110
  br label %66, !dbg !54465

63:                                               ; preds = %57
  %64 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2167, i64 0, i64 9), align 1, !dbg !54465, !nosanitize !4110
  %65 = add i8 %64, 1, !dbg !54465
  store i8 %65, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2167, i64 0, i64 9), align 1, !dbg !54465, !nosanitize !4110
  call void @__asan_report_store1(i64 %49) #42, !dbg !54465
  unreachable

66:                                               ; preds = %._crit_edge5, %bb1._crit_edge
  store i8 0, ptr %_0, align 8, !dbg !54465
  %67 = getelementptr inbounds nuw i8, ptr %_0, i64 40, !dbg !54465
  %68 = ptrtoint ptr %67 to i64, !dbg !54465
  %69 = lshr i64 %68, 3, !dbg !54465
  %70 = add i64 %69, 2147450880, !dbg !54465
  %71 = inttoptr i64 %70 to ptr, !dbg !54465
  %72 = load i8, ptr %71, align 1, !dbg !54465
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %72), !dbg !54465
  %73 = icmp ne i8 %72, 0, !dbg !54465
  br i1 %73, label %74, label %77, !dbg !54465

74:                                               ; preds = %66
  %75 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2167, i64 0, i64 10), align 1, !dbg !54465, !nosanitize !4110
  %76 = add i8 %75, 1, !dbg !54465
  store i8 %76, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2167, i64 0, i64 10), align 1, !dbg !54465, !nosanitize !4110
  call void @__asan_report_store8(i64 %68) #42, !dbg !54465
  unreachable, !dbg !54465

77:                                               ; preds = %66
  %78 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2167, i64 0, i64 11), align 1, !dbg !54465, !nosanitize !4110
  %79 = add i8 %78, 1, !dbg !54465
  store i8 %79, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2167, i64 0, i64 11), align 1, !dbg !54465, !nosanitize !4110
  store ptr null, ptr %67, align 8, !dbg !54465
  br label %bb15, !dbg !54466

bb8:                                              ; preds = %_RNvXsp_NtCshZBO5P2NUJi_4core6resultINtB5_6ResultNtNtCs4oicsBtN6nJ_15spiral_protocol4wire6HeaderNtNtBO_5error5ErrorENtNtNtB7_3ops9try_trait3Try6branchBO_.exit
  %80 = ptrtoint ptr %_0 to i64, !dbg !54467
  %81 = lshr i64 %80, 3, !dbg !54467
  %82 = add i64 %81, 2147450880, !dbg !54467
  %83 = inttoptr i64 %82 to ptr, !dbg !54467
  %84 = load i8, ptr %83, align 1, !dbg !54467
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %84), !dbg !54467
  %85 = icmp ne i8 %84, 0, !dbg !54467
  br i1 %85, label %88, label %bb8._crit_edge, !dbg !54467, !prof !4181

bb8._crit_edge:                                   ; preds = %bb8
  %86 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2167, i64 0, i64 12), align 1, !dbg !54467, !nosanitize !4110
  %87 = add i8 %86, 1, !dbg !54467
  store i8 %87, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2167, i64 0, i64 12), align 1, !dbg !54467, !nosanitize !4110
  br label %97, !dbg !54467

88:                                               ; preds = %bb8
  %89 = and i64 %80, 7, !dbg !54467
  %90 = trunc i64 %89 to i8, !dbg !54467
  call void @__sanitizer_cov_trace_cmp1(i8 %90, i8 %84), !dbg !54467
  %91 = icmp sge i8 %90, %84, !dbg !54467
  br i1 %91, label %94, label %._crit_edge6, !dbg !54467

._crit_edge6:                                     ; preds = %88
  %92 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2167, i64 0, i64 13), align 1, !dbg !54467, !nosanitize !4110
  %93 = add i8 %92, 1, !dbg !54467
  store i8 %93, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2167, i64 0, i64 13), align 1, !dbg !54467, !nosanitize !4110
  br label %97, !dbg !54467

94:                                               ; preds = %88
  %95 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2167, i64 0, i64 14), align 1, !dbg !54467, !nosanitize !4110
  %96 = add i8 %95, 1, !dbg !54467
  store i8 %96, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2167, i64 0, i64 14), align 1, !dbg !54467, !nosanitize !4110
  call void @__asan_report_store1(i64 %80) #42, !dbg !54467
  unreachable

97:                                               ; preds = %._crit_edge6, %bb8._crit_edge
  store i8 %_4.sroa.5.0, ptr %_0, align 8, !dbg !54467, !alias.scope !54469
  %98 = getelementptr inbounds nuw i8, ptr %_0, i64 1, !dbg !54467
  %99 = ptrtoint ptr %98 to i64, !dbg !54467
  %100 = lshr i64 %99, 3, !dbg !54467
  %101 = add i64 %100, 2147450880, !dbg !54467
  %102 = inttoptr i64 %101 to ptr, !dbg !54467
  %103 = load i8, ptr %102, align 1, !dbg !54467
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %103), !dbg !54467
  %104 = icmp ne i8 %103, 0, !dbg !54467
  br i1 %104, label %107, label %._crit_edge7, !dbg !54467, !prof !4181

._crit_edge7:                                     ; preds = %97
  %105 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2167, i64 0, i64 15), align 1, !dbg !54467, !nosanitize !4110
  %106 = add i8 %105, 1, !dbg !54467
  store i8 %106, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2167, i64 0, i64 15), align 1, !dbg !54467, !nosanitize !4110
  br label %116, !dbg !54467

107:                                              ; preds = %97
  %108 = and i64 %99, 7, !dbg !54467
  %109 = trunc i64 %108 to i8, !dbg !54467
  call void @__sanitizer_cov_trace_cmp1(i8 %109, i8 %103), !dbg !54467
  %110 = icmp sge i8 %109, %103, !dbg !54467
  br i1 %110, label %113, label %._crit_edge8, !dbg !54467

._crit_edge8:                                     ; preds = %107
  %111 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2167, i64 0, i64 16), align 1, !dbg !54467, !nosanitize !4110
  %112 = add i8 %111, 1, !dbg !54467
  store i8 %112, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2167, i64 0, i64 16), align 1, !dbg !54467, !nosanitize !4110
  br label %116, !dbg !54467

113:                                              ; preds = %107
  %114 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2167, i64 0, i64 17), align 1, !dbg !54467, !nosanitize !4110
  %115 = add i8 %114, 1, !dbg !54467
  store i8 %115, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2167, i64 0, i64 17), align 1, !dbg !54467, !nosanitize !4110
  call void @__asan_report_store1(i64 %99) #42, !dbg !54467
  unreachable

116:                                              ; preds = %._crit_edge8, %._crit_edge7
  store i8 %_4.sroa.7.0, ptr %98, align 1, !dbg !54467, !alias.scope !54469
  %117 = getelementptr inbounds nuw i8, ptr %_0, i64 40, !dbg !54467
  %118 = ptrtoint ptr %117 to i64, !dbg !54467
  %119 = lshr i64 %118, 3, !dbg !54467
  %120 = add i64 %119, 2147450880, !dbg !54467
  %121 = inttoptr i64 %120 to ptr, !dbg !54467
  %122 = load i8, ptr %121, align 1, !dbg !54467
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %122), !dbg !54467
  %123 = icmp ne i8 %122, 0, !dbg !54467
  br i1 %123, label %124, label %127, !dbg !54467

124:                                              ; preds = %116
  %125 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2167, i64 0, i64 18), align 1, !dbg !54467, !nosanitize !4110
  %126 = add i8 %125, 1, !dbg !54467
  store i8 %126, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2167, i64 0, i64 18), align 1, !dbg !54467, !nosanitize !4110
  call void @__asan_report_store8(i64 %118) #42, !dbg !54467
  unreachable, !dbg !54467

127:                                              ; preds = %116
  %128 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2167, i64 0, i64 19), align 1, !dbg !54467, !nosanitize !4110
  %129 = add i8 %128, 1, !dbg !54467
  store i8 %129, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2167, i64 0, i64 19), align 1, !dbg !54467, !nosanitize !4110
  store ptr null, ptr %117, align 8, !dbg !54467, !alias.scope !54469
  call void @llvm.lifetime.end.p0(ptr nonnull %_4.sroa.9), !dbg !54472
  br label %bb15, !dbg !54466

bb7:                                              ; preds = %_RNvXsp_NtCshZBO5P2NUJi_4core6resultINtB5_6ResultNtNtCs4oicsBtN6nJ_15spiral_protocol4wire6HeaderNtNtBO_5error5ErrorENtNtNtB7_3ops9try_trait3Try6branchBO_.exit
  %_4.sroa.9.8..sroa_idx4 = getelementptr inbounds nuw i8, ptr %_4.sroa.9, i64 5, !dbg !54450
  %130 = call ptr @__asan_memcpy(ptr %h.sroa.0, ptr %_4.sroa.9.8..sroa_idx4, i64 24), !dbg !54450
  call void @llvm.lifetime.end.p0(ptr nonnull %_4.sroa.9), !dbg !54472
  call void @__sanitizer_cov_trace_const_cmp8(i64 -41, i64 %_4.sroa.11.0), !dbg !54473
  %_13.1 = icmp ugt i64 %_4.sroa.11.0, -41, !dbg !54473
  br i1 %_13.1, label %panic, label %bb10, !dbg !54473

bb10:                                             ; preds = %bb7
  %_13.0 = add nuw i64 %_4.sroa.11.0, 40, !dbg !54473
  call void @__sanitizer_cov_trace_cmp8(i64 %raw.1, i64 %_13.0), !dbg !54474
  %_10.not = icmp eq i64 %raw.1, %_13.0, !dbg !54474
  br i1 %_10.not, label %bb12, label %bb11, !dbg !54474

panic:                                            ; preds = %bb7
  %131 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2167, i64 0, i64 20), align 1, !dbg !54473, !nosanitize !4110
  %132 = add i8 %131, 1, !dbg !54473
  store i8 %132, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2167, i64 0, i64 20), align 1, !dbg !54473, !nosanitize !4110
  call void @__asan_handle_no_return(), !dbg !54473
; call core::panicking::panic_const::panic_const_add_overflow
  tail call void @_RNvNtNtCshZBO5P2NUJi_4core9panicking11panic_const24panic_const_add_overflow(ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_8261cc9843ad33371a73da063aa10507) #43, !dbg !54473
  unreachable, !dbg !54473

bb12:                                             ; preds = %bb10
  %new_len.i = add nsw i64 %raw.1, -40, !dbg !54475
  %_11.i = getelementptr inbounds nuw i8, ptr %raw.0, i64 40, !dbg !54478
  %133 = call ptr @__asan_memcpy(ptr %_0, ptr %h.sroa.0, i64 24), !dbg !54480
  %_14.sroa.4.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 24, !dbg !54481
  %134 = ptrtoint ptr %_14.sroa.4.0._0.sroa_idx to i64, !dbg !54481
  %135 = lshr i64 %134, 3, !dbg !54481
  %136 = add i64 %135, 2147450880, !dbg !54481
  %137 = inttoptr i64 %136 to ptr, !dbg !54481
  %138 = load i8, ptr %137, align 1, !dbg !54481
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %138), !dbg !54481
  %139 = icmp ne i8 %138, 0, !dbg !54481
  br i1 %139, label %140, label %143, !dbg !54481

140:                                              ; preds = %bb12
  %141 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2167, i64 0, i64 21), align 1, !dbg !54481, !nosanitize !4110
  %142 = add i8 %141, 1, !dbg !54481
  store i8 %142, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2167, i64 0, i64 21), align 1, !dbg !54481, !nosanitize !4110
  call void @__asan_report_store8(i64 %134) #42, !dbg !54481
  unreachable, !dbg !54481

143:                                              ; preds = %bb12
  store i64 %_4.sroa.11.0, ptr %_14.sroa.4.0._0.sroa_idx, align 8, !dbg !54481
  %_14.sroa.5.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 32, !dbg !54481
  %144 = ptrtoint ptr %_14.sroa.5.0._0.sroa_idx to i64, !dbg !54481
  %145 = lshr i64 %144, 3, !dbg !54481
  %146 = add i64 %145, 2147450880, !dbg !54481
  %147 = inttoptr i64 %146 to ptr, !dbg !54481
  %148 = load i8, ptr %147, align 1, !dbg !54481
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %148), !dbg !54481
  %149 = icmp ne i8 %148, 0, !dbg !54481
  br i1 %149, label %150, label %153, !dbg !54481

150:                                              ; preds = %143
  %151 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2167, i64 0, i64 22), align 1, !dbg !54481, !nosanitize !4110
  %152 = add i8 %151, 1, !dbg !54481
  store i8 %152, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2167, i64 0, i64 22), align 1, !dbg !54481, !nosanitize !4110
  call void @__asan_report_store8(i64 %144) #42, !dbg !54481
  unreachable, !dbg !54481

153:                                              ; preds = %143
  store i64 %_4.sroa.12.0, ptr %_14.sroa.5.0._0.sroa_idx, align 8, !dbg !54481
  %_14.sroa.6.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 40, !dbg !54481
  %154 = ptrtoint ptr %_14.sroa.6.0._0.sroa_idx to i64, !dbg !54481
  %155 = lshr i64 %154, 3, !dbg !54481
  %156 = add i64 %155, 2147450880, !dbg !54481
  %157 = inttoptr i64 %156 to ptr, !dbg !54481
  %158 = load i8, ptr %157, align 1, !dbg !54481
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %158), !dbg !54481
  %159 = icmp ne i8 %158, 0, !dbg !54481
  br i1 %159, label %160, label %163, !dbg !54481

160:                                              ; preds = %153
  %161 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2167, i64 0, i64 23), align 1, !dbg !54481, !nosanitize !4110
  %162 = add i8 %161, 1, !dbg !54481
  store i8 %162, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2167, i64 0, i64 23), align 1, !dbg !54481, !nosanitize !4110
  call void @__asan_report_store8(i64 %154) #42, !dbg !54481
  unreachable, !dbg !54481

163:                                              ; preds = %153
  store ptr %_11.i, ptr %_14.sroa.6.0._0.sroa_idx, align 8, !dbg !54481
  %_14.sroa.7.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 48, !dbg !54481
  %164 = ptrtoint ptr %_14.sroa.7.0._0.sroa_idx to i64, !dbg !54481
  %165 = lshr i64 %164, 3, !dbg !54481
  %166 = add i64 %165, 2147450880, !dbg !54481
  %167 = inttoptr i64 %166 to ptr, !dbg !54481
  %168 = load i8, ptr %167, align 1, !dbg !54481
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %168), !dbg !54481
  %169 = icmp ne i8 %168, 0, !dbg !54481
  br i1 %169, label %170, label %173, !dbg !54481

170:                                              ; preds = %163
  %171 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2167, i64 0, i64 24), align 1, !dbg !54481, !nosanitize !4110
  %172 = add i8 %171, 1, !dbg !54481
  store i8 %172, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2167, i64 0, i64 24), align 1, !dbg !54481, !nosanitize !4110
  call void @__asan_report_store8(i64 %164) #42, !dbg !54481
  unreachable, !dbg !54481

173:                                              ; preds = %163
  %174 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2167, i64 0, i64 25), align 1, !dbg !54481, !nosanitize !4110
  %175 = add i8 %174, 1, !dbg !54481
  store i8 %175, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2167, i64 0, i64 25), align 1, !dbg !54481, !nosanitize !4110
  store i64 %new_len.i, ptr %_14.sroa.7.0._0.sroa_idx, align 8, !dbg !54481
  br label %bb15, !dbg !54482

bb11:                                             ; preds = %bb10
  %176 = ptrtoint ptr %_0 to i64, !dbg !54483
  %177 = lshr i64 %176, 3, !dbg !54483
  %178 = add i64 %177, 2147450880, !dbg !54483
  %179 = inttoptr i64 %178 to ptr, !dbg !54483
  %180 = load i8, ptr %179, align 1, !dbg !54483
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %180), !dbg !54483
  %181 = icmp ne i8 %180, 0, !dbg !54483
  br i1 %181, label %184, label %bb11._crit_edge, !dbg !54483, !prof !4181

bb11._crit_edge:                                  ; preds = %bb11
  %182 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2167, i64 0, i64 26), align 1, !dbg !54483, !nosanitize !4110
  %183 = add i8 %182, 1, !dbg !54483
  store i8 %183, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2167, i64 0, i64 26), align 1, !dbg !54483, !nosanitize !4110
  br label %193, !dbg !54483

184:                                              ; preds = %bb11
  %185 = and i64 %176, 7, !dbg !54483
  %186 = trunc i64 %185 to i8, !dbg !54483
  call void @__sanitizer_cov_trace_cmp1(i8 %186, i8 %180), !dbg !54483
  %187 = icmp sge i8 %186, %180, !dbg !54483
  br i1 %187, label %190, label %._crit_edge9, !dbg !54483

._crit_edge9:                                     ; preds = %184
  %188 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2167, i64 0, i64 27), align 1, !dbg !54483, !nosanitize !4110
  %189 = add i8 %188, 1, !dbg !54483
  store i8 %189, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2167, i64 0, i64 27), align 1, !dbg !54483, !nosanitize !4110
  br label %193, !dbg !54483

190:                                              ; preds = %184
  %191 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2167, i64 0, i64 28), align 1, !dbg !54483, !nosanitize !4110
  %192 = add i8 %191, 1, !dbg !54483
  store i8 %192, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2167, i64 0, i64 28), align 1, !dbg !54483, !nosanitize !4110
  call void @__asan_report_store1(i64 %176) #42, !dbg !54483
  unreachable

193:                                              ; preds = %._crit_edge9, %bb11._crit_edge
  store i8 0, ptr %_0, align 8, !dbg !54483
  %194 = getelementptr inbounds nuw i8, ptr %_0, i64 40, !dbg !54483
  %195 = ptrtoint ptr %194 to i64, !dbg !54483
  %196 = lshr i64 %195, 3, !dbg !54483
  %197 = add i64 %196, 2147450880, !dbg !54483
  %198 = inttoptr i64 %197 to ptr, !dbg !54483
  %199 = load i8, ptr %198, align 1, !dbg !54483
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %199), !dbg !54483
  %200 = icmp ne i8 %199, 0, !dbg !54483
  br i1 %200, label %201, label %204, !dbg !54483

201:                                              ; preds = %193
  %202 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2167, i64 0, i64 29), align 1, !dbg !54483, !nosanitize !4110
  %203 = add i8 %202, 1, !dbg !54483
  store i8 %203, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2167, i64 0, i64 29), align 1, !dbg !54483, !nosanitize !4110
  call void @__asan_report_store8(i64 %195) #42, !dbg !54483
  unreachable, !dbg !54483

204:                                              ; preds = %193
  %205 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2167, i64 0, i64 30), align 1, !dbg !54483, !nosanitize !4110
  %206 = add i8 %205, 1, !dbg !54483
  store i8 %206, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2167, i64 0, i64 30), align 1, !dbg !54483, !nosanitize !4110
  store ptr null, ptr %194, align 8, !dbg !54483
  br label %bb15, !dbg !54484

bb15:                                             ; preds = %204, %127, %77, %173
  store i64 1172321806, ptr %20, align 8, !dbg !54482
  call void @__sanitizer_cov_trace_const_cmp8(i64 0, i64 %11), !dbg !54482
  %207 = icmp ne i64 %11, 0, !dbg !54482
  br i1 %207, label %208, label %218, !dbg !54482

208:                                              ; preds = %bb15
  %209 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2167, i64 0, i64 31), align 1, !dbg !54482, !nosanitize !4110
  %210 = add i8 %209, 1, !dbg !54482
  store i8 %210, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2167, i64 0, i64 31), align 1, !dbg !54482, !nosanitize !4110
  %211 = add i64 %26, 0, !dbg !54482
  %212 = inttoptr i64 %211 to ptr, !dbg !54482
  store i64 -723401728380766731, ptr %212, align 1, !dbg !54482
  %213 = add i64 %26, 8, !dbg !54482
  %214 = inttoptr i64 %213 to ptr, !dbg !54482
  store i64 -723401728380766731, ptr %214, align 1, !dbg !54482
  %215 = getelementptr i8, ptr %12, i64 120, !dbg !54482
  %216 = load i64, ptr %215, align 8, !dbg !54482
  %217 = inttoptr i64 %216 to ptr, !dbg !54482
  store i8 0, ptr %217, align 1, !dbg !54482
  br label %225, !dbg !54482

218:                                              ; preds = %bb15
  %219 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2167, i64 0, i64 32), align 1, !dbg !54482, !nosanitize !4110
  %220 = add i8 %219, 1, !dbg !54482
  store i8 %220, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2167, i64 0, i64 32), align 1, !dbg !54482, !nosanitize !4110
  %221 = add i64 %26, 0, !dbg !54482
  %222 = inttoptr i64 %221 to ptr, !dbg !54482
  store i64 0, ptr %222, align 1, !dbg !54482
  %223 = add i64 %26, 8, !dbg !54482
  %224 = inttoptr i64 %223 to ptr, !dbg !54482
  store i64 0, ptr %224, align 1, !dbg !54482
  br label %225, !dbg !54482

225:                                              ; preds = %218, %208
  ret void, !dbg !54482
}

; Verified production function: tx_data
define void @_RNvMNtCs4oicsBtN6nJ_15spiral_protocol7recordsNtB2_2Tx4data(ptr dead_on_unwind noalias nofree noundef writable writeonly sret([32 x i8]) align 8 captures(none) dereferenceable(32) %_0, ptr noalias nofree noundef align 8 dereferenceable(72) %self, ptr noalias nofree noundef align 8 captures(address) dead_on_return dereferenceable(48) %p) unnamed_addr #11 comdat personality ptr @rust_eh_personality !dbg !31240 !guid !31241 {
start:
  %asan_local_stack_base = alloca i64, align 8
  %0 = load i8, ptr @__sancov_gen_.1477, align 1, !dbg !31242, !nosanitize !4110
  %1 = add i8 %0, 1, !dbg !31242
  store i8 %1, ptr @__sancov_gen_.1477, align 1, !dbg !31242, !nosanitize !4110
  %2 = load i32, ptr @__asan_option_detect_stack_use_after_return, align 4
  call void @__sanitizer_cov_trace_const_cmp4(i32 0, i32 %2), !dbg !31243
  %3 = icmp ne i32 %2, 0
  br i1 %3, label %6, label %start._crit_edge

start._crit_edge:                                 ; preds = %start
  %4 = load i8, ptr getelementptr ([43 x i8], ptr @__sancov_gen_.1477, i64 0, i64 1), align 1, !dbg !31243, !nosanitize !4110
  %5 = add i8 %4, 1, !dbg !31243
  store i8 %5, ptr getelementptr ([43 x i8], ptr @__sancov_gen_.1477, i64 0, i64 1), align 1, !dbg !31243, !nosanitize !4110
  br label %10

6:                                                ; preds = %start
  %7 = load i8, ptr getelementptr ([43 x i8], ptr @__sancov_gen_.1477, i64 0, i64 2), align 1, !dbg !31243, !nosanitize !4110
  %8 = add i8 %7, 1, !dbg !31243
  store i8 %8, ptr getelementptr ([43 x i8], ptr @__sancov_gen_.1477, i64 0, i64 2), align 1, !dbg !31243, !nosanitize !4110
  %9 = call i64 @__asan_stack_malloc_1(i64 128)
  br label %10

10:                                               ; preds = %start._crit_edge, %6
  %11 = phi i64 [ 0, %start._crit_edge ], [ %9, %6 ]
  %12 = inttoptr i64 %11 to ptr
  call void @__sanitizer_cov_trace_const_cmp8(i64 0, i64 %11), !dbg !31243
  %13 = icmp eq i64 %11, 0
  br i1 %13, label %16, label %._crit_edge

._crit_edge:                                      ; preds = %10
  %14 = load i8, ptr getelementptr ([43 x i8], ptr @__sancov_gen_.1477, i64 0, i64 3), align 1, !dbg !31243, !nosanitize !4110
  %15 = add i8 %14, 1, !dbg !31243
  store i8 %15, ptr getelementptr ([43 x i8], ptr @__sancov_gen_.1477, i64 0, i64 3), align 1, !dbg !31243, !nosanitize !4110
  br label %19

16:                                               ; preds = %10
  %17 = load i8, ptr getelementptr ([43 x i8], ptr @__sancov_gen_.1477, i64 0, i64 4), align 1, !dbg !31243, !nosanitize !4110
  %18 = add i8 %17, 1, !dbg !31243
  store i8 %18, ptr getelementptr ([43 x i8], ptr @__sancov_gen_.1477, i64 0, i64 4), align 1, !dbg !31243, !nosanitize !4110
  %MyAlloca = alloca i8, i64 128, align 32
  br label %19

19:                                               ; preds = %._crit_edge, %16
  %20 = phi ptr [ %12, %._crit_edge ], [ %MyAlloca, %16 ]
  store ptr %20, ptr %asan_local_stack_base, align 8
  %21 = getelementptr i8, ptr %20, i64 32
  store i64 1102416563, ptr %20, align 8
  %22 = getelementptr i8, ptr %20, i64 8
  store i64 ptrtoint (ptr @___asan_gen_stack.114 to i64), ptr %22, align 8
  %23 = getelementptr i8, ptr %20, i64 16
  store i64 ptrtoint (ptr @_RNvMNtCs4oicsBtN6nJ_15spiral_protocol7recordsNtB2_2Tx4data to i64), ptr %23, align 8
  %24 = ptrtoint ptr %20 to i64
  %25 = lshr i64 %24, 3
  %26 = add i64 %25, 2147450880
  %27 = add i64 %26, 0
  %28 = inttoptr i64 %27 to ptr
  store i64 -506381209984437775, ptr %28, align 1
  %29 = add i64 %26, 8
  %30 = inttoptr i64 %29 to ptr
  store i64 -868082074056918792, ptr %30, align 1
  %31 = getelementptr inbounds nuw i8, ptr %self, i64 70, !dbg !31244
  %32 = ptrtoint ptr %31 to i64, !dbg !31244
  %33 = lshr i64 %32, 3, !dbg !31244
  %34 = add i64 %33, 2147450880, !dbg !31244
  %35 = inttoptr i64 %34 to ptr, !dbg !31244
  %36 = load i8, ptr %35, align 1, !dbg !31244
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %36), !dbg !31244
  %37 = icmp ne i8 %36, 0, !dbg !31244
  br i1 %37, label %40, label %._crit_edge2, !dbg !31244, !prof !4181

._crit_edge2:                                     ; preds = %19
  %38 = load i8, ptr getelementptr ([43 x i8], ptr @__sancov_gen_.1477, i64 0, i64 5), align 1, !dbg !31244, !nosanitize !4110
  %39 = add i8 %38, 1, !dbg !31244
  store i8 %39, ptr getelementptr ([43 x i8], ptr @__sancov_gen_.1477, i64 0, i64 5), align 1, !dbg !31244, !nosanitize !4110
  br label %49, !dbg !31244

40:                                               ; preds = %19
  %41 = and i64 %32, 7, !dbg !31244
  %42 = trunc i64 %41 to i8, !dbg !31244
  call void @__sanitizer_cov_trace_cmp1(i8 %42, i8 %36), !dbg !31244
  %43 = icmp sge i8 %42, %36, !dbg !31244
  br i1 %43, label %46, label %._crit_edge3, !dbg !31244

._crit_edge3:                                     ; preds = %40
  %44 = load i8, ptr getelementptr ([43 x i8], ptr @__sancov_gen_.1477, i64 0, i64 6), align 1, !dbg !31244, !nosanitize !4110
  %45 = add i8 %44, 1, !dbg !31244
  store i8 %45, ptr getelementptr ([43 x i8], ptr @__sancov_gen_.1477, i64 0, i64 6), align 1, !dbg !31244, !nosanitize !4110
  br label %49, !dbg !31244

46:                                               ; preds = %40
  %47 = load i8, ptr getelementptr ([43 x i8], ptr @__sancov_gen_.1477, i64 0, i64 7), align 1, !dbg !31244, !nosanitize !4110
  %48 = add i8 %47, 1, !dbg !31244
  store i8 %48, ptr getelementptr ([43 x i8], ptr @__sancov_gen_.1477, i64 0, i64 7), align 1, !dbg !31244, !nosanitize !4110
  call void @__asan_report_load1(i64 %32) #42, !dbg !31244
  unreachable

49:                                               ; preds = %._crit_edge3, %._crit_edge2
  %50 = load i8, ptr %31, align 2, !dbg !31244, !range !4348, !noundef !4110
  %_3 = trunc nuw i8 %50 to i1, !dbg !31244
  br i1 %_3, label %.bb4_crit_edge, label %bb1, !dbg !31244

.bb4_crit_edge:                                   ; preds = %49
  %51 = load i8, ptr getelementptr ([43 x i8], ptr @__sancov_gen_.1477, i64 0, i64 8), align 1, !dbg !31244, !nosanitize !4110
  %52 = add i8 %51, 1, !dbg !31244
  store i8 %52, ptr getelementptr ([43 x i8], ptr @__sancov_gen_.1477, i64 0, i64 8), align 1, !dbg !31244, !nosanitize !4110
  br label %bb4, !dbg !31244

bb1:                                              ; preds = %49
  %_5 = getelementptr inbounds nuw i8, ptr %self, i64 37, !dbg !31245
  %53 = ptrtoint ptr %_5 to i64, !dbg !31246
  %54 = lshr i64 %53, 3, !dbg !31246
  %55 = add i64 %54, 2147450880, !dbg !31246
  %56 = inttoptr i64 %55 to ptr, !dbg !31246
  %57 = load i8, ptr %56, align 1, !dbg !31246
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %57), !dbg !31246
  %58 = icmp ne i8 %57, 0, !dbg !31246
  br i1 %58, label %61, label %bb1._crit_edge, !dbg !31246, !prof !4181

bb1._crit_edge:                                   ; preds = %bb1
  %59 = load i8, ptr getelementptr ([43 x i8], ptr @__sancov_gen_.1477, i64 0, i64 9), align 1, !dbg !31246, !nosanitize !4110
  %60 = add i8 %59, 1, !dbg !31246
  store i8 %60, ptr getelementptr ([43 x i8], ptr @__sancov_gen_.1477, i64 0, i64 9), align 1, !dbg !31246, !nosanitize !4110
  br label %70, !dbg !31246

61:                                               ; preds = %bb1
  %62 = and i64 %53, 7, !dbg !31246
  %63 = trunc i64 %62 to i8, !dbg !31246
  call void @__sanitizer_cov_trace_cmp1(i8 %63, i8 %57), !dbg !31246
  %64 = icmp sge i8 %63, %57, !dbg !31246
  br i1 %64, label %67, label %._crit_edge4, !dbg !31246

._crit_edge4:                                     ; preds = %61
  %65 = load i8, ptr getelementptr ([43 x i8], ptr @__sancov_gen_.1477, i64 0, i64 10), align 1, !dbg !31246, !nosanitize !4110
  %66 = add i8 %65, 1, !dbg !31246
  store i8 %66, ptr getelementptr ([43 x i8], ptr @__sancov_gen_.1477, i64 0, i64 10), align 1, !dbg !31246, !nosanitize !4110
  br label %70, !dbg !31246

67:                                               ; preds = %61
  %68 = load i8, ptr getelementptr ([43 x i8], ptr @__sancov_gen_.1477, i64 0, i64 11), align 1, !dbg !31246, !nosanitize !4110
  %69 = add i8 %68, 1, !dbg !31246
  store i8 %69, ptr getelementptr ([43 x i8], ptr @__sancov_gen_.1477, i64 0, i64 11), align 1, !dbg !31246, !nosanitize !4110
  call void @__asan_report_load1(i64 %53) #42, !dbg !31246
  unreachable

70:                                               ; preds = %._crit_edge4, %bb1._crit_edge
  %71 = load i8, ptr %_5, align 1, !dbg !31246, !range !4348, !alias.scope !31253, !noundef !4110
  %72 = trunc nuw i8 %71 to i1, !dbg !31246
  br i1 %72, label %bb5, label %.bb4_crit_edge5, !dbg !31245

.bb4_crit_edge5:                                  ; preds = %70
  %73 = load i8, ptr getelementptr ([43 x i8], ptr @__sancov_gen_.1477, i64 0, i64 12), align 1, !dbg !31245, !nosanitize !4110
  %74 = add i8 %73, 1, !dbg !31245
  store i8 %74, ptr getelementptr ([43 x i8], ptr @__sancov_gen_.1477, i64 0, i64 12), align 1, !dbg !31245, !nosanitize !4110
  br label %bb4, !dbg !31245

bb4:                                              ; preds = %.bb4_crit_edge5, %.bb4_crit_edge
  %75 = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !31256
  %76 = ptrtoint ptr %75 to i64, !dbg !31256
  %77 = lshr i64 %76, 3, !dbg !31256
  %78 = add i64 %77, 2147450880, !dbg !31256
  %79 = inttoptr i64 %78 to ptr, !dbg !31256
  %80 = load i8, ptr %79, align 1, !dbg !31256
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %80), !dbg !31256
  %81 = icmp ne i8 %80, 0, !dbg !31256
  br i1 %81, label %84, label %bb4._crit_edge, !dbg !31256, !prof !4181

bb4._crit_edge:                                   ; preds = %bb4
  %82 = load i8, ptr getelementptr ([43 x i8], ptr @__sancov_gen_.1477, i64 0, i64 13), align 1, !dbg !31256, !nosanitize !4110
  %83 = add i8 %82, 1, !dbg !31256
  store i8 %83, ptr getelementptr ([43 x i8], ptr @__sancov_gen_.1477, i64 0, i64 13), align 1, !dbg !31256, !nosanitize !4110
  br label %93, !dbg !31256

84:                                               ; preds = %bb4
  %85 = and i64 %76, 7, !dbg !31256
  %86 = trunc i64 %85 to i8, !dbg !31256
  call void @__sanitizer_cov_trace_cmp1(i8 %86, i8 %80), !dbg !31256
  %87 = icmp sge i8 %86, %80, !dbg !31256
  br i1 %87, label %90, label %._crit_edge6, !dbg !31256

._crit_edge6:                                     ; preds = %84
  %88 = load i8, ptr getelementptr ([43 x i8], ptr @__sancov_gen_.1477, i64 0, i64 14), align 1, !dbg !31256, !nosanitize !4110
  %89 = add i8 %88, 1, !dbg !31256
  store i8 %89, ptr getelementptr ([43 x i8], ptr @__sancov_gen_.1477, i64 0, i64 14), align 1, !dbg !31256, !nosanitize !4110
  br label %93, !dbg !31256

90:                                               ; preds = %84
  %91 = load i8, ptr getelementptr ([43 x i8], ptr @__sancov_gen_.1477, i64 0, i64 15), align 1, !dbg !31256, !nosanitize !4110
  %92 = add i8 %91, 1, !dbg !31256
  store i8 %92, ptr getelementptr ([43 x i8], ptr @__sancov_gen_.1477, i64 0, i64 15), align 1, !dbg !31256, !nosanitize !4110
  call void @__asan_report_store1(i64 %76) #42, !dbg !31256
  unreachable

93:                                               ; preds = %._crit_edge6, %bb4._crit_edge
  store i8 6, ptr %75, align 8, !dbg !31256
  br label %bb19, !dbg !31257

bb5:                                              ; preds = %70
  %94 = getelementptr inbounds nuw i8, ptr %p, i64 40, !dbg !31259
  %95 = ptrtoint ptr %94 to i64, !dbg !31259
  %96 = lshr i64 %95, 3, !dbg !31259
  %97 = add i64 %96, 2147450880, !dbg !31259
  %98 = inttoptr i64 %97 to ptr, !dbg !31259
  %99 = load i8, ptr %98, align 1, !dbg !31259
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %99), !dbg !31259
  %100 = icmp ne i8 %99, 0, !dbg !31259
  br i1 %100, label %101, label %104, !dbg !31259

101:                                              ; preds = %bb5
  %102 = load i8, ptr getelementptr ([43 x i8], ptr @__sancov_gen_.1477, i64 0, i64 16), align 1, !dbg !31259, !nosanitize !4110
  %103 = add i8 %102, 1, !dbg !31259
  store i8 %103, ptr getelementptr ([43 x i8], ptr @__sancov_gen_.1477, i64 0, i64 16), align 1, !dbg !31259, !nosanitize !4110
  call void @__asan_report_load8(i64 %95) #42, !dbg !31259
  unreachable, !dbg !31259

104:                                              ; preds = %bb5
  %_6 = load i64, ptr %94, align 8, !dbg !31259, !noundef !4110
  %105 = add i64 %_6, -16385, !dbg !31259
  call void @__sanitizer_cov_trace_const_cmp8(i64 -16384, i64 %105), !dbg !31259
  %or.cond = icmp ult i64 %105, -16384, !dbg !31259
  br i1 %or.cond, label %bb2.i, label %bb9, !dbg !31259

bb2.i:                                            ; preds = %104
  %106 = getelementptr inbounds nuw i8, ptr %self, i64 38, !dbg !31260
; call <[u8] as zeroize::Zeroize>::zeroize
  tail call void @_RNvXs9_Cs5e7aMHj0NTS_7zeroizeShNtB5_7Zeroize7zeroizeB5_(ptr noalias nofree noundef nonnull dereferenceable(32) %106, i64 noundef 32) #35, !dbg !31262
  %107 = ptrtoint ptr %_5 to i64, !dbg !31265
  %108 = lshr i64 %107, 3, !dbg !31265
  %109 = add i64 %108, 2147450880, !dbg !31265
  %110 = inttoptr i64 %109 to ptr, !dbg !31265
  %111 = load i8, ptr %110, align 1, !dbg !31265
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %111), !dbg !31265
  %112 = icmp ne i8 %111, 0, !dbg !31265
  br i1 %112, label %115, label %bb2.i._crit_edge, !dbg !31265, !prof !4181

bb2.i._crit_edge:                                 ; preds = %bb2.i
  %113 = load i8, ptr getelementptr ([43 x i8], ptr @__sancov_gen_.1477, i64 0, i64 17), align 1, !dbg !31265, !nosanitize !4110
  %114 = add i8 %113, 1, !dbg !31265
  store i8 %114, ptr getelementptr ([43 x i8], ptr @__sancov_gen_.1477, i64 0, i64 17), align 1, !dbg !31265, !nosanitize !4110
  br label %124, !dbg !31265

115:                                              ; preds = %bb2.i
  %116 = and i64 %107, 7, !dbg !31265
  %117 = trunc i64 %116 to i8, !dbg !31265
  call void @__sanitizer_cov_trace_cmp1(i8 %117, i8 %111), !dbg !31265
  %118 = icmp sge i8 %117, %111, !dbg !31265
  br i1 %118, label %121, label %._crit_edge7, !dbg !31265

._crit_edge7:                                     ; preds = %115
  %119 = load i8, ptr getelementptr ([43 x i8], ptr @__sancov_gen_.1477, i64 0, i64 18), align 1, !dbg !31265, !nosanitize !4110
  %120 = add i8 %119, 1, !dbg !31265
  store i8 %120, ptr getelementptr ([43 x i8], ptr @__sancov_gen_.1477, i64 0, i64 18), align 1, !dbg !31265, !nosanitize !4110
  br label %124, !dbg !31265

121:                                              ; preds = %115
  %122 = load i8, ptr getelementptr ([43 x i8], ptr @__sancov_gen_.1477, i64 0, i64 19), align 1, !dbg !31265, !nosanitize !4110
  %123 = add i8 %122, 1, !dbg !31265
  store i8 %123, ptr getelementptr ([43 x i8], ptr @__sancov_gen_.1477, i64 0, i64 19), align 1, !dbg !31265, !nosanitize !4110
  call void @__asan_report_store1(i64 %107) #42, !dbg !31265
  unreachable

124:                                              ; preds = %._crit_edge7, %bb2.i._crit_edge
  store i8 0, ptr %_5, align 1, !dbg !31265
  %125 = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !31266
  %126 = ptrtoint ptr %125 to i64, !dbg !31266
  %127 = lshr i64 %126, 3, !dbg !31266
  %128 = add i64 %127, 2147450880, !dbg !31266
  %129 = inttoptr i64 %128 to ptr, !dbg !31266
  %130 = load i8, ptr %129, align 1, !dbg !31266
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %130), !dbg !31266
  %131 = icmp ne i8 %130, 0, !dbg !31266
  br i1 %131, label %134, label %._crit_edge8, !dbg !31266, !prof !4181

._crit_edge8:                                     ; preds = %124
  %132 = load i8, ptr getelementptr ([43 x i8], ptr @__sancov_gen_.1477, i64 0, i64 20), align 1, !dbg !31266, !nosanitize !4110
  %133 = add i8 %132, 1, !dbg !31266
  store i8 %133, ptr getelementptr ([43 x i8], ptr @__sancov_gen_.1477, i64 0, i64 20), align 1, !dbg !31266, !nosanitize !4110
  br label %143, !dbg !31266

134:                                              ; preds = %124
  %135 = and i64 %126, 7, !dbg !31266
  %136 = trunc i64 %135 to i8, !dbg !31266
  call void @__sanitizer_cov_trace_cmp1(i8 %136, i8 %130), !dbg !31266
  %137 = icmp sge i8 %136, %130, !dbg !31266
  br i1 %137, label %140, label %._crit_edge9, !dbg !31266

._crit_edge9:                                     ; preds = %134
  %138 = load i8, ptr getelementptr ([43 x i8], ptr @__sancov_gen_.1477, i64 0, i64 21), align 1, !dbg !31266, !nosanitize !4110
  %139 = add i8 %138, 1, !dbg !31266
  store i8 %139, ptr getelementptr ([43 x i8], ptr @__sancov_gen_.1477, i64 0, i64 21), align 1, !dbg !31266, !nosanitize !4110
  br label %143, !dbg !31266

140:                                              ; preds = %134
  %141 = load i8, ptr getelementptr ([43 x i8], ptr @__sancov_gen_.1477, i64 0, i64 22), align 1, !dbg !31266, !nosanitize !4110
  %142 = add i8 %141, 1, !dbg !31266
  store i8 %142, ptr getelementptr ([43 x i8], ptr @__sancov_gen_.1477, i64 0, i64 22), align 1, !dbg !31266, !nosanitize !4110
  call void @__asan_report_store1(i64 %126) #42, !dbg !31266
  unreachable

143:                                              ; preds = %._crit_edge9, %._crit_edge8
  store i8 0, ptr %125, align 8, !dbg !31266
  br label %bb19, !dbg !31257

bb9:                                              ; preds = %104
  %144 = getelementptr inbounds nuw i8, ptr %self, i64 16, !dbg !31267
  %145 = ptrtoint ptr %144 to i64, !dbg !31267
  %146 = lshr i64 %145, 3, !dbg !31267
  %147 = add i64 %146, 2147450880, !dbg !31267
  %148 = inttoptr i64 %147 to ptr, !dbg !31267
  %149 = load i8, ptr %148, align 1, !dbg !31267
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %149), !dbg !31267
  %150 = icmp ne i8 %149, 0, !dbg !31267
  br i1 %150, label %151, label %154, !dbg !31267

151:                                              ; preds = %bb9
  %152 = load i8, ptr getelementptr ([43 x i8], ptr @__sancov_gen_.1477, i64 0, i64 23), align 1, !dbg !31267, !nosanitize !4110
  %153 = add i8 %152, 1, !dbg !31267
  store i8 %153, ptr getelementptr ([43 x i8], ptr @__sancov_gen_.1477, i64 0, i64 23), align 1, !dbg !31267, !nosanitize !4110
  call void @__asan_report_load8(i64 %145) #42, !dbg !31267
  unreachable, !dbg !31267

154:                                              ; preds = %bb9
  %_11 = load i64, ptr %144, align 8, !dbg !31267, !noundef !4110
  call void @__sanitizer_cov_trace_const_cmp8(i64 1048574, i64 %_11), !dbg !31267
  %_10 = icmp ugt i64 %_11, 1048574, !dbg !31267
  br i1 %_10, label %.bb16_crit_edge, label %bb13, !dbg !31267

.bb16_crit_edge:                                  ; preds = %154
  %155 = load i8, ptr getelementptr ([43 x i8], ptr @__sancov_gen_.1477, i64 0, i64 24), align 1, !dbg !31267, !nosanitize !4110
  %156 = add i8 %155, 1, !dbg !31267
  store i8 %156, ptr getelementptr ([43 x i8], ptr @__sancov_gen_.1477, i64 0, i64 24), align 1, !dbg !31267, !nosanitize !4110
  br label %bb16, !dbg !31267

bb13:                                             ; preds = %154
  %157 = getelementptr inbounds nuw i8, ptr %self, i64 24, !dbg !31268
  %158 = ptrtoint ptr %157 to i64, !dbg !31268
  %159 = lshr i64 %158, 3, !dbg !31268
  %160 = add i64 %159, 2147450880, !dbg !31268
  %161 = inttoptr i64 %160 to ptr, !dbg !31268
  %162 = load i8, ptr %161, align 1, !dbg !31268
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %162), !dbg !31268
  %163 = icmp ne i8 %162, 0, !dbg !31268
  br i1 %163, label %164, label %167, !dbg !31268

164:                                              ; preds = %bb13
  %165 = load i8, ptr getelementptr ([43 x i8], ptr @__sancov_gen_.1477, i64 0, i64 25), align 1, !dbg !31268, !nosanitize !4110
  %166 = add i8 %165, 1, !dbg !31268
  store i8 %166, ptr getelementptr ([43 x i8], ptr @__sancov_gen_.1477, i64 0, i64 25), align 1, !dbg !31268, !nosanitize !4110
  call void @__asan_report_load8(i64 %158) #42, !dbg !31268
  unreachable, !dbg !31268

167:                                              ; preds = %bb13
  %_14 = load i64, ptr %157, align 8, !dbg !31268, !noundef !4110
  %_17.0 = add i64 %_14, %_6, !dbg !31268
  call void @__sanitizer_cov_trace_cmp8(i64 %_17.0, i64 %_14), !dbg !31268
  %_17.1 = icmp ult i64 %_17.0, %_14, !dbg !31268
  br i1 %_17.1, label %panic, label %bb14, !dbg !31268

bb14:                                             ; preds = %167
  call void @__sanitizer_cov_trace_const_cmp8(i64 1073741823, i64 %_17.0), !dbg !31268
  %_12 = icmp ugt i64 %_17.0, 1073741823, !dbg !31268
  br i1 %_12, label %bb14.bb16_crit_edge, label %bb17, !dbg !31268

bb14.bb16_crit_edge:                              ; preds = %bb14
  %168 = load i8, ptr getelementptr ([43 x i8], ptr @__sancov_gen_.1477, i64 0, i64 26), align 1, !dbg !31268, !nosanitize !4110
  %169 = add i8 %168, 1, !dbg !31268
  store i8 %169, ptr getelementptr ([43 x i8], ptr @__sancov_gen_.1477, i64 0, i64 26), align 1, !dbg !31268, !nosanitize !4110
  br label %bb16, !dbg !31268

panic:                                            ; preds = %167
  %170 = load i8, ptr getelementptr ([43 x i8], ptr @__sancov_gen_.1477, i64 0, i64 27), align 1, !dbg !31268, !nosanitize !4110
  %171 = add i8 %170, 1, !dbg !31268
  store i8 %171, ptr getelementptr ([43 x i8], ptr @__sancov_gen_.1477, i64 0, i64 27), align 1, !dbg !31268, !nosanitize !4110
  call void @__asan_handle_no_return(), !dbg !31268
; call core::panicking::panic_const::panic_const_add_overflow
  tail call void @_RNvNtNtCshZBO5P2NUJi_4core9panicking11panic_const24panic_const_add_overflow(ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_362e27020121b20fda6b859daf12c2dd) #43, !dbg !31268
  unreachable, !dbg !31268

bb17:                                             ; preds = %bb14
  %172 = load i8, ptr getelementptr ([43 x i8], ptr @__sancov_gen_.1477, i64 0, i64 28), align 1, !dbg !31269, !nosanitize !4110
  %173 = add i8 %172, 1, !dbg !31269
  store i8 %173, ptr getelementptr ([43 x i8], ptr @__sancov_gen_.1477, i64 0, i64 28), align 1, !dbg !31269, !nosanitize !4110
  %174 = add i64 %26, 4, !dbg !31269
  %175 = inttoptr i64 %174 to ptr, !dbg !31269
  store i32 0, ptr %175, align 1, !dbg !31269
  %176 = add i64 %26, 8, !dbg !31269
  %177 = inttoptr i64 %176 to ptr, !dbg !31269
  store i16 0, ptr %177, align 1, !dbg !31269
  %178 = call ptr @__asan_memcpy(ptr %21, ptr %p, i64 48), !dbg !31269
; call <spiral_protocol::records::Tx>::encode
  call fastcc void @_RNvMNtCs4oicsBtN6nJ_15spiral_protocol7recordsNtB2_2Tx6encode(ptr noalias nofree noundef sret([32 x i8]) align 8 captures(none) dereferenceable(32) %_0, ptr noalias nofree noundef align 8 dereferenceable(72) %self, ptr noalias nofree noundef align 8 captures(address) dereferenceable(48) %21) #35, !dbg !31270
  %179 = add i64 %26, 4, !dbg !31271
  %180 = inttoptr i64 %179 to ptr, !dbg !31271
  store i32 -117901064, ptr %180, align 1, !dbg !31271
  %181 = add i64 %26, 8, !dbg !31271
  %182 = inttoptr i64 %181 to ptr, !dbg !31271
  store i16 -1800, ptr %182, align 1, !dbg !31271
  br label %bb20, !dbg !31272

bb20:                                             ; preds = %.bb20_crit_edge13, %.bb20_crit_edge, %bb2.i.i.i.i.i, %bb17
  store i64 1172321806, ptr %20, align 8, !dbg !31273
  call void @__sanitizer_cov_trace_const_cmp8(i64 0, i64 %11), !dbg !31273
  %183 = icmp ne i64 %11, 0, !dbg !31273
  br i1 %183, label %184, label %194, !dbg !31273

184:                                              ; preds = %bb20
  %185 = load i8, ptr getelementptr ([43 x i8], ptr @__sancov_gen_.1477, i64 0, i64 29), align 1, !dbg !31273, !nosanitize !4110
  %186 = add i8 %185, 1, !dbg !31273
  store i8 %186, ptr getelementptr ([43 x i8], ptr @__sancov_gen_.1477, i64 0, i64 29), align 1, !dbg !31273, !nosanitize !4110
  %187 = add i64 %26, 0, !dbg !31273
  %188 = inttoptr i64 %187 to ptr, !dbg !31273
  store i64 -723401728380766731, ptr %188, align 1, !dbg !31273
  %189 = add i64 %26, 8, !dbg !31273
  %190 = inttoptr i64 %189 to ptr, !dbg !31273
  store i64 -723401728380766731, ptr %190, align 1, !dbg !31273
  %191 = getelementptr i8, ptr %12, i64 120, !dbg !31273
  %192 = load i64, ptr %191, align 8, !dbg !31273
  %193 = inttoptr i64 %192 to ptr, !dbg !31273
  store i8 0, ptr %193, align 1, !dbg !31273
  br label %201, !dbg !31273

194:                                              ; preds = %bb20
  %195 = load i8, ptr getelementptr ([43 x i8], ptr @__sancov_gen_.1477, i64 0, i64 30), align 1, !dbg !31273, !nosanitize !4110
  %196 = add i8 %195, 1, !dbg !31273
  store i8 %196, ptr getelementptr ([43 x i8], ptr @__sancov_gen_.1477, i64 0, i64 30), align 1, !dbg !31273, !nosanitize !4110
  %197 = add i64 %26, 0, !dbg !31273
  %198 = inttoptr i64 %197 to ptr, !dbg !31273
  store i64 0, ptr %198, align 1, !dbg !31273
  %199 = add i64 %26, 8, !dbg !31273
  %200 = inttoptr i64 %199 to ptr, !dbg !31273
  store i64 0, ptr %200, align 1, !dbg !31273
  br label %201, !dbg !31273

201:                                              ; preds = %194, %184
  ret void, !dbg !31273

bb16:                                             ; preds = %bb14.bb16_crit_edge, %.bb16_crit_edge
  %202 = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !31274
  %203 = ptrtoint ptr %202 to i64, !dbg !31274
  %204 = lshr i64 %203, 3, !dbg !31274
  %205 = add i64 %204, 2147450880, !dbg !31274
  %206 = inttoptr i64 %205 to ptr, !dbg !31274
  %207 = load i8, ptr %206, align 1, !dbg !31274
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %207), !dbg !31274
  %208 = icmp ne i8 %207, 0, !dbg !31274
  br i1 %208, label %211, label %bb16._crit_edge, !dbg !31274, !prof !4181

bb16._crit_edge:                                  ; preds = %bb16
  %209 = load i8, ptr getelementptr ([43 x i8], ptr @__sancov_gen_.1477, i64 0, i64 31), align 1, !dbg !31274, !nosanitize !4110
  %210 = add i8 %209, 1, !dbg !31274
  store i8 %210, ptr getelementptr ([43 x i8], ptr @__sancov_gen_.1477, i64 0, i64 31), align 1, !dbg !31274, !nosanitize !4110
  br label %220, !dbg !31274

211:                                              ; preds = %bb16
  %212 = and i64 %203, 7, !dbg !31274
  %213 = trunc i64 %212 to i8, !dbg !31274
  call void @__sanitizer_cov_trace_cmp1(i8 %213, i8 %207), !dbg !31274
  %214 = icmp sge i8 %213, %207, !dbg !31274
  br i1 %214, label %217, label %._crit_edge10, !dbg !31274

._crit_edge10:                                    ; preds = %211
  %215 = load i8, ptr getelementptr ([43 x i8], ptr @__sancov_gen_.1477, i64 0, i64 32), align 1, !dbg !31274, !nosanitize !4110
  %216 = add i8 %215, 1, !dbg !31274
  store i8 %216, ptr getelementptr ([43 x i8], ptr @__sancov_gen_.1477, i64 0, i64 32), align 1, !dbg !31274, !nosanitize !4110
  br label %220, !dbg !31274

217:                                              ; preds = %211
  %218 = load i8, ptr getelementptr ([43 x i8], ptr @__sancov_gen_.1477, i64 0, i64 33), align 1, !dbg !31274, !nosanitize !4110
  %219 = add i8 %218, 1, !dbg !31274
  store i8 %219, ptr getelementptr ([43 x i8], ptr @__sancov_gen_.1477, i64 0, i64 33), align 1, !dbg !31274, !nosanitize !4110
  call void @__asan_report_store1(i64 %203) #42, !dbg !31274
  unreachable

220:                                              ; preds = %._crit_edge10, %bb16._crit_edge
  store i8 8, ptr %202, align 8, !dbg !31274
  %221 = getelementptr inbounds nuw i8, ptr %_0, i64 9, !dbg !31274
  %222 = ptrtoint ptr %221 to i64, !dbg !31274
  %223 = lshr i64 %222, 3, !dbg !31274
  %224 = add i64 %223, 2147450880, !dbg !31274
  %225 = inttoptr i64 %224 to ptr, !dbg !31274
  %226 = load i8, ptr %225, align 1, !dbg !31274
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %226), !dbg !31274
  %227 = icmp ne i8 %226, 0, !dbg !31274
  br i1 %227, label %230, label %._crit_edge11, !dbg !31274, !prof !4181

._crit_edge11:                                    ; preds = %220
  %228 = load i8, ptr getelementptr ([43 x i8], ptr @__sancov_gen_.1477, i64 0, i64 34), align 1, !dbg !31274, !nosanitize !4110
  %229 = add i8 %228, 1, !dbg !31274
  store i8 %229, ptr getelementptr ([43 x i8], ptr @__sancov_gen_.1477, i64 0, i64 34), align 1, !dbg !31274, !nosanitize !4110
  br label %239, !dbg !31274

230:                                              ; preds = %220
  %231 = and i64 %222, 7, !dbg !31274
  %232 = trunc i64 %231 to i8, !dbg !31274
  call void @__sanitizer_cov_trace_cmp1(i8 %232, i8 %226), !dbg !31274
  %233 = icmp sge i8 %232, %226, !dbg !31274
  br i1 %233, label %236, label %._crit_edge12, !dbg !31274

._crit_edge12:                                    ; preds = %230
  %234 = load i8, ptr getelementptr ([43 x i8], ptr @__sancov_gen_.1477, i64 0, i64 35), align 1, !dbg !31274, !nosanitize !4110
  %235 = add i8 %234, 1, !dbg !31274
  store i8 %235, ptr getelementptr ([43 x i8], ptr @__sancov_gen_.1477, i64 0, i64 35), align 1, !dbg !31274, !nosanitize !4110
  br label %239, !dbg !31274

236:                                              ; preds = %230
  %237 = load i8, ptr getelementptr ([43 x i8], ptr @__sancov_gen_.1477, i64 0, i64 36), align 1, !dbg !31274, !nosanitize !4110
  %238 = add i8 %237, 1, !dbg !31274
  store i8 %238, ptr getelementptr ([43 x i8], ptr @__sancov_gen_.1477, i64 0, i64 36), align 1, !dbg !31274, !nosanitize !4110
  call void @__asan_report_store1(i64 %222) #42, !dbg !31274
  unreachable

239:                                              ; preds = %._crit_edge12, %._crit_edge11
  store i8 2, ptr %221, align 1, !dbg !31274
  br label %bb19, !dbg !31257

bb19:                                             ; preds = %93, %143, %239
  %240 = ptrtoint ptr %_0 to i64, !dbg !31243
  %241 = lshr i64 %240, 3, !dbg !31243
  %242 = add i64 %241, 2147450880, !dbg !31243
  %243 = inttoptr i64 %242 to ptr, !dbg !31243
  %244 = load i8, ptr %243, align 1, !dbg !31243
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %244), !dbg !31243
  %245 = icmp ne i8 %244, 0, !dbg !31243
  br i1 %245, label %246, label %249, !dbg !31243

246:                                              ; preds = %bb19
  %247 = load i8, ptr getelementptr ([43 x i8], ptr @__sancov_gen_.1477, i64 0, i64 37), align 1, !dbg !31243, !nosanitize !4110
  %248 = add i8 %247, 1, !dbg !31243
  store i8 %248, ptr getelementptr ([43 x i8], ptr @__sancov_gen_.1477, i64 0, i64 37), align 1, !dbg !31243, !nosanitize !4110
  call void @__asan_report_store8(i64 %240) #42, !dbg !31243
  unreachable, !dbg !31243

249:                                              ; preds = %bb19
  store i64 -1, ptr %_0, align 8, !dbg !31243
; call <spiral_protocol::buffer::Buffer as core::ops::drop::Drop>::drop
  tail call void @_RNvXs1_NtCs4oicsBtN6nJ_15spiral_protocol6bufferNtB5_6BufferNtNtNtCshZBO5P2NUJi_4core3ops4drop4Drop4drop(ptr noalias nofree noundef nonnull align 8 dereferenceable(48) %p) #35, !dbg !31275
; call <alloc::vec::Vec<u8> as core::ops::drop::Drop>::drop
  tail call void @_RNvXsp_NtCs95TQQ7nxHrj_5alloc3vecINtB5_3VechENtNtNtCshZBO5P2NUJi_4core3ops4drop4Drop4dropCs7jJvS58pafZ_4ring(ptr noalias nofree noundef nonnull align 8 dereferenceable(48) %p) #35, !dbg !31278
; call <alloc::raw_vec::RawVec<u8> as core::ops::drop::Drop>::drop
  tail call void @_RNvXs4_NtCs95TQQ7nxHrj_5alloc7raw_vecINtB5_6RawVechENtNtNtCshZBO5P2NUJi_4core3ops4drop4Drop4dropCs7jJvS58pafZ_4ring(ptr noalias nofree noundef nonnull align 8 dereferenceable(48) %p) #35, !dbg !31280
  %250 = getelementptr inbounds nuw i8, ptr %p, i64 24, !dbg !31275
  tail call void @llvm.experimental.noalias.scope.decl(metadata !31282), !dbg !31275
  %251 = ptrtoint ptr %250 to i64, !dbg !31285
  %252 = lshr i64 %251, 3, !dbg !31285
  %253 = add i64 %252, 2147450880, !dbg !31285
  %254 = inttoptr i64 %253 to ptr, !dbg !31285
  %255 = load i8, ptr %254, align 1, !dbg !31285
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %255), !dbg !31285
  %256 = icmp ne i8 %255, 0, !dbg !31285
  br i1 %256, label %257, label %260, !dbg !31285

257:                                              ; preds = %249
  %258 = load i8, ptr getelementptr ([43 x i8], ptr @__sancov_gen_.1477, i64 0, i64 38), align 1, !dbg !31285, !nosanitize !4110
  %259 = add i8 %258, 1, !dbg !31285
  store i8 %259, ptr getelementptr ([43 x i8], ptr @__sancov_gen_.1477, i64 0, i64 38), align 1, !dbg !31285, !nosanitize !4110
  call void @__asan_report_load8(i64 %251) #42, !dbg !31285
  unreachable, !dbg !31285

260:                                              ; preds = %249
  %261 = load ptr, ptr %250, align 8, !dbg !31285, !alias.scope !31287, !noundef !4110
  %262 = icmp eq ptr %261, null, !dbg !31285
  br i1 %262, label %.bb20_crit_edge, label %bb2.i.i.i, !dbg !31285

.bb20_crit_edge:                                  ; preds = %260
  %263 = load i8, ptr getelementptr ([43 x i8], ptr @__sancov_gen_.1477, i64 0, i64 39), align 1, !dbg !31285, !nosanitize !4110
  %264 = add i8 %263, 1, !dbg !31285
  store i8 %264, ptr getelementptr ([43 x i8], ptr @__sancov_gen_.1477, i64 0, i64 39), align 1, !dbg !31285, !nosanitize !4110
  br label %bb20, !dbg !31285

bb2.i.i.i:                                        ; preds = %260
  %265 = ptrtoint ptr %261 to i64, !dbg !31292
  %266 = lshr i64 %265, 3, !dbg !31292
  %267 = add i64 %266, 2147450880, !dbg !31292
  %268 = inttoptr i64 %267 to ptr, !dbg !31292
  %269 = load i8, ptr %268, align 1, !dbg !31292
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %269), !dbg !31292
  %270 = icmp ne i8 %269, 0, !dbg !31292
  br i1 %270, label %271, label %274, !dbg !31292

271:                                              ; preds = %bb2.i.i.i
  %272 = load i8, ptr getelementptr ([43 x i8], ptr @__sancov_gen_.1477, i64 0, i64 40), align 1, !dbg !31292, !nosanitize !4110
  %273 = add i8 %272, 1, !dbg !31292
  store i8 %273, ptr getelementptr ([43 x i8], ptr @__sancov_gen_.1477, i64 0, i64 40), align 1, !dbg !31292, !nosanitize !4110
  call void @__asan_report_store8(i64 %265) #42, !dbg !31292
  unreachable, !dbg !31292

274:                                              ; preds = %bb2.i.i.i
  %_2.i.i.i.i.i = atomicrmw sub ptr %261, i64 1 release, align 8, !dbg !31292, !noalias !31297
  call void @__sanitizer_cov_trace_const_cmp8(i64 1, i64 %_2.i.i.i.i.i), !dbg !31302
  %275 = icmp eq i64 %_2.i.i.i.i.i, 1, !dbg !31302
  br i1 %275, label %bb2.i.i.i.i.i, label %.bb20_crit_edge13, !dbg !31302

.bb20_crit_edge13:                                ; preds = %274
  %276 = load i8, ptr getelementptr ([43 x i8], ptr @__sancov_gen_.1477, i64 0, i64 41), align 1, !dbg !31302, !nosanitize !4110
  %277 = add i8 %276, 1, !dbg !31302
  store i8 %277, ptr getelementptr ([43 x i8], ptr @__sancov_gen_.1477, i64 0, i64 41), align 1, !dbg !31302, !nosanitize !4110
  br label %bb20, !dbg !31302

bb2.i.i.i.i.i:                                    ; preds = %274
  %278 = load i8, ptr getelementptr ([43 x i8], ptr @__sancov_gen_.1477, i64 0, i64 42), align 1, !dbg !31303, !nosanitize !4110
  %279 = add i8 %278, 1, !dbg !31303
  store i8 %279, ptr getelementptr ([43 x i8], ptr @__sancov_gen_.1477, i64 0, i64 42), align 1, !dbg !31303, !nosanitize !4110
  fence acquire, !dbg !31303
; call <alloc::rcs::arc::Arc<spiral_protocol::buffer::Pool>>::drop_slow
  tail call void @_RNvMsn_NtNtCs95TQQ7nxHrj_5alloc3rcs3arcINtB5_3ArcNtNtCs4oicsBtN6nJ_15spiral_protocol6buffer4PoolE9drop_slowBP_(ptr noalias nofree noundef nonnull readonly align 8 dereferenceable(8) %250) #35, !dbg !31305
  br label %bb20, !dbg !31306
}

; Verified production function: tx_close
define void @_RNvMNtCs4oicsBtN6nJ_15spiral_protocol7recordsNtB2_2Tx5close(ptr dead_on_unwind noalias nofree noundef writable writeonly sret([58 x i8]) align 1 captures(none) dereferenceable(58) initializes((0, 2)) %result, ptr noalias nofree noundef align 8 dereferenceable(72) %self, i8 noundef %0) unnamed_addr #11 comdat personality ptr @rust_eh_personality !dbg !31307 !guid !31308 {
start:
  %_24.sroa.11.i = alloca [14 x i8], align 1
  %_3.sroa.11.i = alloca [38 x i8], align 1
  %asan_local_stack_base = alloca i64, align 8
  %1 = load i8, ptr @__sancov_gen_.1479, align 1, !dbg !31309, !nosanitize !4110
  %2 = add i8 %1, 1, !dbg !31309
  store i8 %2, ptr @__sancov_gen_.1479, align 1, !dbg !31309, !nosanitize !4110
  %3 = load i32, ptr @__asan_option_detect_stack_use_after_return, align 4
  call void @__sanitizer_cov_trace_const_cmp4(i32 0, i32 %3), !dbg !31310
  %4 = icmp ne i32 %3, 0
  br i1 %4, label %7, label %start._crit_edge

start._crit_edge:                                 ; preds = %start
  %5 = load i8, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 1), align 1, !dbg !31310, !nosanitize !4110
  %6 = add i8 %5, 1, !dbg !31310
  store i8 %6, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 1), align 1, !dbg !31310, !nosanitize !4110
  br label %11

7:                                                ; preds = %start
  %8 = load i8, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 2), align 1, !dbg !31310, !nosanitize !4110
  %9 = add i8 %8, 1, !dbg !31310
  store i8 %9, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 2), align 1, !dbg !31310, !nosanitize !4110
  %10 = call i64 @__asan_stack_malloc_5(i64 1728)
  br label %11

11:                                               ; preds = %start._crit_edge, %7
  %12 = phi i64 [ 0, %start._crit_edge ], [ %10, %7 ]
  %13 = inttoptr i64 %12 to ptr
  call void @__sanitizer_cov_trace_const_cmp8(i64 0, i64 %12), !dbg !31310
  %14 = icmp eq i64 %12, 0
  br i1 %14, label %17, label %._crit_edge

._crit_edge:                                      ; preds = %11
  %15 = load i8, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 3), align 1, !dbg !31310, !nosanitize !4110
  %16 = add i8 %15, 1, !dbg !31310
  store i8 %16, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 3), align 1, !dbg !31310, !nosanitize !4110
  br label %20

17:                                               ; preds = %11
  %18 = load i8, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 4), align 1, !dbg !31310, !nosanitize !4110
  %19 = add i8 %18, 1, !dbg !31310
  store i8 %19, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 4), align 1, !dbg !31310, !nosanitize !4110
  %MyAlloca = alloca i8, i64 1728, align 32
  br label %20

20:                                               ; preds = %._crit_edge, %17
  %21 = phi ptr [ %13, %._crit_edge ], [ %MyAlloca, %17 ]
  store ptr %21, ptr %asan_local_stack_base, align 8
  %22 = getelementptr i8, ptr %21, i64 32
  %23 = getelementptr i8, ptr %21, i64 896
  %24 = getelementptr i8, ptr %21, i64 960
  %25 = getelementptr i8, ptr %21, i64 1168
  %26 = getelementptr i8, ptr %21, i64 1200
  %27 = getelementptr i8, ptr %21, i64 1232
  %28 = getelementptr i8, ptr %21, i64 1248
  %29 = getelementptr i8, ptr %21, i64 1312
  %30 = getelementptr i8, ptr %21, i64 1344
  %31 = getelementptr i8, ptr %21, i64 1376
  %32 = getelementptr i8, ptr %21, i64 1472
  %33 = getelementptr i8, ptr %21, i64 1552
  %34 = getelementptr i8, ptr %21, i64 1632
  store i64 1102416563, ptr %21, align 8
  %35 = getelementptr i8, ptr %21, i64 8
  store i64 ptrtoint (ptr @___asan_gen_stack.115 to i64), ptr %35, align 8
  %36 = getelementptr i8, ptr %21, i64 16
  store i64 ptrtoint (ptr @_RNvMNtCs4oicsBtN6nJ_15spiral_protocol7recordsNtB2_2Tx5close to i64), ptr %36, align 8
  %37 = ptrtoint ptr %21 to i64
  %38 = lshr i64 %37, 3
  %39 = add i64 %38, 2147450880
  %40 = add i64 %39, 0
  %41 = inttoptr i64 %40 to ptr
  store i32 -235802127, ptr %41, align 1
  %42 = add i64 %39, 4
  call void @__asan_set_shadow_f8(i64 %42, i64 92)
  %43 = add i64 %39, 96
  %44 = inttoptr i64 %43 to ptr
  store i64 -940422246894996750, ptr %44, align 1
  %45 = add i64 %39, 104
  %46 = inttoptr i64 %45 to ptr
  store i64 -940422246894996750, ptr %46, align 1
  %47 = add i64 %39, 112
  %48 = inttoptr i64 %47 to ptr
  store i64 -940422246793938696, ptr %48, align 1
  %49 = add i64 %39, 120
  %50 = inttoptr i64 %49 to ptr
  store i64 -506381209866536712, ptr %50, align 1
  %51 = add i64 %39, 128
  %52 = inttoptr i64 %51 to ptr
  store i64 -506381209866536712, ptr %52, align 1
  %53 = add i64 %39, 136
  %54 = inttoptr i64 %53 to ptr
  store i64 -940422246894996744, ptr %54, align 1
  %55 = add i64 %39, 144
  %56 = inttoptr i64 %55 to ptr
  store i64 -506387832806771982, ptr %56, align 1
  %57 = add i64 %39, 152
  %58 = inttoptr i64 %57 to ptr
  store i64 -938726774194769166, ptr %58, align 1
  %59 = add i64 %39, 160
  %60 = inttoptr i64 %59 to ptr
  store i64 -940415624055426318, ptr %60, align 1
  %61 = add i64 %39, 168
  %62 = inttoptr i64 %61 to ptr
  store i64 -506381209967593224, ptr %62, align 1
  %63 = add i64 %39, 176
  %64 = inttoptr i64 %63 to ptr
  store i64 -940422246793938696, ptr %64, align 1
  %65 = add i64 %39, 184
  %66 = inttoptr i64 %65 to ptr
  store i64 -940422221024134920, ptr %66, align 1
  %67 = add i64 %39, 192
  %68 = inttoptr i64 %67 to ptr
  store i64 -506381209866538254, ptr %68, align 1
  %69 = add i64 %39, 200
  %70 = inttoptr i64 %69 to ptr
  store i64 -506381209967594766, ptr %70, align 1
  %71 = add i64 %39, 208
  %72 = inttoptr i64 %71 to ptr
  store i64 -868082074056920072, ptr %72, align 1
  call void @__sanitizer_cov_trace_const_cmp1(i8 2, i8 %0), !dbg !31311
  %_3 = icmp ugt i8 %0, 2, !dbg !31311
  br i1 %_3, label %bb1, label %bb2, !dbg !31311

bb2:                                              ; preds = %20
  %73 = getelementptr inbounds nuw i8, ptr %self, i64 70, !dbg !31312
  %74 = ptrtoint ptr %73 to i64, !dbg !31312
  %75 = lshr i64 %74, 3, !dbg !31312
  %76 = add i64 %75, 2147450880, !dbg !31312
  %77 = inttoptr i64 %76 to ptr, !dbg !31312
  %78 = load i8, ptr %77, align 1, !dbg !31312
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %78), !dbg !31312
  %79 = icmp ne i8 %78, 0, !dbg !31312
  br i1 %79, label %82, label %bb2._crit_edge, !dbg !31312, !prof !4181

bb2._crit_edge:                                   ; preds = %bb2
  %80 = load i8, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 5), align 1, !dbg !31312, !nosanitize !4110
  %81 = add i8 %80, 1, !dbg !31312
  store i8 %81, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 5), align 1, !dbg !31312, !nosanitize !4110
  br label %91, !dbg !31312

82:                                               ; preds = %bb2
  %83 = and i64 %74, 7, !dbg !31312
  %84 = trunc i64 %83 to i8, !dbg !31312
  call void @__sanitizer_cov_trace_cmp1(i8 %84, i8 %78), !dbg !31312
  %85 = icmp sge i8 %84, %78, !dbg !31312
  br i1 %85, label %88, label %._crit_edge5, !dbg !31312

._crit_edge5:                                     ; preds = %82
  %86 = load i8, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 6), align 1, !dbg !31312, !nosanitize !4110
  %87 = add i8 %86, 1, !dbg !31312
  store i8 %87, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 6), align 1, !dbg !31312, !nosanitize !4110
  br label %91, !dbg !31312

88:                                               ; preds = %82
  %89 = load i8, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 7), align 1, !dbg !31312, !nosanitize !4110
  %90 = add i8 %89, 1, !dbg !31312
  store i8 %90, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 7), align 1, !dbg !31312, !nosanitize !4110
  call void @__asan_report_load1(i64 %74) #42, !dbg !31312
  unreachable

91:                                               ; preds = %._crit_edge5, %bb2._crit_edge
  %92 = load i8, ptr %73, align 2, !dbg !31312, !range !4348, !noundef !4110
  %_4 = trunc nuw i8 %92 to i1, !dbg !31312
  br i1 %_4, label %.bb6_crit_edge, label %bb3, !dbg !31312

.bb6_crit_edge:                                   ; preds = %91
  %93 = load i8, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 8), align 1, !dbg !31312, !nosanitize !4110
  %94 = add i8 %93, 1, !dbg !31312
  store i8 %94, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 8), align 1, !dbg !31312, !nosanitize !4110
  br label %bb6, !dbg !31312

bb1:                                              ; preds = %20
  %95 = getelementptr inbounds nuw i8, ptr %result, i64 1, !dbg !31313
  %96 = ptrtoint ptr %95 to i64, !dbg !31313
  %97 = lshr i64 %96, 3, !dbg !31313
  %98 = add i64 %97, 2147450880, !dbg !31313
  %99 = inttoptr i64 %98 to ptr, !dbg !31313
  %100 = load i8, ptr %99, align 1, !dbg !31313
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %100), !dbg !31313
  %101 = icmp ne i8 %100, 0, !dbg !31313
  br i1 %101, label %104, label %bb1._crit_edge, !dbg !31313, !prof !4181

bb1._crit_edge:                                   ; preds = %bb1
  %102 = load i8, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 9), align 1, !dbg !31313, !nosanitize !4110
  %103 = add i8 %102, 1, !dbg !31313
  store i8 %103, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 9), align 1, !dbg !31313, !nosanitize !4110
  br label %113, !dbg !31313

104:                                              ; preds = %bb1
  %105 = and i64 %96, 7, !dbg !31313
  %106 = trunc i64 %105 to i8, !dbg !31313
  call void @__sanitizer_cov_trace_cmp1(i8 %106, i8 %100), !dbg !31313
  %107 = icmp sge i8 %106, %100, !dbg !31313
  br i1 %107, label %110, label %._crit_edge6, !dbg !31313

._crit_edge6:                                     ; preds = %104
  %108 = load i8, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 10), align 1, !dbg !31313, !nosanitize !4110
  %109 = add i8 %108, 1, !dbg !31313
  store i8 %109, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 10), align 1, !dbg !31313, !nosanitize !4110
  br label %113, !dbg !31313

110:                                              ; preds = %104
  %111 = load i8, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 11), align 1, !dbg !31313, !nosanitize !4110
  %112 = add i8 %111, 1, !dbg !31313
  store i8 %112, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 11), align 1, !dbg !31313, !nosanitize !4110
  call void @__asan_report_store1(i64 %96) #42, !dbg !31313
  unreachable

113:                                              ; preds = %._crit_edge6, %bb1._crit_edge
  store i8 0, ptr %95, align 1, !dbg !31313
  %114 = ptrtoint ptr %result to i64, !dbg !31313
  %115 = lshr i64 %114, 3, !dbg !31313
  %116 = add i64 %115, 2147450880, !dbg !31313
  %117 = inttoptr i64 %116 to ptr, !dbg !31313
  %118 = load i8, ptr %117, align 1, !dbg !31313
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %118), !dbg !31313
  %119 = icmp ne i8 %118, 0, !dbg !31313
  br i1 %119, label %122, label %._crit_edge7, !dbg !31313, !prof !4181

._crit_edge7:                                     ; preds = %113
  %120 = load i8, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 12), align 1, !dbg !31313, !nosanitize !4110
  %121 = add i8 %120, 1, !dbg !31313
  store i8 %121, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 12), align 1, !dbg !31313, !nosanitize !4110
  br label %131, !dbg !31313

122:                                              ; preds = %113
  %123 = and i64 %114, 7, !dbg !31313
  %124 = trunc i64 %123 to i8, !dbg !31313
  call void @__sanitizer_cov_trace_cmp1(i8 %124, i8 %118), !dbg !31313
  %125 = icmp sge i8 %124, %118, !dbg !31313
  br i1 %125, label %128, label %._crit_edge8, !dbg !31313

._crit_edge8:                                     ; preds = %122
  %126 = load i8, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 13), align 1, !dbg !31313, !nosanitize !4110
  %127 = add i8 %126, 1, !dbg !31313
  store i8 %127, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 13), align 1, !dbg !31313, !nosanitize !4110
  br label %131, !dbg !31313

128:                                              ; preds = %122
  %129 = load i8, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 14), align 1, !dbg !31313, !nosanitize !4110
  %130 = add i8 %129, 1, !dbg !31313
  store i8 %130, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 14), align 1, !dbg !31313, !nosanitize !4110
  call void @__asan_report_store1(i64 %114) #42, !dbg !31313
  unreachable

131:                                              ; preds = %._crit_edge8, %._crit_edge7
  store i8 1, ptr %result, align 1, !dbg !31313
  br label %bb14, !dbg !31314

bb3:                                              ; preds = %91
  %_6 = getelementptr inbounds nuw i8, ptr %self, i64 37, !dbg !31316
  %132 = ptrtoint ptr %_6 to i64, !dbg !31317
  %133 = lshr i64 %132, 3, !dbg !31317
  %134 = add i64 %133, 2147450880, !dbg !31317
  %135 = inttoptr i64 %134 to ptr, !dbg !31317
  %136 = load i8, ptr %135, align 1, !dbg !31317
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %136), !dbg !31317
  %137 = icmp ne i8 %136, 0, !dbg !31317
  br i1 %137, label %140, label %bb3._crit_edge, !dbg !31317, !prof !4181

bb3._crit_edge:                                   ; preds = %bb3
  %138 = load i8, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 15), align 1, !dbg !31317, !nosanitize !4110
  %139 = add i8 %138, 1, !dbg !31317
  store i8 %139, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 15), align 1, !dbg !31317, !nosanitize !4110
  br label %149, !dbg !31317

140:                                              ; preds = %bb3
  %141 = and i64 %132, 7, !dbg !31317
  %142 = trunc i64 %141 to i8, !dbg !31317
  call void @__sanitizer_cov_trace_cmp1(i8 %142, i8 %136), !dbg !31317
  %143 = icmp sge i8 %142, %136, !dbg !31317
  br i1 %143, label %146, label %._crit_edge9, !dbg !31317

._crit_edge9:                                     ; preds = %140
  %144 = load i8, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 16), align 1, !dbg !31317, !nosanitize !4110
  %145 = add i8 %144, 1, !dbg !31317
  store i8 %145, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 16), align 1, !dbg !31317, !nosanitize !4110
  br label %149, !dbg !31317

146:                                              ; preds = %140
  %147 = load i8, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 17), align 1, !dbg !31317, !nosanitize !4110
  %148 = add i8 %147, 1, !dbg !31317
  store i8 %148, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 17), align 1, !dbg !31317, !nosanitize !4110
  call void @__asan_report_load1(i64 %132) #42, !dbg !31317
  unreachable

149:                                              ; preds = %._crit_edge9, %bb3._crit_edge
  %150 = load i8, ptr %_6, align 1, !dbg !31317, !range !4348, !alias.scope !31320, !noundef !4110
  %151 = trunc nuw i8 %150 to i1, !dbg !31317
  br i1 %151, label %bb7, label %.bb6_crit_edge10, !dbg !31316

.bb6_crit_edge10:                                 ; preds = %149
  %152 = load i8, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 18), align 1, !dbg !31316, !nosanitize !4110
  %153 = add i8 %152, 1, !dbg !31316
  store i8 %153, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 18), align 1, !dbg !31316, !nosanitize !4110
  br label %bb6, !dbg !31316

bb6:                                              ; preds = %.bb6_crit_edge10, %.bb6_crit_edge
  %154 = getelementptr inbounds nuw i8, ptr %result, i64 1, !dbg !31323
  %155 = ptrtoint ptr %154 to i64, !dbg !31323
  %156 = lshr i64 %155, 3, !dbg !31323
  %157 = add i64 %156, 2147450880, !dbg !31323
  %158 = inttoptr i64 %157 to ptr, !dbg !31323
  %159 = load i8, ptr %158, align 1, !dbg !31323
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %159), !dbg !31323
  %160 = icmp ne i8 %159, 0, !dbg !31323
  br i1 %160, label %163, label %bb6._crit_edge, !dbg !31323, !prof !4181

bb6._crit_edge:                                   ; preds = %bb6
  %161 = load i8, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 19), align 1, !dbg !31323, !nosanitize !4110
  %162 = add i8 %161, 1, !dbg !31323
  store i8 %162, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 19), align 1, !dbg !31323, !nosanitize !4110
  br label %172, !dbg !31323

163:                                              ; preds = %bb6
  %164 = and i64 %155, 7, !dbg !31323
  %165 = trunc i64 %164 to i8, !dbg !31323
  call void @__sanitizer_cov_trace_cmp1(i8 %165, i8 %159), !dbg !31323
  %166 = icmp sge i8 %165, %159, !dbg !31323
  br i1 %166, label %169, label %._crit_edge11, !dbg !31323

._crit_edge11:                                    ; preds = %163
  %167 = load i8, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 20), align 1, !dbg !31323, !nosanitize !4110
  %168 = add i8 %167, 1, !dbg !31323
  store i8 %168, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 20), align 1, !dbg !31323, !nosanitize !4110
  br label %172, !dbg !31323

169:                                              ; preds = %163
  %170 = load i8, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 21), align 1, !dbg !31323, !nosanitize !4110
  %171 = add i8 %170, 1, !dbg !31323
  store i8 %171, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 21), align 1, !dbg !31323, !nosanitize !4110
  call void @__asan_report_store1(i64 %155) #42, !dbg !31323
  unreachable

172:                                              ; preds = %._crit_edge11, %bb6._crit_edge
  store i8 6, ptr %154, align 1, !dbg !31323
  %173 = ptrtoint ptr %result to i64, !dbg !31323
  %174 = lshr i64 %173, 3, !dbg !31323
  %175 = add i64 %174, 2147450880, !dbg !31323
  %176 = inttoptr i64 %175 to ptr, !dbg !31323
  %177 = load i8, ptr %176, align 1, !dbg !31323
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %177), !dbg !31323
  %178 = icmp ne i8 %177, 0, !dbg !31323
  br i1 %178, label %181, label %._crit_edge12, !dbg !31323, !prof !4181

._crit_edge12:                                    ; preds = %172
  %179 = load i8, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 22), align 1, !dbg !31323, !nosanitize !4110
  %180 = add i8 %179, 1, !dbg !31323
  store i8 %180, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 22), align 1, !dbg !31323, !nosanitize !4110
  br label %190, !dbg !31323

181:                                              ; preds = %172
  %182 = and i64 %173, 7, !dbg !31323
  %183 = trunc i64 %182 to i8, !dbg !31323
  call void @__sanitizer_cov_trace_cmp1(i8 %183, i8 %177), !dbg !31323
  %184 = icmp sge i8 %183, %177, !dbg !31323
  br i1 %184, label %187, label %._crit_edge13, !dbg !31323

._crit_edge13:                                    ; preds = %181
  %185 = load i8, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 23), align 1, !dbg !31323, !nosanitize !4110
  %186 = add i8 %185, 1, !dbg !31323
  store i8 %186, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 23), align 1, !dbg !31323, !nosanitize !4110
  br label %190, !dbg !31323

187:                                              ; preds = %181
  %188 = load i8, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 24), align 1, !dbg !31323, !nosanitize !4110
  %189 = add i8 %188, 1, !dbg !31323
  store i8 %189, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 24), align 1, !dbg !31323, !nosanitize !4110
  call void @__asan_report_store1(i64 %173) #42, !dbg !31323
  unreachable

190:                                              ; preds = %._crit_edge13, %._crit_edge12
  store i8 1, ptr %result, align 1, !dbg !31323
  br label %bb14, !dbg !31314

bb7:                                              ; preds = %149
  %191 = getelementptr inbounds nuw i8, ptr %self, i64 16, !dbg !31324
  %192 = ptrtoint ptr %191 to i64, !dbg !31324
  %193 = lshr i64 %192, 3, !dbg !31324
  %194 = add i64 %193, 2147450880, !dbg !31324
  %195 = inttoptr i64 %194 to ptr, !dbg !31324
  %196 = load i8, ptr %195, align 1, !dbg !31324
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %196), !dbg !31324
  %197 = icmp ne i8 %196, 0, !dbg !31324
  br i1 %197, label %198, label %201, !dbg !31324

198:                                              ; preds = %bb7
  %199 = load i8, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 25), align 1, !dbg !31324, !nosanitize !4110
  %200 = add i8 %199, 1, !dbg !31324
  store i8 %200, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 25), align 1, !dbg !31324, !nosanitize !4110
  call void @__asan_report_load8(i64 %192) #42, !dbg !31324
  unreachable, !dbg !31324

201:                                              ; preds = %bb7
  %_8 = load i64, ptr %191, align 8, !dbg !31324, !noundef !4110
  call void @__sanitizer_cov_trace_const_cmp8(i64 1048575, i64 %_8), !dbg !31324
  %_7 = icmp ugt i64 %_8, 1048575, !dbg !31324
  br i1 %_7, label %bb2.i, label %bb11, !dbg !31324

bb2.i:                                            ; preds = %201
  %202 = getelementptr inbounds nuw i8, ptr %self, i64 38, !dbg !31325
; call <[u8] as zeroize::Zeroize>::zeroize
  tail call void @_RNvXs9_Cs5e7aMHj0NTS_7zeroizeShNtB5_7Zeroize7zeroizeB5_(ptr noalias nofree noundef nonnull dereferenceable(32) %202, i64 noundef 32) #35, !dbg !31327
  %203 = ptrtoint ptr %_6 to i64, !dbg !31330
  %204 = lshr i64 %203, 3, !dbg !31330
  %205 = add i64 %204, 2147450880, !dbg !31330
  %206 = inttoptr i64 %205 to ptr, !dbg !31330
  %207 = load i8, ptr %206, align 1, !dbg !31330
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %207), !dbg !31330
  %208 = icmp ne i8 %207, 0, !dbg !31330
  br i1 %208, label %211, label %bb2.i._crit_edge, !dbg !31330, !prof !4181

bb2.i._crit_edge:                                 ; preds = %bb2.i
  %209 = load i8, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 26), align 1, !dbg !31330, !nosanitize !4110
  %210 = add i8 %209, 1, !dbg !31330
  store i8 %210, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 26), align 1, !dbg !31330, !nosanitize !4110
  br label %220, !dbg !31330

211:                                              ; preds = %bb2.i
  %212 = and i64 %203, 7, !dbg !31330
  %213 = trunc i64 %212 to i8, !dbg !31330
  call void @__sanitizer_cov_trace_cmp1(i8 %213, i8 %207), !dbg !31330
  %214 = icmp sge i8 %213, %207, !dbg !31330
  br i1 %214, label %217, label %._crit_edge14, !dbg !31330

._crit_edge14:                                    ; preds = %211
  %215 = load i8, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 27), align 1, !dbg !31330, !nosanitize !4110
  %216 = add i8 %215, 1, !dbg !31330
  store i8 %216, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 27), align 1, !dbg !31330, !nosanitize !4110
  br label %220, !dbg !31330

217:                                              ; preds = %211
  %218 = load i8, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 28), align 1, !dbg !31330, !nosanitize !4110
  %219 = add i8 %218, 1, !dbg !31330
  store i8 %219, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 28), align 1, !dbg !31330, !nosanitize !4110
  call void @__asan_report_store1(i64 %203) #42, !dbg !31330
  unreachable

220:                                              ; preds = %._crit_edge14, %bb2.i._crit_edge
  store i8 0, ptr %_6, align 1, !dbg !31330
  %221 = getelementptr inbounds nuw i8, ptr %result, i64 1, !dbg !31331
  %222 = ptrtoint ptr %221 to i64, !dbg !31331
  %223 = lshr i64 %222, 3, !dbg !31331
  %224 = add i64 %223, 2147450880, !dbg !31331
  %225 = inttoptr i64 %224 to ptr, !dbg !31331
  %226 = load i8, ptr %225, align 1, !dbg !31331
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %226), !dbg !31331
  %227 = icmp ne i8 %226, 0, !dbg !31331
  br i1 %227, label %230, label %._crit_edge15, !dbg !31331, !prof !4181

._crit_edge15:                                    ; preds = %220
  %228 = load i8, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 29), align 1, !dbg !31331, !nosanitize !4110
  %229 = add i8 %228, 1, !dbg !31331
  store i8 %229, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 29), align 1, !dbg !31331, !nosanitize !4110
  br label %239, !dbg !31331

230:                                              ; preds = %220
  %231 = and i64 %222, 7, !dbg !31331
  %232 = trunc i64 %231 to i8, !dbg !31331
  call void @__sanitizer_cov_trace_cmp1(i8 %232, i8 %226), !dbg !31331
  %233 = icmp sge i8 %232, %226, !dbg !31331
  br i1 %233, label %236, label %._crit_edge16, !dbg !31331

._crit_edge16:                                    ; preds = %230
  %234 = load i8, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 30), align 1, !dbg !31331, !nosanitize !4110
  %235 = add i8 %234, 1, !dbg !31331
  store i8 %235, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 30), align 1, !dbg !31331, !nosanitize !4110
  br label %239, !dbg !31331

236:                                              ; preds = %230
  %237 = load i8, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 31), align 1, !dbg !31331, !nosanitize !4110
  %238 = add i8 %237, 1, !dbg !31331
  store i8 %238, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 31), align 1, !dbg !31331, !nosanitize !4110
  call void @__asan_report_store1(i64 %222) #42, !dbg !31331
  unreachable

239:                                              ; preds = %._crit_edge16, %._crit_edge15
  store i8 0, ptr %221, align 1, !dbg !31331
  %240 = ptrtoint ptr %result to i64, !dbg !31331
  %241 = lshr i64 %240, 3, !dbg !31331
  %242 = add i64 %241, 2147450880, !dbg !31331
  %243 = inttoptr i64 %242 to ptr, !dbg !31331
  %244 = load i8, ptr %243, align 1, !dbg !31331
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %244), !dbg !31331
  %245 = icmp ne i8 %244, 0, !dbg !31331
  br i1 %245, label %248, label %._crit_edge17, !dbg !31331, !prof !4181

._crit_edge17:                                    ; preds = %239
  %246 = load i8, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 32), align 1, !dbg !31331, !nosanitize !4110
  %247 = add i8 %246, 1, !dbg !31331
  store i8 %247, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 32), align 1, !dbg !31331, !nosanitize !4110
  br label %257, !dbg !31331

248:                                              ; preds = %239
  %249 = and i64 %240, 7, !dbg !31331
  %250 = trunc i64 %249 to i8, !dbg !31331
  call void @__sanitizer_cov_trace_cmp1(i8 %250, i8 %244), !dbg !31331
  %251 = icmp sge i8 %250, %244, !dbg !31331
  br i1 %251, label %254, label %._crit_edge18, !dbg !31331

._crit_edge18:                                    ; preds = %248
  %252 = load i8, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 33), align 1, !dbg !31331, !nosanitize !4110
  %253 = add i8 %252, 1, !dbg !31331
  store i8 %253, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 33), align 1, !dbg !31331, !nosanitize !4110
  br label %257, !dbg !31331

254:                                              ; preds = %248
  %255 = load i8, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 34), align 1, !dbg !31331, !nosanitize !4110
  %256 = add i8 %255, 1, !dbg !31331
  store i8 %256, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 34), align 1, !dbg !31331, !nosanitize !4110
  call void @__asan_report_store1(i64 %240) #42, !dbg !31331
  unreachable

257:                                              ; preds = %._crit_edge18, %._crit_edge17
  store i8 1, ptr %result, align 1, !dbg !31331
  br label %bb14, !dbg !31314

bb11:                                             ; preds = %201
  %_11.0 = add nuw nsw i64 %_8, 1, !dbg !31332
  %258 = ptrtoint ptr %191 to i64, !dbg !31332
  %259 = lshr i64 %258, 3, !dbg !31332
  %260 = add i64 %259, 2147450880, !dbg !31332
  %261 = inttoptr i64 %260 to ptr, !dbg !31332
  %262 = load i8, ptr %261, align 1, !dbg !31332
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %262), !dbg !31332
  %263 = icmp ne i8 %262, 0, !dbg !31332
  br i1 %263, label %264, label %267, !dbg !31332

264:                                              ; preds = %bb11
  %265 = load i8, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 35), align 1, !dbg !31332, !nosanitize !4110
  %266 = add i8 %265, 1, !dbg !31332
  store i8 %266, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 35), align 1, !dbg !31332, !nosanitize !4110
  call void @__asan_report_store8(i64 %258) #42, !dbg !31332
  unreachable, !dbg !31332

267:                                              ; preds = %bb11
  store i64 %_11.0, ptr %191, align 8, !dbg !31332
  %_17 = getelementptr inbounds nuw i8, ptr %self, i64 36, !dbg !31334
  tail call void @llvm.experimental.noalias.scope.decl(metadata !31335), !dbg !31334
  %268 = add i64 %39, 204, !dbg !31338
  %269 = inttoptr i64 %268 to ptr, !dbg !31338
  store i32 0, ptr %269, align 1, !dbg !31338
  %270 = add i64 %39, 208, !dbg !31338
  %271 = inttoptr i64 %270 to ptr, !dbg !31338
  store i8 0, ptr %271, align 1, !dbg !31338
  call void @llvm.lifetime.start.p0(ptr nonnull %_3.sroa.11.i), !dbg !31343
  %272 = add i64 %39, 194, !dbg !31343
  %273 = inttoptr i64 %272 to ptr, !dbg !31343
  store i32 0, ptr %273, align 1, !dbg !31343
  %274 = add i64 %39, 198, !dbg !31343
  %275 = inttoptr i64 %274 to ptr, !dbg !31343
  store i16 256, ptr %275, align 1, !dbg !31343
  %276 = add i64 %39, 184, !dbg !31343
  %277 = inttoptr i64 %276 to ptr, !dbg !31343
  store i32 0, ptr %277, align 1, !dbg !31343
  %278 = add i64 %39, 188, !dbg !31343
  %279 = inttoptr i64 %278 to ptr, !dbg !31343
  store i8 0, ptr %279, align 1, !dbg !31343
  %280 = ptrtoint ptr %_17 to i64, !dbg !31344
  %281 = lshr i64 %280, 3, !dbg !31344
  %282 = add i64 %281, 2147450880, !dbg !31344
  %283 = inttoptr i64 %282 to ptr, !dbg !31344
  %284 = load i8, ptr %283, align 1, !dbg !31344
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %284), !dbg !31344
  %285 = icmp ne i8 %284, 0, !dbg !31344
  br i1 %285, label %288, label %._crit_edge19, !dbg !31344, !prof !4181

._crit_edge19:                                    ; preds = %267
  %286 = load i8, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 36), align 1, !dbg !31344, !nosanitize !4110
  %287 = add i8 %286, 1, !dbg !31344
  store i8 %287, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 36), align 1, !dbg !31344, !nosanitize !4110
  br label %297, !dbg !31344

288:                                              ; preds = %267
  %289 = and i64 %280, 7, !dbg !31344
  %290 = trunc i64 %289 to i8, !dbg !31344
  call void @__sanitizer_cov_trace_cmp1(i8 %290, i8 %284), !dbg !31344
  %291 = icmp sge i8 %290, %284, !dbg !31344
  br i1 %291, label %294, label %._crit_edge20, !dbg !31344

._crit_edge20:                                    ; preds = %288
  %292 = load i8, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 37), align 1, !dbg !31344, !nosanitize !4110
  %293 = add i8 %292, 1, !dbg !31344
  store i8 %293, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 37), align 1, !dbg !31344, !nosanitize !4110
  br label %297, !dbg !31344

294:                                              ; preds = %288
  %295 = load i8, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 38), align 1, !dbg !31344, !nosanitize !4110
  %296 = add i8 %295, 1, !dbg !31344
  store i8 %296, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 38), align 1, !dbg !31344, !nosanitize !4110
  call void @__asan_report_load1(i64 %280) #42, !dbg !31344
  unreachable

297:                                              ; preds = %._crit_edge20, %._crit_edge19
  %_6.i = load i8, ptr %_17, align 4, !dbg !31344, !noalias !31345, !noundef !4110
  %298 = call ptr @__asan_memcpy(ptr %32, ptr %self, i64 16), !dbg !31347
  %299 = getelementptr inbounds nuw i8, ptr %32, i64 32, !dbg !31343
  store i8 17, ptr %299, align 8, !dbg !31343, !noalias !31345
  %300 = getelementptr inbounds nuw i8, ptr %32, i64 33, !dbg !31343
  store i8 %_6.i, ptr %300, align 1, !dbg !31343, !noalias !31345
  %301 = getelementptr inbounds nuw i8, ptr %32, i64 16, !dbg !31343
  store i64 %_8, ptr %301, align 8, !dbg !31343, !noalias !31345
  %302 = getelementptr inbounds nuw i8, ptr %32, i64 24, !dbg !31343
  store i64 17, ptr %302, align 8, !dbg !31343, !noalias !31345
; call <spiral_protocol::wire::Header>::encode
  call void @_RNvMNtCs4oicsBtN6nJ_15spiral_protocol4wireNtB2_6Header6encode(ptr noalias nofree noundef sret([41 x i8]) align 1 captures(address) dereferenceable(41) %33, ptr noalias nofree noundef readonly align 8 captures(address) dereferenceable(40) %32) #35, !dbg !31348, !noalias !31345
  %303 = add i64 %39, 184, !dbg !31349
  %304 = inttoptr i64 %303 to ptr, !dbg !31349
  store i32 -117901064, ptr %304, align 1, !dbg !31349
  %305 = add i64 %39, 188, !dbg !31349
  %306 = inttoptr i64 %305 to ptr, !dbg !31349
  store i8 -8, ptr %306, align 1, !dbg !31349
  call void @llvm.experimental.noalias.scope.decl(metadata !31350), !dbg !31343
  %307 = load i8, ptr %33, align 1, !dbg !31353, !range !4348, !alias.scope !31356, !noalias !31358, !noundef !4110
  %308 = trunc nuw i8 %307 to i1, !dbg !31353
  %309 = getelementptr inbounds nuw i8, ptr %33, i64 1, !dbg !31359
  %e.0.i.i = load i8, ptr %309, align 1, !dbg !31359, !alias.scope !31360, !noalias !31345
  %310 = getelementptr inbounds nuw i8, ptr %33, i64 2, !dbg !31359
  %e.1.i.i = load i8, ptr %310, align 1, !dbg !31359, !alias.scope !31360, !noalias !31345
  br i1 %308, label %bb5.i.critedge, label %bb3.i.i, !dbg !31361

bb3.i.i:                                          ; preds = %297
  %_15 = getelementptr inbounds nuw i8, ptr %self, i64 32, !dbg !31334
  %_3.sroa.11.1..sroa_idx.i = getelementptr inbounds nuw i8, ptr %33, i64 3, !dbg !31362
  %311 = call ptr @__asan_memcpy(ptr %_3.sroa.11.i, ptr %_3.sroa.11.1..sroa_idx.i, i64 38), !dbg !31362
  %312 = add i64 %39, 194, !dbg !31363
  %313 = inttoptr i64 %312 to ptr, !dbg !31363
  store i32 -117901064, ptr %313, align 1, !dbg !31363
  %314 = add i64 %39, 198, !dbg !31363
  %315 = inttoptr i64 %314 to ptr, !dbg !31363
  store i16 -1800, ptr %315, align 1, !dbg !31363
  %val.sroa.5.0.head.sroa_idx.i = getelementptr inbounds nuw i8, ptr %34, i64 2, !dbg !31364
  %316 = call ptr @__asan_memcpy(ptr %val.sroa.5.0.head.sroa_idx.i, ptr %_3.sroa.11.i, i64 38), !dbg !31343
  store i8 %e.0.i.i, ptr %34, align 1, !dbg !31364, !noalias !31345
  %val.sroa.4.0.head.sroa_idx.i = getelementptr inbounds nuw i8, ptr %34, i64 1, !dbg !31364
  store i8 %e.1.i.i, ptr %val.sroa.4.0.head.sroa_idx.i, align 1, !dbg !31364, !noalias !31345
  call void @llvm.lifetime.end.p0(ptr nonnull %_3.sroa.11.i), !dbg !31366
  %317 = add i64 %39, 172, !dbg !31367
  %318 = inttoptr i64 %317 to ptr, !dbg !31367
  store i64 72057594037927936, ptr %318, align 1, !dbg !31367
  %319 = call ptr @__asan_memset(ptr %31, i32 0, i64 57), !dbg !31369
; call core::slice::copy_from_slice_impl::<u8>
  call void @_RINvNtCshZBO5P2NUJi_4core5slice20copy_from_slice_implhECs7jJvS58pafZ_4ring(ptr noalias nofree noundef nonnull %31, i64 noundef range(i64 0, -9223372036854775808) 40, ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) %34, i64 noundef 40, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_8a4e298d7bb62ef6d253dab8c98c3695) #35, !dbg !31370, !noalias !31345
  %320 = getelementptr inbounds nuw i8, ptr %31, i64 40, !dbg !31373
  store i8 %0, ptr %320, align 1, !dbg !31373, !noalias !31345
  %321 = add i64 %39, 168, !dbg !31374
  %322 = inttoptr i64 %321 to ptr, !dbg !31374
  store i16 1024, ptr %322, align 1, !dbg !31374
  %323 = ptrtoint ptr %_15 to i64, !dbg !31375
  %324 = lshr i64 %323, 3, !dbg !31375
  %325 = add i64 %324, 2147450880, !dbg !31375
  %326 = inttoptr i64 %325 to ptr, !dbg !31375
  %327 = load i8, ptr %326, align 1, !dbg !31375
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %327), !dbg !31375
  %328 = icmp ne i8 %327, 0, !dbg !31375
  br i1 %328, label %331, label %bb3.i.i._crit_edge, !dbg !31375, !prof !4181

bb3.i.i._crit_edge:                               ; preds = %bb3.i.i
  %329 = load i8, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 39), align 1, !dbg !31375, !nosanitize !4110
  %330 = add i8 %329, 1, !dbg !31375
  store i8 %330, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 39), align 1, !dbg !31375, !nosanitize !4110
  br label %341, !dbg !31375

331:                                              ; preds = %bb3.i.i
  %332 = and i64 %323, 7, !dbg !31375
  %333 = add i64 %332, 3, !dbg !31375
  %334 = trunc i64 %333 to i8, !dbg !31375
  call void @__sanitizer_cov_trace_cmp1(i8 %334, i8 %327), !dbg !31375
  %335 = icmp sge i8 %334, %327, !dbg !31375
  br i1 %335, label %338, label %._crit_edge21, !dbg !31375

._crit_edge21:                                    ; preds = %331
  %336 = load i8, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 40), align 1, !dbg !31375, !nosanitize !4110
  %337 = add i8 %336, 1, !dbg !31375
  store i8 %337, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 40), align 1, !dbg !31375, !nosanitize !4110
  br label %341, !dbg !31375

338:                                              ; preds = %331
  %339 = load i8, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 41), align 1, !dbg !31375, !nosanitize !4110
  %340 = add i8 %339, 1, !dbg !31375
  store i8 %340, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 41), align 1, !dbg !31375, !nosanitize !4110
  call void @__asan_report_load4(i64 %323) #42, !dbg !31375
  unreachable

341:                                              ; preds = %._crit_edge21, %bb3.i.i._crit_edge
  %_20.sroa.0.0.copyload.i = load i32, ptr %_15, align 8, !dbg !31375, !noalias !31345
  %342 = add i64 %39, 154
  %343 = inttoptr i64 %342 to ptr
  store i8 4, ptr %343, align 1
  store i32 %_20.sroa.0.0.copyload.i, ptr %27, align 4, !noalias !31376
  %344 = add i64 %39, 150, !dbg !31379
  %345 = inttoptr i64 %344 to ptr, !dbg !31379
  store i16 1024, ptr %345, align 1, !dbg !31379
  %346 = call ptr @__asan_memset(ptr %26, i32 0, i64 12), !dbg !31382
; call core::slice::copy_from_slice_impl::<u8>
  call void @_RINvNtCshZBO5P2NUJi_4core5slice20copy_from_slice_implhECs7jJvS58pafZ_4ring(ptr noalias nofree noundef nonnull %26, i64 noundef range(i64 0, -9223372036854775808) 4, ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) %27, i64 noundef 4, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_6f2dbdb6ae1f37cfa5b5aca94af9f1fb) #35, !dbg !31383, !noalias !31376
  %_11.i.i.i.i = getelementptr inbounds nuw i8, ptr %26, i64 4, !dbg !31386
  %347 = add i64 %39, 146, !dbg !31397
  %348 = inttoptr i64 %347 to ptr, !dbg !31397
  store i8 0, ptr %348, align 1, !dbg !31397
  %self1.i.i.i = call noundef i64 @llvm.bswap.i64(i64 %_8), !dbg !31398
  store i64 %self1.i.i.i, ptr %25, align 8, !dbg !31402, !noalias !31376
; call core::slice::copy_from_slice_impl::<u8>
  call void @_RINvNtCshZBO5P2NUJi_4core5slice20copy_from_slice_implhECs7jJvS58pafZ_4ring(ptr noalias nofree noundef nonnull %_11.i.i.i.i, i64 noundef range(i64 0, -9223372036854775808) 8, ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) %25, i64 noundef 8, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_91f5d2a8241d378b989535ff8e1d2b0c) #35, !dbg !31403, !noalias !31376
  %349 = add i64 %39, 146, !dbg !31405
  %350 = inttoptr i64 %349 to ptr, !dbg !31405
  store i8 -8, ptr %350, align 1, !dbg !31405
  %351 = call ptr @__asan_memcpy(ptr %30, ptr %26, i64 12), !dbg !31406
  %352 = add i64 %39, 150, !dbg !31407
  %353 = inttoptr i64 %352 to ptr, !dbg !31407
  store i16 -1800, ptr %353, align 1, !dbg !31407
  %354 = add i64 %39, 154, !dbg !31408
  %355 = inttoptr i64 %354 to ptr, !dbg !31408
  store i8 -8, ptr %355, align 1, !dbg !31408
  %356 = add i64 %39, 164, !dbg !31409
  %357 = inttoptr i64 %356 to ptr, !dbg !31409
  store i16 0, ptr %357, align 1, !dbg !31409
  call void @llvm.lifetime.start.p0(ptr nonnull %_24.sroa.11.i), !dbg !31411
  %358 = add i64 %39, 156, !dbg !31411
  %359 = inttoptr i64 %358 to ptr, !dbg !31411
  store i16 0, ptr %359, align 1, !dbg !31411
  %360 = add i64 %39, 158, !dbg !31411
  %361 = inttoptr i64 %360 to ptr, !dbg !31411
  store i8 1, ptr %361, align 1, !dbg !31411
  %362 = ptrtoint ptr %_6 to i64, !dbg !31412
  %363 = lshr i64 %362, 3, !dbg !31412
  %364 = add i64 %363, 2147450880, !dbg !31412
  %365 = inttoptr i64 %364 to ptr, !dbg !31412
  %366 = load i8, ptr %365, align 1, !dbg !31412
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %366), !dbg !31412
  %367 = icmp ne i8 %366, 0, !dbg !31412
  br i1 %367, label %370, label %._crit_edge22, !dbg !31412, !prof !4181

._crit_edge22:                                    ; preds = %341
  %368 = load i8, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 42), align 1, !dbg !31412, !nosanitize !4110
  %369 = add i8 %368, 1, !dbg !31412
  store i8 %369, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 42), align 1, !dbg !31412, !nosanitize !4110
  br label %379, !dbg !31412

370:                                              ; preds = %341
  %371 = and i64 %362, 7, !dbg !31412
  %372 = trunc i64 %371 to i8, !dbg !31412
  call void @__sanitizer_cov_trace_cmp1(i8 %372, i8 %366), !dbg !31412
  %373 = icmp sge i8 %372, %366, !dbg !31412
  br i1 %373, label %376, label %._crit_edge23, !dbg !31412

._crit_edge23:                                    ; preds = %370
  %374 = load i8, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 43), align 1, !dbg !31412, !nosanitize !4110
  %375 = add i8 %374, 1, !dbg !31412
  store i8 %375, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 43), align 1, !dbg !31412, !nosanitize !4110
  br label %379, !dbg !31412

376:                                              ; preds = %370
  %377 = load i8, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 44), align 1, !dbg !31412, !nosanitize !4110
  %378 = add i8 %377, 1, !dbg !31412
  store i8 %378, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 44), align 1, !dbg !31412, !nosanitize !4110
  call void @__asan_report_load1(i64 %362) #42, !dbg !31412
  unreachable

379:                                              ; preds = %._crit_edge23, %._crit_edge22
  %380 = load i8, ptr %_6, align 1, !dbg !31412, !range !4348, !alias.scope !31415, !noalias !31345, !noundef !4110
  %381 = trunc nuw i8 %380 to i1, !dbg !31412
  br i1 %381, label %bb13.i, label %bb14.i, !dbg !31411

bb5.i.critedge:                                   ; preds = %297
  %382 = add i64 %39, 194, !dbg !31363
  %383 = inttoptr i64 %382 to ptr, !dbg !31363
  store i32 -117901064, ptr %383, align 1, !dbg !31363
  %384 = add i64 %39, 198, !dbg !31363
  %385 = inttoptr i64 %384 to ptr, !dbg !31363
  store i16 -1800, ptr %385, align 1, !dbg !31363
  %386 = getelementptr inbounds nuw i8, ptr %result, i64 1, !dbg !31418
  %387 = ptrtoint ptr %386 to i64, !dbg !31418
  %388 = lshr i64 %387, 3, !dbg !31418
  %389 = add i64 %388, 2147450880, !dbg !31418
  %390 = inttoptr i64 %389 to ptr, !dbg !31418
  %391 = load i8, ptr %390, align 1, !dbg !31418
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %391), !dbg !31418
  %392 = icmp ne i8 %391, 0, !dbg !31418
  br i1 %392, label %395, label %bb5.i.critedge._crit_edge, !dbg !31418, !prof !4181

bb5.i.critedge._crit_edge:                        ; preds = %bb5.i.critedge
  %393 = load i8, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 45), align 1, !dbg !31418, !nosanitize !4110
  %394 = add i8 %393, 1, !dbg !31418
  store i8 %394, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 45), align 1, !dbg !31418, !nosanitize !4110
  br label %404, !dbg !31418

395:                                              ; preds = %bb5.i.critedge
  %396 = and i64 %387, 7, !dbg !31418
  %397 = trunc i64 %396 to i8, !dbg !31418
  call void @__sanitizer_cov_trace_cmp1(i8 %397, i8 %391), !dbg !31418
  %398 = icmp sge i8 %397, %391, !dbg !31418
  br i1 %398, label %401, label %._crit_edge24, !dbg !31418

._crit_edge24:                                    ; preds = %395
  %399 = load i8, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 46), align 1, !dbg !31418, !nosanitize !4110
  %400 = add i8 %399, 1, !dbg !31418
  store i8 %400, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 46), align 1, !dbg !31418, !nosanitize !4110
  br label %404, !dbg !31418

401:                                              ; preds = %395
  %402 = load i8, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 47), align 1, !dbg !31418, !nosanitize !4110
  %403 = add i8 %402, 1, !dbg !31418
  store i8 %403, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 47), align 1, !dbg !31418, !nosanitize !4110
  call void @__asan_report_store1(i64 %387) #42, !dbg !31418
  unreachable

404:                                              ; preds = %._crit_edge24, %bb5.i.critedge._crit_edge
  store i8 %e.0.i.i, ptr %386, align 1, !dbg !31418, !alias.scope !31423, !noalias !31426
  %405 = getelementptr inbounds nuw i8, ptr %result, i64 2, !dbg !31418
  %406 = ptrtoint ptr %405 to i64, !dbg !31418
  %407 = lshr i64 %406, 3, !dbg !31418
  %408 = add i64 %407, 2147450880, !dbg !31418
  %409 = inttoptr i64 %408 to ptr, !dbg !31418
  %410 = load i8, ptr %409, align 1, !dbg !31418
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %410), !dbg !31418
  %411 = icmp ne i8 %410, 0, !dbg !31418
  br i1 %411, label %414, label %._crit_edge25, !dbg !31418, !prof !4181

._crit_edge25:                                    ; preds = %404
  %412 = load i8, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 48), align 1, !dbg !31418, !nosanitize !4110
  %413 = add i8 %412, 1, !dbg !31418
  store i8 %413, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 48), align 1, !dbg !31418, !nosanitize !4110
  br label %423, !dbg !31418

414:                                              ; preds = %404
  %415 = and i64 %406, 7, !dbg !31418
  %416 = trunc i64 %415 to i8, !dbg !31418
  call void @__sanitizer_cov_trace_cmp1(i8 %416, i8 %410), !dbg !31418
  %417 = icmp sge i8 %416, %410, !dbg !31418
  br i1 %417, label %420, label %._crit_edge26, !dbg !31418

._crit_edge26:                                    ; preds = %414
  %418 = load i8, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 49), align 1, !dbg !31418, !nosanitize !4110
  %419 = add i8 %418, 1, !dbg !31418
  store i8 %419, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 49), align 1, !dbg !31418, !nosanitize !4110
  br label %423, !dbg !31418

420:                                              ; preds = %414
  %421 = load i8, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 50), align 1, !dbg !31418, !nosanitize !4110
  %422 = add i8 %421, 1, !dbg !31418
  store i8 %422, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 50), align 1, !dbg !31418, !nosanitize !4110
  call void @__asan_report_store1(i64 %406) #42, !dbg !31418
  unreachable

423:                                              ; preds = %._crit_edge26, %._crit_edge25
  store i8 %e.1.i.i, ptr %405, align 1, !dbg !31418, !alias.scope !31423, !noalias !31426
  %424 = ptrtoint ptr %result to i64, !dbg !31418
  %425 = lshr i64 %424, 3, !dbg !31418
  %426 = add i64 %425, 2147450880, !dbg !31418
  %427 = inttoptr i64 %426 to ptr, !dbg !31418
  %428 = load i8, ptr %427, align 1, !dbg !31418
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %428), !dbg !31418
  %429 = icmp ne i8 %428, 0, !dbg !31418
  br i1 %429, label %432, label %._crit_edge27, !dbg !31418, !prof !4181

._crit_edge27:                                    ; preds = %423
  %430 = load i8, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 51), align 1, !dbg !31418, !nosanitize !4110
  %431 = add i8 %430, 1, !dbg !31418
  store i8 %431, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 51), align 1, !dbg !31418, !nosanitize !4110
  br label %441, !dbg !31418

432:                                              ; preds = %423
  %433 = and i64 %424, 7, !dbg !31418
  %434 = trunc i64 %433 to i8, !dbg !31418
  call void @__sanitizer_cov_trace_cmp1(i8 %434, i8 %428), !dbg !31418
  %435 = icmp sge i8 %434, %428, !dbg !31418
  br i1 %435, label %438, label %._crit_edge28, !dbg !31418

._crit_edge28:                                    ; preds = %432
  %436 = load i8, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 52), align 1, !dbg !31418, !nosanitize !4110
  %437 = add i8 %436, 1, !dbg !31418
  store i8 %437, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 52), align 1, !dbg !31418, !nosanitize !4110
  br label %441, !dbg !31418

438:                                              ; preds = %432
  %439 = load i8, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 53), align 1, !dbg !31418, !nosanitize !4110
  %440 = add i8 %439, 1, !dbg !31418
  store i8 %440, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 53), align 1, !dbg !31418, !nosanitize !4110
  call void @__asan_report_store1(i64 %424) #42, !dbg !31418
  unreachable

441:                                              ; preds = %._crit_edge28, %._crit_edge27
  store i8 1, ptr %result, align 1, !dbg !31418, !alias.scope !31423, !noalias !31426
  call void @llvm.lifetime.end.p0(ptr nonnull %_3.sroa.11.i), !dbg !31366
  br label %_RNCNvMNtCs4oicsBtN6nJ_15spiral_protocol7recordsNtB4_2Tx5close0B6_.exit, !dbg !31427

bb14.i:                                           ; preds = %379
  %442 = getelementptr inbounds nuw i8, ptr %result, i64 1, !dbg !31429
  %443 = ptrtoint ptr %442 to i64, !dbg !31429
  %444 = lshr i64 %443, 3, !dbg !31429
  %445 = add i64 %444, 2147450880, !dbg !31429
  %446 = inttoptr i64 %445 to ptr, !dbg !31429
  %447 = load i8, ptr %446, align 1, !dbg !31429
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %447), !dbg !31429
  %448 = icmp ne i8 %447, 0, !dbg !31429
  br i1 %448, label %451, label %bb14.i._crit_edge, !dbg !31429, !prof !4181

bb14.i._crit_edge:                                ; preds = %bb14.i
  %449 = load i8, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 54), align 1, !dbg !31429, !nosanitize !4110
  %450 = add i8 %449, 1, !dbg !31429
  store i8 %450, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 54), align 1, !dbg !31429, !nosanitize !4110
  br label %460, !dbg !31429

451:                                              ; preds = %bb14.i
  %452 = and i64 %443, 7, !dbg !31429
  %453 = trunc i64 %452 to i8, !dbg !31429
  call void @__sanitizer_cov_trace_cmp1(i8 %453, i8 %447), !dbg !31429
  %454 = icmp sge i8 %453, %447, !dbg !31429
  br i1 %454, label %457, label %._crit_edge29, !dbg !31429

._crit_edge29:                                    ; preds = %451
  %455 = load i8, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 55), align 1, !dbg !31429, !nosanitize !4110
  %456 = add i8 %455, 1, !dbg !31429
  store i8 %456, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 55), align 1, !dbg !31429, !nosanitize !4110
  br label %460, !dbg !31429

457:                                              ; preds = %451
  %458 = load i8, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 56), align 1, !dbg !31429, !nosanitize !4110
  %459 = add i8 %458, 1, !dbg !31429
  store i8 %459, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 56), align 1, !dbg !31429, !nosanitize !4110
  call void @__asan_report_store1(i64 %443) #42, !dbg !31429
  unreachable

460:                                              ; preds = %._crit_edge29, %bb14.i._crit_edge
  store i8 6, ptr %442, align 1, !dbg !31429, !alias.scope !31432, !noalias !31426
  %461 = ptrtoint ptr %result to i64, !dbg !31429
  %462 = lshr i64 %461, 3, !dbg !31429
  %463 = add i64 %462, 2147450880, !dbg !31429
  %464 = inttoptr i64 %463 to ptr, !dbg !31429
  %465 = load i8, ptr %464, align 1, !dbg !31429
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %465), !dbg !31429
  %466 = icmp ne i8 %465, 0, !dbg !31429
  br i1 %466, label %469, label %._crit_edge30, !dbg !31429, !prof !4181

._crit_edge30:                                    ; preds = %460
  %467 = load i8, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 57), align 1, !dbg !31429, !nosanitize !4110
  %468 = add i8 %467, 1, !dbg !31429
  store i8 %468, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 57), align 1, !dbg !31429, !nosanitize !4110
  br label %478, !dbg !31429

469:                                              ; preds = %460
  %470 = and i64 %461, 7, !dbg !31429
  %471 = trunc i64 %470 to i8, !dbg !31429
  call void @__sanitizer_cov_trace_cmp1(i8 %471, i8 %465), !dbg !31429
  %472 = icmp sge i8 %471, %465, !dbg !31429
  br i1 %472, label %475, label %._crit_edge31, !dbg !31429

._crit_edge31:                                    ; preds = %469
  %473 = load i8, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 58), align 1, !dbg !31429, !nosanitize !4110
  %474 = add i8 %473, 1, !dbg !31429
  store i8 %474, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 58), align 1, !dbg !31429, !nosanitize !4110
  br label %478, !dbg !31429

475:                                              ; preds = %469
  %476 = load i8, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 59), align 1, !dbg !31429, !nosanitize !4110
  %477 = add i8 %476, 1, !dbg !31429
  store i8 %477, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 59), align 1, !dbg !31429, !nosanitize !4110
  call void @__asan_report_store1(i64 %461) #42, !dbg !31429
  unreachable

478:                                              ; preds = %._crit_edge31, %._crit_edge30
  store i8 1, ptr %result, align 1, !dbg !31429, !alias.scope !31432, !noalias !31426
  %479 = add i64 %39, 156, !dbg !31435
  %480 = inttoptr i64 %479 to ptr, !dbg !31435
  store i16 -1800, ptr %480, align 1, !dbg !31435
  %481 = add i64 %39, 158, !dbg !31435
  %482 = inttoptr i64 %481 to ptr, !dbg !31435
  store i8 -8, ptr %482, align 1, !dbg !31435
  call void @llvm.lifetime.end.p0(ptr nonnull %_24.sroa.11.i), !dbg !31436
  br label %bb27.i, !dbg !31437

bb13.i:                                           ; preds = %379
  %x.i.i = getelementptr inbounds nuw i8, ptr %self, i64 38, !dbg !31439
  %483 = add i64 %39, 4, !dbg !31440
  call void @__asan_set_shadow_00(i64 %483, i64 92), !dbg !31440
  %484 = add i64 %39, 120, !dbg !31444
  %485 = inttoptr i64 %484 to ptr, !dbg !31444
  store i64 0, ptr %485, align 1, !dbg !31444
  %486 = add i64 %39, 128, !dbg !31444
  %487 = inttoptr i64 %486 to ptr, !dbg !31444
  store i64 0, ptr %487, align 1, !dbg !31444
  %488 = add i64 %39, 136, !dbg !31444
  %489 = inttoptr i64 %488 to ptr, !dbg !31444
  store i8 4, ptr %489, align 1, !dbg !31444
; call <cipher::stream_wrapper::StreamCipherCoreWrapper<chacha20::ChaChaCore<typenum::uint::UInt<typenum::uint::UInt<typenum::uint::UInt<typenum::uint::UInt<typenum::uint::UTerm, typenum::bit::B1>, typenum::bit::B0>, typenum::bit::B1>, typenum::bit::B0>>> as crypto_common::KeyIvInit>::new
  call fastcc void @_RNvXs3_NtCs3uTrKuTqj2Q_6cipher14stream_wrapperINtB5_23StreamCipherCoreWrapperINtCslD4gSC9HkLH_8chacha2010ChaChaCoreINtNtCs9T39WwoIZ0p_7typenum4uint4UIntIB1Q_IB1Q_IB1Q_NtB1S_5UTermNtNtB1U_3bit2B1ENtB2T_2B0EB2R_EB37_EEENtCs9ByizG5C30O_13crypto_common9KeyIvInit3newCs4oicsBtN6nJ_15spiral_protocol(ptr noalias nofree noundef sret([132 x i8]) align 4 captures(none) dereferenceable(132) %24, ptr noalias nofree noundef readonly captures(address, read_provenance) dereferenceable(32) %x.i.i, ptr noalias nofree noundef readonly captures(address, read_provenance) dereferenceable(12) %30) #35, !dbg !31444, !noalias !31445
  call void @llvm.experimental.noalias.scope.decl(metadata !31450), !dbg !31440
  call void @llvm.experimental.noalias.scope.decl(metadata !31453), !dbg !31440
  %490 = add i64 %39, 112, !dbg !31455
  %491 = inttoptr i64 %490 to ptr, !dbg !31455
  store i32 0, ptr %491, align 1, !dbg !31455
  %492 = call ptr @__asan_memset(ptr %23, i32 0, i64 32), !dbg !31461
; call <cipher::stream_wrapper::StreamCipherCoreWrapper<chacha20::ChaChaCore<typenum::uint::UInt<typenum::uint::UInt<typenum::uint::UInt<typenum::uint::UInt<typenum::uint::UTerm, typenum::bit::B1>, typenum::bit::B0>, typenum::bit::B1>, typenum::bit::B0>>> as cipher::stream::StreamCipher>::apply_keystream
  call fastcc void @_RNvYINtNtCs3uTrKuTqj2Q_6cipher14stream_wrapper23StreamCipherCoreWrapperINtCslD4gSC9HkLH_8chacha2010ChaChaCoreINtNtCs9T39WwoIZ0p_7typenum4uint4UIntIB1K_IB1K_IB1K_NtB1M_5UTermNtNtB1O_3bit2B1ENtB2N_2B0EB2L_EB31_EEENtNtB7_6stream12StreamCipher15apply_keystreamCs4oicsBtN6nJ_15spiral_protocol(ptr noalias nofree noundef align 4 dereferenceable(132) %24, ptr noalias nofree noundef nonnull %23, i64 noundef 32) #35, !dbg !31468, !noalias !31470
; call <poly1305::Poly1305 as crypto_common::KeyInit>::new
  call void @_RNvXs_Cs47sDuqytMRH_8poly1305NtB4_8Poly1305NtCs9ByizG5C30O_13crypto_common7KeyInit3new(ptr noalias nofree noundef sret([576 x i8]) align 32 captures(none) dereferenceable(736) %22, ptr noalias nofree noundef readonly captures(address, read_provenance) dereferenceable(32) %23) #35, !dbg !31471, !noalias !31445
; call <[u8] as zeroize::Zeroize>::zeroize
  call void @_RNvXs9_Cs5e7aMHj0NTS_7zeroizeShNtB5_7Zeroize7zeroizeB5_(ptr noalias nofree noundef nonnull %23, i64 noundef 32) #35, !dbg !31472, !noalias !31470
  %493 = getelementptr inbounds nuw i8, ptr %24, i64 48, !dbg !31474
  store i32 1, ptr %493, align 4, !dbg !31474, !alias.scope !31478, !noalias !31485
  %494 = getelementptr inbounds nuw i8, ptr %24, i64 128, !dbg !31488
  store i8 0, ptr %494, align 4, !dbg !31488, !alias.scope !31489, !noalias !31485
  %495 = getelementptr inbounds nuw i8, ptr %22, i64 576, !dbg !31490
  %496 = call ptr @__asan_memcpy(ptr %495, ptr %24, i64 132), !dbg !31491
  %497 = add i64 %39, 112, !dbg !31492
  %498 = inttoptr i64 %497 to ptr, !dbg !31492
  store i32 -117901064, ptr %498, align 1, !dbg !31492
  %499 = add i64 %39, 120, !dbg !31493
  %500 = inttoptr i64 %499 to ptr, !dbg !31493
  store i64 -506381209866536712, ptr %500, align 1, !dbg !31493
  %501 = add i64 %39, 128, !dbg !31493
  %502 = inttoptr i64 %501 to ptr, !dbg !31493
  store i64 -506381209866536712, ptr %502, align 1, !dbg !31493
  %503 = add i64 %39, 136, !dbg !31493
  %504 = inttoptr i64 %503 to ptr, !dbg !31493
  store i8 -8, ptr %504, align 1, !dbg !31493
; call <chacha20poly1305::cipher::Cipher<cipher::stream_wrapper::StreamCipherCoreWrapper<chacha20::ChaChaCore<typenum::uint::UInt<typenum::uint::UInt<typenum::uint::UInt<typenum::uint::UInt<typenum::uint::UTerm, typenum::bit::B1>, typenum::bit::B0>, typenum::bit::B1>, typenum::bit::B0>>>>>::encrypt_in_place_detached
  call void @_RNvMNtCskG2NEjLuYj5_16chacha20poly13056cipherINtB2_6CipherINtNtCs3uTrKuTqj2Q_6cipher14stream_wrapper23StreamCipherCoreWrapperINtCslD4gSC9HkLH_8chacha2010ChaChaCoreINtNtCs9T39WwoIZ0p_7typenum4uint4UIntIB2C_IB2C_IB2C_NtB2E_5UTermNtNtB2G_3bit2B1ENtB3F_2B0EB3D_EB3T_EEEE25encrypt_in_place_detachedCs4oicsBtN6nJ_15spiral_protocol(ptr noalias nofree noundef sret([17 x i8]) align 1 captures(address) dereferenceable(17) %28, ptr noalias nofree noundef align 32 captures(address) dereferenceable(736) %22, ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) %34, i64 noundef 40, ptr noalias nofree noundef nonnull %320, i64 noundef range(i64 0, -9223372036854775808) 1) #35, !dbg !31494, !noalias !31345
  %505 = add i64 %39, 4, !dbg !31495
  call void @__asan_set_shadow_f8(i64 %505, i64 92), !dbg !31495
  call void @llvm.experimental.noalias.scope.decl(metadata !31496), !dbg !31499
  %506 = load i8, ptr %28, align 1, !dbg !31500, !range !4348, !alias.scope !31503, !noalias !31505, !noundef !4110
  %507 = trunc nuw i8 %506 to i1, !dbg !31500
  br i1 %507, label %bb13.i._RINvMNtCshZBO5P2NUJi_4core6resultINtB3_6ResultINtCs18jWmPaaUdo_13generic_array12GenericArrayhINtNtCs9T39WwoIZ0p_7typenum4uint4UIntIB1u_IB1u_IB1u_IB1u_NtB1w_5UTermNtNtB1y_3bit2B1ENtB2C_2B0EB2Q_EB2Q_EB2Q_EENtCsjG0YvJ6QUY8_4aead5ErrorE7map_errNtNtCs4oicsBtN6nJ_15spiral_protocol5error5ErrorNCNCNvMNtB3U_7recordsNtB4I_2Tx5close00EB3U_.exit.i_crit_edge, label %bb3.i16.i, !dbg !31506

bb13.i._RINvMNtCshZBO5P2NUJi_4core6resultINtB3_6ResultINtCs18jWmPaaUdo_13generic_array12GenericArrayhINtNtCs9T39WwoIZ0p_7typenum4uint4UIntIB1u_IB1u_IB1u_IB1u_NtB1w_5UTermNtNtB1y_3bit2B1ENtB2C_2B0EB2Q_EB2Q_EB2Q_EENtCsjG0YvJ6QUY8_4aead5ErrorE7map_errNtNtCs4oicsBtN6nJ_15spiral_protocol5error5ErrorNCNCNvMNtB3U_7recordsNtB4I_2Tx5close00EB3U_.exit.i_crit_edge: ; preds = %bb13.i
  %508 = load i8, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 60), align 1, !dbg !31506, !nosanitize !4110
  %509 = add i8 %508, 1, !dbg !31506
  store i8 %509, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 60), align 1, !dbg !31506, !nosanitize !4110
  br label %_RINvMNtCshZBO5P2NUJi_4core6resultINtB3_6ResultINtCs18jWmPaaUdo_13generic_array12GenericArrayhINtNtCs9T39WwoIZ0p_7typenum4uint4UIntIB1u_IB1u_IB1u_IB1u_NtB1w_5UTermNtNtB1y_3bit2B1ENtB2C_2B0EB2Q_EB2Q_EB2Q_EENtCsjG0YvJ6QUY8_4aead5ErrorE7map_errNtNtCs4oicsBtN6nJ_15spiral_protocol5error5ErrorNCNCNvMNtB3U_7recordsNtB4I_2Tx5close00EB3U_.exit.i, !dbg !31506

bb3.i16.i:                                        ; preds = %bb13.i
  %510 = load i8, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 61), align 1, !dbg !31507, !nosanitize !4110
  %511 = add i8 %510, 1, !dbg !31507
  store i8 %511, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 61), align 1, !dbg !31507, !nosanitize !4110
  %512 = getelementptr inbounds nuw i8, ptr %28, i64 1, !dbg !31507
  %_24.sroa.5.1.copyload.i = load i8, ptr %512, align 1, !dbg !31507, !alias.scope !31508, !noalias !31345
  %_24.sroa.9.1..sroa_idx.i = getelementptr inbounds nuw i8, ptr %28, i64 2, !dbg !31507
  %_24.sroa.9.1.copyload.i = load i8, ptr %_24.sroa.9.1..sroa_idx.i, align 1, !dbg !31507, !alias.scope !31508, !noalias !31345
  %_24.sroa.11.1..sroa_idx.i = getelementptr inbounds nuw i8, ptr %28, i64 3, !dbg !31507
  %513 = call ptr @__asan_memcpy(ptr %_24.sroa.11.i, ptr %_24.sroa.11.1..sroa_idx.i, i64 14), !dbg !31507
  br label %_RINvMNtCshZBO5P2NUJi_4core6resultINtB3_6ResultINtCs18jWmPaaUdo_13generic_array12GenericArrayhINtNtCs9T39WwoIZ0p_7typenum4uint4UIntIB1u_IB1u_IB1u_IB1u_NtB1w_5UTermNtNtB1y_3bit2B1ENtB2C_2B0EB2Q_EB2Q_EB2Q_EENtCsjG0YvJ6QUY8_4aead5ErrorE7map_errNtNtCs4oicsBtN6nJ_15spiral_protocol5error5ErrorNCNCNvMNtB3U_7recordsNtB4I_2Tx5close00EB3U_.exit.i, !dbg !31509

_RINvMNtCshZBO5P2NUJi_4core6resultINtB3_6ResultINtCs18jWmPaaUdo_13generic_array12GenericArrayhINtNtCs9T39WwoIZ0p_7typenum4uint4UIntIB1u_IB1u_IB1u_IB1u_NtB1w_5UTermNtNtB1y_3bit2B1ENtB2C_2B0EB2Q_EB2Q_EB2Q_EENtCsjG0YvJ6QUY8_4aead5ErrorE7map_errNtNtCs4oicsBtN6nJ_15spiral_protocol5error5ErrorNCNCNvMNtB3U_7recordsNtB4I_2Tx5close00EB3U_.exit.i: ; preds = %bb13.i._RINvMNtCshZBO5P2NUJi_4core6resultINtB3_6ResultINtCs18jWmPaaUdo_13generic_array12GenericArrayhINtNtCs9T39WwoIZ0p_7typenum4uint4UIntIB1u_IB1u_IB1u_IB1u_NtB1w_5UTermNtNtB1y_3bit2B1ENtB2C_2B0EB2Q_EB2Q_EB2Q_EENtCsjG0YvJ6QUY8_4aead5ErrorE7map_errNtNtCs4oicsBtN6nJ_15spiral_protocol5error5ErrorNCNCNvMNtB3U_7recordsNtB4I_2Tx5close00EB3U_.exit.i_crit_edge, %bb3.i16.i
  %_24.sroa.5.0.i = phi i8 [ %_24.sroa.5.1.copyload.i, %bb3.i16.i ], [ 2, %bb13.i._RINvMNtCshZBO5P2NUJi_4core6resultINtB3_6ResultINtCs18jWmPaaUdo_13generic_array12GenericArrayhINtNtCs9T39WwoIZ0p_7typenum4uint4UIntIB1u_IB1u_IB1u_IB1u_NtB1w_5UTermNtNtB1y_3bit2B1ENtB2C_2B0EB2Q_EB2Q_EB2Q_EENtCsjG0YvJ6QUY8_4aead5ErrorE7map_errNtNtCs4oicsBtN6nJ_15spiral_protocol5error5ErrorNCNCNvMNtB3U_7recordsNtB4I_2Tx5close00EB3U_.exit.i_crit_edge ], !dbg !31510
  %_24.sroa.9.0.i = phi i8 [ %_24.sroa.9.1.copyload.i, %bb3.i16.i ], [ undef, %bb13.i._RINvMNtCshZBO5P2NUJi_4core6resultINtB3_6ResultINtCs18jWmPaaUdo_13generic_array12GenericArrayhINtNtCs9T39WwoIZ0p_7typenum4uint4UIntIB1u_IB1u_IB1u_IB1u_NtB1w_5UTermNtNtB1y_3bit2B1ENtB2C_2B0EB2Q_EB2Q_EB2Q_EENtCsjG0YvJ6QUY8_4aead5ErrorE7map_errNtNtCs4oicsBtN6nJ_15spiral_protocol5error5ErrorNCNCNvMNtB3U_7recordsNtB4I_2Tx5close00EB3U_.exit.i_crit_edge ]
  %514 = add i64 %39, 156, !dbg !31435
  %515 = inttoptr i64 %514 to ptr, !dbg !31435
  store i16 -1800, ptr %515, align 1, !dbg !31435
  %516 = add i64 %39, 158, !dbg !31435
  %517 = inttoptr i64 %516 to ptr, !dbg !31435
  store i8 -8, ptr %517, align 1, !dbg !31435
  br i1 %507, label %bb22.critedge.i, label %bb3.i19.i, !dbg !31511

bb3.i19.i:                                        ; preds = %_RINvMNtCshZBO5P2NUJi_4core6resultINtB3_6ResultINtCs18jWmPaaUdo_13generic_array12GenericArrayhINtNtCs9T39WwoIZ0p_7typenum4uint4UIntIB1u_IB1u_IB1u_IB1u_NtB1w_5UTermNtNtB1y_3bit2B1ENtB2C_2B0EB2Q_EB2Q_EB2Q_EENtCsjG0YvJ6QUY8_4aead5ErrorE7map_errNtNtCs4oicsBtN6nJ_15spiral_protocol5error5ErrorNCNCNvMNtB3U_7recordsNtB4I_2Tx5close00EB3U_.exit.i
  %val1.sroa.5.0.tag.sroa_idx.i = getelementptr inbounds nuw i8, ptr %29, i64 2, !dbg !31514
  %518 = call ptr @__asan_memcpy(ptr %val1.sroa.5.0.tag.sroa_idx.i, ptr %_24.sroa.11.i, i64 14), !dbg !31516
  call void @llvm.lifetime.end.p0(ptr nonnull %_24.sroa.11.i), !dbg !31436
  store i8 %_24.sroa.5.0.i, ptr %29, align 1, !dbg !31514, !noalias !31345
  %val1.sroa.4.0.tag.sroa_idx.i = getelementptr inbounds nuw i8, ptr %29, i64 1, !dbg !31514
  store i8 %_24.sroa.9.0.i, ptr %val1.sroa.4.0.tag.sroa_idx.i, align 1, !dbg !31514, !noalias !31345
  %_11.i.i.i = getelementptr inbounds nuw i8, ptr %31, i64 41, !dbg !31517
; call core::slice::copy_from_slice_impl::<u8>
  call void @_RINvNtCshZBO5P2NUJi_4core5slice20copy_from_slice_implhECs7jJvS58pafZ_4ring(ptr noalias nofree noundef nonnull %_11.i.i.i, i64 noundef range(i64 0, -9223372036854775808) 16, ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) %29, i64 noundef range(i64 0, -9223372036854775808) 16, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_317e64ba812d023bfe8178c9d18ae276) #35, !dbg !31524, !noalias !31345
  %519 = getelementptr inbounds nuw i8, ptr %result, i64 1, !dbg !31526
  %520 = call ptr @__asan_memcpy(ptr %519, ptr %31, i64 57), !dbg !31527
  %521 = ptrtoint ptr %result to i64, !dbg !31526
  %522 = lshr i64 %521, 3, !dbg !31526
  %523 = add i64 %522, 2147450880, !dbg !31526
  %524 = inttoptr i64 %523 to ptr, !dbg !31526
  %525 = load i8, ptr %524, align 1, !dbg !31526
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %525), !dbg !31526
  %526 = icmp ne i8 %525, 0, !dbg !31526
  br i1 %526, label %529, label %bb3.i19.i._crit_edge, !dbg !31526, !prof !4181

bb3.i19.i._crit_edge:                             ; preds = %bb3.i19.i
  %527 = load i8, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 62), align 1, !dbg !31526, !nosanitize !4110
  %528 = add i8 %527, 1, !dbg !31526
  store i8 %528, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 62), align 1, !dbg !31526, !nosanitize !4110
  br label %538, !dbg !31526

529:                                              ; preds = %bb3.i19.i
  %530 = and i64 %521, 7, !dbg !31526
  %531 = trunc i64 %530 to i8, !dbg !31526
  call void @__sanitizer_cov_trace_cmp1(i8 %531, i8 %525), !dbg !31526
  %532 = icmp sge i8 %531, %525, !dbg !31526
  br i1 %532, label %535, label %._crit_edge32, !dbg !31526

._crit_edge32:                                    ; preds = %529
  %533 = load i8, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 63), align 1, !dbg !31526, !nosanitize !4110
  %534 = add i8 %533, 1, !dbg !31526
  store i8 %534, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 63), align 1, !dbg !31526, !nosanitize !4110
  br label %538, !dbg !31526

535:                                              ; preds = %529
  %536 = load i8, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 64), align 1, !dbg !31526, !nosanitize !4110
  %537 = add i8 %536, 1, !dbg !31526
  store i8 %537, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 64), align 1, !dbg !31526, !nosanitize !4110
  call void @__asan_report_store1(i64 %521) #42, !dbg !31526
  unreachable

538:                                              ; preds = %._crit_edge32, %bb3.i19.i._crit_edge
  store i8 0, ptr %result, align 1, !dbg !31526, !alias.scope !31335, !noalias !31426
  %539 = add i64 %39, 164, !dbg !31528
  %540 = inttoptr i64 %539 to ptr, !dbg !31528
  store i16 -1800, ptr %540, align 1, !dbg !31528
  %541 = add i64 %39, 168, !dbg !31529
  %542 = inttoptr i64 %541 to ptr, !dbg !31529
  store i16 -1800, ptr %542, align 1, !dbg !31529
  %543 = add i64 %39, 172, !dbg !31530
  %544 = inttoptr i64 %543 to ptr, !dbg !31530
  store i64 -506381209866536712, ptr %544, align 1, !dbg !31530
  br label %_RNCNvMNtCs4oicsBtN6nJ_15spiral_protocol7recordsNtB4_2Tx5close0B6_.exit, !dbg !31531

bb22.critedge.i:                                  ; preds = %_RINvMNtCshZBO5P2NUJi_4core6resultINtB3_6ResultINtCs18jWmPaaUdo_13generic_array12GenericArrayhINtNtCs9T39WwoIZ0p_7typenum4uint4UIntIB1u_IB1u_IB1u_IB1u_NtB1w_5UTermNtNtB1y_3bit2B1ENtB2C_2B0EB2Q_EB2Q_EB2Q_EENtCsjG0YvJ6QUY8_4aead5ErrorE7map_errNtNtCs4oicsBtN6nJ_15spiral_protocol5error5ErrorNCNCNvMNtB3U_7recordsNtB4I_2Tx5close00EB3U_.exit.i
  call void @llvm.lifetime.end.p0(ptr nonnull %_24.sroa.11.i), !dbg !31436
  %545 = getelementptr inbounds nuw i8, ptr %result, i64 1, !dbg !31532
  %546 = ptrtoint ptr %545 to i64, !dbg !31532
  %547 = lshr i64 %546, 3, !dbg !31532
  %548 = add i64 %547, 2147450880, !dbg !31532
  %549 = inttoptr i64 %548 to ptr, !dbg !31532
  %550 = load i8, ptr %549, align 1, !dbg !31532
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %550), !dbg !31532
  %551 = icmp ne i8 %550, 0, !dbg !31532
  br i1 %551, label %554, label %bb22.critedge.i._crit_edge, !dbg !31532, !prof !4181

bb22.critedge.i._crit_edge:                       ; preds = %bb22.critedge.i
  %552 = load i8, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 65), align 1, !dbg !31532, !nosanitize !4110
  %553 = add i8 %552, 1, !dbg !31532
  store i8 %553, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 65), align 1, !dbg !31532, !nosanitize !4110
  br label %563, !dbg !31532

554:                                              ; preds = %bb22.critedge.i
  %555 = and i64 %546, 7, !dbg !31532
  %556 = trunc i64 %555 to i8, !dbg !31532
  call void @__sanitizer_cov_trace_cmp1(i8 %556, i8 %550), !dbg !31532
  %557 = icmp sge i8 %556, %550, !dbg !31532
  br i1 %557, label %560, label %._crit_edge33, !dbg !31532

._crit_edge33:                                    ; preds = %554
  %558 = load i8, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 66), align 1, !dbg !31532, !nosanitize !4110
  %559 = add i8 %558, 1, !dbg !31532
  store i8 %559, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 66), align 1, !dbg !31532, !nosanitize !4110
  br label %563, !dbg !31532

560:                                              ; preds = %554
  %561 = load i8, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 67), align 1, !dbg !31532, !nosanitize !4110
  %562 = add i8 %561, 1, !dbg !31532
  store i8 %562, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 67), align 1, !dbg !31532, !nosanitize !4110
  call void @__asan_report_store1(i64 %546) #42, !dbg !31532
  unreachable

563:                                              ; preds = %._crit_edge33, %bb22.critedge.i._crit_edge
  store i8 %_24.sroa.5.0.i, ptr %545, align 1, !dbg !31532, !alias.scope !31535, !noalias !31426
  %564 = getelementptr inbounds nuw i8, ptr %result, i64 2, !dbg !31532
  %565 = ptrtoint ptr %564 to i64, !dbg !31532
  %566 = lshr i64 %565, 3, !dbg !31532
  %567 = add i64 %566, 2147450880, !dbg !31532
  %568 = inttoptr i64 %567 to ptr, !dbg !31532
  %569 = load i8, ptr %568, align 1, !dbg !31532
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %569), !dbg !31532
  %570 = icmp ne i8 %569, 0, !dbg !31532
  br i1 %570, label %573, label %._crit_edge34, !dbg !31532, !prof !4181

._crit_edge34:                                    ; preds = %563
  %571 = load i8, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 68), align 1, !dbg !31532, !nosanitize !4110
  %572 = add i8 %571, 1, !dbg !31532
  store i8 %572, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 68), align 1, !dbg !31532, !nosanitize !4110
  br label %582, !dbg !31532

573:                                              ; preds = %563
  %574 = and i64 %565, 7, !dbg !31532
  %575 = trunc i64 %574 to i8, !dbg !31532
  call void @__sanitizer_cov_trace_cmp1(i8 %575, i8 %569), !dbg !31532
  %576 = icmp sge i8 %575, %569, !dbg !31532
  br i1 %576, label %579, label %._crit_edge35, !dbg !31532

._crit_edge35:                                    ; preds = %573
  %577 = load i8, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 69), align 1, !dbg !31532, !nosanitize !4110
  %578 = add i8 %577, 1, !dbg !31532
  store i8 %578, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 69), align 1, !dbg !31532, !nosanitize !4110
  br label %582, !dbg !31532

579:                                              ; preds = %573
  %580 = load i8, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 70), align 1, !dbg !31532, !nosanitize !4110
  %581 = add i8 %580, 1, !dbg !31532
  store i8 %581, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 70), align 1, !dbg !31532, !nosanitize !4110
  call void @__asan_report_store1(i64 %565) #42, !dbg !31532
  unreachable

582:                                              ; preds = %._crit_edge35, %._crit_edge34
  store i8 %_24.sroa.9.0.i, ptr %564, align 1, !dbg !31532, !alias.scope !31535, !noalias !31426
  %583 = ptrtoint ptr %result to i64, !dbg !31532
  %584 = lshr i64 %583, 3, !dbg !31532
  %585 = add i64 %584, 2147450880, !dbg !31532
  %586 = inttoptr i64 %585 to ptr, !dbg !31532
  %587 = load i8, ptr %586, align 1, !dbg !31532
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %587), !dbg !31532
  %588 = icmp ne i8 %587, 0, !dbg !31532
  br i1 %588, label %591, label %._crit_edge36, !dbg !31532, !prof !4181

._crit_edge36:                                    ; preds = %582
  %589 = load i8, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 71), align 1, !dbg !31532, !nosanitize !4110
  %590 = add i8 %589, 1, !dbg !31532
  store i8 %590, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 71), align 1, !dbg !31532, !nosanitize !4110
  br label %600, !dbg !31532

591:                                              ; preds = %582
  %592 = and i64 %583, 7, !dbg !31532
  %593 = trunc i64 %592 to i8, !dbg !31532
  call void @__sanitizer_cov_trace_cmp1(i8 %593, i8 %587), !dbg !31532
  %594 = icmp sge i8 %593, %587, !dbg !31532
  br i1 %594, label %597, label %._crit_edge37, !dbg !31532

._crit_edge37:                                    ; preds = %591
  %595 = load i8, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 72), align 1, !dbg !31532, !nosanitize !4110
  %596 = add i8 %595, 1, !dbg !31532
  store i8 %596, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 72), align 1, !dbg !31532, !nosanitize !4110
  br label %600, !dbg !31532

597:                                              ; preds = %591
  %598 = load i8, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 73), align 1, !dbg !31532, !nosanitize !4110
  %599 = add i8 %598, 1, !dbg !31532
  store i8 %599, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 73), align 1, !dbg !31532, !nosanitize !4110
  call void @__asan_report_store1(i64 %583) #42, !dbg !31532
  unreachable

600:                                              ; preds = %._crit_edge37, %._crit_edge36
  store i8 1, ptr %result, align 1, !dbg !31532, !alias.scope !31535, !noalias !31426
  br label %bb27.i, !dbg !31437

bb27.i:                                           ; preds = %600, %478
  %601 = add i64 %39, 164, !dbg !31528
  %602 = inttoptr i64 %601 to ptr, !dbg !31528
  store i16 -1800, ptr %602, align 1, !dbg !31528
  %603 = add i64 %39, 168, !dbg !31529
  %604 = inttoptr i64 %603 to ptr, !dbg !31529
  store i16 -1800, ptr %604, align 1, !dbg !31529
  %605 = add i64 %39, 172, !dbg !31530
  %606 = inttoptr i64 %605 to ptr, !dbg !31530
  store i64 -506381209866536712, ptr %606, align 1, !dbg !31530
  br label %_RNCNvMNtCs4oicsBtN6nJ_15spiral_protocol7recordsNtB4_2Tx5close0B6_.exit, !dbg !31538

_RNCNvMNtCs4oicsBtN6nJ_15spiral_protocol7recordsNtB4_2Tx5close0B6_.exit: ; preds = %441, %bb27.i, %538
  %607 = add i64 %39, 204, !dbg !31540
  %608 = inttoptr i64 %607 to ptr, !dbg !31540
  store i32 -117901064, ptr %608, align 1, !dbg !31540
  %609 = add i64 %39, 208, !dbg !31540
  %610 = inttoptr i64 %609 to ptr, !dbg !31540
  store i8 -8, ptr %610, align 1, !dbg !31540
  %611 = ptrtoint ptr %73 to i64, !dbg !31541
  %612 = lshr i64 %611, 3, !dbg !31541
  %613 = add i64 %612, 2147450880, !dbg !31541
  %614 = inttoptr i64 %613 to ptr, !dbg !31541
  %615 = load i8, ptr %614, align 1, !dbg !31541
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %615), !dbg !31541
  %616 = icmp ne i8 %615, 0, !dbg !31541
  br i1 %616, label %619, label %_RNCNvMNtCs4oicsBtN6nJ_15spiral_protocol7recordsNtB4_2Tx5close0B6_.exit._crit_edge, !dbg !31541, !prof !4181

_RNCNvMNtCs4oicsBtN6nJ_15spiral_protocol7recordsNtB4_2Tx5close0B6_.exit._crit_edge: ; preds = %_RNCNvMNtCs4oicsBtN6nJ_15spiral_protocol7recordsNtB4_2Tx5close0B6_.exit
  %617 = load i8, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 74), align 1, !dbg !31541, !nosanitize !4110
  %618 = add i8 %617, 1, !dbg !31541
  store i8 %618, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 74), align 1, !dbg !31541, !nosanitize !4110
  br label %628, !dbg !31541

619:                                              ; preds = %_RNCNvMNtCs4oicsBtN6nJ_15spiral_protocol7recordsNtB4_2Tx5close0B6_.exit
  %620 = and i64 %611, 7, !dbg !31541
  %621 = trunc i64 %620 to i8, !dbg !31541
  call void @__sanitizer_cov_trace_cmp1(i8 %621, i8 %615), !dbg !31541
  %622 = icmp sge i8 %621, %615, !dbg !31541
  br i1 %622, label %625, label %._crit_edge38, !dbg !31541

._crit_edge38:                                    ; preds = %619
  %623 = load i8, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 75), align 1, !dbg !31541, !nosanitize !4110
  %624 = add i8 %623, 1, !dbg !31541
  store i8 %624, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 75), align 1, !dbg !31541, !nosanitize !4110
  br label %628, !dbg !31541

625:                                              ; preds = %619
  %626 = load i8, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 76), align 1, !dbg !31541, !nosanitize !4110
  %627 = add i8 %626, 1, !dbg !31541
  store i8 %627, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 76), align 1, !dbg !31541, !nosanitize !4110
  call void @__asan_report_store1(i64 %611) #42, !dbg !31541
  unreachable

628:                                              ; preds = %._crit_edge38, %_RNCNvMNtCs4oicsBtN6nJ_15spiral_protocol7recordsNtB4_2Tx5close0B6_.exit._crit_edge
  store i8 1, ptr %73, align 2, !dbg !31541
  %629 = ptrtoint ptr %_6 to i64, !dbg !31543
  %630 = lshr i64 %629, 3, !dbg !31543
  %631 = add i64 %630, 2147450880, !dbg !31543
  %632 = inttoptr i64 %631 to ptr, !dbg !31543
  %633 = load i8, ptr %632, align 1, !dbg !31543
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %633), !dbg !31543
  %634 = icmp ne i8 %633, 0, !dbg !31543
  br i1 %634, label %637, label %._crit_edge39, !dbg !31543, !prof !4181

._crit_edge39:                                    ; preds = %628
  %635 = load i8, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 77), align 1, !dbg !31543, !nosanitize !4110
  %636 = add i8 %635, 1, !dbg !31543
  store i8 %636, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 77), align 1, !dbg !31543, !nosanitize !4110
  br label %646, !dbg !31543

637:                                              ; preds = %628
  %638 = and i64 %629, 7, !dbg !31543
  %639 = trunc i64 %638 to i8, !dbg !31543
  call void @__sanitizer_cov_trace_cmp1(i8 %639, i8 %633), !dbg !31543
  %640 = icmp sge i8 %639, %633, !dbg !31543
  br i1 %640, label %643, label %._crit_edge40, !dbg !31543

._crit_edge40:                                    ; preds = %637
  %641 = load i8, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 78), align 1, !dbg !31543, !nosanitize !4110
  %642 = add i8 %641, 1, !dbg !31543
  store i8 %642, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 78), align 1, !dbg !31543, !nosanitize !4110
  br label %646, !dbg !31543

643:                                              ; preds = %637
  %644 = load i8, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 79), align 1, !dbg !31543, !nosanitize !4110
  %645 = add i8 %644, 1, !dbg !31543
  store i8 %645, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 79), align 1, !dbg !31543, !nosanitize !4110
  call void @__asan_report_load1(i64 %629) #42, !dbg !31543
  unreachable

646:                                              ; preds = %._crit_edge40, %._crit_edge39
  %647 = load i8, ptr %_6, align 1, !dbg !31543, !range !4348, !alias.scope !31545, !noundef !4110
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %647), !dbg !31543
  %648 = icmp eq i8 %647, 0, !dbg !31543
  br i1 %648, label %._RINvNtCshZBO5P2NUJi_4core3ptr9drop_glueINtNtB4_6option6OptionINtCskG2NEjLuYj5_16chacha20poly130514ChaChaPoly1305INtNtCs3uTrKuTqj2Q_6cipher14stream_wrapper23StreamCipherCoreWrapperINtCslD4gSC9HkLH_8chacha2010ChaChaCoreINtNtCs9T39WwoIZ0p_7typenum4uint4UIntIB3u_IB3u_IB3u_NtB3w_5UTermNtNtB3y_3bit2B1ENtB4x_2B0EB4v_EB4L_EEEEEECs4oicsBtN6nJ_15spiral_protocol.exit2_crit_edge, label %bb2.i1, !dbg !31543

._RINvNtCshZBO5P2NUJi_4core3ptr9drop_glueINtNtB4_6option6OptionINtCskG2NEjLuYj5_16chacha20poly130514ChaChaPoly1305INtNtCs3uTrKuTqj2Q_6cipher14stream_wrapper23StreamCipherCoreWrapperINtCslD4gSC9HkLH_8chacha2010ChaChaCoreINtNtCs9T39WwoIZ0p_7typenum4uint4UIntIB3u_IB3u_IB3u_NtB3w_5UTermNtNtB3y_3bit2B1ENtB4x_2B0EB4v_EB4L_EEEEEECs4oicsBtN6nJ_15spiral_protocol.exit2_crit_edge: ; preds = %646
  %649 = load i8, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 80), align 1, !dbg !31543, !nosanitize !4110
  %650 = add i8 %649, 1, !dbg !31543
  store i8 %650, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 80), align 1, !dbg !31543, !nosanitize !4110
  br label %_RINvNtCshZBO5P2NUJi_4core3ptr9drop_glueINtNtB4_6option6OptionINtCskG2NEjLuYj5_16chacha20poly130514ChaChaPoly1305INtNtCs3uTrKuTqj2Q_6cipher14stream_wrapper23StreamCipherCoreWrapperINtCslD4gSC9HkLH_8chacha2010ChaChaCoreINtNtCs9T39WwoIZ0p_7typenum4uint4UIntIB3u_IB3u_IB3u_NtB3w_5UTermNtNtB3y_3bit2B1ENtB4x_2B0EB4v_EB4L_EEEEEECs4oicsBtN6nJ_15spiral_protocol.exit2, !dbg !31543

bb2.i1:                                           ; preds = %646
  %651 = load i8, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 81), align 1, !dbg !31543, !nosanitize !4110
  %652 = add i8 %651, 1, !dbg !31543
  store i8 %652, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 81), align 1, !dbg !31543, !nosanitize !4110
  %653 = getelementptr inbounds nuw i8, ptr %self, i64 38, !dbg !31543
; call <[u8] as zeroize::Zeroize>::zeroize
  call void @_RNvXs9_Cs5e7aMHj0NTS_7zeroizeShNtB5_7Zeroize7zeroizeB5_(ptr noalias nofree noundef nonnull dereferenceable(32) %653, i64 noundef 32) #35, !dbg !31548
  br label %_RINvNtCshZBO5P2NUJi_4core3ptr9drop_glueINtNtB4_6option6OptionINtCskG2NEjLuYj5_16chacha20poly130514ChaChaPoly1305INtNtCs3uTrKuTqj2Q_6cipher14stream_wrapper23StreamCipherCoreWrapperINtCslD4gSC9HkLH_8chacha2010ChaChaCoreINtNtCs9T39WwoIZ0p_7typenum4uint4UIntIB3u_IB3u_IB3u_NtB3w_5UTermNtNtB3y_3bit2B1ENtB4x_2B0EB4v_EB4L_EEEEEECs4oicsBtN6nJ_15spiral_protocol.exit2, !dbg !31543

_RINvNtCshZBO5P2NUJi_4core3ptr9drop_glueINtNtB4_6option6OptionINtCskG2NEjLuYj5_16chacha20poly130514ChaChaPoly1305INtNtCs3uTrKuTqj2Q_6cipher14stream_wrapper23StreamCipherCoreWrapperINtCslD4gSC9HkLH_8chacha2010ChaChaCoreINtNtCs9T39WwoIZ0p_7typenum4uint4UIntIB3u_IB3u_IB3u_NtB3w_5UTermNtNtB3y_3bit2B1ENtB4x_2B0EB4v_EB4L_EEEEEECs4oicsBtN6nJ_15spiral_protocol.exit2: ; preds = %._RINvNtCshZBO5P2NUJi_4core3ptr9drop_glueINtNtB4_6option6OptionINtCskG2NEjLuYj5_16chacha20poly130514ChaChaPoly1305INtNtCs3uTrKuTqj2Q_6cipher14stream_wrapper23StreamCipherCoreWrapperINtCslD4gSC9HkLH_8chacha2010ChaChaCoreINtNtCs9T39WwoIZ0p_7typenum4uint4UIntIB3u_IB3u_IB3u_NtB3w_5UTermNtNtB3y_3bit2B1ENtB4x_2B0EB4v_EB4L_EEEEEECs4oicsBtN6nJ_15spiral_protocol.exit2_crit_edge, %bb2.i1
  %654 = ptrtoint ptr %_6 to i64, !dbg !31551
  %655 = lshr i64 %654, 3, !dbg !31551
  %656 = add i64 %655, 2147450880, !dbg !31551
  %657 = inttoptr i64 %656 to ptr, !dbg !31551
  %658 = load i8, ptr %657, align 1, !dbg !31551
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %658), !dbg !31551
  %659 = icmp ne i8 %658, 0, !dbg !31551
  br i1 %659, label %662, label %_RINvNtCshZBO5P2NUJi_4core3ptr9drop_glueINtNtB4_6option6OptionINtCskG2NEjLuYj5_16chacha20poly130514ChaChaPoly1305INtNtCs3uTrKuTqj2Q_6cipher14stream_wrapper23StreamCipherCoreWrapperINtCslD4gSC9HkLH_8chacha2010ChaChaCoreINtNtCs9T39WwoIZ0p_7typenum4uint4UIntIB3u_IB3u_IB3u_NtB3w_5UTermNtNtB3y_3bit2B1ENtB4x_2B0EB4v_EB4L_EEEEEECs4oicsBtN6nJ_15spiral_protocol.exit2._crit_edge, !dbg !31551, !prof !4181

_RINvNtCshZBO5P2NUJi_4core3ptr9drop_glueINtNtB4_6option6OptionINtCskG2NEjLuYj5_16chacha20poly130514ChaChaPoly1305INtNtCs3uTrKuTqj2Q_6cipher14stream_wrapper23StreamCipherCoreWrapperINtCslD4gSC9HkLH_8chacha2010ChaChaCoreINtNtCs9T39WwoIZ0p_7typenum4uint4UIntIB3u_IB3u_IB3u_NtB3w_5UTermNtNtB3y_3bit2B1ENtB4x_2B0EB4v_EB4L_EEEEEECs4oicsBtN6nJ_15spiral_protocol.exit2._crit_edge: ; preds = %_RINvNtCshZBO5P2NUJi_4core3ptr9drop_glueINtNtB4_6option6OptionINtCskG2NEjLuYj5_16chacha20poly130514ChaChaPoly1305INtNtCs3uTrKuTqj2Q_6cipher14stream_wrapper23StreamCipherCoreWrapperINtCslD4gSC9HkLH_8chacha2010ChaChaCoreINtNtCs9T39WwoIZ0p_7typenum4uint4UIntIB3u_IB3u_IB3u_NtB3w_5UTermNtNtB3y_3bit2B1ENtB4x_2B0EB4v_EB4L_EEEEEECs4oicsBtN6nJ_15spiral_protocol.exit2
  %660 = load i8, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 82), align 1, !dbg !31551, !nosanitize !4110
  %661 = add i8 %660, 1, !dbg !31551
  store i8 %661, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 82), align 1, !dbg !31551, !nosanitize !4110
  br label %671, !dbg !31551

662:                                              ; preds = %_RINvNtCshZBO5P2NUJi_4core3ptr9drop_glueINtNtB4_6option6OptionINtCskG2NEjLuYj5_16chacha20poly130514ChaChaPoly1305INtNtCs3uTrKuTqj2Q_6cipher14stream_wrapper23StreamCipherCoreWrapperINtCslD4gSC9HkLH_8chacha2010ChaChaCoreINtNtCs9T39WwoIZ0p_7typenum4uint4UIntIB3u_IB3u_IB3u_NtB3w_5UTermNtNtB3y_3bit2B1ENtB4x_2B0EB4v_EB4L_EEEEEECs4oicsBtN6nJ_15spiral_protocol.exit2
  %663 = and i64 %654, 7, !dbg !31551
  %664 = trunc i64 %663 to i8, !dbg !31551
  call void @__sanitizer_cov_trace_cmp1(i8 %664, i8 %658), !dbg !31551
  %665 = icmp sge i8 %664, %658, !dbg !31551
  br i1 %665, label %668, label %._crit_edge41, !dbg !31551

._crit_edge41:                                    ; preds = %662
  %666 = load i8, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 83), align 1, !dbg !31551, !nosanitize !4110
  %667 = add i8 %666, 1, !dbg !31551
  store i8 %667, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 83), align 1, !dbg !31551, !nosanitize !4110
  br label %671, !dbg !31551

668:                                              ; preds = %662
  %669 = load i8, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 84), align 1, !dbg !31551, !nosanitize !4110
  %670 = add i8 %669, 1, !dbg !31551
  store i8 %670, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 84), align 1, !dbg !31551, !nosanitize !4110
  call void @__asan_report_store1(i64 %654) #42, !dbg !31551
  unreachable

671:                                              ; preds = %._crit_edge41, %_RINvNtCshZBO5P2NUJi_4core3ptr9drop_glueINtNtB4_6option6OptionINtCskG2NEjLuYj5_16chacha20poly130514ChaChaPoly1305INtNtCs3uTrKuTqj2Q_6cipher14stream_wrapper23StreamCipherCoreWrapperINtCslD4gSC9HkLH_8chacha2010ChaChaCoreINtNtCs9T39WwoIZ0p_7typenum4uint4UIntIB3u_IB3u_IB3u_NtB3w_5UTermNtNtB3y_3bit2B1ENtB4x_2B0EB4v_EB4L_EEEEEECs4oicsBtN6nJ_15spiral_protocol.exit2._crit_edge
  store i8 0, ptr %_6, align 1, !dbg !31551
  br label %bb14, !dbg !31552

bb14:                                             ; preds = %131, %190, %257, %671
  store i64 1172321806, ptr %21, align 8, !dbg !31552
  call void @__sanitizer_cov_trace_const_cmp8(i64 0, i64 %12), !dbg !31552
  %672 = icmp ne i64 %12, 0, !dbg !31552
  br i1 %672, label %673, label %676, !dbg !31552

673:                                              ; preds = %bb14
  %674 = load i8, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 85), align 1, !dbg !31552, !nosanitize !4110
  %675 = add i8 %674, 1, !dbg !31552
  store i8 %675, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 85), align 1, !dbg !31552, !nosanitize !4110
  call void @__asan_stack_free_5(i64 %12, i64 1728), !dbg !31552
  br label %680, !dbg !31552

676:                                              ; preds = %bb14
  %677 = load i8, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 86), align 1, !dbg !31552, !nosanitize !4110
  %678 = add i8 %677, 1, !dbg !31552
  store i8 %678, ptr getelementptr ([87 x i8], ptr @__sancov_gen_.1479, i64 0, i64 86), align 1, !dbg !31552, !nosanitize !4110
  %679 = add i64 %39, 0, !dbg !31552
  call void @__asan_set_shadow_00(i64 %679, i64 216), !dbg !31552
  br label %680, !dbg !31552

680:                                              ; preds = %676, %673
  ret void, !dbg !31552
}

; Verified production function: tx_encode
define internal fastcc void @_RNvMNtCs4oicsBtN6nJ_15spiral_protocol7recordsNtB2_2Tx6encode(ptr dead_on_unwind noalias nofree noundef nonnull writable writeonly sret([32 x i8]) align 8 captures(none) dereferenceable(32) %_0, ptr noalias nofree noundef nonnull align 8 dereferenceable(72) %self, ptr noalias nofree noundef nonnull align 8 captures(address) dead_on_return dereferenceable(48) %p) unnamed_addr #11 comdat personality ptr @rust_eh_personality !dbg !31553 !guid !31554 {
start:
  %_42.sroa.11.i = alloca [14 x i8], align 1
  %_6.sroa.11.i = alloca [38 x i8], align 1
  %result.sroa.15 = alloca [22 x i8], align 2
  %asan_local_stack_base = alloca i64, align 8
  %0 = load i8, ptr @__sancov_gen_.1481, align 1, !dbg !31555, !nosanitize !4110
  %1 = add i8 %0, 1, !dbg !31555
  store i8 %1, ptr @__sancov_gen_.1481, align 1, !dbg !31555, !nosanitize !4110
  %2 = load i32, ptr @__asan_option_detect_stack_use_after_return, align 4
  call void @__sanitizer_cov_trace_const_cmp4(i32 0, i32 %2), !dbg !31556
  %3 = icmp ne i32 %2, 0
  br i1 %3, label %6, label %start._crit_edge

start._crit_edge:                                 ; preds = %start
  %4 = load i8, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 1), align 1, !dbg !31556, !nosanitize !4110
  %5 = add i8 %4, 1, !dbg !31556
  store i8 %5, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 1), align 1, !dbg !31556, !nosanitize !4110
  br label %10

6:                                                ; preds = %start
  %7 = load i8, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 2), align 1, !dbg !31556, !nosanitize !4110
  %8 = add i8 %7, 1, !dbg !31556
  store i8 %8, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 2), align 1, !dbg !31556, !nosanitize !4110
  %9 = call i64 @__asan_stack_malloc_5(i64 1696)
  br label %10

10:                                               ; preds = %start._crit_edge, %6
  %11 = phi i64 [ 0, %start._crit_edge ], [ %9, %6 ]
  %12 = inttoptr i64 %11 to ptr
  call void @__sanitizer_cov_trace_const_cmp8(i64 0, i64 %11), !dbg !31556
  %13 = icmp eq i64 %11, 0
  br i1 %13, label %16, label %._crit_edge

._crit_edge:                                      ; preds = %10
  %14 = load i8, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 3), align 1, !dbg !31556, !nosanitize !4110
  %15 = add i8 %14, 1, !dbg !31556
  store i8 %15, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 3), align 1, !dbg !31556, !nosanitize !4110
  br label %19

16:                                               ; preds = %10
  %17 = load i8, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 4), align 1, !dbg !31556, !nosanitize !4110
  %18 = add i8 %17, 1, !dbg !31556
  store i8 %18, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 4), align 1, !dbg !31556, !nosanitize !4110
  %MyAlloca = alloca i8, i64 1696, align 32
  br label %19

19:                                               ; preds = %._crit_edge, %16
  %20 = phi ptr [ %12, %._crit_edge ], [ %MyAlloca, %16 ]
  store ptr %20, ptr %asan_local_stack_base, align 8
  %21 = getelementptr i8, ptr %20, i64 32
  %22 = getelementptr i8, ptr %20, i64 896
  %23 = getelementptr i8, ptr %20, i64 960
  %24 = getelementptr i8, ptr %20, i64 1168
  %25 = getelementptr i8, ptr %20, i64 1200
  %26 = getelementptr i8, ptr %20, i64 1232
  %27 = getelementptr i8, ptr %20, i64 1248
  %28 = getelementptr i8, ptr %20, i64 1312
  %29 = getelementptr i8, ptr %20, i64 1344
  %30 = getelementptr i8, ptr %20, i64 1376
  %31 = getelementptr i8, ptr %20, i64 1456
  %32 = getelementptr i8, ptr %20, i64 1536
  %33 = getelementptr i8, ptr %20, i64 1616
  store i64 1102416563, ptr %20, align 8
  %34 = getelementptr i8, ptr %20, i64 8
  store i64 ptrtoint (ptr @___asan_gen_stack.116 to i64), ptr %34, align 8
  %35 = getelementptr i8, ptr %20, i64 16
  store i64 ptrtoint (ptr @_RNvMNtCs4oicsBtN6nJ_15spiral_protocol7recordsNtB2_2Tx6encode to i64), ptr %35, align 8
  %36 = ptrtoint ptr %20 to i64
  %37 = lshr i64 %36, 3
  %38 = add i64 %37, 2147450880
  %39 = add i64 %38, 0
  %40 = inttoptr i64 %39 to ptr
  store i32 -235802127, ptr %40, align 1
  %41 = add i64 %38, 4
  call void @__asan_set_shadow_f8(i64 %41, i64 92)
  %42 = add i64 %38, 96
  %43 = inttoptr i64 %42 to ptr
  store i64 -940422246894996750, ptr %43, align 1
  %44 = add i64 %38, 104
  %45 = inttoptr i64 %44 to ptr
  store i64 -940422246894996750, ptr %45, align 1
  %46 = add i64 %38, 112
  %47 = inttoptr i64 %46 to ptr
  store i64 -940422246793938696, ptr %47, align 1
  %48 = add i64 %38, 120
  %49 = inttoptr i64 %48 to ptr
  store i64 -506381209866536712, ptr %49, align 1
  %50 = add i64 %38, 128
  %51 = inttoptr i64 %50 to ptr
  store i64 -506381209866536712, ptr %51, align 1
  %52 = add i64 %38, 136
  %53 = inttoptr i64 %52 to ptr
  store i64 -940422246894996744, ptr %53, align 1
  %54 = add i64 %38, 144
  %55 = inttoptr i64 %54 to ptr
  store i64 -506387832806771982, ptr %55, align 1
  %56 = add i64 %38, 152
  %57 = inttoptr i64 %56 to ptr
  store i64 -938726774194769166, ptr %57, align 1
  %58 = add i64 %38, 160
  %59 = inttoptr i64 %58 to ptr
  store i64 -940415624055426318, ptr %59, align 1
  %60 = add i64 %38, 168
  %61 = inttoptr i64 %60 to ptr
  store i64 -506381209967593224, ptr %61, align 1
  %62 = add i64 %38, 176
  %63 = inttoptr i64 %62 to ptr
  store i64 -506387832807165192, ptr %63, align 1
  %64 = add i64 %38, 184
  %65 = inttoptr i64 %64 to ptr
  store i64 -940422246793938696, ptr %65, align 1
  %66 = add i64 %38, 192
  %67 = inttoptr i64 %66 to ptr
  store i64 -940422221024134920, ptr %67, align 1
  %68 = add i64 %38, 200
  %69 = inttoptr i64 %68 to ptr
  store i64 -868076554939731214, ptr %69, align 1
  %70 = add i64 %38, 208
  %71 = inttoptr i64 %70 to ptr
  store i32 -202116109, ptr %71, align 1
  %72 = getelementptr inbounds nuw i8, ptr %self, i64 70, !dbg !31557
  %73 = ptrtoint ptr %72 to i64, !dbg !31557
  %74 = lshr i64 %73, 3, !dbg !31557
  %75 = add i64 %74, 2147450880, !dbg !31557
  %76 = inttoptr i64 %75 to ptr, !dbg !31557
  %77 = load i8, ptr %76, align 1, !dbg !31557
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %77), !dbg !31557
  %78 = icmp ne i8 %77, 0, !dbg !31557
  br i1 %78, label %81, label %._crit_edge2, !dbg !31557, !prof !4181

._crit_edge2:                                     ; preds = %19
  %79 = load i8, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 5), align 1, !dbg !31557, !nosanitize !4110
  %80 = add i8 %79, 1, !dbg !31557
  store i8 %80, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 5), align 1, !dbg !31557, !nosanitize !4110
  br label %90, !dbg !31557

81:                                               ; preds = %19
  %82 = and i64 %73, 7, !dbg !31557
  %83 = trunc i64 %82 to i8, !dbg !31557
  call void @__sanitizer_cov_trace_cmp1(i8 %83, i8 %77), !dbg !31557
  %84 = icmp sge i8 %83, %77, !dbg !31557
  br i1 %84, label %87, label %._crit_edge3, !dbg !31557

._crit_edge3:                                     ; preds = %81
  %85 = load i8, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 6), align 1, !dbg !31557, !nosanitize !4110
  %86 = add i8 %85, 1, !dbg !31557
  store i8 %86, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 6), align 1, !dbg !31557, !nosanitize !4110
  br label %90, !dbg !31557

87:                                               ; preds = %81
  %88 = load i8, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 7), align 1, !dbg !31557, !nosanitize !4110
  %89 = add i8 %88, 1, !dbg !31557
  store i8 %89, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 7), align 1, !dbg !31557, !nosanitize !4110
  call void @__asan_report_load1(i64 %73) #42, !dbg !31557
  unreachable

90:                                               ; preds = %._crit_edge3, %._crit_edge2
  %91 = load i8, ptr %72, align 2, !dbg !31557, !range !4348, !noundef !4110
  %_4 = trunc nuw i8 %91 to i1, !dbg !31557
  br i1 %_4, label %.bb16_crit_edge, label %bb1, !dbg !31557

.bb16_crit_edge:                                  ; preds = %90
  %92 = load i8, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 8), align 1, !dbg !31557, !nosanitize !4110
  %93 = add i8 %92, 1, !dbg !31557
  store i8 %93, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 8), align 1, !dbg !31557, !nosanitize !4110
  br label %bb16, !dbg !31557

bb1:                                              ; preds = %90
  %_6 = getelementptr inbounds nuw i8, ptr %self, i64 37, !dbg !31558
  %94 = ptrtoint ptr %_6 to i64, !dbg !31559
  %95 = lshr i64 %94, 3, !dbg !31559
  %96 = add i64 %95, 2147450880, !dbg !31559
  %97 = inttoptr i64 %96 to ptr, !dbg !31559
  %98 = load i8, ptr %97, align 1, !dbg !31559
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %98), !dbg !31559
  %99 = icmp ne i8 %98, 0, !dbg !31559
  br i1 %99, label %102, label %bb1._crit_edge, !dbg !31559, !prof !4181

bb1._crit_edge:                                   ; preds = %bb1
  %100 = load i8, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 9), align 1, !dbg !31559, !nosanitize !4110
  %101 = add i8 %100, 1, !dbg !31559
  store i8 %101, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 9), align 1, !dbg !31559, !nosanitize !4110
  br label %111, !dbg !31559

102:                                              ; preds = %bb1
  %103 = and i64 %94, 7, !dbg !31559
  %104 = trunc i64 %103 to i8, !dbg !31559
  call void @__sanitizer_cov_trace_cmp1(i8 %104, i8 %98), !dbg !31559
  %105 = icmp sge i8 %104, %98, !dbg !31559
  br i1 %105, label %108, label %._crit_edge4, !dbg !31559

._crit_edge4:                                     ; preds = %102
  %106 = load i8, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 10), align 1, !dbg !31559, !nosanitize !4110
  %107 = add i8 %106, 1, !dbg !31559
  store i8 %107, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 10), align 1, !dbg !31559, !nosanitize !4110
  br label %111, !dbg !31559

108:                                              ; preds = %102
  %109 = load i8, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 11), align 1, !dbg !31559, !nosanitize !4110
  %110 = add i8 %109, 1, !dbg !31559
  store i8 %110, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 11), align 1, !dbg !31559, !nosanitize !4110
  call void @__asan_report_load1(i64 %94) #42, !dbg !31559
  unreachable

111:                                              ; preds = %._crit_edge4, %bb1._crit_edge
  %112 = load i8, ptr %_6, align 1, !dbg !31559, !range !4348, !alias.scope !31562, !noundef !4110
  %113 = trunc nuw i8 %112 to i1, !dbg !31559
  br i1 %113, label %bb5, label %.bb16_crit_edge5, !dbg !31558

.bb16_crit_edge5:                                 ; preds = %111
  %114 = load i8, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 12), align 1, !dbg !31558, !nosanitize !4110
  %115 = add i8 %114, 1, !dbg !31558
  store i8 %115, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 12), align 1, !dbg !31558, !nosanitize !4110
  br label %bb16, !dbg !31558

bb5:                                              ; preds = %111
  %116 = getelementptr inbounds nuw i8, ptr %self, i64 16, !dbg !31565
  %117 = ptrtoint ptr %116 to i64, !dbg !31565
  %118 = lshr i64 %117, 3, !dbg !31565
  %119 = add i64 %118, 2147450880, !dbg !31565
  %120 = inttoptr i64 %119 to ptr, !dbg !31565
  %121 = load i8, ptr %120, align 1, !dbg !31565
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %121), !dbg !31565
  %122 = icmp ne i8 %121, 0, !dbg !31565
  br i1 %122, label %123, label %126, !dbg !31565

123:                                              ; preds = %bb5
  %124 = load i8, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 13), align 1, !dbg !31565, !nosanitize !4110
  %125 = add i8 %124, 1, !dbg !31565
  store i8 %125, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 13), align 1, !dbg !31565, !nosanitize !4110
  call void @__asan_report_load8(i64 %117) #42, !dbg !31565
  unreachable, !dbg !31565

126:                                              ; preds = %bb5
  %_8 = load i64, ptr %116, align 8, !dbg !31565, !noundef !4110
  call void @__sanitizer_cov_trace_const_cmp8(i64 1048575, i64 %_8), !dbg !31565
  %_7 = icmp ugt i64 %_8, 1048575, !dbg !31565
  br i1 %_7, label %bb2.i, label %bb9, !dbg !31565

bb2.i:                                            ; preds = %126
  %127 = getelementptr inbounds nuw i8, ptr %self, i64 38, !dbg !31566
; call <[u8] as zeroize::Zeroize>::zeroize
  tail call void @_RNvXs9_Cs5e7aMHj0NTS_7zeroizeShNtB5_7Zeroize7zeroizeB5_(ptr noalias nofree noundef nonnull dereferenceable(32) %127, i64 noundef 32) #35, !dbg !31568
  %128 = ptrtoint ptr %_6 to i64, !dbg !31571
  %129 = lshr i64 %128, 3, !dbg !31571
  %130 = add i64 %129, 2147450880, !dbg !31571
  %131 = inttoptr i64 %130 to ptr, !dbg !31571
  %132 = load i8, ptr %131, align 1, !dbg !31571
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %132), !dbg !31571
  %133 = icmp ne i8 %132, 0, !dbg !31571
  br i1 %133, label %136, label %bb2.i._crit_edge, !dbg !31571, !prof !4181

bb2.i._crit_edge:                                 ; preds = %bb2.i
  %134 = load i8, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 14), align 1, !dbg !31571, !nosanitize !4110
  %135 = add i8 %134, 1, !dbg !31571
  store i8 %135, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 14), align 1, !dbg !31571, !nosanitize !4110
  br label %145, !dbg !31571

136:                                              ; preds = %bb2.i
  %137 = and i64 %128, 7, !dbg !31571
  %138 = trunc i64 %137 to i8, !dbg !31571
  call void @__sanitizer_cov_trace_cmp1(i8 %138, i8 %132), !dbg !31571
  %139 = icmp sge i8 %138, %132, !dbg !31571
  br i1 %139, label %142, label %._crit_edge6, !dbg !31571

._crit_edge6:                                     ; preds = %136
  %140 = load i8, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 15), align 1, !dbg !31571, !nosanitize !4110
  %141 = add i8 %140, 1, !dbg !31571
  store i8 %141, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 15), align 1, !dbg !31571, !nosanitize !4110
  br label %145, !dbg !31571

142:                                              ; preds = %136
  %143 = load i8, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 16), align 1, !dbg !31571, !nosanitize !4110
  %144 = add i8 %143, 1, !dbg !31571
  store i8 %144, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 16), align 1, !dbg !31571, !nosanitize !4110
  call void @__asan_report_store1(i64 %128) #42, !dbg !31571
  unreachable

145:                                              ; preds = %._crit_edge6, %bb2.i._crit_edge
  store i8 0, ptr %_6, align 1, !dbg !31571
  br label %bb16, !dbg !31572

bb9:                                              ; preds = %126
  %_11.0 = add nuw nsw i64 %_8, 1, !dbg !31574
  %146 = ptrtoint ptr %116 to i64, !dbg !31574
  %147 = lshr i64 %146, 3, !dbg !31574
  %148 = add i64 %147, 2147450880, !dbg !31574
  %149 = inttoptr i64 %148 to ptr, !dbg !31574
  %150 = load i8, ptr %149, align 1, !dbg !31574
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %150), !dbg !31574
  %151 = icmp ne i8 %150, 0, !dbg !31574
  br i1 %151, label %152, label %155, !dbg !31574

152:                                              ; preds = %bb9
  %153 = load i8, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 17), align 1, !dbg !31574, !nosanitize !4110
  %154 = add i8 %153, 1, !dbg !31574
  store i8 %154, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 17), align 1, !dbg !31574, !nosanitize !4110
  call void @__asan_report_store8(i64 %146) #42, !dbg !31574
  unreachable, !dbg !31574

155:                                              ; preds = %bb9
  store i64 %_11.0, ptr %116, align 8, !dbg !31574
  call void @llvm.lifetime.start.p0(ptr nonnull %result.sroa.15), !dbg !31576
  %_14 = getelementptr inbounds nuw i8, ptr %p, i64 32, !dbg !31577
  %_15 = getelementptr inbounds nuw i8, ptr %p, i64 40, !dbg !31577
  %_18 = getelementptr inbounds nuw i8, ptr %self, i64 32, !dbg !31577
  %_21 = getelementptr inbounds nuw i8, ptr %self, i64 24, !dbg !31577
  %156 = add i64 %38, 202, !dbg !31578
  %157 = inttoptr i64 %156 to ptr, !dbg !31578
  store i32 0, ptr %157, align 1, !dbg !31578
  %158 = call ptr @__asan_memcpy(ptr %33, ptr %p, i64 32), !dbg !31577
  %159 = ptrtoint ptr %_14 to i64, !dbg !31582
  %160 = lshr i64 %159, 3, !dbg !31582
  %161 = add i64 %160, 2147450880, !dbg !31582
  %162 = inttoptr i64 %161 to ptr, !dbg !31582
  %163 = load i8, ptr %162, align 1, !dbg !31582
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %163), !dbg !31582
  %164 = icmp ne i8 %163, 0, !dbg !31582
  br i1 %164, label %165, label %168, !dbg !31582

165:                                              ; preds = %155
  %166 = load i8, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 18), align 1, !dbg !31582, !nosanitize !4110
  %167 = add i8 %166, 1, !dbg !31582
  store i8 %167, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 18), align 1, !dbg !31582, !nosanitize !4110
  call void @__asan_report_load8(i64 %159) #42, !dbg !31582
  unreachable, !dbg !31582

168:                                              ; preds = %155
  %start2.i = load i64, ptr %_14, align 8, !dbg !31582, !noalias !31583, !noundef !4110
  %169 = ptrtoint ptr %_15 to i64, !dbg !31587
  %170 = lshr i64 %169, 3, !dbg !31587
  %171 = add i64 %170, 2147450880, !dbg !31587
  %172 = inttoptr i64 %171 to ptr, !dbg !31587
  %173 = load i8, ptr %172, align 1, !dbg !31587
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %173), !dbg !31587
  %174 = icmp ne i8 %173, 0, !dbg !31587
  br i1 %174, label %175, label %178, !dbg !31587

175:                                              ; preds = %168
  %176 = load i8, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 19), align 1, !dbg !31587, !nosanitize !4110
  %177 = add i8 %176, 1, !dbg !31587
  store i8 %177, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 19), align 1, !dbg !31587, !nosanitize !4110
  call void @__asan_report_load8(i64 %169) #42, !dbg !31587
  unreachable, !dbg !31587

178:                                              ; preds = %168
  %length.i = load i64, ptr %_15, align 8, !dbg !31587, !noalias !31583, !noundef !4110
  %179 = add i64 %38, 192, !dbg !31588
  %180 = inttoptr i64 %179 to ptr, !dbg !31588
  store i32 0, ptr %180, align 1, !dbg !31588
  %181 = add i64 %38, 196, !dbg !31588
  %182 = inttoptr i64 %181 to ptr, !dbg !31588
  store i8 0, ptr %182, align 1, !dbg !31588
  call void @llvm.lifetime.start.p0(ptr nonnull %_6.sroa.11.i), !dbg !31590
  %183 = add i64 %38, 182, !dbg !31590
  %184 = inttoptr i64 %183 to ptr, !dbg !31590
  store i32 0, ptr %184, align 1, !dbg !31590
  %185 = add i64 %38, 186, !dbg !31590
  %186 = inttoptr i64 %185 to ptr, !dbg !31590
  store i16 256, ptr %186, align 1, !dbg !31590
  %187 = add i64 %38, 172, !dbg !31590
  %188 = inttoptr i64 %187 to ptr, !dbg !31590
  store i32 0, ptr %188, align 1, !dbg !31590
  %189 = add i64 %38, 176, !dbg !31590
  %190 = inttoptr i64 %189 to ptr, !dbg !31590
  store i8 0, ptr %190, align 1, !dbg !31590
  call void @__sanitizer_cov_trace_const_cmp8(i64 -17, i64 %length.i), !dbg !31591
  %_14.1.i = icmp ugt i64 %length.i, -17, !dbg !31591
  br i1 %_14.1.i, label %panic.i, label %bb1.i, !dbg !31591

bb1.i:                                            ; preds = %178
  %_20 = getelementptr inbounds nuw i8, ptr %self, i64 36, !dbg !31577
  %191 = ptrtoint ptr %_20 to i64, !dbg !31592
  %192 = lshr i64 %191, 3, !dbg !31592
  %193 = add i64 %192, 2147450880, !dbg !31592
  %194 = inttoptr i64 %193 to ptr, !dbg !31592
  %195 = load i8, ptr %194, align 1, !dbg !31592
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %195), !dbg !31592
  %196 = icmp ne i8 %195, 0, !dbg !31592
  br i1 %196, label %199, label %bb1.i._crit_edge, !dbg !31592, !prof !4181

bb1.i._crit_edge:                                 ; preds = %bb1.i
  %197 = load i8, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 20), align 1, !dbg !31592, !nosanitize !4110
  %198 = add i8 %197, 1, !dbg !31592
  store i8 %198, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 20), align 1, !dbg !31592, !nosanitize !4110
  br label %208, !dbg !31592

199:                                              ; preds = %bb1.i
  %200 = and i64 %191, 7, !dbg !31592
  %201 = trunc i64 %200 to i8, !dbg !31592
  call void @__sanitizer_cov_trace_cmp1(i8 %201, i8 %195), !dbg !31592
  %202 = icmp sge i8 %201, %195, !dbg !31592
  br i1 %202, label %205, label %._crit_edge7, !dbg !31592

._crit_edge7:                                     ; preds = %199
  %203 = load i8, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 21), align 1, !dbg !31592, !nosanitize !4110
  %204 = add i8 %203, 1, !dbg !31592
  store i8 %204, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 21), align 1, !dbg !31592, !nosanitize !4110
  br label %208, !dbg !31592

205:                                              ; preds = %199
  %206 = load i8, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 22), align 1, !dbg !31592, !nosanitize !4110
  %207 = add i8 %206, 1, !dbg !31592
  store i8 %207, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 22), align 1, !dbg !31592, !nosanitize !4110
  call void @__asan_report_load1(i64 %191) #42, !dbg !31592
  unreachable

208:                                              ; preds = %._crit_edge7, %bb1.i._crit_edge
  %_10.i = load i8, ptr %_20, align 4, !dbg !31592, !noalias !31583, !noundef !4110
  %_14.0.i = add nuw i64 %length.i, 16, !dbg !31591
  %209 = getelementptr inbounds nuw i8, ptr %30, i64 32, !dbg !31590
  store i8 16, ptr %209, align 8, !dbg !31590, !noalias !31583
  %210 = getelementptr inbounds nuw i8, ptr %30, i64 33, !dbg !31590
  store i8 %_10.i, ptr %210, align 1, !dbg !31590, !noalias !31583
  %211 = call ptr @__asan_memcpy(ptr %30, ptr %self, i64 16), !dbg !31590
  %212 = getelementptr inbounds nuw i8, ptr %30, i64 16, !dbg !31590
  store i64 %_8, ptr %212, align 8, !dbg !31590, !noalias !31583
  %213 = getelementptr inbounds nuw i8, ptr %30, i64 24, !dbg !31590
  store i64 %_14.0.i, ptr %213, align 8, !dbg !31590, !noalias !31583
; call <spiral_protocol::wire::Header>::encode
  call void @_RNvMNtCs4oicsBtN6nJ_15spiral_protocol4wireNtB2_6Header6encode(ptr noalias nofree noundef sret([41 x i8]) align 1 captures(address) dereferenceable(41) %31, ptr noalias nofree noundef readonly align 8 captures(address) dereferenceable(40) %30) #35, !dbg !31593, !noalias !31583
  %214 = add i64 %38, 172, !dbg !31594
  %215 = inttoptr i64 %214 to ptr, !dbg !31594
  store i32 -117901064, ptr %215, align 1, !dbg !31594
  %216 = add i64 %38, 176, !dbg !31594
  %217 = inttoptr i64 %216 to ptr, !dbg !31594
  store i8 -8, ptr %217, align 1, !dbg !31594
  call void @llvm.experimental.noalias.scope.decl(metadata !31595), !dbg !31590
  %218 = load i8, ptr %31, align 1, !dbg !31598, !range !4348, !alias.scope !31600, !noalias !31602, !noundef !4110
  %219 = trunc nuw i8 %218 to i1, !dbg !31598
  %220 = getelementptr inbounds nuw i8, ptr %31, i64 1, !dbg !31603
  %e.0.i.i = load i8, ptr %220, align 1, !dbg !31603, !alias.scope !31604, !noalias !31583
  %221 = getelementptr inbounds nuw i8, ptr %31, i64 2, !dbg !31603
  %e.1.i.i = load i8, ptr %221, align 1, !dbg !31603, !alias.scope !31604, !noalias !31583
  br i1 %219, label %bb6.i.critedge, label %bb3.i.i, !dbg !31605

bb3.i.i:                                          ; preds = %208
  %_6.sroa.11.1..sroa_idx.i = getelementptr inbounds nuw i8, ptr %31, i64 3, !dbg !31606
  %222 = call ptr @__asan_memcpy(ptr %_6.sroa.11.i, ptr %_6.sroa.11.1..sroa_idx.i, i64 38), !dbg !31606
  %223 = add i64 %38, 182, !dbg !31607
  %224 = inttoptr i64 %223 to ptr, !dbg !31607
  store i32 -117901064, ptr %224, align 1, !dbg !31607
  %225 = add i64 %38, 186, !dbg !31607
  %226 = inttoptr i64 %225 to ptr, !dbg !31607
  store i16 -1800, ptr %226, align 1, !dbg !31607
  %val.sroa.5.0.h.sroa_idx.i = getelementptr inbounds nuw i8, ptr %32, i64 2, !dbg !31608
  %227 = call ptr @__asan_memcpy(ptr %val.sroa.5.0.h.sroa_idx.i, ptr %_6.sroa.11.i, i64 38), !dbg !31590
  store i8 %e.0.i.i, ptr %32, align 1, !dbg !31608, !noalias !31583
  %val.sroa.4.0.h.sroa_idx.i = getelementptr inbounds nuw i8, ptr %32, i64 1, !dbg !31608
  store i8 %e.1.i.i, ptr %val.sroa.4.0.h.sroa_idx.i, align 1, !dbg !31608, !noalias !31583
  call void @llvm.lifetime.end.p0(ptr nonnull %_6.sroa.11.i), !dbg !31610
  %self1.i.i = load i64, ptr %33, align 8, !dbg !31611, !range !9222, !alias.scope !31619, !noalias !31583, !noundef !4110
  %_23.0.i = add i64 %length.i, 40, !dbg !31622
  call void @__sanitizer_cov_trace_const_cmp8(i64 -41, i64 %length.i), !dbg !31622
  %_23.1.i = icmp ugt i64 %length.i, -41, !dbg !31622
  br i1 %_23.1.i, label %panic3.i, label %bb9.i, !dbg !31622

panic.i:                                          ; preds = %178
  %228 = load i8, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 23), align 1, !dbg !31591, !nosanitize !4110
  %229 = add i8 %228, 1, !dbg !31591
  store i8 %229, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 23), align 1, !dbg !31591, !nosanitize !4110
  call void @__asan_handle_no_return(), !dbg !31591
; call core::panicking::panic_const::panic_const_add_overflow
  tail call void @_RNvNtNtCshZBO5P2NUJi_4core9panicking11panic_const24panic_const_add_overflow(ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_bfbbf8a280ed413c0a04ce8160fba009) #43, !dbg !31591, !noalias !31583
  unreachable, !dbg !31591

bb6.i.critedge:                                   ; preds = %208
  %230 = load i8, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 24), align 1, !dbg !31607, !nosanitize !4110
  %231 = add i8 %230, 1, !dbg !31607
  store i8 %231, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 24), align 1, !dbg !31607, !nosanitize !4110
  %232 = add i64 %38, 182, !dbg !31607
  %233 = inttoptr i64 %232 to ptr, !dbg !31607
  store i32 -117901064, ptr %233, align 1, !dbg !31607
  %234 = add i64 %38, 186, !dbg !31607
  %235 = inttoptr i64 %234 to ptr, !dbg !31607
  store i16 -1800, ptr %235, align 1, !dbg !31607
  call void @llvm.lifetime.end.p0(ptr nonnull %_6.sroa.11.i), !dbg !31610
  br label %bb47.i, !dbg !31623

bb9.i:                                            ; preds = %bb3.i.i
  %_24.0.i = add i64 %length.i, 56, !dbg !31622
  call void @__sanitizer_cov_trace_cmp8(i64 %_24.0.i, i64 %_23.0.i), !dbg !31622
  %_24.1.i = icmp ult i64 %_24.0.i, %_23.0.i, !dbg !31622
  br i1 %_24.1.i, label %panic4.i, label %bb10.i, !dbg !31622

panic3.i:                                         ; preds = %bb3.i.i
  %236 = load i8, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 25), align 1, !dbg !31622, !nosanitize !4110
  %237 = add i8 %236, 1, !dbg !31622
  store i8 %237, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 25), align 1, !dbg !31622, !nosanitize !4110
  call void @__asan_handle_no_return(), !dbg !31622
; call core::panicking::panic_const::panic_const_add_overflow
  call void @_RNvNtNtCshZBO5P2NUJi_4core9panicking11panic_const24panic_const_add_overflow(ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_91ef075a2cd32e8fdb4bf6278411d0b1) #43, !dbg !31622, !noalias !31583
  unreachable, !dbg !31622

bb10.i:                                           ; preds = %bb9.i
  call void @__sanitizer_cov_trace_cmp8(i64 %self1.i.i, i64 %_24.0.i), !dbg !31625
  %_18.i = icmp ult i64 %self1.i.i, %_24.0.i, !dbg !31625
  br i1 %_18.i, label %bb10.i.bb47.i_crit_edge, label %bb14.i, !dbg !31625

bb10.i.bb47.i_crit_edge:                          ; preds = %bb10.i
  %238 = load i8, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 26), align 1, !dbg !31625, !nosanitize !4110
  %239 = add i8 %238, 1, !dbg !31625
  store i8 %239, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 26), align 1, !dbg !31625, !nosanitize !4110
  br label %bb47.i, !dbg !31625

panic4.i:                                         ; preds = %bb9.i
  %240 = load i8, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 27), align 1, !dbg !31622, !nosanitize !4110
  %241 = add i8 %240, 1, !dbg !31622
  store i8 %241, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 27), align 1, !dbg !31622, !nosanitize !4110
  call void @__asan_handle_no_return(), !dbg !31622
; call core::panicking::panic_const::panic_const_add_overflow
  call void @_RNvNtNtCshZBO5P2NUJi_4core9panicking11panic_const24panic_const_add_overflow(ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_91ef075a2cd32e8fdb4bf6278411d0b1) #43, !dbg !31622, !noalias !31583
  unreachable, !dbg !31622

bb14.i:                                           ; preds = %bb10.i
; call <alloc::vec::Vec<u8>>::resize
  call void @_RNvMs1_NtCs95TQQ7nxHrj_5alloc3vecINtB5_3VechE6resizeCsiLEqvKq9QKh_13data_encoding(ptr noalias nofree noundef align 8 dereferenceable(24) %33, i64 noundef %_24.0.i, i8 noundef 0) #35, !dbg !31626, !noalias !31583
  %242 = getelementptr inbounds nuw i8, ptr %33, i64 8, !dbg !31627
  %_5.i.i = load ptr, ptr %242, align 8, !dbg !31627, !alias.scope !31641, !noalias !31583, !nonnull !4110, !noundef !4110
  %243 = getelementptr inbounds nuw i8, ptr %33, i64 16, !dbg !31644
  %_32.0.i = add i64 %length.i, %start2.i, !dbg !31645
  call void @__sanitizer_cov_trace_cmp8(i64 %_32.0.i, i64 %start2.i), !dbg !31645
  %_32.1.i = icmp ult i64 %_32.0.i, %start2.i, !dbg !31645
  br i1 %_32.1.i, label %panic7.i, label %bb17.i, !dbg !31645

bb17.i:                                           ; preds = %bb14.i
  %_4.i.i = load i64, ptr %243, align 8, !dbg !31644, !alias.scope !31641, !noalias !31583, !noundef !4110
  call void @llvm.experimental.noalias.scope.decl(metadata !31646), !dbg !31649
; call core::slice::index::range::<core::ops::range::Range<usize>>
  %244 = call { i64, i64 } @_RINvNtNtCshZBO5P2NUJi_4core5slice5index5rangeINtNtNtB6_3ops5range5RangejEECslStLScDMZvw_6rustls(i64 noundef %start2.i, i64 noundef %_32.0.i, i64 noundef range(i64 0, -9223372036854775808) %_4.i.i, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_77bce9645d44629b226a97c15a248fa7) #35, !dbg !31650, !noalias !31653
  %_6.0.i.i = extractvalue { i64, i64 } %244, 0, !dbg !31650
  %_6.1.i.i = extractvalue { i64, i64 } %244, 1, !dbg !31650
  %count.i.i = sub i64 %_6.1.i.i, %_6.0.i.i, !dbg !31654
  %_11.i.i = sub i64 %_4.i.i, %count.i.i, !dbg !31656
  call void @__sanitizer_cov_trace_const_cmp8(i64 39, i64 %_11.i.i), !dbg !31658
  %_10.i.i = icmp ugt i64 %_11.i.i, 39, !dbg !31658
  br i1 %_10.i.i, label %_RINvMNtCshZBO5P2NUJi_4core5sliceSh11copy_withinINtNtNtB5_3ops5range5RangejEECs4oicsBtN6nJ_15spiral_protocol.exit.i, label %bb3.i17.i, !dbg !31658, !prof !4186

bb3.i17.i:                                        ; preds = %bb17.i
  %245 = load i8, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 28), align 1, !dbg !31659, !nosanitize !4110
  %246 = add i8 %245, 1, !dbg !31659
  store i8 %246, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 28), align 1, !dbg !31659, !nosanitize !4110
  call void @__asan_handle_no_return(), !dbg !31659
; call core::panicking::panic_fmt
  call void @_RNvNtCshZBO5P2NUJi_4core9panicking9panic_fmt(ptr noundef nonnull @alloc_1d6e4bfe7d2b96ab3af8255b2a238662, ptr noundef nonnull inttoptr (i64 43 to ptr), ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_77bce9645d44629b226a97c15a248fa7) #43, !dbg !31659, !noalias !31653
  unreachable, !dbg !31659

_RINvMNtCshZBO5P2NUJi_4core5sliceSh11copy_withinINtNtNtB5_3ops5range5RangejEECs4oicsBtN6nJ_15spiral_protocol.exit.i: ; preds = %bb17.i
  %src_ptr.i.i = getelementptr inbounds nuw i8, ptr %_5.i.i, i64 %_6.0.i.i, !dbg !31660
  %dest_ptr.i.i = getelementptr inbounds nuw i8, ptr %_5.i.i, i64 40, !dbg !31664
  %247 = call ptr @__asan_memmove(ptr %dest_ptr.i.i, ptr %src_ptr.i.i, i64 %count.i.i), !dbg !31667
  call void @llvm.experimental.noalias.scope.decl(metadata !31671), !dbg !31674
  %_6.i.i = load i64, ptr %243, align 8, !dbg !31675, !alias.scope !31671, !noalias !31583, !noundef !4110
  call void @__sanitizer_cov_trace_const_cmp8(i64 40, i64 %_6.i.i), !dbg !31556
  %_7.not.i.i.i.i = icmp ult i64 %_6.i.i, 40
  br i1 %_7.not.i.i.i.i, label %bb3.i.i.i.i, label %_RNvXse_NtCs95TQQ7nxHrj_5alloc3vecINtB5_3VechEINtNtNtCshZBO5P2NUJi_4core3ops5index8IndexMutINtNtBM_5range7RangeTojEE9index_mutCs4oicsBtN6nJ_15spiral_protocol.exit.i, !dbg !31683, !prof !15873

bb3.i.i.i.i:                                      ; preds = %_RINvMNtCshZBO5P2NUJi_4core5sliceSh11copy_withinINtNtNtB5_3ops5range5RangejEECs4oicsBtN6nJ_15spiral_protocol.exit.i
  %248 = load i8, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 29), align 1, !dbg !31691, !nosanitize !4110
  %249 = add i8 %248, 1, !dbg !31691
  store i8 %249, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 29), align 1, !dbg !31691, !nosanitize !4110
  call void @__asan_handle_no_return(), !dbg !31691
; call core::slice::index::slice_index_fail
  call void @_RNvNtNtCshZBO5P2NUJi_4core5slice5index16slice_index_fail(i64 noundef 0, i64 noundef 40, i64 noundef range(i64 0, -9223372036854775808) %_6.i.i, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_b33a68eab2efa3f6d1d92f71902595ac) #43, !dbg !31691, !noalias !31692
  unreachable, !dbg !31691

_RNvXse_NtCs95TQQ7nxHrj_5alloc3vecINtB5_3VechEINtNtNtCshZBO5P2NUJi_4core3ops5index8IndexMutINtNtBM_5range7RangeTojEE9index_mutCs4oicsBtN6nJ_15spiral_protocol.exit.i: ; preds = %_RINvMNtCshZBO5P2NUJi_4core5sliceSh11copy_withinINtNtNtB5_3ops5range5RangejEECs4oicsBtN6nJ_15spiral_protocol.exit.i
  %_7.i.i = load ptr, ptr %242, align 8, !dbg !31697, !alias.scope !31671, !noalias !31583, !nonnull !4110, !noundef !4110
; call core::slice::copy_from_slice_impl::<u8>
  call void @_RINvNtCshZBO5P2NUJi_4core5slice20copy_from_slice_implhECs7jJvS58pafZ_4ring(ptr noalias nofree noundef nonnull %_7.i.i, i64 noundef range(i64 0, -9223372036854775808) 40, ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) %32, i64 noundef 40, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_cac023432f7e8b0a9ef1a0ab53729325) #35, !dbg !31706, !noalias !31583
  %250 = add i64 %38, 168, !dbg !31708
  %251 = inttoptr i64 %250 to ptr, !dbg !31708
  store i16 1024, ptr %251, align 1, !dbg !31708
  %252 = ptrtoint ptr %_18 to i64, !dbg !31709
  %253 = lshr i64 %252, 3, !dbg !31709
  %254 = add i64 %253, 2147450880, !dbg !31709
  %255 = inttoptr i64 %254 to ptr, !dbg !31709
  %256 = load i8, ptr %255, align 1, !dbg !31709
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %256), !dbg !31709
  %257 = icmp ne i8 %256, 0, !dbg !31709
  br i1 %257, label %260, label %_RNvXse_NtCs95TQQ7nxHrj_5alloc3vecINtB5_3VechEINtNtNtCshZBO5P2NUJi_4core3ops5index8IndexMutINtNtBM_5range7RangeTojEE9index_mutCs4oicsBtN6nJ_15spiral_protocol.exit.i._crit_edge, !dbg !31709, !prof !4181

_RNvXse_NtCs95TQQ7nxHrj_5alloc3vecINtB5_3VechEINtNtNtCshZBO5P2NUJi_4core3ops5index8IndexMutINtNtBM_5range7RangeTojEE9index_mutCs4oicsBtN6nJ_15spiral_protocol.exit.i._crit_edge: ; preds = %_RNvXse_NtCs95TQQ7nxHrj_5alloc3vecINtB5_3VechEINtNtNtCshZBO5P2NUJi_4core3ops5index8IndexMutINtNtBM_5range7RangeTojEE9index_mutCs4oicsBtN6nJ_15spiral_protocol.exit.i
  %258 = load i8, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 30), align 1, !dbg !31709, !nosanitize !4110
  %259 = add i8 %258, 1, !dbg !31709
  store i8 %259, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 30), align 1, !dbg !31709, !nosanitize !4110
  br label %270, !dbg !31709

260:                                              ; preds = %_RNvXse_NtCs95TQQ7nxHrj_5alloc3vecINtB5_3VechEINtNtNtCshZBO5P2NUJi_4core3ops5index8IndexMutINtNtBM_5range7RangeTojEE9index_mutCs4oicsBtN6nJ_15spiral_protocol.exit.i
  %261 = and i64 %252, 7, !dbg !31709
  %262 = add i64 %261, 3, !dbg !31709
  %263 = trunc i64 %262 to i8, !dbg !31709
  call void @__sanitizer_cov_trace_cmp1(i8 %263, i8 %256), !dbg !31709
  %264 = icmp sge i8 %263, %256, !dbg !31709
  br i1 %264, label %267, label %._crit_edge8, !dbg !31709

._crit_edge8:                                     ; preds = %260
  %265 = load i8, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 31), align 1, !dbg !31709, !nosanitize !4110
  %266 = add i8 %265, 1, !dbg !31709
  store i8 %266, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 31), align 1, !dbg !31709, !nosanitize !4110
  br label %270, !dbg !31709

267:                                              ; preds = %260
  %268 = load i8, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 32), align 1, !dbg !31709, !nosanitize !4110
  %269 = add i8 %268, 1, !dbg !31709
  store i8 %269, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 32), align 1, !dbg !31709, !nosanitize !4110
  call void @__asan_report_load4(i64 %252) #42, !dbg !31709
  unreachable

270:                                              ; preds = %._crit_edge8, %_RNvXse_NtCs95TQQ7nxHrj_5alloc3vecINtB5_3VechEINtNtNtCshZBO5P2NUJi_4core3ops5index8IndexMutINtNtBM_5range7RangeTojEE9index_mutCs4oicsBtN6nJ_15spiral_protocol.exit.i._crit_edge
  %_39.sroa.0.0.copyload.i = load i32, ptr %_18, align 8, !dbg !31709, !noalias !31583
  %271 = add i64 %38, 154
  %272 = inttoptr i64 %271 to ptr
  store i8 4, ptr %272, align 1
  store i32 %_39.sroa.0.0.copyload.i, ptr %26, align 4, !noalias !31710
  %273 = add i64 %38, 150, !dbg !31713
  %274 = inttoptr i64 %273 to ptr, !dbg !31713
  store i16 1024, ptr %274, align 1, !dbg !31713
  %275 = call ptr @__asan_memset(ptr %25, i32 0, i64 12), !dbg !31715
; call core::slice::copy_from_slice_impl::<u8>
  call void @_RINvNtCshZBO5P2NUJi_4core5slice20copy_from_slice_implhECs7jJvS58pafZ_4ring(ptr noalias nofree noundef nonnull %25, i64 noundef range(i64 0, -9223372036854775808) 4, ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) %26, i64 noundef 4, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_6f2dbdb6ae1f37cfa5b5aca94af9f1fb) #35, !dbg !31716, !noalias !31710
  %_11.i.i.i.i = getelementptr inbounds nuw i8, ptr %25, i64 4, !dbg !31718
  %276 = add i64 %38, 146, !dbg !31723
  %277 = inttoptr i64 %276 to ptr, !dbg !31723
  store i8 0, ptr %277, align 1, !dbg !31723
  %self1.i.i.i = call noundef i64 @llvm.bswap.i64(i64 %_8), !dbg !31724
  store i64 %self1.i.i.i, ptr %24, align 8, !dbg !31728, !noalias !31710
; call core::slice::copy_from_slice_impl::<u8>
  call void @_RINvNtCshZBO5P2NUJi_4core5slice20copy_from_slice_implhECs7jJvS58pafZ_4ring(ptr noalias nofree noundef nonnull %_11.i.i.i.i, i64 noundef range(i64 0, -9223372036854775808) 8, ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) %24, i64 noundef 8, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_91f5d2a8241d378b989535ff8e1d2b0c) #35, !dbg !31729, !noalias !31710
  %278 = add i64 %38, 146, !dbg !31731
  %279 = inttoptr i64 %278 to ptr, !dbg !31731
  store i8 -8, ptr %279, align 1, !dbg !31731
  %280 = call ptr @__asan_memcpy(ptr %29, ptr %25, i64 12), !dbg !31732
  %281 = add i64 %38, 150, !dbg !31733
  %282 = inttoptr i64 %281 to ptr, !dbg !31733
  store i16 -1800, ptr %282, align 1, !dbg !31733
  %283 = add i64 %38, 154, !dbg !31734
  %284 = inttoptr i64 %283 to ptr, !dbg !31734
  store i8 -8, ptr %284, align 1, !dbg !31734
  %285 = add i64 %38, 164, !dbg !31735
  %286 = inttoptr i64 %285 to ptr, !dbg !31735
  store i16 0, ptr %286, align 1, !dbg !31735
  call void @llvm.lifetime.start.p0(ptr nonnull %_42.sroa.11.i), !dbg !31737
  %287 = add i64 %38, 156, !dbg !31737
  %288 = inttoptr i64 %287 to ptr, !dbg !31737
  store i16 0, ptr %288, align 1, !dbg !31737
  %289 = add i64 %38, 158, !dbg !31737
  %290 = inttoptr i64 %289 to ptr, !dbg !31737
  store i8 1, ptr %290, align 1, !dbg !31737
  %291 = ptrtoint ptr %_6 to i64, !dbg !31738
  %292 = lshr i64 %291, 3, !dbg !31738
  %293 = add i64 %292, 2147450880, !dbg !31738
  %294 = inttoptr i64 %293 to ptr, !dbg !31738
  %295 = load i8, ptr %294, align 1, !dbg !31738
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %295), !dbg !31738
  %296 = icmp ne i8 %295, 0, !dbg !31738
  br i1 %296, label %299, label %._crit_edge9, !dbg !31738, !prof !4181

._crit_edge9:                                     ; preds = %270
  %297 = load i8, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 33), align 1, !dbg !31738, !nosanitize !4110
  %298 = add i8 %297, 1, !dbg !31738
  store i8 %298, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 33), align 1, !dbg !31738, !nosanitize !4110
  br label %308, !dbg !31738

299:                                              ; preds = %270
  %300 = and i64 %291, 7, !dbg !31738
  %301 = trunc i64 %300 to i8, !dbg !31738
  call void @__sanitizer_cov_trace_cmp1(i8 %301, i8 %295), !dbg !31738
  %302 = icmp sge i8 %301, %295, !dbg !31738
  br i1 %302, label %305, label %._crit_edge10, !dbg !31738

._crit_edge10:                                    ; preds = %299
  %303 = load i8, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 34), align 1, !dbg !31738, !nosanitize !4110
  %304 = add i8 %303, 1, !dbg !31738
  store i8 %304, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 34), align 1, !dbg !31738, !nosanitize !4110
  br label %308, !dbg !31738

305:                                              ; preds = %299
  %306 = load i8, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 35), align 1, !dbg !31738, !nosanitize !4110
  %307 = add i8 %306, 1, !dbg !31738
  store i8 %307, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 35), align 1, !dbg !31738, !nosanitize !4110
  call void @__asan_report_load1(i64 %291) #42, !dbg !31738
  unreachable

308:                                              ; preds = %._crit_edge10, %._crit_edge9
  %309 = load i8, ptr %_6, align 1, !dbg !31738, !range !4348, !alias.scope !31740, !noalias !31583, !noundef !4110
  %310 = trunc nuw i8 %309 to i1, !dbg !31738
  %x.i.i = getelementptr inbounds nuw i8, ptr %self, i64 38, !dbg !31743
  br i1 %310, label %bb25.i, label %bb26.i, !dbg !31737

panic7.i:                                         ; preds = %bb14.i
  %311 = load i8, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 36), align 1, !dbg !31645, !nosanitize !4110
  %312 = add i8 %311, 1, !dbg !31645
  store i8 %312, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 36), align 1, !dbg !31645, !nosanitize !4110
  call void @__asan_handle_no_return(), !dbg !31645
; call core::panicking::panic_const::panic_const_add_overflow
  call void @_RNvNtNtCshZBO5P2NUJi_4core9panicking11panic_const24panic_const_add_overflow(ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_00509356b62a7a6be769cc5e0764a318) #43, !dbg !31645, !noalias !31583
  unreachable, !dbg !31645

bb26.i:                                           ; preds = %308
  %313 = load i8, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 37), align 1, !dbg !31744, !nosanitize !4110
  %314 = add i8 %313, 1, !dbg !31744
  store i8 %314, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 37), align 1, !dbg !31744, !nosanitize !4110
  %315 = add i64 %38, 156, !dbg !31744
  %316 = inttoptr i64 %315 to ptr, !dbg !31744
  store i16 -1800, ptr %316, align 1, !dbg !31744
  %317 = add i64 %38, 158, !dbg !31744
  %318 = inttoptr i64 %317 to ptr, !dbg !31744
  store i8 -8, ptr %318, align 1, !dbg !31744
  br label %bb46.i, !dbg !31745

bb25.i:                                           ; preds = %308
  call void @llvm.experimental.noalias.scope.decl(metadata !31747), !dbg !31750
  %_6.i27.i = load i64, ptr %243, align 8, !dbg !31751, !alias.scope !31747, !noalias !31583, !noundef !4110
  call void @__sanitizer_cov_trace_cmp8(i64 %_23.0.i, i64 %_6.i27.i), !dbg !31556
  %_7.not.i.i.i = icmp ugt i64 %_23.0.i, %_6.i27.i
  br i1 %_7.not.i.i.i, label %bb3.i.i.i, label %_RNvXse_NtCs95TQQ7nxHrj_5alloc3vecINtB5_3VechEINtNtNtCshZBO5P2NUJi_4core3ops5index8IndexMutINtNtBM_5range5RangejEE9index_mutCs4oicsBtN6nJ_15spiral_protocol.exit.i, !dbg !31758, !prof !15873

bb3.i.i.i:                                        ; preds = %bb25.i
  %319 = load i8, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 38), align 1, !dbg !31763, !nosanitize !4110
  %320 = add i8 %319, 1, !dbg !31763
  store i8 %320, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 38), align 1, !dbg !31763, !nosanitize !4110
  call void @__asan_handle_no_return(), !dbg !31763
; call core::slice::index::slice_index_fail
  call void @_RNvNtNtCshZBO5P2NUJi_4core5slice5index16slice_index_fail(i64 noundef 40, i64 noundef %_23.0.i, i64 noundef range(i64 0, -9223372036854775808) %_6.i27.i, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_d078cd7c1be8706e157b7fc00a99de04) #43, !dbg !31763, !noalias !31764
  unreachable, !dbg !31763

_RNvXse_NtCs95TQQ7nxHrj_5alloc3vecINtB5_3VechEINtNtNtCshZBO5P2NUJi_4core3ops5index8IndexMutINtNtBM_5range5RangejEE9index_mutCs4oicsBtN6nJ_15spiral_protocol.exit.i: ; preds = %bb25.i
  %_7.i28.i = load ptr, ptr %242, align 8, !dbg !31767, !alias.scope !31747, !noalias !31583, !nonnull !4110, !noundef !4110
  %_16.i.i.i = getelementptr inbounds nuw i8, ptr %_7.i28.i, i64 40, !dbg !31776
  %321 = add i64 %38, 4, !dbg !31778
  call void @__asan_set_shadow_00(i64 %321, i64 92), !dbg !31778
  %322 = add i64 %38, 120, !dbg !31780
  %323 = inttoptr i64 %322 to ptr, !dbg !31780
  store i64 0, ptr %323, align 1, !dbg !31780
  %324 = add i64 %38, 128, !dbg !31780
  %325 = inttoptr i64 %324 to ptr, !dbg !31780
  store i64 0, ptr %325, align 1, !dbg !31780
  %326 = add i64 %38, 136, !dbg !31780
  %327 = inttoptr i64 %326 to ptr, !dbg !31780
  store i8 4, ptr %327, align 1, !dbg !31780
; call <cipher::stream_wrapper::StreamCipherCoreWrapper<chacha20::ChaChaCore<typenum::uint::UInt<typenum::uint::UInt<typenum::uint::UInt<typenum::uint::UInt<typenum::uint::UTerm, typenum::bit::B1>, typenum::bit::B0>, typenum::bit::B1>, typenum::bit::B0>>> as crypto_common::KeyIvInit>::new
  call fastcc void @_RNvXs3_NtCs3uTrKuTqj2Q_6cipher14stream_wrapperINtB5_23StreamCipherCoreWrapperINtCslD4gSC9HkLH_8chacha2010ChaChaCoreINtNtCs9T39WwoIZ0p_7typenum4uint4UIntIB1Q_IB1Q_IB1Q_NtB1S_5UTermNtNtB1U_3bit2B1ENtB2T_2B0EB2R_EB37_EEENtCs9ByizG5C30O_13crypto_common9KeyIvInit3newCs4oicsBtN6nJ_15spiral_protocol(ptr noalias nofree noundef sret([132 x i8]) align 4 captures(none) dereferenceable(132) %23, ptr noalias nofree noundef readonly captures(address, read_provenance) dereferenceable(32) %x.i.i, ptr noalias nofree noundef readonly captures(address, read_provenance) dereferenceable(12) %29) #35, !dbg !31780, !noalias !31781
  call void @llvm.experimental.noalias.scope.decl(metadata !31786), !dbg !31778
  call void @llvm.experimental.noalias.scope.decl(metadata !31789), !dbg !31778
  %328 = add i64 %38, 112, !dbg !31791
  %329 = inttoptr i64 %328 to ptr, !dbg !31791
  store i32 0, ptr %329, align 1, !dbg !31791
  %330 = call ptr @__asan_memset(ptr %22, i32 0, i64 32), !dbg !31793
; call <cipher::stream_wrapper::StreamCipherCoreWrapper<chacha20::ChaChaCore<typenum::uint::UInt<typenum::uint::UInt<typenum::uint::UInt<typenum::uint::UInt<typenum::uint::UTerm, typenum::bit::B1>, typenum::bit::B0>, typenum::bit::B1>, typenum::bit::B0>>> as cipher::stream::StreamCipher>::apply_keystream
  call fastcc void @_RNvYINtNtCs3uTrKuTqj2Q_6cipher14stream_wrapper23StreamCipherCoreWrapperINtCslD4gSC9HkLH_8chacha2010ChaChaCoreINtNtCs9T39WwoIZ0p_7typenum4uint4UIntIB1K_IB1K_IB1K_NtB1M_5UTermNtNtB1O_3bit2B1ENtB2N_2B0EB2L_EB31_EEENtNtB7_6stream12StreamCipher15apply_keystreamCs4oicsBtN6nJ_15spiral_protocol(ptr noalias nofree noundef align 4 dereferenceable(132) %23, ptr noalias nofree noundef nonnull %22, i64 noundef 32) #35, !dbg !31799, !noalias !31800
; call <poly1305::Poly1305 as crypto_common::KeyInit>::new
  call void @_RNvXs_Cs47sDuqytMRH_8poly1305NtB4_8Poly1305NtCs9ByizG5C30O_13crypto_common7KeyInit3new(ptr noalias nofree noundef sret([576 x i8]) align 32 captures(none) dereferenceable(736) %21, ptr noalias nofree noundef readonly captures(address, read_provenance) dereferenceable(32) %22) #35, !dbg !31801, !noalias !31781
; call <[u8] as zeroize::Zeroize>::zeroize
  call void @_RNvXs9_Cs5e7aMHj0NTS_7zeroizeShNtB5_7Zeroize7zeroizeB5_(ptr noalias nofree noundef nonnull %22, i64 noundef 32) #35, !dbg !31802, !noalias !31800
  %331 = getelementptr inbounds nuw i8, ptr %23, i64 48, !dbg !31803
  store i32 1, ptr %331, align 4, !dbg !31803, !alias.scope !31807, !noalias !31814
  %332 = getelementptr inbounds nuw i8, ptr %23, i64 128, !dbg !31817
  store i8 0, ptr %332, align 4, !dbg !31817, !alias.scope !31818, !noalias !31814
  %333 = getelementptr inbounds nuw i8, ptr %21, i64 576, !dbg !31819
  %334 = call ptr @__asan_memcpy(ptr %333, ptr %23, i64 132), !dbg !31820
  %335 = add i64 %38, 112, !dbg !31821
  %336 = inttoptr i64 %335 to ptr, !dbg !31821
  store i32 -117901064, ptr %336, align 1, !dbg !31821
  %337 = add i64 %38, 120, !dbg !31822
  %338 = inttoptr i64 %337 to ptr, !dbg !31822
  store i64 -506381209866536712, ptr %338, align 1, !dbg !31822
  %339 = add i64 %38, 128, !dbg !31822
  %340 = inttoptr i64 %339 to ptr, !dbg !31822
  store i64 -506381209866536712, ptr %340, align 1, !dbg !31822
  %341 = add i64 %38, 136, !dbg !31822
  %342 = inttoptr i64 %341 to ptr, !dbg !31822
  store i8 -8, ptr %342, align 1, !dbg !31822
; call <chacha20poly1305::cipher::Cipher<cipher::stream_wrapper::StreamCipherCoreWrapper<chacha20::ChaChaCore<typenum::uint::UInt<typenum::uint::UInt<typenum::uint::UInt<typenum::uint::UInt<typenum::uint::UTerm, typenum::bit::B1>, typenum::bit::B0>, typenum::bit::B1>, typenum::bit::B0>>>>>::encrypt_in_place_detached
  call void @_RNvMNtCskG2NEjLuYj5_16chacha20poly13056cipherINtB2_6CipherINtNtCs3uTrKuTqj2Q_6cipher14stream_wrapper23StreamCipherCoreWrapperINtCslD4gSC9HkLH_8chacha2010ChaChaCoreINtNtCs9T39WwoIZ0p_7typenum4uint4UIntIB2C_IB2C_IB2C_NtB2E_5UTermNtNtB2G_3bit2B1ENtB3F_2B0EB3D_EB3T_EEEE25encrypt_in_place_detachedCs4oicsBtN6nJ_15spiral_protocol(ptr noalias nofree noundef sret([17 x i8]) align 1 captures(address) dereferenceable(17) %27, ptr noalias nofree noundef align 32 captures(address) dereferenceable(736) %21, ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) %32, i64 noundef 40, ptr noalias nofree noundef nonnull %_16.i.i.i, i64 noundef range(i64 0, -9223372036854775808) %length.i) #35, !dbg !31823, !noalias !31583
  %343 = add i64 %38, 4, !dbg !31824
  call void @__asan_set_shadow_f8(i64 %343, i64 92), !dbg !31824
  call void @llvm.experimental.noalias.scope.decl(metadata !31825), !dbg !31828
  %344 = load i8, ptr %27, align 1, !dbg !31829, !range !4348, !alias.scope !31832, !noalias !31834, !noundef !4110
  %345 = trunc nuw i8 %344 to i1, !dbg !31829
  br i1 %345, label %_RNvXse_NtCs95TQQ7nxHrj_5alloc3vecINtB5_3VechEINtNtNtCshZBO5P2NUJi_4core3ops5index8IndexMutINtNtBM_5range5RangejEE9index_mutCs4oicsBtN6nJ_15spiral_protocol.exit.i._RINvMNtCshZBO5P2NUJi_4core6resultINtB3_6ResultINtCs18jWmPaaUdo_13generic_array12GenericArrayhINtNtCs9T39WwoIZ0p_7typenum4uint4UIntIB1u_IB1u_IB1u_IB1u_NtB1w_5UTermNtNtB1y_3bit2B1ENtB2C_2B0EB2Q_EB2Q_EB2Q_EENtCsjG0YvJ6QUY8_4aead5ErrorE7map_errNtNtCs4oicsBtN6nJ_15spiral_protocol5error5ErrorNCNCNvMNtB3U_7recordsNtB4I_2Tx6encode00EB3U_.exit.i_crit_edge, label %bb3.i31.i, !dbg !31835

_RNvXse_NtCs95TQQ7nxHrj_5alloc3vecINtB5_3VechEINtNtNtCshZBO5P2NUJi_4core3ops5index8IndexMutINtNtBM_5range5RangejEE9index_mutCs4oicsBtN6nJ_15spiral_protocol.exit.i._RINvMNtCshZBO5P2NUJi_4core6resultINtB3_6ResultINtCs18jWmPaaUdo_13generic_array12GenericArrayhINtNtCs9T39WwoIZ0p_7typenum4uint4UIntIB1u_IB1u_IB1u_IB1u_NtB1w_5UTermNtNtB1y_3bit2B1ENtB2C_2B0EB2Q_EB2Q_EB2Q_EENtCsjG0YvJ6QUY8_4aead5ErrorE7map_errNtNtCs4oicsBtN6nJ_15spiral_protocol5error5ErrorNCNCNvMNtB3U_7recordsNtB4I_2Tx6encode00EB3U_.exit.i_crit_edge: ; preds = %_RNvXse_NtCs95TQQ7nxHrj_5alloc3vecINtB5_3VechEINtNtNtCshZBO5P2NUJi_4core3ops5index8IndexMutINtNtBM_5range5RangejEE9index_mutCs4oicsBtN6nJ_15spiral_protocol.exit.i
  %346 = load i8, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 39), align 1, !dbg !31835, !nosanitize !4110
  %347 = add i8 %346, 1, !dbg !31835
  store i8 %347, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 39), align 1, !dbg !31835, !nosanitize !4110
  br label %_RINvMNtCshZBO5P2NUJi_4core6resultINtB3_6ResultINtCs18jWmPaaUdo_13generic_array12GenericArrayhINtNtCs9T39WwoIZ0p_7typenum4uint4UIntIB1u_IB1u_IB1u_IB1u_NtB1w_5UTermNtNtB1y_3bit2B1ENtB2C_2B0EB2Q_EB2Q_EB2Q_EENtCsjG0YvJ6QUY8_4aead5ErrorE7map_errNtNtCs4oicsBtN6nJ_15spiral_protocol5error5ErrorNCNCNvMNtB3U_7recordsNtB4I_2Tx6encode00EB3U_.exit.i, !dbg !31835

bb3.i31.i:                                        ; preds = %_RNvXse_NtCs95TQQ7nxHrj_5alloc3vecINtB5_3VechEINtNtNtCshZBO5P2NUJi_4core3ops5index8IndexMutINtNtBM_5range5RangejEE9index_mutCs4oicsBtN6nJ_15spiral_protocol.exit.i
  %348 = load i8, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 40), align 1, !dbg !31836, !nosanitize !4110
  %349 = add i8 %348, 1, !dbg !31836
  store i8 %349, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 40), align 1, !dbg !31836, !nosanitize !4110
  %350 = getelementptr inbounds nuw i8, ptr %27, i64 1, !dbg !31836
  %_42.sroa.5.1.copyload.i = load i8, ptr %350, align 1, !dbg !31836, !alias.scope !31837, !noalias !31583
  %_42.sroa.9.1..sroa_idx.i = getelementptr inbounds nuw i8, ptr %27, i64 2, !dbg !31836
  %_42.sroa.9.1.copyload.i = load i8, ptr %_42.sroa.9.1..sroa_idx.i, align 1, !dbg !31836, !alias.scope !31837, !noalias !31583
  %_42.sroa.11.1..sroa_idx.i = getelementptr inbounds nuw i8, ptr %27, i64 3, !dbg !31836
  %351 = call ptr @__asan_memcpy(ptr %_42.sroa.11.i, ptr %_42.sroa.11.1..sroa_idx.i, i64 14), !dbg !31836
  br label %_RINvMNtCshZBO5P2NUJi_4core6resultINtB3_6ResultINtCs18jWmPaaUdo_13generic_array12GenericArrayhINtNtCs9T39WwoIZ0p_7typenum4uint4UIntIB1u_IB1u_IB1u_IB1u_NtB1w_5UTermNtNtB1y_3bit2B1ENtB2C_2B0EB2Q_EB2Q_EB2Q_EENtCsjG0YvJ6QUY8_4aead5ErrorE7map_errNtNtCs4oicsBtN6nJ_15spiral_protocol5error5ErrorNCNCNvMNtB3U_7recordsNtB4I_2Tx6encode00EB3U_.exit.i, !dbg !31838

_RINvMNtCshZBO5P2NUJi_4core6resultINtB3_6ResultINtCs18jWmPaaUdo_13generic_array12GenericArrayhINtNtCs9T39WwoIZ0p_7typenum4uint4UIntIB1u_IB1u_IB1u_IB1u_NtB1w_5UTermNtNtB1y_3bit2B1ENtB2C_2B0EB2Q_EB2Q_EB2Q_EENtCsjG0YvJ6QUY8_4aead5ErrorE7map_errNtNtCs4oicsBtN6nJ_15spiral_protocol5error5ErrorNCNCNvMNtB3U_7recordsNtB4I_2Tx6encode00EB3U_.exit.i: ; preds = %_RNvXse_NtCs95TQQ7nxHrj_5alloc3vecINtB5_3VechEINtNtNtCshZBO5P2NUJi_4core3ops5index8IndexMutINtNtBM_5range5RangejEE9index_mutCs4oicsBtN6nJ_15spiral_protocol.exit.i._RINvMNtCshZBO5P2NUJi_4core6resultINtB3_6ResultINtCs18jWmPaaUdo_13generic_array12GenericArrayhINtNtCs9T39WwoIZ0p_7typenum4uint4UIntIB1u_IB1u_IB1u_IB1u_NtB1w_5UTermNtNtB1y_3bit2B1ENtB2C_2B0EB2Q_EB2Q_EB2Q_EENtCsjG0YvJ6QUY8_4aead5ErrorE7map_errNtNtCs4oicsBtN6nJ_15spiral_protocol5error5ErrorNCNCNvMNtB3U_7recordsNtB4I_2Tx6encode00EB3U_.exit.i_crit_edge, %bb3.i31.i
  %_42.sroa.5.0.i = phi i8 [ %_42.sroa.5.1.copyload.i, %bb3.i31.i ], [ 2, %_RNvXse_NtCs95TQQ7nxHrj_5alloc3vecINtB5_3VechEINtNtNtCshZBO5P2NUJi_4core3ops5index8IndexMutINtNtBM_5range5RangejEE9index_mutCs4oicsBtN6nJ_15spiral_protocol.exit.i._RINvMNtCshZBO5P2NUJi_4core6resultINtB3_6ResultINtCs18jWmPaaUdo_13generic_array12GenericArrayhINtNtCs9T39WwoIZ0p_7typenum4uint4UIntIB1u_IB1u_IB1u_IB1u_NtB1w_5UTermNtNtB1y_3bit2B1ENtB2C_2B0EB2Q_EB2Q_EB2Q_EENtCsjG0YvJ6QUY8_4aead5ErrorE7map_errNtNtCs4oicsBtN6nJ_15spiral_protocol5error5ErrorNCNCNvMNtB3U_7recordsNtB4I_2Tx6encode00EB3U_.exit.i_crit_edge ], !dbg !31839
  %_42.sroa.9.0.i = phi i8 [ %_42.sroa.9.1.copyload.i, %bb3.i31.i ], [ undef, %_RNvXse_NtCs95TQQ7nxHrj_5alloc3vecINtB5_3VechEINtNtNtCshZBO5P2NUJi_4core3ops5index8IndexMutINtNtBM_5range5RangejEE9index_mutCs4oicsBtN6nJ_15spiral_protocol.exit.i._RINvMNtCshZBO5P2NUJi_4core6resultINtB3_6ResultINtCs18jWmPaaUdo_13generic_array12GenericArrayhINtNtCs9T39WwoIZ0p_7typenum4uint4UIntIB1u_IB1u_IB1u_IB1u_NtB1w_5UTermNtNtB1y_3bit2B1ENtB2C_2B0EB2Q_EB2Q_EB2Q_EENtCsjG0YvJ6QUY8_4aead5ErrorE7map_errNtNtCs4oicsBtN6nJ_15spiral_protocol5error5ErrorNCNCNvMNtB3U_7recordsNtB4I_2Tx6encode00EB3U_.exit.i_crit_edge ]
  %352 = add i64 %38, 156, !dbg !31744
  %353 = inttoptr i64 %352 to ptr, !dbg !31744
  store i16 -1800, ptr %353, align 1, !dbg !31744
  %354 = add i64 %38, 158, !dbg !31744
  %355 = inttoptr i64 %354 to ptr, !dbg !31744
  store i8 -8, ptr %355, align 1, !dbg !31744
  br i1 %345, label %_RINvMNtCshZBO5P2NUJi_4core6resultINtB3_6ResultINtCs18jWmPaaUdo_13generic_array12GenericArrayhINtNtCs9T39WwoIZ0p_7typenum4uint4UIntIB1u_IB1u_IB1u_IB1u_NtB1w_5UTermNtNtB1y_3bit2B1ENtB2C_2B0EB2Q_EB2Q_EB2Q_EENtCsjG0YvJ6QUY8_4aead5ErrorE7map_errNtNtCs4oicsBtN6nJ_15spiral_protocol5error5ErrorNCNCNvMNtB3U_7recordsNtB4I_2Tx6encode00EB3U_.exit.i.bb46.i_crit_edge, label %bb3.i34.i, !dbg !31840

_RINvMNtCshZBO5P2NUJi_4core6resultINtB3_6ResultINtCs18jWmPaaUdo_13generic_array12GenericArrayhINtNtCs9T39WwoIZ0p_7typenum4uint4UIntIB1u_IB1u_IB1u_IB1u_NtB1w_5UTermNtNtB1y_3bit2B1ENtB2C_2B0EB2Q_EB2Q_EB2Q_EENtCsjG0YvJ6QUY8_4aead5ErrorE7map_errNtNtCs4oicsBtN6nJ_15spiral_protocol5error5ErrorNCNCNvMNtB3U_7recordsNtB4I_2Tx6encode00EB3U_.exit.i.bb46.i_crit_edge: ; preds = %_RINvMNtCshZBO5P2NUJi_4core6resultINtB3_6ResultINtCs18jWmPaaUdo_13generic_array12GenericArrayhINtNtCs9T39WwoIZ0p_7typenum4uint4UIntIB1u_IB1u_IB1u_IB1u_NtB1w_5UTermNtNtB1y_3bit2B1ENtB2C_2B0EB2Q_EB2Q_EB2Q_EENtCsjG0YvJ6QUY8_4aead5ErrorE7map_errNtNtCs4oicsBtN6nJ_15spiral_protocol5error5ErrorNCNCNvMNtB3U_7recordsNtB4I_2Tx6encode00EB3U_.exit.i
  %356 = load i8, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 41), align 1, !dbg !31840, !nosanitize !4110
  %357 = add i8 %356, 1, !dbg !31840
  store i8 %357, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 41), align 1, !dbg !31840, !nosanitize !4110
  br label %bb46.i, !dbg !31840

bb3.i34.i:                                        ; preds = %_RINvMNtCshZBO5P2NUJi_4core6resultINtB3_6ResultINtCs18jWmPaaUdo_13generic_array12GenericArrayhINtNtCs9T39WwoIZ0p_7typenum4uint4UIntIB1u_IB1u_IB1u_IB1u_NtB1w_5UTermNtNtB1y_3bit2B1ENtB2C_2B0EB2Q_EB2Q_EB2Q_EENtCsjG0YvJ6QUY8_4aead5ErrorE7map_errNtNtCs4oicsBtN6nJ_15spiral_protocol5error5ErrorNCNCNvMNtB3U_7recordsNtB4I_2Tx6encode00EB3U_.exit.i
  %val1.sroa.5.0.tag.sroa_idx.i = getelementptr inbounds nuw i8, ptr %28, i64 2, !dbg !31842
  %358 = call ptr @__asan_memcpy(ptr %val1.sroa.5.0.tag.sroa_idx.i, ptr %_42.sroa.11.i, i64 14), !dbg !31844
  call void @llvm.lifetime.end.p0(ptr nonnull %_42.sroa.11.i), !dbg !31845
  store i8 %_42.sroa.5.0.i, ptr %28, align 1, !dbg !31842, !noalias !31583
  %val1.sroa.4.0.tag.sroa_idx.i = getelementptr inbounds nuw i8, ptr %28, i64 1, !dbg !31842
  store i8 %_42.sroa.9.0.i, ptr %val1.sroa.4.0.tag.sroa_idx.i, align 1, !dbg !31842, !noalias !31583
  call void @llvm.experimental.noalias.scope.decl(metadata !31846), !dbg !31849
  %_6.i39.i = load i64, ptr %243, align 8, !dbg !31851, !alias.scope !31846, !noalias !31858, !noundef !4110
  call void @__sanitizer_cov_trace_cmp8(i64 %_23.0.i, i64 %_6.i39.i), !dbg !31860
  %_3.i.i.i = icmp ugt i64 %_23.0.i, %_6.i39.i, !dbg !31860
  br i1 %_3.i.i.i, label %bb1.i.i.i, label %_RNvXse_NtCs95TQQ7nxHrj_5alloc3vecINtB5_3VechEINtNtNtCshZBO5P2NUJi_4core3ops5index8IndexMutINtNtBM_5range9RangeFromjEE9index_mutCs4oicsBtN6nJ_15spiral_protocol.exit.i, !dbg !31860, !prof !4407

bb1.i.i.i:                                        ; preds = %bb3.i34.i
  %359 = load i8, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 42), align 1, !dbg !31864, !nosanitize !4110
  %360 = add i8 %359, 1, !dbg !31864
  store i8 %360, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 42), align 1, !dbg !31864, !nosanitize !4110
  call void @__asan_handle_no_return(), !dbg !31864
; call core::slice::index::slice_index_fail
  call void @_RNvNtNtCshZBO5P2NUJi_4core5slice5index16slice_index_fail(i64 noundef %_23.0.i, i64 noundef range(i64 0, -9223372036854775808) %_6.i39.i, i64 noundef range(i64 0, -9223372036854775808) %_6.i39.i, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_e919af20c1c2ad96f5bf35858781da71) #43, !dbg !31864, !noalias !31865
  unreachable, !dbg !31864

_RNvXse_NtCs95TQQ7nxHrj_5alloc3vecINtB5_3VechEINtNtNtCshZBO5P2NUJi_4core3ops5index8IndexMutINtNtBM_5range9RangeFromjEE9index_mutCs4oicsBtN6nJ_15spiral_protocol.exit.i: ; preds = %bb3.i34.i
  %_7.i40.i = load ptr, ptr %242, align 8, !dbg !31868, !alias.scope !31846, !noalias !31858, !nonnull !4110, !noundef !4110
  %new_len.i.i.i = sub nuw nsw i64 %_6.i39.i, %_23.0.i, !dbg !31877
  %_11.i.i.i = getelementptr inbounds nuw i8, ptr %_7.i40.i, i64 %_23.0.i, !dbg !31878
; call core::slice::copy_from_slice_impl::<u8>
  call void @_RINvNtCshZBO5P2NUJi_4core5slice20copy_from_slice_implhECs7jJvS58pafZ_4ring(ptr noalias nofree noundef nonnull %_11.i.i.i, i64 noundef range(i64 0, -9223372036854775808) %new_len.i.i.i, ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) %28, i64 noundef range(i64 0, -9223372036854775808) 16, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_38b06556c7164ba80a6e92631d690d8a) #35, !dbg !31880, !noalias !31583
  %361 = ptrtoint ptr %_21 to i64, !dbg !31882
  %362 = lshr i64 %361, 3, !dbg !31882
  %363 = add i64 %362, 2147450880, !dbg !31882
  %364 = inttoptr i64 %363 to ptr, !dbg !31882
  %365 = load i8, ptr %364, align 1, !dbg !31882
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %365), !dbg !31882
  %366 = icmp ne i8 %365, 0, !dbg !31882
  br i1 %366, label %367, label %370, !dbg !31882

367:                                              ; preds = %_RNvXse_NtCs95TQQ7nxHrj_5alloc3vecINtB5_3VechEINtNtNtCshZBO5P2NUJi_4core3ops5index8IndexMutINtNtBM_5range9RangeFromjEE9index_mutCs4oicsBtN6nJ_15spiral_protocol.exit.i
  %368 = load i8, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 43), align 1, !dbg !31882, !nosanitize !4110
  %369 = add i8 %368, 1, !dbg !31882
  store i8 %369, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 43), align 1, !dbg !31882, !nosanitize !4110
  call void @__asan_report_load8(i64 %361) #42, !dbg !31882
  unreachable, !dbg !31882

370:                                              ; preds = %_RNvXse_NtCs95TQQ7nxHrj_5alloc3vecINtB5_3VechEINtNtNtCshZBO5P2NUJi_4core3ops5index8IndexMutINtNtBM_5range9RangeFromjEE9index_mutCs4oicsBtN6nJ_15spiral_protocol.exit.i
  %371 = load i64, ptr %_21, align 8, !dbg !31882, !noalias !31583, !noundef !4110
  %_69.0.i = add i64 %371, %length.i, !dbg !31882
  call void @__sanitizer_cov_trace_cmp8(i64 %_69.0.i, i64 %length.i), !dbg !31882
  %_69.1.i = icmp ult i64 %_69.0.i, %length.i, !dbg !31882
  br i1 %_69.1.i, label %panic11.i, label %bb42.i, !dbg !31882

bb42.i:                                           ; preds = %370
  %372 = ptrtoint ptr %_21 to i64, !dbg !31882
  %373 = lshr i64 %372, 3, !dbg !31882
  %374 = add i64 %373, 2147450880, !dbg !31882
  %375 = inttoptr i64 %374 to ptr, !dbg !31882
  %376 = load i8, ptr %375, align 1, !dbg !31882
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %376), !dbg !31882
  %377 = icmp ne i8 %376, 0, !dbg !31882
  br i1 %377, label %378, label %381, !dbg !31882

378:                                              ; preds = %bb42.i
  %379 = load i8, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 44), align 1, !dbg !31882, !nosanitize !4110
  %380 = add i8 %379, 1, !dbg !31882
  store i8 %380, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 44), align 1, !dbg !31882, !nosanitize !4110
  call void @__asan_report_store8(i64 %372) #42, !dbg !31882
  unreachable, !dbg !31882

381:                                              ; preds = %bb42.i
  %382 = load i8, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 45), align 1, !dbg !31882, !nosanitize !4110
  %383 = add i8 %382, 1, !dbg !31882
  store i8 %383, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 45), align 1, !dbg !31882, !nosanitize !4110
  store i64 %_69.0.i, ptr %_21, align 8, !dbg !31882, !noalias !31583
  %result.sroa.0.0.copyload8 = load i64, ptr %33, align 8, !dbg !31883, !noalias !31884
  %result.sroa.9.0.copyload9 = load i8, ptr %242, align 8, !dbg !31883, !noalias !31884
  %result.sroa.13.0.buffer.i.sroa_idx = getelementptr inbounds nuw i8, ptr %33, i64 9, !dbg !31883
  %result.sroa.13.0.copyload10 = load i8, ptr %result.sroa.13.0.buffer.i.sroa_idx, align 1, !dbg !31883, !noalias !31884
  %result.sroa.15.0.buffer.i.sroa_idx = getelementptr inbounds nuw i8, ptr %33, i64 10, !dbg !31883
  %384 = call ptr @__asan_memcpy(ptr %result.sroa.15, ptr %result.sroa.15.0.buffer.i.sroa_idx, i64 22), !dbg !31883
  %385 = add i64 %38, 164, !dbg !31885
  %386 = inttoptr i64 %385 to ptr, !dbg !31885
  store i16 -1800, ptr %386, align 1, !dbg !31885
  %387 = add i64 %38, 168, !dbg !31886
  %388 = inttoptr i64 %387 to ptr, !dbg !31886
  store i16 -1800, ptr %388, align 1, !dbg !31886
  %389 = add i64 %38, 192, !dbg !31887
  %390 = inttoptr i64 %389 to ptr, !dbg !31887
  store i32 -117901064, ptr %390, align 1, !dbg !31887
  %391 = add i64 %38, 196, !dbg !31887
  %392 = inttoptr i64 %391 to ptr, !dbg !31887
  store i8 -8, ptr %392, align 1, !dbg !31887
  br label %_RNCNvMNtCs4oicsBtN6nJ_15spiral_protocol7recordsNtB4_2Tx6encode0B6_.exit, !dbg !31888

panic11.i:                                        ; preds = %370
  %393 = load i8, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 46), align 1, !dbg !31882, !nosanitize !4110
  %394 = add i8 %393, 1, !dbg !31882
  store i8 %394, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 46), align 1, !dbg !31882, !nosanitize !4110
  call void @__asan_handle_no_return(), !dbg !31882
; call core::panicking::panic_const::panic_const_add_overflow
  call void @_RNvNtNtCshZBO5P2NUJi_4core9panicking11panic_const24panic_const_add_overflow(ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_24203dc156860e3b7c4730271253c100) #43, !dbg !31882, !noalias !31583
  unreachable, !dbg !31882

bb46.i:                                           ; preds = %_RINvMNtCshZBO5P2NUJi_4core6resultINtB3_6ResultINtCs18jWmPaaUdo_13generic_array12GenericArrayhINtNtCs9T39WwoIZ0p_7typenum4uint4UIntIB1u_IB1u_IB1u_IB1u_NtB1w_5UTermNtNtB1y_3bit2B1ENtB2C_2B0EB2Q_EB2Q_EB2Q_EENtCsjG0YvJ6QUY8_4aead5ErrorE7map_errNtNtCs4oicsBtN6nJ_15spiral_protocol5error5ErrorNCNCNvMNtB3U_7recordsNtB4I_2Tx6encode00EB3U_.exit.i.bb46.i_crit_edge, %bb26.i
  %result.sroa.13.0 = phi i8 [ undef, %bb26.i ], [ %_42.sroa.9.0.i, %_RINvMNtCshZBO5P2NUJi_4core6resultINtB3_6ResultINtCs18jWmPaaUdo_13generic_array12GenericArrayhINtNtCs9T39WwoIZ0p_7typenum4uint4UIntIB1u_IB1u_IB1u_IB1u_NtB1w_5UTermNtNtB1y_3bit2B1ENtB2C_2B0EB2Q_EB2Q_EB2Q_EENtCsjG0YvJ6QUY8_4aead5ErrorE7map_errNtNtCs4oicsBtN6nJ_15spiral_protocol5error5ErrorNCNCNvMNtB3U_7recordsNtB4I_2Tx6encode00EB3U_.exit.i.bb46.i_crit_edge ]
  %result.sroa.9.0 = phi i8 [ 6, %bb26.i ], [ %_42.sroa.5.0.i, %_RINvMNtCshZBO5P2NUJi_4core6resultINtB3_6ResultINtCs18jWmPaaUdo_13generic_array12GenericArrayhINtNtCs9T39WwoIZ0p_7typenum4uint4UIntIB1u_IB1u_IB1u_IB1u_NtB1w_5UTermNtNtB1y_3bit2B1ENtB2C_2B0EB2Q_EB2Q_EB2Q_EENtCsjG0YvJ6QUY8_4aead5ErrorE7map_errNtNtCs4oicsBtN6nJ_15spiral_protocol5error5ErrorNCNCNvMNtB3U_7recordsNtB4I_2Tx6encode00EB3U_.exit.i.bb46.i_crit_edge ], !dbg !31889
  call void @llvm.lifetime.end.p0(ptr nonnull %_42.sroa.11.i), !dbg !31845
  %395 = add i64 %38, 164, !dbg !31885
  %396 = inttoptr i64 %395 to ptr, !dbg !31885
  store i16 -1800, ptr %396, align 1, !dbg !31885
  %397 = add i64 %38, 168, !dbg !31886
  %398 = inttoptr i64 %397 to ptr, !dbg !31886
  store i16 -1800, ptr %398, align 1, !dbg !31886
  br label %bb47.i, !dbg !31890

bb47.i:                                           ; preds = %bb10.i.bb47.i_crit_edge, %bb46.i, %bb6.i.critedge
  %result.sroa.13.1 = phi i8 [ %e.1.i.i, %bb6.i.critedge ], [ %result.sroa.13.0, %bb46.i ], [ undef, %bb10.i.bb47.i_crit_edge ]
  %result.sroa.9.1 = phi i8 [ %e.0.i.i, %bb6.i.critedge ], [ %result.sroa.9.0, %bb46.i ], [ 9, %bb10.i.bb47.i_crit_edge ], !dbg !31892
  %399 = add i64 %38, 192, !dbg !31887
  %400 = inttoptr i64 %399 to ptr, !dbg !31887
  store i32 -117901064, ptr %400, align 1, !dbg !31887
  %401 = add i64 %38, 196, !dbg !31887
  %402 = inttoptr i64 %401 to ptr, !dbg !31887
  store i8 -8, ptr %402, align 1, !dbg !31887
; call <spiral_protocol::buffer::Buffer as core::ops::drop::Drop>::drop
  call void @_RNvXs1_NtCs4oicsBtN6nJ_15spiral_protocol6bufferNtB5_6BufferNtNtNtCshZBO5P2NUJi_4core3ops4drop4Drop4drop(ptr noalias nofree noundef nonnull align 8 dereferenceable(32) %33) #35, !dbg !31893, !noalias !31583
; call <alloc::vec::Vec<u8> as core::ops::drop::Drop>::drop
  call void @_RNvXsp_NtCs95TQQ7nxHrj_5alloc3vecINtB5_3VechENtNtNtCshZBO5P2NUJi_4core3ops4drop4Drop4dropCs7jJvS58pafZ_4ring(ptr noalias nofree noundef nonnull align 8 dereferenceable(32) %33) #35, !dbg !31895, !noalias !31583
; call <alloc::raw_vec::RawVec<u8> as core::ops::drop::Drop>::drop
  call void @_RNvXs4_NtCs95TQQ7nxHrj_5alloc7raw_vecINtB5_6RawVechENtNtNtCshZBO5P2NUJi_4core3ops4drop4Drop4dropCs7jJvS58pafZ_4ring(ptr noalias nofree noundef nonnull align 8 dereferenceable(32) %33) #35, !dbg !31897, !noalias !31583
  %403 = getelementptr inbounds nuw i8, ptr %33, i64 24, !dbg !31893
  call void @llvm.experimental.noalias.scope.decl(metadata !31899), !dbg !31893
  %404 = load ptr, ptr %403, align 8, !dbg !31902, !alias.scope !31904, !noalias !31583, !noundef !4110
  %405 = icmp eq ptr %404, null, !dbg !31902
  br i1 %405, label %bb47.i._RNCNvMNtCs4oicsBtN6nJ_15spiral_protocol7recordsNtB4_2Tx6encode0B6_.exit_crit_edge, label %bb2.i.i.i, !dbg !31902

bb47.i._RNCNvMNtCs4oicsBtN6nJ_15spiral_protocol7recordsNtB4_2Tx6encode0B6_.exit_crit_edge: ; preds = %bb47.i
  %406 = load i8, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 47), align 1, !dbg !31902, !nosanitize !4110
  %407 = add i8 %406, 1, !dbg !31902
  store i8 %407, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 47), align 1, !dbg !31902, !nosanitize !4110
  br label %_RNCNvMNtCs4oicsBtN6nJ_15spiral_protocol7recordsNtB4_2Tx6encode0B6_.exit, !dbg !31902

bb2.i.i.i:                                        ; preds = %bb47.i
  %408 = ptrtoint ptr %404 to i64, !dbg !31907
  %409 = lshr i64 %408, 3, !dbg !31907
  %410 = add i64 %409, 2147450880, !dbg !31907
  %411 = inttoptr i64 %410 to ptr, !dbg !31907
  %412 = load i8, ptr %411, align 1, !dbg !31907
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %412), !dbg !31907
  %413 = icmp ne i8 %412, 0, !dbg !31907
  br i1 %413, label %414, label %417, !dbg !31907

414:                                              ; preds = %bb2.i.i.i
  %415 = load i8, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 48), align 1, !dbg !31907, !nosanitize !4110
  %416 = add i8 %415, 1, !dbg !31907
  store i8 %416, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 48), align 1, !dbg !31907, !nosanitize !4110
  call void @__asan_report_store8(i64 %408) #42, !dbg !31907
  unreachable, !dbg !31907

417:                                              ; preds = %bb2.i.i.i
  %_2.i.i.i.i.i = atomicrmw sub ptr %404, i64 1 release, align 8, !dbg !31907, !noalias !31912
  call void @__sanitizer_cov_trace_const_cmp8(i64 1, i64 %_2.i.i.i.i.i), !dbg !31917
  %418 = icmp eq i64 %_2.i.i.i.i.i, 1, !dbg !31917
  br i1 %418, label %bb2.i.i.i.i.i, label %._RNCNvMNtCs4oicsBtN6nJ_15spiral_protocol7recordsNtB4_2Tx6encode0B6_.exit_crit_edge, !dbg !31917

._RNCNvMNtCs4oicsBtN6nJ_15spiral_protocol7recordsNtB4_2Tx6encode0B6_.exit_crit_edge: ; preds = %417
  %419 = load i8, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 49), align 1, !dbg !31917, !nosanitize !4110
  %420 = add i8 %419, 1, !dbg !31917
  store i8 %420, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 49), align 1, !dbg !31917, !nosanitize !4110
  br label %_RNCNvMNtCs4oicsBtN6nJ_15spiral_protocol7recordsNtB4_2Tx6encode0B6_.exit, !dbg !31917

bb2.i.i.i.i.i:                                    ; preds = %417
  %421 = load i8, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 50), align 1, !dbg !31918, !nosanitize !4110
  %422 = add i8 %421, 1, !dbg !31918
  store i8 %422, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 50), align 1, !dbg !31918, !nosanitize !4110
  fence acquire, !dbg !31918
; call <alloc::rcs::arc::Arc<spiral_protocol::buffer::Pool>>::drop_slow
  call void @_RNvMsn_NtNtCs95TQQ7nxHrj_5alloc3rcs3arcINtB5_3ArcNtNtCs4oicsBtN6nJ_15spiral_protocol6buffer4PoolE9drop_slowBP_(ptr noalias nofree noundef nonnull readonly align 8 dereferenceable(8) %403) #35, !dbg !31920, !noalias !31583
  br label %_RNCNvMNtCs4oicsBtN6nJ_15spiral_protocol7recordsNtB4_2Tx6encode0B6_.exit, !dbg !31921

_RNCNvMNtCs4oicsBtN6nJ_15spiral_protocol7recordsNtB4_2Tx6encode0B6_.exit: ; preds = %._RNCNvMNtCs4oicsBtN6nJ_15spiral_protocol7recordsNtB4_2Tx6encode0B6_.exit_crit_edge, %bb47.i._RNCNvMNtCs4oicsBtN6nJ_15spiral_protocol7recordsNtB4_2Tx6encode0B6_.exit_crit_edge, %bb2.i.i.i.i.i, %381
  %result.sroa.13.2 = phi i8 [ %result.sroa.13.0.copyload10, %381 ], [ %result.sroa.13.1, %bb2.i.i.i.i.i ], [ %result.sroa.13.1, %._RNCNvMNtCs4oicsBtN6nJ_15spiral_protocol7recordsNtB4_2Tx6encode0B6_.exit_crit_edge ], [ %result.sroa.13.1, %bb47.i._RNCNvMNtCs4oicsBtN6nJ_15spiral_protocol7recordsNtB4_2Tx6encode0B6_.exit_crit_edge ], !dbg !31892
  %result.sroa.9.2 = phi i8 [ %result.sroa.9.0.copyload9, %381 ], [ %result.sroa.9.1, %bb2.i.i.i.i.i ], [ %result.sroa.9.1, %._RNCNvMNtCs4oicsBtN6nJ_15spiral_protocol7recordsNtB4_2Tx6encode0B6_.exit_crit_edge ], [ %result.sroa.9.1, %bb47.i._RNCNvMNtCs4oicsBtN6nJ_15spiral_protocol7recordsNtB4_2Tx6encode0B6_.exit_crit_edge ], !dbg !31892
  %result.sroa.0.2 = phi i64 [ %result.sroa.0.0.copyload8, %381 ], [ -1, %bb2.i.i.i.i.i ], [ -1, %._RNCNvMNtCs4oicsBtN6nJ_15spiral_protocol7recordsNtB4_2Tx6encode0B6_.exit_crit_edge ], [ -1, %bb47.i._RNCNvMNtCs4oicsBtN6nJ_15spiral_protocol7recordsNtB4_2Tx6encode0B6_.exit_crit_edge ], !dbg !31892
  %423 = add i64 %38, 202, !dbg !31888
  %424 = inttoptr i64 %423 to ptr, !dbg !31888
  store i32 -117901064, ptr %424, align 1, !dbg !31888
  call void @__sanitizer_cov_trace_const_cmp8(i64 -1, i64 %result.sroa.0.2), !dbg !31922
  %.not.i = icmp eq i64 %result.sroa.0.2, -1, !dbg !31922
  br i1 %.not.i, label %bb12, label %_RNCNvMNtCs4oicsBtN6nJ_15spiral_protocol7recordsNtB4_2Tx6encode0B6_.exit.bb15_crit_edge, !dbg !31930

_RNCNvMNtCs4oicsBtN6nJ_15spiral_protocol7recordsNtB4_2Tx6encode0B6_.exit.bb15_crit_edge: ; preds = %_RNCNvMNtCs4oicsBtN6nJ_15spiral_protocol7recordsNtB4_2Tx6encode0B6_.exit
  %425 = load i8, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 51), align 1, !dbg !31930, !nosanitize !4110
  %426 = add i8 %425, 1, !dbg !31930
  store i8 %426, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 51), align 1, !dbg !31930, !nosanitize !4110
  br label %bb15, !dbg !31930

bb12:                                             ; preds = %_RNCNvMNtCs4oicsBtN6nJ_15spiral_protocol7recordsNtB4_2Tx6encode0B6_.exit
  %427 = ptrtoint ptr %_6 to i64, !dbg !31931
  %428 = lshr i64 %427, 3, !dbg !31931
  %429 = add i64 %428, 2147450880, !dbg !31931
  %430 = inttoptr i64 %429 to ptr, !dbg !31931
  %431 = load i8, ptr %430, align 1, !dbg !31931
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %431), !dbg !31931
  %432 = icmp ne i8 %431, 0, !dbg !31931
  br i1 %432, label %435, label %bb12._crit_edge, !dbg !31931, !prof !4181

bb12._crit_edge:                                  ; preds = %bb12
  %433 = load i8, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 52), align 1, !dbg !31931, !nosanitize !4110
  %434 = add i8 %433, 1, !dbg !31931
  store i8 %434, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 52), align 1, !dbg !31931, !nosanitize !4110
  br label %444, !dbg !31931

435:                                              ; preds = %bb12
  %436 = and i64 %427, 7, !dbg !31931
  %437 = trunc i64 %436 to i8, !dbg !31931
  call void @__sanitizer_cov_trace_cmp1(i8 %437, i8 %431), !dbg !31931
  %438 = icmp sge i8 %437, %431, !dbg !31931
  br i1 %438, label %441, label %._crit_edge11, !dbg !31931

._crit_edge11:                                    ; preds = %435
  %439 = load i8, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 53), align 1, !dbg !31931, !nosanitize !4110
  %440 = add i8 %439, 1, !dbg !31931
  store i8 %440, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 53), align 1, !dbg !31931, !nosanitize !4110
  br label %444, !dbg !31931

441:                                              ; preds = %435
  %442 = load i8, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 54), align 1, !dbg !31931, !nosanitize !4110
  %443 = add i8 %442, 1, !dbg !31931
  store i8 %443, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 54), align 1, !dbg !31931, !nosanitize !4110
  call void @__asan_report_load1(i64 %427) #42, !dbg !31931
  unreachable

444:                                              ; preds = %._crit_edge11, %bb12._crit_edge
  %445 = load i8, ptr %_6, align 1, !dbg !31931, !range !4348, !alias.scope !31933, !noundef !4110
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %445), !dbg !31931
  %446 = icmp eq i8 %445, 0, !dbg !31931
  br i1 %446, label %._RINvNtCshZBO5P2NUJi_4core3ptr9drop_glueINtNtB4_6option6OptionINtCskG2NEjLuYj5_16chacha20poly130514ChaChaPoly1305INtNtCs3uTrKuTqj2Q_6cipher14stream_wrapper23StreamCipherCoreWrapperINtCslD4gSC9HkLH_8chacha2010ChaChaCoreINtNtCs9T39WwoIZ0p_7typenum4uint4UIntIB3u_IB3u_IB3u_NtB3w_5UTermNtNtB3y_3bit2B1ENtB4x_2B0EB4v_EB4L_EEEEEECs4oicsBtN6nJ_15spiral_protocol.exit3_crit_edge, label %bb2.i1, !dbg !31931

._RINvNtCshZBO5P2NUJi_4core3ptr9drop_glueINtNtB4_6option6OptionINtCskG2NEjLuYj5_16chacha20poly130514ChaChaPoly1305INtNtCs3uTrKuTqj2Q_6cipher14stream_wrapper23StreamCipherCoreWrapperINtCslD4gSC9HkLH_8chacha2010ChaChaCoreINtNtCs9T39WwoIZ0p_7typenum4uint4UIntIB3u_IB3u_IB3u_NtB3w_5UTermNtNtB3y_3bit2B1ENtB4x_2B0EB4v_EB4L_EEEEEECs4oicsBtN6nJ_15spiral_protocol.exit3_crit_edge: ; preds = %444
  %447 = load i8, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 55), align 1, !dbg !31931, !nosanitize !4110
  %448 = add i8 %447, 1, !dbg !31931
  store i8 %448, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 55), align 1, !dbg !31931, !nosanitize !4110
  br label %_RINvNtCshZBO5P2NUJi_4core3ptr9drop_glueINtNtB4_6option6OptionINtCskG2NEjLuYj5_16chacha20poly130514ChaChaPoly1305INtNtCs3uTrKuTqj2Q_6cipher14stream_wrapper23StreamCipherCoreWrapperINtCslD4gSC9HkLH_8chacha2010ChaChaCoreINtNtCs9T39WwoIZ0p_7typenum4uint4UIntIB3u_IB3u_IB3u_NtB3w_5UTermNtNtB3y_3bit2B1ENtB4x_2B0EB4v_EB4L_EEEEEECs4oicsBtN6nJ_15spiral_protocol.exit3, !dbg !31931

bb2.i1:                                           ; preds = %444
  %449 = load i8, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 56), align 1, !dbg !31931, !nosanitize !4110
  %450 = add i8 %449, 1, !dbg !31931
  store i8 %450, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 56), align 1, !dbg !31931, !nosanitize !4110
  %451 = getelementptr inbounds nuw i8, ptr %self, i64 38, !dbg !31931
; call <[u8] as zeroize::Zeroize>::zeroize
  call void @_RNvXs9_Cs5e7aMHj0NTS_7zeroizeShNtB5_7Zeroize7zeroizeB5_(ptr noalias nofree noundef nonnull dereferenceable(32) %451, i64 noundef 32) #35, !dbg !31936
  br label %_RINvNtCshZBO5P2NUJi_4core3ptr9drop_glueINtNtB4_6option6OptionINtCskG2NEjLuYj5_16chacha20poly130514ChaChaPoly1305INtNtCs3uTrKuTqj2Q_6cipher14stream_wrapper23StreamCipherCoreWrapperINtCslD4gSC9HkLH_8chacha2010ChaChaCoreINtNtCs9T39WwoIZ0p_7typenum4uint4UIntIB3u_IB3u_IB3u_NtB3w_5UTermNtNtB3y_3bit2B1ENtB4x_2B0EB4v_EB4L_EEEEEECs4oicsBtN6nJ_15spiral_protocol.exit3, !dbg !31931

_RINvNtCshZBO5P2NUJi_4core3ptr9drop_glueINtNtB4_6option6OptionINtCskG2NEjLuYj5_16chacha20poly130514ChaChaPoly1305INtNtCs3uTrKuTqj2Q_6cipher14stream_wrapper23StreamCipherCoreWrapperINtCslD4gSC9HkLH_8chacha2010ChaChaCoreINtNtCs9T39WwoIZ0p_7typenum4uint4UIntIB3u_IB3u_IB3u_NtB3w_5UTermNtNtB3y_3bit2B1ENtB4x_2B0EB4v_EB4L_EEEEEECs4oicsBtN6nJ_15spiral_protocol.exit3: ; preds = %._RINvNtCshZBO5P2NUJi_4core3ptr9drop_glueINtNtB4_6option6OptionINtCskG2NEjLuYj5_16chacha20poly130514ChaChaPoly1305INtNtCs3uTrKuTqj2Q_6cipher14stream_wrapper23StreamCipherCoreWrapperINtCslD4gSC9HkLH_8chacha2010ChaChaCoreINtNtCs9T39WwoIZ0p_7typenum4uint4UIntIB3u_IB3u_IB3u_NtB3w_5UTermNtNtB3y_3bit2B1ENtB4x_2B0EB4v_EB4L_EEEEEECs4oicsBtN6nJ_15spiral_protocol.exit3_crit_edge, %bb2.i1
  %452 = ptrtoint ptr %_6 to i64, !dbg !31939
  %453 = lshr i64 %452, 3, !dbg !31939
  %454 = add i64 %453, 2147450880, !dbg !31939
  %455 = inttoptr i64 %454 to ptr, !dbg !31939
  %456 = load i8, ptr %455, align 1, !dbg !31939
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %456), !dbg !31939
  %457 = icmp ne i8 %456, 0, !dbg !31939
  br i1 %457, label %460, label %_RINvNtCshZBO5P2NUJi_4core3ptr9drop_glueINtNtB4_6option6OptionINtCskG2NEjLuYj5_16chacha20poly130514ChaChaPoly1305INtNtCs3uTrKuTqj2Q_6cipher14stream_wrapper23StreamCipherCoreWrapperINtCslD4gSC9HkLH_8chacha2010ChaChaCoreINtNtCs9T39WwoIZ0p_7typenum4uint4UIntIB3u_IB3u_IB3u_NtB3w_5UTermNtNtB3y_3bit2B1ENtB4x_2B0EB4v_EB4L_EEEEEECs4oicsBtN6nJ_15spiral_protocol.exit3._crit_edge, !dbg !31939, !prof !4181

_RINvNtCshZBO5P2NUJi_4core3ptr9drop_glueINtNtB4_6option6OptionINtCskG2NEjLuYj5_16chacha20poly130514ChaChaPoly1305INtNtCs3uTrKuTqj2Q_6cipher14stream_wrapper23StreamCipherCoreWrapperINtCslD4gSC9HkLH_8chacha2010ChaChaCoreINtNtCs9T39WwoIZ0p_7typenum4uint4UIntIB3u_IB3u_IB3u_NtB3w_5UTermNtNtB3y_3bit2B1ENtB4x_2B0EB4v_EB4L_EEEEEECs4oicsBtN6nJ_15spiral_protocol.exit3._crit_edge: ; preds = %_RINvNtCshZBO5P2NUJi_4core3ptr9drop_glueINtNtB4_6option6OptionINtCskG2NEjLuYj5_16chacha20poly130514ChaChaPoly1305INtNtCs3uTrKuTqj2Q_6cipher14stream_wrapper23StreamCipherCoreWrapperINtCslD4gSC9HkLH_8chacha2010ChaChaCoreINtNtCs9T39WwoIZ0p_7typenum4uint4UIntIB3u_IB3u_IB3u_NtB3w_5UTermNtNtB3y_3bit2B1ENtB4x_2B0EB4v_EB4L_EEEEEECs4oicsBtN6nJ_15spiral_protocol.exit3
  %458 = load i8, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 57), align 1, !dbg !31939, !nosanitize !4110
  %459 = add i8 %458, 1, !dbg !31939
  store i8 %459, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 57), align 1, !dbg !31939, !nosanitize !4110
  br label %469, !dbg !31939

460:                                              ; preds = %_RINvNtCshZBO5P2NUJi_4core3ptr9drop_glueINtNtB4_6option6OptionINtCskG2NEjLuYj5_16chacha20poly130514ChaChaPoly1305INtNtCs3uTrKuTqj2Q_6cipher14stream_wrapper23StreamCipherCoreWrapperINtCslD4gSC9HkLH_8chacha2010ChaChaCoreINtNtCs9T39WwoIZ0p_7typenum4uint4UIntIB3u_IB3u_IB3u_NtB3w_5UTermNtNtB3y_3bit2B1ENtB4x_2B0EB4v_EB4L_EEEEEECs4oicsBtN6nJ_15spiral_protocol.exit3
  %461 = and i64 %452, 7, !dbg !31939
  %462 = trunc i64 %461 to i8, !dbg !31939
  call void @__sanitizer_cov_trace_cmp1(i8 %462, i8 %456), !dbg !31939
  %463 = icmp sge i8 %462, %456, !dbg !31939
  br i1 %463, label %466, label %._crit_edge12, !dbg !31939

._crit_edge12:                                    ; preds = %460
  %464 = load i8, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 58), align 1, !dbg !31939, !nosanitize !4110
  %465 = add i8 %464, 1, !dbg !31939
  store i8 %465, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 58), align 1, !dbg !31939, !nosanitize !4110
  br label %469, !dbg !31939

466:                                              ; preds = %460
  %467 = load i8, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 59), align 1, !dbg !31939, !nosanitize !4110
  %468 = add i8 %467, 1, !dbg !31939
  store i8 %468, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 59), align 1, !dbg !31939, !nosanitize !4110
  call void @__asan_report_store1(i64 %452) #42, !dbg !31939
  unreachable

469:                                              ; preds = %._crit_edge12, %_RINvNtCshZBO5P2NUJi_4core3ptr9drop_glueINtNtB4_6option6OptionINtCskG2NEjLuYj5_16chacha20poly130514ChaChaPoly1305INtNtCs3uTrKuTqj2Q_6cipher14stream_wrapper23StreamCipherCoreWrapperINtCslD4gSC9HkLH_8chacha2010ChaChaCoreINtNtCs9T39WwoIZ0p_7typenum4uint4UIntIB3u_IB3u_IB3u_NtB3w_5UTermNtNtB3y_3bit2B1ENtB4x_2B0EB4v_EB4L_EEEEEECs4oicsBtN6nJ_15spiral_protocol.exit3._crit_edge
  store i8 0, ptr %_6, align 1, !dbg !31939
  %470 = ptrtoint ptr %72 to i64, !dbg !31940
  %471 = lshr i64 %470, 3, !dbg !31940
  %472 = add i64 %471, 2147450880, !dbg !31940
  %473 = inttoptr i64 %472 to ptr, !dbg !31940
  %474 = load i8, ptr %473, align 1, !dbg !31940
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %474), !dbg !31940
  %475 = icmp ne i8 %474, 0, !dbg !31940
  br i1 %475, label %478, label %._crit_edge13, !dbg !31940, !prof !4181

._crit_edge13:                                    ; preds = %469
  %476 = load i8, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 60), align 1, !dbg !31940, !nosanitize !4110
  %477 = add i8 %476, 1, !dbg !31940
  store i8 %477, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 60), align 1, !dbg !31940, !nosanitize !4110
  br label %487, !dbg !31940

478:                                              ; preds = %469
  %479 = and i64 %470, 7, !dbg !31940
  %480 = trunc i64 %479 to i8, !dbg !31940
  call void @__sanitizer_cov_trace_cmp1(i8 %480, i8 %474), !dbg !31940
  %481 = icmp sge i8 %480, %474, !dbg !31940
  br i1 %481, label %484, label %._crit_edge14, !dbg !31940

._crit_edge14:                                    ; preds = %478
  %482 = load i8, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 61), align 1, !dbg !31940, !nosanitize !4110
  %483 = add i8 %482, 1, !dbg !31940
  store i8 %483, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 61), align 1, !dbg !31940, !nosanitize !4110
  br label %487, !dbg !31940

484:                                              ; preds = %478
  %485 = load i8, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 62), align 1, !dbg !31940, !nosanitize !4110
  %486 = add i8 %485, 1, !dbg !31940
  store i8 %486, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 62), align 1, !dbg !31940, !nosanitize !4110
  call void @__asan_report_store1(i64 %470) #42, !dbg !31940
  unreachable

487:                                              ; preds = %._crit_edge14, %._crit_edge13
  store i8 1, ptr %72, align 2, !dbg !31940
  br label %bb15, !dbg !31941

bb15:                                             ; preds = %_RNCNvMNtCs4oicsBtN6nJ_15spiral_protocol7recordsNtB4_2Tx6encode0B6_.exit.bb15_crit_edge, %487
  %488 = ptrtoint ptr %_0 to i64, !dbg !31942
  %489 = lshr i64 %488, 3, !dbg !31942
  %490 = add i64 %489, 2147450880, !dbg !31942
  %491 = inttoptr i64 %490 to ptr, !dbg !31942
  %492 = load i8, ptr %491, align 1, !dbg !31942
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %492), !dbg !31942
  %493 = icmp ne i8 %492, 0, !dbg !31942
  br i1 %493, label %494, label %497, !dbg !31942

494:                                              ; preds = %bb15
  %495 = load i8, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 63), align 1, !dbg !31942, !nosanitize !4110
  %496 = add i8 %495, 1, !dbg !31942
  store i8 %496, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 63), align 1, !dbg !31942, !nosanitize !4110
  call void @__asan_report_store8(i64 %488) #42, !dbg !31942
  unreachable, !dbg !31942

497:                                              ; preds = %bb15
  store i64 %result.sroa.0.2, ptr %_0, align 8, !dbg !31942
  %result.sroa.9.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !31942
  %498 = ptrtoint ptr %result.sroa.9.0._0.sroa_idx to i64, !dbg !31942
  %499 = lshr i64 %498, 3, !dbg !31942
  %500 = add i64 %499, 2147450880, !dbg !31942
  %501 = inttoptr i64 %500 to ptr, !dbg !31942
  %502 = load i8, ptr %501, align 1, !dbg !31942
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %502), !dbg !31942
  %503 = icmp ne i8 %502, 0, !dbg !31942
  br i1 %503, label %506, label %._crit_edge15, !dbg !31942, !prof !4181

._crit_edge15:                                    ; preds = %497
  %504 = load i8, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 64), align 1, !dbg !31942, !nosanitize !4110
  %505 = add i8 %504, 1, !dbg !31942
  store i8 %505, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 64), align 1, !dbg !31942, !nosanitize !4110
  br label %515, !dbg !31942

506:                                              ; preds = %497
  %507 = and i64 %498, 7, !dbg !31942
  %508 = trunc i64 %507 to i8, !dbg !31942
  call void @__sanitizer_cov_trace_cmp1(i8 %508, i8 %502), !dbg !31942
  %509 = icmp sge i8 %508, %502, !dbg !31942
  br i1 %509, label %512, label %._crit_edge16, !dbg !31942

._crit_edge16:                                    ; preds = %506
  %510 = load i8, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 65), align 1, !dbg !31942, !nosanitize !4110
  %511 = add i8 %510, 1, !dbg !31942
  store i8 %511, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 65), align 1, !dbg !31942, !nosanitize !4110
  br label %515, !dbg !31942

512:                                              ; preds = %506
  %513 = load i8, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 66), align 1, !dbg !31942, !nosanitize !4110
  %514 = add i8 %513, 1, !dbg !31942
  store i8 %514, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 66), align 1, !dbg !31942, !nosanitize !4110
  call void @__asan_report_store1(i64 %498) #42, !dbg !31942
  unreachable

515:                                              ; preds = %._crit_edge16, %._crit_edge15
  store i8 %result.sroa.9.2, ptr %result.sroa.9.0._0.sroa_idx, align 8, !dbg !31942
  %result.sroa.13.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 9, !dbg !31942
  %516 = ptrtoint ptr %result.sroa.13.0._0.sroa_idx to i64, !dbg !31942
  %517 = lshr i64 %516, 3, !dbg !31942
  %518 = add i64 %517, 2147450880, !dbg !31942
  %519 = inttoptr i64 %518 to ptr, !dbg !31942
  %520 = load i8, ptr %519, align 1, !dbg !31942
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %520), !dbg !31942
  %521 = icmp ne i8 %520, 0, !dbg !31942
  br i1 %521, label %524, label %._crit_edge17, !dbg !31942, !prof !4181

._crit_edge17:                                    ; preds = %515
  %522 = load i8, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 67), align 1, !dbg !31942, !nosanitize !4110
  %523 = add i8 %522, 1, !dbg !31942
  store i8 %523, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 67), align 1, !dbg !31942, !nosanitize !4110
  br label %533, !dbg !31942

524:                                              ; preds = %515
  %525 = and i64 %516, 7, !dbg !31942
  %526 = trunc i64 %525 to i8, !dbg !31942
  call void @__sanitizer_cov_trace_cmp1(i8 %526, i8 %520), !dbg !31942
  %527 = icmp sge i8 %526, %520, !dbg !31942
  br i1 %527, label %530, label %._crit_edge18, !dbg !31942

._crit_edge18:                                    ; preds = %524
  %528 = load i8, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 68), align 1, !dbg !31942, !nosanitize !4110
  %529 = add i8 %528, 1, !dbg !31942
  store i8 %529, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 68), align 1, !dbg !31942, !nosanitize !4110
  br label %533, !dbg !31942

530:                                              ; preds = %524
  %531 = load i8, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 69), align 1, !dbg !31942, !nosanitize !4110
  %532 = add i8 %531, 1, !dbg !31942
  store i8 %532, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 69), align 1, !dbg !31942, !nosanitize !4110
  call void @__asan_report_store1(i64 %516) #42, !dbg !31942
  unreachable

533:                                              ; preds = %._crit_edge18, %._crit_edge17
  store i8 %result.sroa.13.2, ptr %result.sroa.13.0._0.sroa_idx, align 1, !dbg !31942
  %result.sroa.15.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 10, !dbg !31942
  %534 = call ptr @__asan_memcpy(ptr %result.sroa.15.0._0.sroa_idx, ptr %result.sroa.15, i64 22), !dbg !31942
  call void @llvm.lifetime.end.p0(ptr nonnull %result.sroa.15), !dbg !31943
  br label %bb17, !dbg !31944

bb17:                                             ; preds = %.bb17_crit_edge20, %.bb17_crit_edge, %bb2.i.i.i.i.i7, %533
  store i64 1172321806, ptr %20, align 8, !dbg !31945
  call void @__sanitizer_cov_trace_const_cmp8(i64 0, i64 %11), !dbg !31945
  %535 = icmp ne i64 %11, 0, !dbg !31945
  br i1 %535, label %536, label %539, !dbg !31945

536:                                              ; preds = %bb17
  %537 = load i8, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 70), align 1, !dbg !31945, !nosanitize !4110
  %538 = add i8 %537, 1, !dbg !31945
  store i8 %538, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 70), align 1, !dbg !31945, !nosanitize !4110
  call void @__asan_stack_free_5(i64 %11, i64 1696), !dbg !31945
  br label %543, !dbg !31945

539:                                              ; preds = %bb17
  %540 = load i8, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 71), align 1, !dbg !31945, !nosanitize !4110
  %541 = add i8 %540, 1, !dbg !31945
  store i8 %541, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 71), align 1, !dbg !31945, !nosanitize !4110
  %542 = add i64 %38, 0, !dbg !31945
  call void @__asan_set_shadow_00(i64 %542, i64 212), !dbg !31945
  br label %543, !dbg !31945

543:                                              ; preds = %539, %536
  ret void, !dbg !31945

bb16:                                             ; preds = %.bb16_crit_edge5, %.bb16_crit_edge, %145
  %.sink = phi i8 [ 0, %145 ], [ 6, %.bb16_crit_edge5 ], [ 6, %.bb16_crit_edge ]
  %544 = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !31556
  %545 = ptrtoint ptr %544 to i64, !dbg !31556
  %546 = lshr i64 %545, 3, !dbg !31556
  %547 = add i64 %546, 2147450880, !dbg !31556
  %548 = inttoptr i64 %547 to ptr, !dbg !31556
  %549 = load i8, ptr %548, align 1, !dbg !31556
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %549), !dbg !31556
  %550 = icmp ne i8 %549, 0, !dbg !31556
  br i1 %550, label %553, label %bb16._crit_edge, !dbg !31556, !prof !4181

bb16._crit_edge:                                  ; preds = %bb16
  %551 = load i8, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 72), align 1, !dbg !31556, !nosanitize !4110
  %552 = add i8 %551, 1, !dbg !31556
  store i8 %552, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 72), align 1, !dbg !31556, !nosanitize !4110
  br label %562, !dbg !31556

553:                                              ; preds = %bb16
  %554 = and i64 %545, 7, !dbg !31556
  %555 = trunc i64 %554 to i8, !dbg !31556
  call void @__sanitizer_cov_trace_cmp1(i8 %555, i8 %549), !dbg !31556
  %556 = icmp sge i8 %555, %549, !dbg !31556
  br i1 %556, label %559, label %._crit_edge19, !dbg !31556

._crit_edge19:                                    ; preds = %553
  %557 = load i8, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 73), align 1, !dbg !31556, !nosanitize !4110
  %558 = add i8 %557, 1, !dbg !31556
  store i8 %558, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 73), align 1, !dbg !31556, !nosanitize !4110
  br label %562, !dbg !31556

559:                                              ; preds = %553
  %560 = load i8, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 74), align 1, !dbg !31556, !nosanitize !4110
  %561 = add i8 %560, 1, !dbg !31556
  store i8 %561, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 74), align 1, !dbg !31556, !nosanitize !4110
  call void @__asan_report_store1(i64 %545) #42, !dbg !31556
  unreachable

562:                                              ; preds = %._crit_edge19, %bb16._crit_edge
  store i8 %.sink, ptr %544, align 8, !dbg !31556
  %563 = ptrtoint ptr %_0 to i64, !dbg !31556
  %564 = lshr i64 %563, 3, !dbg !31556
  %565 = add i64 %564, 2147450880, !dbg !31556
  %566 = inttoptr i64 %565 to ptr, !dbg !31556
  %567 = load i8, ptr %566, align 1, !dbg !31556
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %567), !dbg !31556
  %568 = icmp ne i8 %567, 0, !dbg !31556
  br i1 %568, label %569, label %572, !dbg !31556

569:                                              ; preds = %562
  %570 = load i8, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 75), align 1, !dbg !31556, !nosanitize !4110
  %571 = add i8 %570, 1, !dbg !31556
  store i8 %571, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 75), align 1, !dbg !31556, !nosanitize !4110
  call void @__asan_report_store8(i64 %563) #42, !dbg !31556
  unreachable, !dbg !31556

572:                                              ; preds = %562
  store i64 -1, ptr %_0, align 8, !dbg !31556
; call <spiral_protocol::buffer::Buffer as core::ops::drop::Drop>::drop
  tail call void @_RNvXs1_NtCs4oicsBtN6nJ_15spiral_protocol6bufferNtB5_6BufferNtNtNtCshZBO5P2NUJi_4core3ops4drop4Drop4drop(ptr noalias nofree noundef nonnull align 8 dereferenceable(48) %p) #35, !dbg !31946
; call <alloc::vec::Vec<u8> as core::ops::drop::Drop>::drop
  tail call void @_RNvXsp_NtCs95TQQ7nxHrj_5alloc3vecINtB5_3VechENtNtNtCshZBO5P2NUJi_4core3ops4drop4Drop4dropCs7jJvS58pafZ_4ring(ptr noalias nofree noundef nonnull align 8 dereferenceable(48) %p) #35, !dbg !31949
; call <alloc::raw_vec::RawVec<u8> as core::ops::drop::Drop>::drop
  tail call void @_RNvXs4_NtCs95TQQ7nxHrj_5alloc7raw_vecINtB5_6RawVechENtNtNtCshZBO5P2NUJi_4core3ops4drop4Drop4dropCs7jJvS58pafZ_4ring(ptr noalias nofree noundef nonnull align 8 dereferenceable(48) %p) #35, !dbg !31951
  %573 = getelementptr inbounds nuw i8, ptr %p, i64 24, !dbg !31946
  tail call void @llvm.experimental.noalias.scope.decl(metadata !31953), !dbg !31946
  %574 = ptrtoint ptr %573 to i64, !dbg !31956
  %575 = lshr i64 %574, 3, !dbg !31956
  %576 = add i64 %575, 2147450880, !dbg !31956
  %577 = inttoptr i64 %576 to ptr, !dbg !31956
  %578 = load i8, ptr %577, align 1, !dbg !31956
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %578), !dbg !31956
  %579 = icmp ne i8 %578, 0, !dbg !31956
  br i1 %579, label %580, label %583, !dbg !31956

580:                                              ; preds = %572
  %581 = load i8, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 76), align 1, !dbg !31956, !nosanitize !4110
  %582 = add i8 %581, 1, !dbg !31956
  store i8 %582, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 76), align 1, !dbg !31956, !nosanitize !4110
  call void @__asan_report_load8(i64 %574) #42, !dbg !31956
  unreachable, !dbg !31956

583:                                              ; preds = %572
  %584 = load ptr, ptr %573, align 8, !dbg !31956, !alias.scope !31958, !noundef !4110
  %585 = icmp eq ptr %584, null, !dbg !31956
  br i1 %585, label %.bb17_crit_edge, label %bb2.i.i.i4, !dbg !31956

.bb17_crit_edge:                                  ; preds = %583
  %586 = load i8, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 77), align 1, !dbg !31956, !nosanitize !4110
  %587 = add i8 %586, 1, !dbg !31956
  store i8 %587, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 77), align 1, !dbg !31956, !nosanitize !4110
  br label %bb17, !dbg !31956

bb2.i.i.i4:                                       ; preds = %583
  %588 = ptrtoint ptr %584 to i64, !dbg !31963
  %589 = lshr i64 %588, 3, !dbg !31963
  %590 = add i64 %589, 2147450880, !dbg !31963
  %591 = inttoptr i64 %590 to ptr, !dbg !31963
  %592 = load i8, ptr %591, align 1, !dbg !31963
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %592), !dbg !31963
  %593 = icmp ne i8 %592, 0, !dbg !31963
  br i1 %593, label %594, label %597, !dbg !31963

594:                                              ; preds = %bb2.i.i.i4
  %595 = load i8, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 78), align 1, !dbg !31963, !nosanitize !4110
  %596 = add i8 %595, 1, !dbg !31963
  store i8 %596, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 78), align 1, !dbg !31963, !nosanitize !4110
  call void @__asan_report_store8(i64 %588) #42, !dbg !31963
  unreachable, !dbg !31963

597:                                              ; preds = %bb2.i.i.i4
  %_2.i.i.i.i.i5 = atomicrmw sub ptr %584, i64 1 release, align 8, !dbg !31963, !noalias !31968
  call void @__sanitizer_cov_trace_const_cmp8(i64 1, i64 %_2.i.i.i.i.i5), !dbg !31973
  %598 = icmp eq i64 %_2.i.i.i.i.i5, 1, !dbg !31973
  br i1 %598, label %bb2.i.i.i.i.i7, label %.bb17_crit_edge20, !dbg !31973

.bb17_crit_edge20:                                ; preds = %597
  %599 = load i8, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 79), align 1, !dbg !31973, !nosanitize !4110
  %600 = add i8 %599, 1, !dbg !31973
  store i8 %600, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 79), align 1, !dbg !31973, !nosanitize !4110
  br label %bb17, !dbg !31973

bb2.i.i.i.i.i7:                                   ; preds = %597
  %601 = load i8, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 80), align 1, !dbg !31974, !nosanitize !4110
  %602 = add i8 %601, 1, !dbg !31974
  store i8 %602, ptr getelementptr ([81 x i8], ptr @__sancov_gen_.1481, i64 0, i64 80), align 1, !dbg !31974, !nosanitize !4110
  fence acquire, !dbg !31974
; call <alloc::rcs::arc::Arc<spiral_protocol::buffer::Pool>>::drop_slow
  tail call void @_RNvMsn_NtNtCs95TQQ7nxHrj_5alloc3rcs3arcINtB5_3ArcNtNtCs4oicsBtN6nJ_15spiral_protocol6buffer4PoolE9drop_slowBP_(ptr noalias nofree noundef nonnull readonly align 8 dereferenceable(8) %573) #35, !dbg !31976
  br label %bb17, !dbg !31977
}

; Verified production function: rx_decode
define void @_RNvMs_NtCs4oicsBtN6nJ_15spiral_protocol7recordsNtB4_2Rx6decode(ptr dead_on_unwind noalias nofree noundef writable sret([56 x i8]) align 8 captures(none) dereferenceable(56) %result, ptr noalias nofree noundef align 8 dereferenceable(72) %self, ptr noalias nofree noundef readonly align 8 captures(none) dead_on_return dereferenceable(32) %buf) unnamed_addr #11 comdat personality ptr @rust_eh_personality !dbg !49248 !guid !49249 {
start:
  %_70.sroa.4.sroa.0.i = alloca [39 x i8], align 1
  %asan_local_stack_base = alloca i64, align 8
  %0 = load i8, ptr @__sancov_gen_.2018, align 1, !dbg !49250, !nosanitize !4110
  %1 = add i8 %0, 1, !dbg !49250
  store i8 %1, ptr @__sancov_gen_.2018, align 1, !dbg !49250, !nosanitize !4110
  %2 = load i32, ptr @__asan_option_detect_stack_use_after_return, align 4
  call void @__sanitizer_cov_trace_const_cmp4(i32 0, i32 %2), !dbg !49251
  %3 = icmp ne i32 %2, 0
  br i1 %3, label %6, label %start._crit_edge

start._crit_edge:                                 ; preds = %start
  %4 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 1), align 1, !dbg !49251, !nosanitize !4110
  %5 = add i8 %4, 1, !dbg !49251
  store i8 %5, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 1), align 1, !dbg !49251, !nosanitize !4110
  br label %10

6:                                                ; preds = %start
  %7 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 2), align 1, !dbg !49251, !nosanitize !4110
  %8 = add i8 %7, 1, !dbg !49251
  store i8 %8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 2), align 1, !dbg !49251, !nosanitize !4110
  %9 = call i64 @__asan_stack_malloc_3(i64 384)
  br label %10

10:                                               ; preds = %start._crit_edge, %6
  %11 = phi i64 [ 0, %start._crit_edge ], [ %9, %6 ]
  %12 = inttoptr i64 %11 to ptr
  call void @__sanitizer_cov_trace_const_cmp8(i64 0, i64 %11), !dbg !49251
  %13 = icmp eq i64 %11, 0
  br i1 %13, label %16, label %._crit_edge

._crit_edge:                                      ; preds = %10
  %14 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 3), align 1, !dbg !49251, !nosanitize !4110
  %15 = add i8 %14, 1, !dbg !49251
  store i8 %15, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 3), align 1, !dbg !49251, !nosanitize !4110
  br label %19

16:                                               ; preds = %10
  %17 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 4), align 1, !dbg !49251, !nosanitize !4110
  %18 = add i8 %17, 1, !dbg !49251
  store i8 %18, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 4), align 1, !dbg !49251, !nosanitize !4110
  %MyAlloca = alloca i8, i64 384, align 32
  br label %19

19:                                               ; preds = %._crit_edge, %16
  %20 = phi ptr [ %12, %._crit_edge ], [ %MyAlloca, %16 ]
  store ptr %20, ptr %asan_local_stack_base, align 8
  %21 = getelementptr i8, ptr %20, i64 32
  %22 = getelementptr i8, ptr %20, i64 64
  %23 = getelementptr i8, ptr %20, i64 96
  %24 = getelementptr i8, ptr %20, i64 128
  %25 = getelementptr i8, ptr %20, i64 144
  %26 = getelementptr i8, ptr %20, i64 224
  %27 = getelementptr i8, ptr %20, i64 256
  store i64 1102416563, ptr %20, align 8
  %28 = getelementptr i8, ptr %20, i64 8
  store i64 ptrtoint (ptr @___asan_gen_stack.213 to i64), ptr %28, align 8
  %29 = getelementptr i8, ptr %20, i64 16
  store i64 ptrtoint (ptr @_RNvMs_NtCs4oicsBtN6nJ_15spiral_protocol7recordsNtB4_2Rx6decode to i64), ptr %29, align 8
  %30 = ptrtoint ptr %20 to i64
  %31 = lshr i64 %30, 3
  %32 = add i64 %31, 2147450880
  %33 = add i64 %32, 0
  %34 = inttoptr i64 %33 to ptr
  store i64 -940422221142035983, ptr %34, align 1
  %35 = add i64 %32, 8
  %36 = inttoptr i64 %35 to ptr
  store i64 -940415624055426312, ptr %36, align 1
  %37 = add i64 %32, 16
  %38 = inttoptr i64 %37 to ptr
  store i64 -506381209866538248, ptr %38, align 1
  %39 = add i64 %32, 24
  %40 = inttoptr i64 %39 to ptr
  store i64 -940415624055426318, ptr %40, align 1
  %41 = add i64 %32, 32
  %42 = inttoptr i64 %41 to ptr
  store i64 -506381209866536712, ptr %42, align 1
  %43 = add i64 %32, 40
  %44 = inttoptr i64 %43 to ptr
  store i64 -868082074056591112, ptr %44, align 1
  %45 = add i64 %32, 32, !dbg !49252
  %46 = inttoptr i64 %45 to ptr, !dbg !49252
  store i64 0, ptr %46, align 1, !dbg !49252
  %47 = add i64 %32, 40, !dbg !49252
  %48 = inttoptr i64 %47 to ptr, !dbg !49252
  store i16 0, ptr %48, align 1, !dbg !49252
  %49 = add i64 %32, 42, !dbg !49252
  %50 = inttoptr i64 %49 to ptr, !dbg !49252
  store i8 0, ptr %50, align 1, !dbg !49252
  %_4 = getelementptr inbounds nuw i8, ptr %self, i64 37, !dbg !49252
  %_5 = getelementptr inbounds nuw i8, ptr %self, i64 32, !dbg !49252
  %_7 = getelementptr inbounds nuw i8, ptr %self, i64 36, !dbg !49252
  %_8 = getelementptr inbounds nuw i8, ptr %self, i64 16, !dbg !49252
  %_9 = getelementptr inbounds nuw i8, ptr %self, i64 24, !dbg !49252
  %_10 = getelementptr inbounds nuw i8, ptr %self, i64 70, !dbg !49252
  %51 = getelementptr inbounds nuw i8, ptr %27, i64 32, !dbg !49252
  store ptr %_4, ptr %51, align 8, !dbg !49252
  %52 = getelementptr inbounds nuw i8, ptr %27, i64 40, !dbg !49252
  store ptr %_5, ptr %52, align 8, !dbg !49252
  %53 = getelementptr inbounds nuw i8, ptr %27, i64 48, !dbg !49252
  store ptr %self, ptr %53, align 8, !dbg !49252
  %54 = getelementptr inbounds nuw i8, ptr %27, i64 56, !dbg !49252
  store ptr %_7, ptr %54, align 8, !dbg !49252
  %55 = getelementptr inbounds nuw i8, ptr %27, i64 64, !dbg !49252
  store ptr %_8, ptr %55, align 8, !dbg !49252
  %56 = getelementptr inbounds nuw i8, ptr %27, i64 72, !dbg !49252
  store ptr %_9, ptr %56, align 8, !dbg !49252
  %57 = getelementptr inbounds nuw i8, ptr %27, i64 80, !dbg !49252
  store ptr %_10, ptr %57, align 8, !dbg !49252
  %58 = call ptr @__asan_memcpy(ptr %27, ptr %buf, i64 32), !dbg !49252
  tail call void @llvm.experimental.noalias.scope.decl(metadata !49253), !dbg !49252
  tail call void @llvm.experimental.noalias.scope.decl(metadata !49256), !dbg !49252
  %59 = ptrtoint ptr %_10 to i64, !dbg !49258
  %60 = lshr i64 %59, 3, !dbg !49258
  %61 = add i64 %60, 2147450880, !dbg !49258
  %62 = inttoptr i64 %61 to ptr, !dbg !49258
  %63 = load i8, ptr %62, align 1, !dbg !49258
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %63), !dbg !49258
  %64 = icmp ne i8 %63, 0, !dbg !49258
  br i1 %64, label %67, label %._crit_edge3, !dbg !49258, !prof !4181

._crit_edge3:                                     ; preds = %19
  %65 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 5), align 1, !dbg !49258, !nosanitize !4110
  %66 = add i8 %65, 1, !dbg !49258
  store i8 %66, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 5), align 1, !dbg !49258, !nosanitize !4110
  br label %76, !dbg !49258

67:                                               ; preds = %19
  %68 = and i64 %59, 7, !dbg !49258
  %69 = trunc i64 %68 to i8, !dbg !49258
  call void @__sanitizer_cov_trace_cmp1(i8 %69, i8 %63), !dbg !49258
  %70 = icmp sge i8 %69, %63, !dbg !49258
  br i1 %70, label %73, label %._crit_edge4, !dbg !49258

._crit_edge4:                                     ; preds = %67
  %71 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 6), align 1, !dbg !49258, !nosanitize !4110
  %72 = add i8 %71, 1, !dbg !49258
  store i8 %72, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 6), align 1, !dbg !49258, !nosanitize !4110
  br label %76, !dbg !49258

73:                                               ; preds = %67
  %74 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 7), align 1, !dbg !49258, !nosanitize !4110
  %75 = add i8 %74, 1, !dbg !49258
  store i8 %75, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 7), align 1, !dbg !49258, !nosanitize !4110
  call void @__asan_report_load1(i64 %59) #42, !dbg !49258
  unreachable

76:                                               ; preds = %._crit_edge4, %._crit_edge3
  %77 = load i8, ptr %_10, align 2, !dbg !49258, !range !4348, !noalias !49263, !noundef !4110
  %_2.i = trunc nuw i8 %77 to i1, !dbg !49258
  br i1 %_2.i, label %.bb4.i_crit_edge, label %bb1.i, !dbg !49258

.bb4.i_crit_edge:                                 ; preds = %76
  %78 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 8), align 1, !dbg !49258, !nosanitize !4110
  %79 = add i8 %78, 1, !dbg !49258
  store i8 %79, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 8), align 1, !dbg !49258, !nosanitize !4110
  br label %bb4.i, !dbg !49258

bb1.i:                                            ; preds = %76
  %80 = ptrtoint ptr %_4 to i64, !dbg !49264
  %81 = lshr i64 %80, 3, !dbg !49264
  %82 = add i64 %81, 2147450880, !dbg !49264
  %83 = inttoptr i64 %82 to ptr, !dbg !49264
  %84 = load i8, ptr %83, align 1, !dbg !49264
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %84), !dbg !49264
  %85 = icmp ne i8 %84, 0, !dbg !49264
  br i1 %85, label %88, label %bb1.i._crit_edge, !dbg !49264, !prof !4181

bb1.i._crit_edge:                                 ; preds = %bb1.i
  %86 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 9), align 1, !dbg !49264, !nosanitize !4110
  %87 = add i8 %86, 1, !dbg !49264
  store i8 %87, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 9), align 1, !dbg !49264, !nosanitize !4110
  br label %97, !dbg !49264

88:                                               ; preds = %bb1.i
  %89 = and i64 %80, 7, !dbg !49264
  %90 = trunc i64 %89 to i8, !dbg !49264
  call void @__sanitizer_cov_trace_cmp1(i8 %90, i8 %84), !dbg !49264
  %91 = icmp sge i8 %90, %84, !dbg !49264
  br i1 %91, label %94, label %._crit_edge5, !dbg !49264

._crit_edge5:                                     ; preds = %88
  %92 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 10), align 1, !dbg !49264, !nosanitize !4110
  %93 = add i8 %92, 1, !dbg !49264
  store i8 %93, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 10), align 1, !dbg !49264, !nosanitize !4110
  br label %97, !dbg !49264

94:                                               ; preds = %88
  %95 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 11), align 1, !dbg !49264, !nosanitize !4110
  %96 = add i8 %95, 1, !dbg !49264
  store i8 %96, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 11), align 1, !dbg !49264, !nosanitize !4110
  call void @__asan_report_load1(i64 %80) #42, !dbg !49264
  unreachable

97:                                               ; preds = %._crit_edge5, %bb1.i._crit_edge
  %98 = load i8, ptr %_4, align 1, !dbg !49264, !range !4348, !alias.scope !49267, !noalias !49263, !noundef !4110
  %99 = trunc nuw i8 %98 to i1, !dbg !49264
  br i1 %99, label %bb5.i, label %.bb4.i_crit_edge6, !dbg !49270

.bb4.i_crit_edge6:                                ; preds = %97
  %100 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 12), align 1, !dbg !49270, !nosanitize !4110
  %101 = add i8 %100, 1, !dbg !49270
  store i8 %101, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 12), align 1, !dbg !49270, !nosanitize !4110
  br label %bb4.i, !dbg !49270

bb4.i:                                            ; preds = %.bb4.i_crit_edge6, %.bb4.i_crit_edge
  %102 = ptrtoint ptr %result to i64, !dbg !49271
  %103 = lshr i64 %102, 3, !dbg !49271
  %104 = add i64 %103, 2147450880, !dbg !49271
  %105 = inttoptr i64 %104 to ptr, !dbg !49271
  %106 = load i8, ptr %105, align 1, !dbg !49271
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %106), !dbg !49271
  %107 = icmp ne i8 %106, 0, !dbg !49271
  br i1 %107, label %110, label %bb4.i._crit_edge, !dbg !49271, !prof !4181

bb4.i._crit_edge:                                 ; preds = %bb4.i
  %108 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 13), align 1, !dbg !49271, !nosanitize !4110
  %109 = add i8 %108, 1, !dbg !49271
  store i8 %109, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 13), align 1, !dbg !49271, !nosanitize !4110
  br label %119, !dbg !49271

110:                                              ; preds = %bb4.i
  %111 = and i64 %102, 7, !dbg !49271
  %112 = trunc i64 %111 to i8, !dbg !49271
  call void @__sanitizer_cov_trace_cmp1(i8 %112, i8 %106), !dbg !49271
  %113 = icmp sge i8 %112, %106, !dbg !49271
  br i1 %113, label %116, label %._crit_edge7, !dbg !49271

._crit_edge7:                                     ; preds = %110
  %114 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 14), align 1, !dbg !49271, !nosanitize !4110
  %115 = add i8 %114, 1, !dbg !49271
  store i8 %115, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 14), align 1, !dbg !49271, !nosanitize !4110
  br label %119, !dbg !49271

116:                                              ; preds = %110
  %117 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 15), align 1, !dbg !49271, !nosanitize !4110
  %118 = add i8 %117, 1, !dbg !49271
  store i8 %118, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 15), align 1, !dbg !49271, !nosanitize !4110
  call void @__asan_report_store1(i64 %102) #42, !dbg !49271
  unreachable

119:                                              ; preds = %._crit_edge7, %bb4.i._crit_edge
  store i8 6, ptr %result, align 8, !dbg !49271, !alias.scope !49253, !noalias !49256
  %120 = getelementptr inbounds nuw i8, ptr %result, i64 8, !dbg !49271
  %121 = ptrtoint ptr %120 to i64, !dbg !49271
  %122 = lshr i64 %121, 3, !dbg !49271
  %123 = add i64 %122, 2147450880, !dbg !49271
  %124 = inttoptr i64 %123 to ptr, !dbg !49271
  %125 = load i8, ptr %124, align 1, !dbg !49271
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %125), !dbg !49271
  %126 = icmp ne i8 %125, 0, !dbg !49271
  br i1 %126, label %127, label %130, !dbg !49271

127:                                              ; preds = %119
  %128 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 16), align 1, !dbg !49271, !nosanitize !4110
  %129 = add i8 %128, 1, !dbg !49271
  store i8 %129, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 16), align 1, !dbg !49271, !nosanitize !4110
  call void @__asan_report_store8(i64 %121) #42, !dbg !49271
  unreachable, !dbg !49271

130:                                              ; preds = %119
  %131 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 17), align 1, !dbg !49271, !nosanitize !4110
  %132 = add i8 %131, 1, !dbg !49271
  store i8 %132, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 17), align 1, !dbg !49271, !nosanitize !4110
  store i64 -1, ptr %120, align 8, !dbg !49271, !alias.scope !49253, !noalias !49256
  br label %bb62.i, !dbg !49272

bb5.i:                                            ; preds = %97
  %133 = getelementptr inbounds nuw i8, ptr %27, i64 8, !dbg !49274
  %134 = getelementptr inbounds nuw i8, ptr %27, i64 16, !dbg !49281
  %_4.i.i = load i64, ptr %134, align 8, !dbg !49281, !alias.scope !49282, !noalias !49253, !noundef !4110
  call void @__sanitizer_cov_trace_const_cmp8(i64 40, i64 %_4.i.i), !dbg !49285
  %_2.i.i = icmp samesign ult i64 %_4.i.i, 40, !dbg !49285
  br i1 %_2.i.i, label %bb5.i._RNvNtCs4oicsBtN6nJ_15spiral_protocol4wire5parse.exit.i_crit_edge, label %bb2.i.i, !dbg !49285

bb5.i._RNvNtCs4oicsBtN6nJ_15spiral_protocol4wire5parse.exit.i_crit_edge: ; preds = %bb5.i
  %135 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 18), align 1, !dbg !49285, !nosanitize !4110
  %136 = add i8 %135, 1, !dbg !49285
  store i8 %136, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 18), align 1, !dbg !49285, !nosanitize !4110
  br label %_RNvNtCs4oicsBtN6nJ_15spiral_protocol4wire5parse.exit.i, !dbg !49285

bb2.i.i:                                          ; preds = %bb5.i
  %_5.i.i = load ptr, ptr %133, align 8, !dbg !49274, !alias.scope !49282, !noalias !49253, !nonnull !4110, !noundef !4110
  %137 = add i64 %32, 18, !dbg !49287
  %138 = inttoptr i64 %137 to ptr, !dbg !49287
  store i32 0, ptr %138, align 1, !dbg !49287
  %139 = add i64 %32, 22, !dbg !49287
  %140 = inttoptr i64 %139 to ptr, !dbg !49287
  store i16 0, ptr %140, align 1, !dbg !49287
; call <spiral_protocol::wire::Header>::parse
  call void @_RNvMNtCs4oicsBtN6nJ_15spiral_protocol4wireNtB2_6Header5parse(ptr noalias nofree noundef sret([48 x i8]) align 8 captures(none) dereferenceable(48) %25, ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) %_5.i.i, i64 noundef 40) #35, !dbg !49287, !noalias !49288
  tail call void @llvm.experimental.noalias.scope.decl(metadata !49291), !dbg !49287
  %141 = load i8, ptr %25, align 8, !dbg !49294, !range !4348, !alias.scope !49296, !noalias !49298, !noundef !4110
  %142 = trunc nuw i8 %141 to i1, !dbg !49294
  br i1 %142, label %bb2.i.i.i, label %bb3.i.i.i, !dbg !49300

bb2.i.i.i:                                        ; preds = %bb2.i.i
  %143 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 19), align 1, !dbg !49301, !nosanitize !4110
  %144 = add i8 %143, 1, !dbg !49301
  store i8 %144, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 19), align 1, !dbg !49301, !nosanitize !4110
  %145 = getelementptr inbounds nuw i8, ptr %25, i64 1, !dbg !49301
  %e.0.i.i.i = load i8, ptr %145, align 1, !dbg !49301, !range !18504, !alias.scope !49296, !noalias !49298, !noundef !4110
  %146 = getelementptr inbounds nuw i8, ptr %25, i64 2, !dbg !49301
  %e.1.i.i.i = load i8, ptr %146, align 2, !dbg !49301, !alias.scope !49296, !noalias !49298
  br label %_RNvXsp_NtCshZBO5P2NUJi_4core6resultINtB5_6ResultNtNtCs4oicsBtN6nJ_15spiral_protocol4wire6HeaderNtNtBO_5error5ErrorENtNtNtB7_3ops9try_trait3Try6branchBO_.exit.i.i, !dbg !49302

bb3.i.i.i:                                        ; preds = %bb2.i.i
  %147 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 20), align 1, !dbg !49303, !nosanitize !4110
  %148 = add i8 %147, 1, !dbg !49303
  store i8 %148, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 20), align 1, !dbg !49303, !nosanitize !4110
  %149 = getelementptr inbounds nuw i8, ptr %25, i64 8, !dbg !49303
  %_4.sroa.9.i.sroa.3.5.copyload.i = load i8, ptr %149, align 8, !dbg !49303, !alias.scope !49304, !noalias !49305
  %_4.sroa.9.i.sroa.5.5..sroa_idx.i = getelementptr inbounds nuw i8, ptr %25, i64 9, !dbg !49303
  %_4.sroa.9.i.sroa.5.5.copyload.i = load i8, ptr %_4.sroa.9.i.sroa.5.5..sroa_idx.i, align 1, !dbg !49303, !alias.scope !49304, !noalias !49305
  %_4.sroa.9.i.sroa.6.5..sroa_idx.i = getelementptr inbounds nuw i8, ptr %25, i64 10, !dbg !49303
  %_4.sroa.9.i.sroa.6.5.copyload.i = load i112, ptr %_4.sroa.9.i.sroa.6.5..sroa_idx.i, align 2, !dbg !49303, !alias.scope !49304, !noalias !49305
  %_4.sroa.9.i.sroa.7.5..sroa_idx.i = getelementptr inbounds nuw i8, ptr %25, i64 24, !dbg !49303
  %_4.sroa.9.i.sroa.7.5.copyload.i = load i64, ptr %_4.sroa.9.i.sroa.7.5..sroa_idx.i, align 8, !dbg !49303, !alias.scope !49304, !noalias !49305
  %_4.sroa.11.8..sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %25, i64 32, !dbg !49303
  %_4.sroa.11.8.copyload.i.i = load i64, ptr %_4.sroa.11.8..sroa_idx.i.i, align 8, !dbg !49303, !alias.scope !49304, !noalias !49305
  %_4.sroa.12.8..sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %25, i64 40, !dbg !49303
  %_4.sroa.12.8.copyload.i.i = load i64, ptr %_4.sroa.12.8..sroa_idx.i.i, align 8, !dbg !49303, !alias.scope !49304, !noalias !49305
  br label %_RNvXsp_NtCshZBO5P2NUJi_4core6resultINtB5_6ResultNtNtCs4oicsBtN6nJ_15spiral_protocol4wire6HeaderNtNtBO_5error5ErrorENtNtNtB7_3ops9try_trait3Try6branchBO_.exit.i.i, !dbg !49306

_RNvXsp_NtCshZBO5P2NUJi_4core6resultINtB5_6ResultNtNtCs4oicsBtN6nJ_15spiral_protocol4wire6HeaderNtNtBO_5error5ErrorENtNtNtB7_3ops9try_trait3Try6branchBO_.exit.i.i: ; preds = %bb3.i.i.i, %bb2.i.i.i
  %_4.sroa.9.i.sroa.3.0.i = phi i8 [ undef, %bb2.i.i.i ], [ %_4.sroa.9.i.sroa.3.5.copyload.i, %bb3.i.i.i ]
  %_4.sroa.9.i.sroa.5.0.i = phi i8 [ undef, %bb2.i.i.i ], [ %_4.sroa.9.i.sroa.5.5.copyload.i, %bb3.i.i.i ]
  %_4.sroa.9.i.sroa.6.0.i = phi i112 [ undef, %bb2.i.i.i ], [ %_4.sroa.9.i.sroa.6.5.copyload.i, %bb3.i.i.i ]
  %_4.sroa.9.i.sroa.7.0.i = phi i64 [ undef, %bb2.i.i.i ], [ %_4.sroa.9.i.sroa.7.5.copyload.i, %bb3.i.i.i ]
  %_4.sroa.11.0.i.i = phi i64 [ undef, %bb2.i.i.i ], [ %_4.sroa.11.8.copyload.i.i, %bb3.i.i.i ]
  %_4.sroa.7.0.i.i = phi i8 [ %e.1.i.i.i, %bb2.i.i.i ], [ undef, %bb3.i.i.i ]
  %_4.sroa.5.0.i.i = phi i8 [ %e.0.i.i.i, %bb2.i.i.i ], [ undef, %bb3.i.i.i ]
  %_4.sroa.12.0.i.i = phi i64 [ undef, %bb2.i.i.i ], [ %_4.sroa.12.8.copyload.i.i, %bb3.i.i.i ]
  %150 = add i64 %32, 18, !dbg !49307
  %151 = inttoptr i64 %150 to ptr, !dbg !49307
  store i32 -117901064, ptr %151, align 1, !dbg !49307
  %152 = add i64 %32, 22, !dbg !49307
  %153 = inttoptr i64 %152 to ptr, !dbg !49307
  store i16 -1800, ptr %153, align 1, !dbg !49307
  br i1 %142, label %_RNvXsp_NtCshZBO5P2NUJi_4core6resultINtB5_6ResultNtNtCs4oicsBtN6nJ_15spiral_protocol4wire6HeaderNtNtBO_5error5ErrorENtNtNtB7_3ops9try_trait3Try6branchBO_.exit.i.i._RNvNtCs4oicsBtN6nJ_15spiral_protocol4wire5parse.exit.i_crit_edge, label %bb7.i.i, !dbg !49287

_RNvXsp_NtCshZBO5P2NUJi_4core6resultINtB5_6ResultNtNtCs4oicsBtN6nJ_15spiral_protocol4wire6HeaderNtNtBO_5error5ErrorENtNtNtB7_3ops9try_trait3Try6branchBO_.exit.i.i._RNvNtCs4oicsBtN6nJ_15spiral_protocol4wire5parse.exit.i_crit_edge: ; preds = %_RNvXsp_NtCshZBO5P2NUJi_4core6resultINtB5_6ResultNtNtCs4oicsBtN6nJ_15spiral_protocol4wire6HeaderNtNtBO_5error5ErrorENtNtNtB7_3ops9try_trait3Try6branchBO_.exit.i.i
  %154 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 21), align 1, !dbg !49287, !nosanitize !4110
  %155 = add i8 %154, 1, !dbg !49287
  store i8 %155, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 21), align 1, !dbg !49287, !nosanitize !4110
  br label %_RNvNtCs4oicsBtN6nJ_15spiral_protocol4wire5parse.exit.i, !dbg !49287

bb7.i.i:                                          ; preds = %_RNvXsp_NtCshZBO5P2NUJi_4core6resultINtB5_6ResultNtNtCs4oicsBtN6nJ_15spiral_protocol4wire6HeaderNtNtBO_5error5ErrorENtNtNtB7_3ops9try_trait3Try6branchBO_.exit.i.i
  call void @__sanitizer_cov_trace_const_cmp8(i64 -41, i64 %_4.sroa.11.0.i.i), !dbg !49308
  %_13.1.i.i = icmp ugt i64 %_4.sroa.11.0.i.i, -41, !dbg !49308
  br i1 %_13.1.i.i, label %panic.i.i, label %bb10.i.i, !dbg !49308

bb10.i.i:                                         ; preds = %bb7.i.i
  %_13.0.i.i = add nuw i64 %_4.sroa.11.0.i.i, 40, !dbg !49308
  call void @__sanitizer_cov_trace_cmp8(i64 %_4.i.i, i64 %_13.0.i.i), !dbg !49309
  %_10.not.i.i = icmp eq i64 %_4.i.i, %_13.0.i.i, !dbg !49309
  br i1 %_10.not.i.i, label %bb12.i.i, label %bb10.i.i._RNvNtCs4oicsBtN6nJ_15spiral_protocol4wire5parse.exit.i_crit_edge, !dbg !49309

bb10.i.i._RNvNtCs4oicsBtN6nJ_15spiral_protocol4wire5parse.exit.i_crit_edge: ; preds = %bb10.i.i
  %156 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 22), align 1, !dbg !49309, !nosanitize !4110
  %157 = add i8 %156, 1, !dbg !49309
  store i8 %157, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 22), align 1, !dbg !49309, !nosanitize !4110
  br label %_RNvNtCs4oicsBtN6nJ_15spiral_protocol4wire5parse.exit.i, !dbg !49309

panic.i.i:                                        ; preds = %bb7.i.i
  %158 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 23), align 1, !dbg !49308, !nosanitize !4110
  %159 = add i8 %158, 1, !dbg !49308
  store i8 %159, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 23), align 1, !dbg !49308, !nosanitize !4110
  call void @__asan_handle_no_return(), !dbg !49308
; call core::panicking::panic_const::panic_const_add_overflow
  tail call void @_RNvNtNtCshZBO5P2NUJi_4core9panicking11panic_const24panic_const_add_overflow(ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_8261cc9843ad33371a73da063aa10507) #43, !dbg !49308, !noalias !49305
  unreachable, !dbg !49308

bb12.i.i:                                         ; preds = %bb10.i.i
  %160 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 24), align 1, !dbg !49310, !nosanitize !4110
  %161 = add i8 %160, 1, !dbg !49310
  store i8 %161, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 24), align 1, !dbg !49310, !nosanitize !4110
  br label %_RNvNtCs4oicsBtN6nJ_15spiral_protocol4wire5parse.exit.i, !dbg !49310

_RNvNtCs4oicsBtN6nJ_15spiral_protocol4wire5parse.exit.i: ; preds = %bb10.i.i._RNvNtCs4oicsBtN6nJ_15spiral_protocol4wire5parse.exit.i_crit_edge, %_RNvXsp_NtCshZBO5P2NUJi_4core6resultINtB5_6ResultNtNtCs4oicsBtN6nJ_15spiral_protocol4wire6HeaderNtNtBO_5error5ErrorENtNtNtB7_3ops9try_trait3Try6branchBO_.exit.i.i._RNvNtCs4oicsBtN6nJ_15spiral_protocol4wire5parse.exit.i_crit_edge, %bb5.i._RNvNtCs4oicsBtN6nJ_15spiral_protocol4wire5parse.exit.i_crit_edge, %bb12.i.i
  %_7.sroa.17.0.i = phi i1 [ true, %_RNvXsp_NtCshZBO5P2NUJi_4core6resultINtB5_6ResultNtNtCs4oicsBtN6nJ_15spiral_protocol4wire6HeaderNtNtBO_5error5ErrorENtNtNtB7_3ops9try_trait3Try6branchBO_.exit.i.i._RNvNtCs4oicsBtN6nJ_15spiral_protocol4wire5parse.exit.i_crit_edge ], [ true, %bb5.i._RNvNtCs4oicsBtN6nJ_15spiral_protocol4wire5parse.exit.i_crit_edge ], [ false, %bb12.i.i ], [ true, %bb10.i.i._RNvNtCs4oicsBtN6nJ_15spiral_protocol4wire5parse.exit.i_crit_edge ], !dbg !49311
  %_7.sroa.14.0.i = phi i64 [ undef, %_RNvXsp_NtCshZBO5P2NUJi_4core6resultINtB5_6ResultNtNtCs4oicsBtN6nJ_15spiral_protocol4wire6HeaderNtNtBO_5error5ErrorENtNtNtB7_3ops9try_trait3Try6branchBO_.exit.i.i._RNvNtCs4oicsBtN6nJ_15spiral_protocol4wire5parse.exit.i_crit_edge ], [ undef, %bb5.i._RNvNtCs4oicsBtN6nJ_15spiral_protocol4wire5parse.exit.i_crit_edge ], [ %_4.sroa.12.0.i.i, %bb12.i.i ], [ undef, %bb10.i.i._RNvNtCs4oicsBtN6nJ_15spiral_protocol4wire5parse.exit.i_crit_edge ]
  %_7.sroa.12.0.i = phi i64 [ undef, %_RNvXsp_NtCshZBO5P2NUJi_4core6resultINtB5_6ResultNtNtCs4oicsBtN6nJ_15spiral_protocol4wire6HeaderNtNtBO_5error5ErrorENtNtNtB7_3ops9try_trait3Try6branchBO_.exit.i.i._RNvNtCs4oicsBtN6nJ_15spiral_protocol4wire5parse.exit.i_crit_edge ], [ undef, %bb5.i._RNvNtCs4oicsBtN6nJ_15spiral_protocol4wire5parse.exit.i_crit_edge ], [ %_4.sroa.11.0.i.i, %bb12.i.i ], [ undef, %bb10.i.i._RNvNtCs4oicsBtN6nJ_15spiral_protocol4wire5parse.exit.i_crit_edge ]
  %_7.sroa.8.0.i = phi i8 [ %_4.sroa.7.0.i.i, %_RNvXsp_NtCshZBO5P2NUJi_4core6resultINtB5_6ResultNtNtCs4oicsBtN6nJ_15spiral_protocol4wire6HeaderNtNtBO_5error5ErrorENtNtNtB7_3ops9try_trait3Try6branchBO_.exit.i.i._RNvNtCs4oicsBtN6nJ_15spiral_protocol4wire5parse.exit.i_crit_edge ], [ undef, %bb5.i._RNvNtCs4oicsBtN6nJ_15spiral_protocol4wire5parse.exit.i_crit_edge ], [ %_4.sroa.9.i.sroa.5.0.i, %bb12.i.i ], [ undef, %bb10.i.i._RNvNtCs4oicsBtN6nJ_15spiral_protocol4wire5parse.exit.i_crit_edge ]
  %_7.sroa.0.0.i = phi i8 [ %_4.sroa.5.0.i.i, %_RNvXsp_NtCshZBO5P2NUJi_4core6resultINtB5_6ResultNtNtCs4oicsBtN6nJ_15spiral_protocol4wire6HeaderNtNtBO_5error5ErrorENtNtNtB7_3ops9try_trait3Try6branchBO_.exit.i.i._RNvNtCs4oicsBtN6nJ_15spiral_protocol4wire5parse.exit.i_crit_edge ], [ 0, %bb5.i._RNvNtCs4oicsBtN6nJ_15spiral_protocol4wire5parse.exit.i_crit_edge ], [ %_4.sroa.9.i.sroa.3.0.i, %bb12.i.i ], [ 0, %bb10.i.i._RNvNtCs4oicsBtN6nJ_15spiral_protocol4wire5parse.exit.i_crit_edge ], !dbg !49311
  %_7.sroa.11.sroa.0.0.i = phi i112 [ undef, %_RNvXsp_NtCshZBO5P2NUJi_4core6resultINtB5_6ResultNtNtCs4oicsBtN6nJ_15spiral_protocol4wire6HeaderNtNtBO_5error5ErrorENtNtNtB7_3ops9try_trait3Try6branchBO_.exit.i.i._RNvNtCs4oicsBtN6nJ_15spiral_protocol4wire5parse.exit.i_crit_edge ], [ undef, %bb5.i._RNvNtCs4oicsBtN6nJ_15spiral_protocol4wire5parse.exit.i_crit_edge ], [ %_4.sroa.9.i.sroa.6.0.i, %bb12.i.i ], [ undef, %bb10.i.i._RNvNtCs4oicsBtN6nJ_15spiral_protocol4wire5parse.exit.i_crit_edge ]
  %_7.sroa.11.sroa.4.0.i = phi i64 [ undef, %_RNvXsp_NtCshZBO5P2NUJi_4core6resultINtB5_6ResultNtNtCs4oicsBtN6nJ_15spiral_protocol4wire6HeaderNtNtBO_5error5ErrorENtNtNtB7_3ops9try_trait3Try6branchBO_.exit.i.i._RNvNtCs4oicsBtN6nJ_15spiral_protocol4wire5parse.exit.i_crit_edge ], [ undef, %bb5.i._RNvNtCs4oicsBtN6nJ_15spiral_protocol4wire5parse.exit.i_crit_edge ], [ %_4.sroa.9.i.sroa.7.0.i, %bb12.i.i ], [ undef, %bb10.i.i._RNvNtCs4oicsBtN6nJ_15spiral_protocol4wire5parse.exit.i_crit_edge ]
  br i1 %_7.sroa.17.0.i, label %bb11.i, label %bb3.i.i, !dbg !49312

bb3.i.i:                                          ; preds = %_RNvNtCs4oicsBtN6nJ_15spiral_protocol4wire5parse.exit.i
  %_7.sroa.14.32.extract.trunc.i = trunc i64 %_7.sroa.14.0.i to i8, !dbg !49315
  %val.sroa.0.sroa.0.sroa.3.0.insert.ext.i = zext i112 %_7.sroa.11.sroa.0.0.i to i128, !dbg !49317
  %val.sroa.0.sroa.0.sroa.3.0.insert.shift.i = shl nuw i128 %val.sroa.0.sroa.0.sroa.3.0.insert.ext.i, 16, !dbg !49317
  %val.sroa.0.sroa.0.sroa.2.0.insert.ext.i = zext i8 %_7.sroa.8.0.i to i128, !dbg !49317
  %val.sroa.0.sroa.0.sroa.2.0.insert.shift.i = shl nuw nsw i128 %val.sroa.0.sroa.0.sroa.2.0.insert.ext.i, 8, !dbg !49317
  %val.sroa.0.sroa.0.sroa.2.0.insert.insert.i = or disjoint i128 %val.sroa.0.sroa.0.sroa.3.0.insert.shift.i, %val.sroa.0.sroa.0.sroa.2.0.insert.shift.i, !dbg !49317
  %val.sroa.0.sroa.0.sroa.0.0.insert.ext.i = zext i8 %_7.sroa.0.0.i to i128, !dbg !49317
  %val.sroa.0.sroa.0.sroa.0.0.insert.insert.i = or disjoint i128 %val.sroa.0.sroa.0.sroa.2.0.insert.insert.i, %val.sroa.0.sroa.0.sroa.0.0.insert.ext.i, !dbg !49317
  %162 = ptrtoint ptr %_7 to i64, !dbg !49318
  %163 = lshr i64 %162, 3, !dbg !49318
  %164 = add i64 %163, 2147450880, !dbg !49318
  %165 = inttoptr i64 %164 to ptr, !dbg !49318
  %166 = load i8, ptr %165, align 1, !dbg !49318
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %166), !dbg !49318
  %167 = icmp ne i8 %166, 0, !dbg !49318
  br i1 %167, label %170, label %bb3.i.i._crit_edge, !dbg !49318, !prof !4181

bb3.i.i._crit_edge:                               ; preds = %bb3.i.i
  %168 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 25), align 1, !dbg !49318, !nosanitize !4110
  %169 = add i8 %168, 1, !dbg !49318
  store i8 %169, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 25), align 1, !dbg !49318, !nosanitize !4110
  br label %179, !dbg !49318

170:                                              ; preds = %bb3.i.i
  %171 = and i64 %162, 7, !dbg !49318
  %172 = trunc i64 %171 to i8, !dbg !49318
  call void @__sanitizer_cov_trace_cmp1(i8 %172, i8 %166), !dbg !49318
  %173 = icmp sge i8 %172, %166, !dbg !49318
  br i1 %173, label %176, label %._crit_edge8, !dbg !49318

._crit_edge8:                                     ; preds = %170
  %174 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 26), align 1, !dbg !49318, !nosanitize !4110
  %175 = add i8 %174, 1, !dbg !49318
  store i8 %175, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 26), align 1, !dbg !49318, !nosanitize !4110
  br label %179, !dbg !49318

176:                                              ; preds = %170
  %177 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 27), align 1, !dbg !49318, !nosanitize !4110
  %178 = add i8 %177, 1, !dbg !49318
  store i8 %178, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 27), align 1, !dbg !49318, !nosanitize !4110
  call void @__asan_report_load1(i64 %162) #42, !dbg !49318
  unreachable

179:                                              ; preds = %._crit_edge8, %bb3.i.i._crit_edge
  %_16.i = load i8, ptr %_7, align 4, !dbg !49318, !noalias !49263, !noundef !4110
  call void @__sanitizer_cov_trace_const_cmp1(i8 1, i8 %_16.i), !dbg !49320
  %_17.1.i = icmp ugt i8 %_16.i, 1, !dbg !49320
  br i1 %_17.1.i, label %panic.i, label %bb13.i, !dbg !49320

bb11.i:                                           ; preds = %_RNvNtCs4oicsBtN6nJ_15spiral_protocol4wire5parse.exit.i
  %180 = ptrtoint ptr %result to i64, !dbg !49321
  %181 = lshr i64 %180, 3, !dbg !49321
  %182 = add i64 %181, 2147450880, !dbg !49321
  %183 = inttoptr i64 %182 to ptr, !dbg !49321
  %184 = load i8, ptr %183, align 1, !dbg !49321
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %184), !dbg !49321
  %185 = icmp ne i8 %184, 0, !dbg !49321
  br i1 %185, label %188, label %bb11.i._crit_edge, !dbg !49321, !prof !4181

bb11.i._crit_edge:                                ; preds = %bb11.i
  %186 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 28), align 1, !dbg !49321, !nosanitize !4110
  %187 = add i8 %186, 1, !dbg !49321
  store i8 %187, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 28), align 1, !dbg !49321, !nosanitize !4110
  br label %197, !dbg !49321

188:                                              ; preds = %bb11.i
  %189 = and i64 %180, 7, !dbg !49321
  %190 = trunc i64 %189 to i8, !dbg !49321
  call void @__sanitizer_cov_trace_cmp1(i8 %190, i8 %184), !dbg !49321
  %191 = icmp sge i8 %190, %184, !dbg !49321
  br i1 %191, label %194, label %._crit_edge9, !dbg !49321

._crit_edge9:                                     ; preds = %188
  %192 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 29), align 1, !dbg !49321, !nosanitize !4110
  %193 = add i8 %192, 1, !dbg !49321
  store i8 %193, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 29), align 1, !dbg !49321, !nosanitize !4110
  br label %197, !dbg !49321

194:                                              ; preds = %188
  %195 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 30), align 1, !dbg !49321, !nosanitize !4110
  %196 = add i8 %195, 1, !dbg !49321
  store i8 %196, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 30), align 1, !dbg !49321, !nosanitize !4110
  call void @__asan_report_store1(i64 %180) #42, !dbg !49321
  unreachable

197:                                              ; preds = %._crit_edge9, %bb11.i._crit_edge
  store i8 %_7.sroa.0.0.i, ptr %result, align 8, !dbg !49321, !alias.scope !49326, !noalias !49256
  %198 = getelementptr inbounds nuw i8, ptr %result, i64 1, !dbg !49321
  %199 = ptrtoint ptr %198 to i64, !dbg !49321
  %200 = lshr i64 %199, 3, !dbg !49321
  %201 = add i64 %200, 2147450880, !dbg !49321
  %202 = inttoptr i64 %201 to ptr, !dbg !49321
  %203 = load i8, ptr %202, align 1, !dbg !49321
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %203), !dbg !49321
  %204 = icmp ne i8 %203, 0, !dbg !49321
  br i1 %204, label %207, label %._crit_edge10, !dbg !49321, !prof !4181

._crit_edge10:                                    ; preds = %197
  %205 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 31), align 1, !dbg !49321, !nosanitize !4110
  %206 = add i8 %205, 1, !dbg !49321
  store i8 %206, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 31), align 1, !dbg !49321, !nosanitize !4110
  br label %216, !dbg !49321

207:                                              ; preds = %197
  %208 = and i64 %199, 7, !dbg !49321
  %209 = trunc i64 %208 to i8, !dbg !49321
  call void @__sanitizer_cov_trace_cmp1(i8 %209, i8 %203), !dbg !49321
  %210 = icmp sge i8 %209, %203, !dbg !49321
  br i1 %210, label %213, label %._crit_edge11, !dbg !49321

._crit_edge11:                                    ; preds = %207
  %211 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 32), align 1, !dbg !49321, !nosanitize !4110
  %212 = add i8 %211, 1, !dbg !49321
  store i8 %212, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 32), align 1, !dbg !49321, !nosanitize !4110
  br label %216, !dbg !49321

213:                                              ; preds = %207
  %214 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 33), align 1, !dbg !49321, !nosanitize !4110
  %215 = add i8 %214, 1, !dbg !49321
  store i8 %215, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 33), align 1, !dbg !49321, !nosanitize !4110
  call void @__asan_report_store1(i64 %199) #42, !dbg !49321
  unreachable

216:                                              ; preds = %._crit_edge11, %._crit_edge10
  store i8 %_7.sroa.8.0.i, ptr %198, align 1, !dbg !49321, !alias.scope !49326, !noalias !49256
  %217 = getelementptr inbounds nuw i8, ptr %result, i64 8, !dbg !49321
  %218 = ptrtoint ptr %217 to i64, !dbg !49321
  %219 = lshr i64 %218, 3, !dbg !49321
  %220 = add i64 %219, 2147450880, !dbg !49321
  %221 = inttoptr i64 %220 to ptr, !dbg !49321
  %222 = load i8, ptr %221, align 1, !dbg !49321
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %222), !dbg !49321
  %223 = icmp ne i8 %222, 0, !dbg !49321
  br i1 %223, label %224, label %227, !dbg !49321

224:                                              ; preds = %216
  %225 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 34), align 1, !dbg !49321, !nosanitize !4110
  %226 = add i8 %225, 1, !dbg !49321
  store i8 %226, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 34), align 1, !dbg !49321, !nosanitize !4110
  call void @__asan_report_store8(i64 %218) #42, !dbg !49321
  unreachable, !dbg !49321

227:                                              ; preds = %216
  %228 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 35), align 1, !dbg !49321, !nosanitize !4110
  %229 = add i8 %228, 1, !dbg !49321
  store i8 %229, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 35), align 1, !dbg !49321, !nosanitize !4110
  store i64 -1, ptr %217, align 8, !dbg !49321, !alias.scope !49326, !noalias !49256
  br label %bb62.i, !dbg !49272

bb13.i:                                           ; preds = %179
  %_7.sroa.14.33.extract.shift.i = lshr i64 %_7.sroa.14.0.i, 8, !dbg !49315
  %extract.t.i = trunc i64 %_7.sroa.14.33.extract.shift.i to i8, !dbg !49329
  %_17.0.i = sub nuw nsw i8 1, %_16.i, !dbg !49320
  call void @__sanitizer_cov_trace_cmp1(i8 %_17.0.i, i8 %extract.t.i), !dbg !49330
  %_8.not.i.i = icmp eq i8 %_17.0.i, %extract.t.i, !dbg !49330
  br i1 %_8.not.i.i, label %bb5.i.i, label %bb13.i.bb10.i24.i_crit_edge, !dbg !49330

bb13.i.bb10.i24.i_crit_edge:                      ; preds = %bb13.i
  %230 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 36), align 1, !dbg !49330, !nosanitize !4110
  %231 = add i8 %230, 1, !dbg !49330
  store i8 %231, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 36), align 1, !dbg !49330, !nosanitize !4110
  br label %bb10.i24.i, !dbg !49330

bb5.i.i:                                          ; preds = %bb13.i
  %232 = ptrtoint ptr %_8 to i64, !dbg !49332
  %233 = lshr i64 %232, 3, !dbg !49332
  %234 = add i64 %233, 2147450880, !dbg !49332
  %235 = inttoptr i64 %234 to ptr, !dbg !49332
  %236 = load i8, ptr %235, align 1, !dbg !49332
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %236), !dbg !49332
  %237 = icmp ne i8 %236, 0, !dbg !49332
  br i1 %237, label %238, label %241, !dbg !49332

238:                                              ; preds = %bb5.i.i
  %239 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 37), align 1, !dbg !49332, !nosanitize !4110
  %240 = add i8 %239, 1, !dbg !49332
  store i8 %240, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 37), align 1, !dbg !49332, !nosanitize !4110
  call void @__asan_report_load8(i64 %232) #42, !dbg !49332
  unreachable, !dbg !49332

241:                                              ; preds = %bb5.i.i
  %_20.i = load i64, ptr %_8, align 8, !dbg !49332, !noalias !49263, !noundef !4110
  %242 = ptrtoint ptr %self to i64, !dbg !49333
  %243 = lshr i64 %242, 3, !dbg !49333
  %244 = add i64 %243, 2147450880, !dbg !49333
  %245 = inttoptr i64 %244 to ptr, !dbg !49333
  %246 = load i16, ptr %245, align 1, !dbg !49333
  call void @__sanitizer_cov_trace_const_cmp2(i16 0, i16 %246), !dbg !49333
  %247 = icmp ne i16 %246, 0, !dbg !49333
  br i1 %247, label %248, label %251, !dbg !49333

248:                                              ; preds = %241
  %249 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 38), align 1, !dbg !49333, !nosanitize !4110
  %250 = add i8 %249, 1, !dbg !49333
  store i8 %250, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 38), align 1, !dbg !49333, !nosanitize !4110
  call void @__asan_report_load16(i64 %242) #42, !dbg !49333
  unreachable, !dbg !49333

251:                                              ; preds = %241
  %_19.sroa.0.0.copyload.i = load i128, ptr %self, align 8, !dbg !49333, !noalias !49263
  %_3.i.i.i.i.not.i.i = icmp eq i128 %_19.sroa.0.0.copyload.i, %val.sroa.0.sroa.0.sroa.0.0.insert.insert.i, !dbg !49334
  call void @__sanitizer_cov_trace_cmp8(i64 %_20.i, i64 %_7.sroa.11.sroa.4.0.i), !dbg !49251
  %_12.not.i.i = icmp eq i64 %_20.i, %_7.sroa.11.sroa.4.0.i
  %or.cond.i = select i1 %_3.i.i.i.i.not.i.i, i1 %_12.not.i.i, i1 false, !dbg !49340
  br i1 %or.cond.i, label %bb16.i, label %.bb10.i24.i_crit_edge, !dbg !49340

.bb10.i24.i_crit_edge:                            ; preds = %251
  %252 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 39), align 1, !dbg !49340, !nosanitize !4110
  %253 = add i8 %252, 1, !dbg !49340
  store i8 %253, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 39), align 1, !dbg !49340, !nosanitize !4110
  br label %bb10.i24.i, !dbg !49340

bb10.i24.i:                                       ; preds = %.bb10.i24.i_crit_edge, %bb13.i.bb10.i24.i_crit_edge
  %254 = ptrtoint ptr %result to i64, !dbg !49341
  %255 = lshr i64 %254, 3, !dbg !49341
  %256 = add i64 %255, 2147450880, !dbg !49341
  %257 = inttoptr i64 %256 to ptr, !dbg !49341
  %258 = load i8, ptr %257, align 1, !dbg !49341
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %258), !dbg !49341
  %259 = icmp ne i8 %258, 0, !dbg !49341
  br i1 %259, label %262, label %bb10.i24.i._crit_edge, !dbg !49341, !prof !4181

bb10.i24.i._crit_edge:                            ; preds = %bb10.i24.i
  %260 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 40), align 1, !dbg !49341, !nosanitize !4110
  %261 = add i8 %260, 1, !dbg !49341
  store i8 %261, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 40), align 1, !dbg !49341, !nosanitize !4110
  br label %271, !dbg !49341

262:                                              ; preds = %bb10.i24.i
  %263 = and i64 %254, 7, !dbg !49341
  %264 = trunc i64 %263 to i8, !dbg !49341
  call void @__sanitizer_cov_trace_cmp1(i8 %264, i8 %258), !dbg !49341
  %265 = icmp sge i8 %264, %258, !dbg !49341
  br i1 %265, label %268, label %._crit_edge12, !dbg !49341

._crit_edge12:                                    ; preds = %262
  %266 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 41), align 1, !dbg !49341, !nosanitize !4110
  %267 = add i8 %266, 1, !dbg !49341
  store i8 %267, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 41), align 1, !dbg !49341, !nosanitize !4110
  br label %271, !dbg !49341

268:                                              ; preds = %262
  %269 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 42), align 1, !dbg !49341, !nosanitize !4110
  %270 = add i8 %269, 1, !dbg !49341
  store i8 %270, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 42), align 1, !dbg !49341, !nosanitize !4110
  call void @__asan_report_store1(i64 %254) #42, !dbg !49341
  unreachable

271:                                              ; preds = %._crit_edge12, %bb10.i24.i._crit_edge
  store i8 0, ptr %result, align 8, !dbg !49341, !alias.scope !49344, !noalias !49256
  %272 = getelementptr inbounds nuw i8, ptr %result, i64 8, !dbg !49341
  %273 = ptrtoint ptr %272 to i64, !dbg !49341
  %274 = lshr i64 %273, 3, !dbg !49341
  %275 = add i64 %274, 2147450880, !dbg !49341
  %276 = inttoptr i64 %275 to ptr, !dbg !49341
  %277 = load i8, ptr %276, align 1, !dbg !49341
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %277), !dbg !49341
  %278 = icmp ne i8 %277, 0, !dbg !49341
  br i1 %278, label %279, label %282, !dbg !49341

279:                                              ; preds = %271
  %280 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 43), align 1, !dbg !49341, !nosanitize !4110
  %281 = add i8 %280, 1, !dbg !49341
  store i8 %281, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 43), align 1, !dbg !49341, !nosanitize !4110
  call void @__asan_report_store8(i64 %273) #42, !dbg !49341
  unreachable, !dbg !49341

282:                                              ; preds = %271
  %283 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 44), align 1, !dbg !49341, !nosanitize !4110
  %284 = add i8 %283, 1, !dbg !49341
  store i8 %284, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 44), align 1, !dbg !49341, !nosanitize !4110
  store i64 -1, ptr %272, align 8, !dbg !49341, !alias.scope !49344, !noalias !49256
  br label %bb62.i, !dbg !49347

panic.i:                                          ; preds = %179
  %285 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 45), align 1, !dbg !49320, !nosanitize !4110
  %286 = add i8 %285, 1, !dbg !49320
  store i8 %286, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 45), align 1, !dbg !49320, !nosanitize !4110
  call void @__asan_handle_no_return(), !dbg !49320
; call core::panicking::panic_const::panic_const_sub_overflow
  tail call void @_RNvNtNtCshZBO5P2NUJi_4core9panicking11panic_const24panic_const_sub_overflow(ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_49df60ed7fd7dba04cb3078e3b344e44) #43, !dbg !49320, !noalias !49263
  unreachable, !dbg !49320

bb16.i:                                           ; preds = %251
  %287 = and i8 %_7.sroa.14.32.extract.trunc.i, -2, !dbg !49349
  call void @__sanitizer_cov_trace_const_cmp1(i8 16, i8 %287), !dbg !49349
  %switch.i = icmp eq i8 %287, 16, !dbg !49349
  br i1 %switch.i, label %bb20.i, label %bb19.i, !dbg !49349

bb19.i:                                           ; preds = %bb16.i
  %288 = ptrtoint ptr %result to i64, !dbg !49352
  %289 = lshr i64 %288, 3, !dbg !49352
  %290 = add i64 %289, 2147450880, !dbg !49352
  %291 = inttoptr i64 %290 to ptr, !dbg !49352
  %292 = load i8, ptr %291, align 1, !dbg !49352
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %292), !dbg !49352
  %293 = icmp ne i8 %292, 0, !dbg !49352
  br i1 %293, label %296, label %bb19.i._crit_edge, !dbg !49352, !prof !4181

bb19.i._crit_edge:                                ; preds = %bb19.i
  %294 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 46), align 1, !dbg !49352, !nosanitize !4110
  %295 = add i8 %294, 1, !dbg !49352
  store i8 %295, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 46), align 1, !dbg !49352, !nosanitize !4110
  br label %305, !dbg !49352

296:                                              ; preds = %bb19.i
  %297 = and i64 %288, 7, !dbg !49352
  %298 = trunc i64 %297 to i8, !dbg !49352
  call void @__sanitizer_cov_trace_cmp1(i8 %298, i8 %292), !dbg !49352
  %299 = icmp sge i8 %298, %292, !dbg !49352
  br i1 %299, label %302, label %._crit_edge13, !dbg !49352

._crit_edge13:                                    ; preds = %296
  %300 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 47), align 1, !dbg !49352, !nosanitize !4110
  %301 = add i8 %300, 1, !dbg !49352
  store i8 %301, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 47), align 1, !dbg !49352, !nosanitize !4110
  br label %305, !dbg !49352

302:                                              ; preds = %296
  %303 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 48), align 1, !dbg !49352, !nosanitize !4110
  %304 = add i8 %303, 1, !dbg !49352
  store i8 %304, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 48), align 1, !dbg !49352, !nosanitize !4110
  call void @__asan_report_store1(i64 %288) #42, !dbg !49352
  unreachable

305:                                              ; preds = %._crit_edge13, %bb19.i._crit_edge
  store i8 0, ptr %result, align 8, !dbg !49352, !alias.scope !49253, !noalias !49256
  %306 = getelementptr inbounds nuw i8, ptr %result, i64 8, !dbg !49352
  %307 = ptrtoint ptr %306 to i64, !dbg !49352
  %308 = lshr i64 %307, 3, !dbg !49352
  %309 = add i64 %308, 2147450880, !dbg !49352
  %310 = inttoptr i64 %309 to ptr, !dbg !49352
  %311 = load i8, ptr %310, align 1, !dbg !49352
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %311), !dbg !49352
  %312 = icmp ne i8 %311, 0, !dbg !49352
  br i1 %312, label %313, label %316, !dbg !49352

313:                                              ; preds = %305
  %314 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 49), align 1, !dbg !49352, !nosanitize !4110
  %315 = add i8 %314, 1, !dbg !49352
  store i8 %315, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 49), align 1, !dbg !49352, !nosanitize !4110
  call void @__asan_report_store8(i64 %307) #42, !dbg !49352
  unreachable, !dbg !49352

316:                                              ; preds = %305
  %317 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 50), align 1, !dbg !49352, !nosanitize !4110
  %318 = add i8 %317, 1, !dbg !49352
  store i8 %318, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 50), align 1, !dbg !49352, !nosanitize !4110
  store i64 -1, ptr %306, align 8, !dbg !49352, !alias.scope !49253, !noalias !49256
  br label %bb62.i, !dbg !49347

bb20.i:                                           ; preds = %bb16.i
  %_25.0.i = add i64 %_7.sroa.12.0.i, -16, !dbg !49353
  call void @__sanitizer_cov_trace_const_cmp8(i64 16, i64 %_7.sroa.12.0.i), !dbg !49353
  %_25.1.i = icmp ult i64 %_7.sroa.12.0.i, 16, !dbg !49353
  br i1 %_25.1.i, label %panic1.i, label %bb21.i, !dbg !49353

bb21.i:                                           ; preds = %bb20.i
  call void @__sanitizer_cov_trace_const_cmp1(i8 16, i8 %_7.sroa.14.32.extract.trunc.i), !dbg !49354
  %_26.i = icmp eq i8 %_7.sroa.14.32.extract.trunc.i, 16, !dbg !49354
  br i1 %_26.i, label %bb22.i, label %bb21.i.bb26.i_crit_edge, !dbg !49354

bb21.i.bb26.i_crit_edge:                          ; preds = %bb21.i
  %319 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 51), align 1, !dbg !49354, !nosanitize !4110
  %320 = add i8 %319, 1, !dbg !49354
  store i8 %320, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 51), align 1, !dbg !49354, !nosanitize !4110
  br label %bb26.i, !dbg !49354

panic1.i:                                         ; preds = %bb20.i
  %321 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 52), align 1, !dbg !49353, !nosanitize !4110
  %322 = add i8 %321, 1, !dbg !49353
  store i8 %322, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 52), align 1, !dbg !49353, !nosanitize !4110
  call void @__asan_handle_no_return(), !dbg !49353
; call core::panicking::panic_const::panic_const_sub_overflow
  tail call void @_RNvNtNtCshZBO5P2NUJi_4core9panicking11panic_const24panic_const_sub_overflow(ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_4e5c04fce0bf95e6afd600b887f31b6c) #43, !dbg !49353, !noalias !49263
  unreachable, !dbg !49353

bb22.i:                                           ; preds = %bb21.i
  %323 = ptrtoint ptr %_9 to i64, !dbg !49356
  %324 = lshr i64 %323, 3, !dbg !49356
  %325 = add i64 %324, 2147450880, !dbg !49356
  %326 = inttoptr i64 %325 to ptr, !dbg !49356
  %327 = load i8, ptr %326, align 1, !dbg !49356
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %327), !dbg !49356
  %328 = icmp ne i8 %327, 0, !dbg !49356
  br i1 %328, label %329, label %332, !dbg !49356

329:                                              ; preds = %bb22.i
  %330 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 53), align 1, !dbg !49356, !nosanitize !4110
  %331 = add i8 %330, 1, !dbg !49356
  store i8 %331, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 53), align 1, !dbg !49356, !nosanitize !4110
  call void @__asan_report_load8(i64 %323) #42, !dbg !49356
  unreachable, !dbg !49356

332:                                              ; preds = %bb22.i
  %_30.i = load i64, ptr %_9, align 8, !dbg !49356, !noalias !49263, !noundef !4110
  %_32.0.i = add i64 %_30.i, %_25.0.i, !dbg !49356
  call void @__sanitizer_cov_trace_cmp8(i64 %_32.0.i, i64 %_30.i), !dbg !49356
  %_32.1.i = icmp ult i64 %_32.0.i, %_30.i, !dbg !49356
  br i1 %_32.1.i, label %panic2.i, label %bb23.i, !dbg !49356

bb26.i:                                           ; preds = %bb23.i.bb26.i_crit_edge, %bb21.i.bb26.i_crit_edge
  %333 = add i64 %32, 28, !dbg !49357
  %334 = inttoptr i64 %333 to ptr, !dbg !49357
  store i16 1024, ptr %334, align 1, !dbg !49357
  %335 = ptrtoint ptr %_5 to i64, !dbg !49358
  %336 = lshr i64 %335, 3, !dbg !49358
  %337 = add i64 %336, 2147450880, !dbg !49358
  %338 = inttoptr i64 %337 to ptr, !dbg !49358
  %339 = load i8, ptr %338, align 1, !dbg !49358
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %339), !dbg !49358
  %340 = icmp ne i8 %339, 0, !dbg !49358
  br i1 %340, label %343, label %bb26.i._crit_edge, !dbg !49358, !prof !4181

bb26.i._crit_edge:                                ; preds = %bb26.i
  %341 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 54), align 1, !dbg !49358, !nosanitize !4110
  %342 = add i8 %341, 1, !dbg !49358
  store i8 %342, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 54), align 1, !dbg !49358, !nosanitize !4110
  br label %353, !dbg !49358

343:                                              ; preds = %bb26.i
  %344 = and i64 %335, 7, !dbg !49358
  %345 = add i64 %344, 3, !dbg !49358
  %346 = trunc i64 %345 to i8, !dbg !49358
  call void @__sanitizer_cov_trace_cmp1(i8 %346, i8 %339), !dbg !49358
  %347 = icmp sge i8 %346, %339, !dbg !49358
  br i1 %347, label %350, label %._crit_edge14, !dbg !49358

._crit_edge14:                                    ; preds = %343
  %348 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 55), align 1, !dbg !49358, !nosanitize !4110
  %349 = add i8 %348, 1, !dbg !49358
  store i8 %349, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 55), align 1, !dbg !49358, !nosanitize !4110
  br label %353, !dbg !49358

350:                                              ; preds = %343
  %351 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 56), align 1, !dbg !49358, !nosanitize !4110
  %352 = add i8 %351, 1, !dbg !49358
  store i8 %352, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 56), align 1, !dbg !49358, !nosanitize !4110
  call void @__asan_report_load4(i64 %335) #42, !dbg !49358
  unreachable

353:                                              ; preds = %._crit_edge14, %bb26.i._crit_edge
  %_34.sroa.0.0.copyload.i = load i32, ptr %_5, align 8, !dbg !49358, !noalias !49263
  %354 = add i64 %32, 16
  %355 = inttoptr i64 %354 to ptr
  store i8 4, ptr %355, align 1
  store i32 %_34.sroa.0.0.copyload.i, ptr %24, align 4, !noalias !49359
  %356 = add i64 %32, 12, !dbg !49362
  %357 = inttoptr i64 %356 to ptr, !dbg !49362
  store i16 1024, ptr %357, align 1, !dbg !49362
  %358 = call ptr @__asan_memset(ptr %23, i32 0, i64 12), !dbg !49364
; call core::slice::copy_from_slice_impl::<u8>
  call void @_RINvNtCshZBO5P2NUJi_4core5slice20copy_from_slice_implhECs7jJvS58pafZ_4ring(ptr noalias nofree noundef nonnull %23, i64 noundef range(i64 0, -9223372036854775808) 4, ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) %24, i64 noundef 4, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_6f2dbdb6ae1f37cfa5b5aca94af9f1fb) #35, !dbg !49365, !noalias !49359
  %_11.i.i.i.i = getelementptr inbounds nuw i8, ptr %23, i64 4, !dbg !49367
  %359 = add i64 %32, 8, !dbg !49372
  %360 = inttoptr i64 %359 to ptr, !dbg !49372
  store i8 0, ptr %360, align 1, !dbg !49372
  %self1.i.i.i = call noundef i64 @llvm.bswap.i64(i64 %_20.i), !dbg !49373
  store i64 %self1.i.i.i, ptr %22, align 8, !dbg !49377, !noalias !49359
; call core::slice::copy_from_slice_impl::<u8>
  call void @_RINvNtCshZBO5P2NUJi_4core5slice20copy_from_slice_implhECs7jJvS58pafZ_4ring(ptr noalias nofree noundef nonnull %_11.i.i.i.i, i64 noundef range(i64 0, -9223372036854775808) 8, ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) %22, i64 noundef 8, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_91f5d2a8241d378b989535ff8e1d2b0c) #35, !dbg !49378, !noalias !49359
  %361 = add i64 %32, 8, !dbg !49380
  %362 = inttoptr i64 %361 to ptr, !dbg !49380
  store i8 -8, ptr %362, align 1, !dbg !49380
  %363 = call ptr @__asan_memcpy(ptr %26, ptr %23, i64 12), !dbg !49381
  %364 = add i64 %32, 12, !dbg !49382
  %365 = inttoptr i64 %364 to ptr, !dbg !49382
  store i16 -1800, ptr %365, align 1, !dbg !49382
  %366 = add i64 %32, 16, !dbg !49383
  %367 = inttoptr i64 %366 to ptr, !dbg !49383
  store i8 -8, ptr %367, align 1, !dbg !49383
  %_5.i27.i = load ptr, ptr %133, align 8, !dbg !49384, !alias.scope !49392, !noalias !49253, !nonnull !4110, !noundef !4110
  br i1 %_2.i.i, label %bb3.i30.i, label %_RNvMNtCshZBO5P2NUJi_4core5sliceSh12split_at_mutCs4oicsBtN6nJ_15spiral_protocol.exit.i, !dbg !49395, !prof !4407

bb3.i30.i:                                        ; preds = %353
  %368 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 57), align 1, !dbg !49400, !nosanitize !4110
  %369 = add i8 %368, 1, !dbg !49400
  store i8 %369, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 57), align 1, !dbg !49400, !nosanitize !4110
  call void @__asan_handle_no_return(), !dbg !49400
; call core::panicking::panic_fmt
  call void @_RNvNtCshZBO5P2NUJi_4core9panicking9panic_fmt(ptr noundef nonnull @alloc_d1084648e479974e70c9329824bf76f9, ptr noundef nonnull inttoptr (i64 19 to ptr), ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_1185a3cb92d4a0e47b1097f6ff9fa708) #43, !dbg !49400, !noalias !49401
  unreachable, !dbg !49400

_RNvMNtCshZBO5P2NUJi_4core5sliceSh12split_at_mutCs4oicsBtN6nJ_15spiral_protocol.exit.i: ; preds = %353
  %len.i.i.i = add nsw i64 %_4.i.i, -40, !dbg !49405
  %data.i.i.i = getelementptr inbounds nuw i8, ptr %_5.i27.i, i64 40, !dbg !49410
  call void @__sanitizer_cov_trace_cmp8(i64 %_25.0.i, i64 %len.i.i.i), !dbg !49413
  %_6.not.i31.i = icmp ugt i64 %_25.0.i, %len.i.i.i, !dbg !49413
  br i1 %_6.not.i31.i, label %bb3.i38.i, label %_RNvMNtCshZBO5P2NUJi_4core5sliceSh12split_at_mutCs4oicsBtN6nJ_15spiral_protocol.exit39.i, !dbg !49413, !prof !4407

bb3.i38.i:                                        ; preds = %_RNvMNtCshZBO5P2NUJi_4core5sliceSh12split_at_mutCs4oicsBtN6nJ_15spiral_protocol.exit.i
  %370 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 58), align 1, !dbg !49417, !nosanitize !4110
  %371 = add i8 %370, 1, !dbg !49417
  store i8 %371, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 58), align 1, !dbg !49417, !nosanitize !4110
  call void @__asan_handle_no_return(), !dbg !49417
; call core::panicking::panic_fmt
  call void @_RNvNtCshZBO5P2NUJi_4core9panicking9panic_fmt(ptr noundef nonnull @alloc_d1084648e479974e70c9329824bf76f9, ptr noundef nonnull inttoptr (i64 19 to ptr), ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_3de7214d22cc3ca1cceb1f9ba0f03f42) #43, !dbg !49417, !noalias !49418
  unreachable, !dbg !49417

_RNvMNtCshZBO5P2NUJi_4core5sliceSh12split_at_mutCs4oicsBtN6nJ_15spiral_protocol.exit39.i: ; preds = %_RNvMNtCshZBO5P2NUJi_4core5sliceSh12split_at_mutCs4oicsBtN6nJ_15spiral_protocol.exit.i
  %data.i.i34.i = getelementptr inbounds nuw i8, ptr %data.i.i.i, i64 %_25.0.i, !dbg !49422
  %372 = ptrtoint ptr %_4 to i64, !dbg !49425
  %373 = lshr i64 %372, 3, !dbg !49425
  %374 = add i64 %373, 2147450880, !dbg !49425
  %375 = inttoptr i64 %374 to ptr, !dbg !49425
  %376 = load i8, ptr %375, align 1, !dbg !49425
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %376), !dbg !49425
  %377 = icmp ne i8 %376, 0, !dbg !49425
  br i1 %377, label %380, label %_RNvMNtCshZBO5P2NUJi_4core5sliceSh12split_at_mutCs4oicsBtN6nJ_15spiral_protocol.exit39.i._crit_edge, !dbg !49425, !prof !4181

_RNvMNtCshZBO5P2NUJi_4core5sliceSh12split_at_mutCs4oicsBtN6nJ_15spiral_protocol.exit39.i._crit_edge: ; preds = %_RNvMNtCshZBO5P2NUJi_4core5sliceSh12split_at_mutCs4oicsBtN6nJ_15spiral_protocol.exit39.i
  %378 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 59), align 1, !dbg !49425, !nosanitize !4110
  %379 = add i8 %378, 1, !dbg !49425
  store i8 %379, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 59), align 1, !dbg !49425, !nosanitize !4110
  br label %389, !dbg !49425

380:                                              ; preds = %_RNvMNtCshZBO5P2NUJi_4core5sliceSh12split_at_mutCs4oicsBtN6nJ_15spiral_protocol.exit39.i
  %381 = and i64 %372, 7, !dbg !49425
  %382 = trunc i64 %381 to i8, !dbg !49425
  call void @__sanitizer_cov_trace_cmp1(i8 %382, i8 %376), !dbg !49425
  %383 = icmp sge i8 %382, %376, !dbg !49425
  br i1 %383, label %386, label %._crit_edge15, !dbg !49425

._crit_edge15:                                    ; preds = %380
  %384 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 60), align 1, !dbg !49425, !nosanitize !4110
  %385 = add i8 %384, 1, !dbg !49425
  store i8 %385, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 60), align 1, !dbg !49425, !nosanitize !4110
  br label %389, !dbg !49425

386:                                              ; preds = %380
  %387 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 61), align 1, !dbg !49425, !nosanitize !4110
  %388 = add i8 %387, 1, !dbg !49425
  store i8 %388, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 61), align 1, !dbg !49425, !nosanitize !4110
  call void @__asan_report_load1(i64 %372) #42, !dbg !49425
  unreachable

389:                                              ; preds = %._crit_edge15, %_RNvMNtCshZBO5P2NUJi_4core5sliceSh12split_at_mutCs4oicsBtN6nJ_15spiral_protocol.exit39.i._crit_edge
  %390 = load i8, ptr %_4, align 1, !dbg !49425, !range !4348, !alias.scope !49428, !noalias !49263, !noundef !4110
  %391 = trunc nuw i8 %390 to i1, !dbg !49425
  %x.i.i = getelementptr inbounds nuw i8, ptr %self, i64 38, !dbg !49431
  br i1 %391, label %bb34.i, label %.bb59.i_crit_edge, !dbg !49432

.bb59.i_crit_edge:                                ; preds = %389
  %392 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 62), align 1, !dbg !49432, !nosanitize !4110
  %393 = add i8 %392, 1, !dbg !49432
  store i8 %393, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 62), align 1, !dbg !49432, !nosanitize !4110
  br label %bb59.i, !dbg !49432

bb23.i:                                           ; preds = %332
  call void @__sanitizer_cov_trace_const_cmp8(i64 1073741823, i64 %_32.0.i), !dbg !49356
  %_28.i = icmp ugt i64 %_32.0.i, 1073741823, !dbg !49356
  br i1 %_28.i, label %bb24.i, label %bb23.i.bb26.i_crit_edge, !dbg !49356

bb23.i.bb26.i_crit_edge:                          ; preds = %bb23.i
  %394 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 63), align 1, !dbg !49356, !nosanitize !4110
  %395 = add i8 %394, 1, !dbg !49356
  store i8 %395, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 63), align 1, !dbg !49356, !nosanitize !4110
  br label %bb26.i, !dbg !49356

panic2.i:                                         ; preds = %332
  %396 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 64), align 1, !dbg !49356, !nosanitize !4110
  %397 = add i8 %396, 1, !dbg !49356
  store i8 %397, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 64), align 1, !dbg !49356, !nosanitize !4110
  call void @__asan_handle_no_return(), !dbg !49356
; call core::panicking::panic_const::panic_const_add_overflow
  tail call void @_RNvNtNtCshZBO5P2NUJi_4core9panicking11panic_const24panic_const_add_overflow(ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_f31224e576dbaa11256ec37fc67731ca) #43, !dbg !49356, !noalias !49263
  unreachable, !dbg !49356

bb24.i:                                           ; preds = %bb23.i
  %398 = ptrtoint ptr %result to i64, !dbg !49433
  %399 = lshr i64 %398, 3, !dbg !49433
  %400 = add i64 %399, 2147450880, !dbg !49433
  %401 = inttoptr i64 %400 to ptr, !dbg !49433
  %402 = load i8, ptr %401, align 1, !dbg !49433
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %402), !dbg !49433
  %403 = icmp ne i8 %402, 0, !dbg !49433
  br i1 %403, label %406, label %bb24.i._crit_edge, !dbg !49433, !prof !4181

bb24.i._crit_edge:                                ; preds = %bb24.i
  %404 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 65), align 1, !dbg !49433, !nosanitize !4110
  %405 = add i8 %404, 1, !dbg !49433
  store i8 %405, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 65), align 1, !dbg !49433, !nosanitize !4110
  br label %415, !dbg !49433

406:                                              ; preds = %bb24.i
  %407 = and i64 %398, 7, !dbg !49433
  %408 = trunc i64 %407 to i8, !dbg !49433
  call void @__sanitizer_cov_trace_cmp1(i8 %408, i8 %402), !dbg !49433
  %409 = icmp sge i8 %408, %402, !dbg !49433
  br i1 %409, label %412, label %._crit_edge16, !dbg !49433

._crit_edge16:                                    ; preds = %406
  %410 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 66), align 1, !dbg !49433, !nosanitize !4110
  %411 = add i8 %410, 1, !dbg !49433
  store i8 %411, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 66), align 1, !dbg !49433, !nosanitize !4110
  br label %415, !dbg !49433

412:                                              ; preds = %406
  %413 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 67), align 1, !dbg !49433, !nosanitize !4110
  %414 = add i8 %413, 1, !dbg !49433
  store i8 %414, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 67), align 1, !dbg !49433, !nosanitize !4110
  call void @__asan_report_store1(i64 %398) #42, !dbg !49433
  unreachable

415:                                              ; preds = %._crit_edge16, %bb24.i._crit_edge
  store i8 8, ptr %result, align 8, !dbg !49433, !alias.scope !49253, !noalias !49256
  %416 = getelementptr inbounds nuw i8, ptr %result, i64 1, !dbg !49433
  %417 = ptrtoint ptr %416 to i64, !dbg !49433
  %418 = lshr i64 %417, 3, !dbg !49433
  %419 = add i64 %418, 2147450880, !dbg !49433
  %420 = inttoptr i64 %419 to ptr, !dbg !49433
  %421 = load i8, ptr %420, align 1, !dbg !49433
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %421), !dbg !49433
  %422 = icmp ne i8 %421, 0, !dbg !49433
  br i1 %422, label %425, label %._crit_edge17, !dbg !49433, !prof !4181

._crit_edge17:                                    ; preds = %415
  %423 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 68), align 1, !dbg !49433, !nosanitize !4110
  %424 = add i8 %423, 1, !dbg !49433
  store i8 %424, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 68), align 1, !dbg !49433, !nosanitize !4110
  br label %434, !dbg !49433

425:                                              ; preds = %415
  %426 = and i64 %417, 7, !dbg !49433
  %427 = trunc i64 %426 to i8, !dbg !49433
  call void @__sanitizer_cov_trace_cmp1(i8 %427, i8 %421), !dbg !49433
  %428 = icmp sge i8 %427, %421, !dbg !49433
  br i1 %428, label %431, label %._crit_edge18, !dbg !49433

._crit_edge18:                                    ; preds = %425
  %429 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 69), align 1, !dbg !49433, !nosanitize !4110
  %430 = add i8 %429, 1, !dbg !49433
  store i8 %430, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 69), align 1, !dbg !49433, !nosanitize !4110
  br label %434, !dbg !49433

431:                                              ; preds = %425
  %432 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 70), align 1, !dbg !49433, !nosanitize !4110
  %433 = add i8 %432, 1, !dbg !49433
  store i8 %433, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 70), align 1, !dbg !49433, !nosanitize !4110
  call void @__asan_report_store1(i64 %417) #42, !dbg !49433
  unreachable

434:                                              ; preds = %._crit_edge18, %._crit_edge17
  store i8 2, ptr %416, align 1, !dbg !49433, !alias.scope !49253, !noalias !49256
  %435 = getelementptr inbounds nuw i8, ptr %result, i64 8, !dbg !49433
  %436 = ptrtoint ptr %435 to i64, !dbg !49433
  %437 = lshr i64 %436, 3, !dbg !49433
  %438 = add i64 %437, 2147450880, !dbg !49433
  %439 = inttoptr i64 %438 to ptr, !dbg !49433
  %440 = load i8, ptr %439, align 1, !dbg !49433
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %440), !dbg !49433
  %441 = icmp ne i8 %440, 0, !dbg !49433
  br i1 %441, label %442, label %445, !dbg !49433

442:                                              ; preds = %434
  %443 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 71), align 1, !dbg !49433, !nosanitize !4110
  %444 = add i8 %443, 1, !dbg !49433
  store i8 %444, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 71), align 1, !dbg !49433, !nosanitize !4110
  call void @__asan_report_store8(i64 %436) #42, !dbg !49433
  unreachable, !dbg !49433

445:                                              ; preds = %434
  %446 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 72), align 1, !dbg !49433, !nosanitize !4110
  %447 = add i8 %446, 1, !dbg !49433
  store i8 %447, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 72), align 1, !dbg !49433, !nosanitize !4110
  store i64 -1, ptr %435, align 8, !dbg !49433, !alias.scope !49253, !noalias !49256
  br label %bb62.i, !dbg !49434

bb34.i:                                           ; preds = %389
  %len.i.i33.i = sub nuw nsw i64 %len.i.i.i, %_25.0.i, !dbg !49436
  %448 = add i64 %32, 4, !dbg !49437
  %449 = inttoptr i64 %448 to ptr, !dbg !49437
  store i8 0, ptr %449, align 1, !dbg !49437
  store i64 %len.i.i33.i, ptr %21, align 8, !dbg !49437, !noalias !49446
  call void @__sanitizer_cov_trace_const_cmp8(i64 16, i64 %len.i.i33.i), !dbg !49453
  %_4.i.i.i.i = icmp eq i64 %len.i.i33.i, 16, !dbg !49453
  br i1 %_4.i.i.i.i, label %_RNvMsj_Cs18jWmPaaUdo_13generic_arrayINtB5_12GenericArrayhINtNtCs9T39WwoIZ0p_7typenum4uint4UIntIBU_IBU_IBU_IBU_NtBW_5UTermNtNtBY_3bit2B1ENtB1X_2B0EB2a_EB2a_EB2a_EE10from_sliceCs4oicsBtN6nJ_15spiral_protocol.exit.i, label %bb2.i.i.i.i, !dbg !49453, !prof !4186

bb2.i.i.i.i:                                      ; preds = %bb34.i
  %450 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 73), align 1, !dbg !49456, !nosanitize !4110
  %451 = add i8 %450, 1, !dbg !49456
  store i8 %451, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 73), align 1, !dbg !49456, !nosanitize !4110
  call void @__asan_handle_no_return(), !dbg !49456
; call core::panicking::assert_failed::<usize, usize>
  call void @_RINvNtCshZBO5P2NUJi_4core9panicking13assert_failedjjECs38j2clKJAvj_5bytes(i8 noundef 0, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(8) %21, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(8) @alloc_87930ff84f26c4dc0d3a344636709737, ptr noundef null, ptr undef, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_82dfddd402afb0460c4a7b520cfc1550) #43, !dbg !49456, !noalias !49446
  unreachable, !dbg !49456

_RNvMsj_Cs18jWmPaaUdo_13generic_arrayINtB5_12GenericArrayhINtNtCs9T39WwoIZ0p_7typenum4uint4UIntIBU_IBU_IBU_IBU_NtBW_5UTermNtNtBY_3bit2B1ENtB1X_2B0EB2a_EB2a_EB2a_EE10from_sliceCs4oicsBtN6nJ_15spiral_protocol.exit.i: ; preds = %bb34.i
  %452 = add i64 %32, 4, !dbg !49459
  %453 = inttoptr i64 %452 to ptr, !dbg !49459
  store i8 -8, ptr %453, align 1, !dbg !49459
; call <chacha20poly1305::ChaChaPoly1305<cipher::stream_wrapper::StreamCipherCoreWrapper<chacha20::ChaChaCore<typenum::uint::UInt<typenum::uint::UInt<typenum::uint::UInt<typenum::uint::UInt<typenum::uint::UTerm, typenum::bit::B1>, typenum::bit::B0>, typenum::bit::B1>, typenum::bit::B0>>>> as aead::AeadInPlace>::decrypt_in_place_detached
  %_46.i = call noundef zeroext i1 @_RNvXs1_CskG2NEjLuYj5_16chacha20poly1305INtB5_14ChaChaPoly1305INtNtCs3uTrKuTqj2Q_6cipher14stream_wrapper23StreamCipherCoreWrapperINtCslD4gSC9HkLH_8chacha2010ChaChaCoreINtNtCs9T39WwoIZ0p_7typenum4uint4UIntIB2F_IB2F_IB2F_NtB2H_5UTermNtNtB2J_3bit2B1ENtB3I_2B0EB3G_EB3W_EEEENtCsjG0YvJ6QUY8_4aead11AeadInPlace25decrypt_in_place_detachedCs4oicsBtN6nJ_15spiral_protocol(ptr noalias nofree noundef readonly captures(address, read_provenance) dereferenceable(32) %x.i.i, ptr noalias nofree noundef readonly captures(address, read_provenance) dereferenceable(12) %26, ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) %_5.i27.i, i64 noundef 40, ptr noalias nofree noundef nonnull %data.i.i.i, i64 noundef %_25.0.i, ptr noalias nofree noundef readonly captures(address, read_provenance) dereferenceable(16) %data.i.i34.i) #35, !dbg !49460, !noalias !49263
  br i1 %_46.i, label %_RNvMsj_Cs18jWmPaaUdo_13generic_arrayINtB5_12GenericArrayhINtNtCs9T39WwoIZ0p_7typenum4uint4UIntIBU_IBU_IBU_IBU_NtBW_5UTermNtNtBY_3bit2B1ENtB1X_2B0EB2a_EB2a_EB2a_EE10from_sliceCs4oicsBtN6nJ_15spiral_protocol.exit.i.bb59.i_crit_edge, label %bb42.i, !dbg !49432

_RNvMsj_Cs18jWmPaaUdo_13generic_arrayINtB5_12GenericArrayhINtNtCs9T39WwoIZ0p_7typenum4uint4UIntIBU_IBU_IBU_IBU_NtBW_5UTermNtNtBY_3bit2B1ENtB1X_2B0EB2a_EB2a_EB2a_EE10from_sliceCs4oicsBtN6nJ_15spiral_protocol.exit.i.bb59.i_crit_edge: ; preds = %_RNvMsj_Cs18jWmPaaUdo_13generic_arrayINtB5_12GenericArrayhINtNtCs9T39WwoIZ0p_7typenum4uint4UIntIBU_IBU_IBU_IBU_NtBW_5UTermNtNtBY_3bit2B1ENtB1X_2B0EB2a_EB2a_EB2a_EE10from_sliceCs4oicsBtN6nJ_15spiral_protocol.exit.i
  %454 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 74), align 1, !dbg !49432, !nosanitize !4110
  %455 = add i8 %454, 1, !dbg !49432
  store i8 %455, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 74), align 1, !dbg !49432, !nosanitize !4110
  br label %bb59.i, !dbg !49432

bb42.i:                                           ; preds = %_RNvMsj_Cs18jWmPaaUdo_13generic_arrayINtB5_12GenericArrayhINtNtCs9T39WwoIZ0p_7typenum4uint4UIntIBU_IBU_IBU_IBU_NtBW_5UTermNtNtBY_3bit2B1ENtB1X_2B0EB2a_EB2a_EB2a_EE10from_sliceCs4oicsBtN6nJ_15spiral_protocol.exit.i
  call void @__sanitizer_cov_trace_const_cmp1(i8 17, i8 %_7.sroa.14.32.extract.trunc.i), !dbg !49461
  %456 = icmp eq i8 %_7.sroa.14.32.extract.trunc.i, 17, !dbg !49461
  br i1 %456, label %bb45.i, label %bb42.i.bb51.i_crit_edge, !dbg !49461

bb42.i.bb51.i_crit_edge:                          ; preds = %bb42.i
  %457 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 75), align 1, !dbg !49461, !nosanitize !4110
  %458 = add i8 %457, 1, !dbg !49461
  store i8 %458, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 75), align 1, !dbg !49461, !nosanitize !4110
  br label %bb51.i, !dbg !49461

bb45.i:                                           ; preds = %bb42.i
  call void @__sanitizer_cov_trace_const_cmp8(i64 1, i64 %_25.0.i), !dbg !49462
  %459 = icmp eq i64 %_25.0.i, 1, !dbg !49462
  br i1 %459, label %bb47.i, label %bb45.i.bb59.i_crit_edge, !dbg !49462

bb45.i.bb59.i_crit_edge:                          ; preds = %bb45.i
  %460 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 76), align 1, !dbg !49462, !nosanitize !4110
  %461 = add i8 %460, 1, !dbg !49462
  store i8 %461, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 76), align 1, !dbg !49462, !nosanitize !4110
  br label %bb59.i, !dbg !49462

bb51.i:                                           ; preds = %.bb51.i_crit_edge, %bb42.i.bb51.i_crit_edge
  %462 = ptrtoint ptr %_8 to i64, !dbg !49463
  %463 = lshr i64 %462, 3, !dbg !49463
  %464 = add i64 %463, 2147450880, !dbg !49463
  %465 = inttoptr i64 %464 to ptr, !dbg !49463
  %466 = load i8, ptr %465, align 1, !dbg !49463
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %466), !dbg !49463
  %467 = icmp ne i8 %466, 0, !dbg !49463
  br i1 %467, label %468, label %471, !dbg !49463

468:                                              ; preds = %bb51.i
  %469 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 77), align 1, !dbg !49463, !nosanitize !4110
  %470 = add i8 %469, 1, !dbg !49463
  store i8 %470, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 77), align 1, !dbg !49463, !nosanitize !4110
  call void @__asan_report_load8(i64 %462) #42, !dbg !49463
  unreachable, !dbg !49463

471:                                              ; preds = %bb51.i
  %472 = load i64, ptr %_8, align 8, !dbg !49463, !noalias !49263, !noundef !4110
  call void @__sanitizer_cov_trace_const_cmp8(i64 -1, i64 %472), !dbg !49463
  %_66.1.i = icmp eq i64 %472, -1, !dbg !49463
  br i1 %_66.1.i, label %panic5.i, label %bb52.i, !dbg !49463

bb47.i:                                           ; preds = %bb45.i
  %473 = ptrtoint ptr %data.i.i.i to i64, !dbg !49464
  %474 = lshr i64 %473, 3, !dbg !49464
  %475 = add i64 %474, 2147450880, !dbg !49464
  %476 = inttoptr i64 %475 to ptr, !dbg !49464
  %477 = load i8, ptr %476, align 1, !dbg !49464
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %477), !dbg !49464
  %478 = icmp ne i8 %477, 0, !dbg !49464
  br i1 %478, label %481, label %bb47.i._crit_edge, !dbg !49464, !prof !4181

bb47.i._crit_edge:                                ; preds = %bb47.i
  %479 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 78), align 1, !dbg !49464, !nosanitize !4110
  %480 = add i8 %479, 1, !dbg !49464
  store i8 %480, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 78), align 1, !dbg !49464, !nosanitize !4110
  br label %490, !dbg !49464

481:                                              ; preds = %bb47.i
  %482 = and i64 %473, 7, !dbg !49464
  %483 = trunc i64 %482 to i8, !dbg !49464
  call void @__sanitizer_cov_trace_cmp1(i8 %483, i8 %477), !dbg !49464
  %484 = icmp sge i8 %483, %477, !dbg !49464
  br i1 %484, label %487, label %._crit_edge19, !dbg !49464

._crit_edge19:                                    ; preds = %481
  %485 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 79), align 1, !dbg !49464, !nosanitize !4110
  %486 = add i8 %485, 1, !dbg !49464
  store i8 %486, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 79), align 1, !dbg !49464, !nosanitize !4110
  br label %490, !dbg !49464

487:                                              ; preds = %481
  %488 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 80), align 1, !dbg !49464, !nosanitize !4110
  %489 = add i8 %488, 1, !dbg !49464
  store i8 %489, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 80), align 1, !dbg !49464, !nosanitize !4110
  call void @__asan_report_load1(i64 %473) #42, !dbg !49464
  unreachable

490:                                              ; preds = %._crit_edge19, %bb47.i._crit_edge
  %_63.i = load i8, ptr %data.i.i.i, align 1, !dbg !49464, !noalias !49263, !noundef !4110
  call void @__sanitizer_cov_trace_const_cmp1(i8 2, i8 %_63.i), !dbg !49464
  %_62.i = icmp ugt i8 %_63.i, 2, !dbg !49464
  br i1 %_62.i, label %.bb59.i_crit_edge20, label %.bb51.i_crit_edge, !dbg !49464

.bb51.i_crit_edge:                                ; preds = %490
  %491 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 81), align 1, !dbg !49464, !nosanitize !4110
  %492 = add i8 %491, 1, !dbg !49464
  store i8 %492, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 81), align 1, !dbg !49464, !nosanitize !4110
  br label %bb51.i, !dbg !49464

.bb59.i_crit_edge20:                              ; preds = %490
  %493 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 82), align 1, !dbg !49464, !nosanitize !4110
  %494 = add i8 %493, 1, !dbg !49464
  store i8 %494, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 82), align 1, !dbg !49464, !nosanitize !4110
  br label %bb59.i, !dbg !49464

bb59.i:                                           ; preds = %.bb59.i_crit_edge20, %bb45.i.bb59.i_crit_edge, %_RNvMsj_Cs18jWmPaaUdo_13generic_arrayINtB5_12GenericArrayhINtNtCs9T39WwoIZ0p_7typenum4uint4UIntIBU_IBU_IBU_IBU_NtBW_5UTermNtNtBY_3bit2B1ENtB1X_2B0EB2a_EB2a_EB2a_EE10from_sliceCs4oicsBtN6nJ_15spiral_protocol.exit.i.bb59.i_crit_edge, %.bb59.i_crit_edge
  %.sink = phi i8 [ 1, %_RNvMsj_Cs18jWmPaaUdo_13generic_arrayINtB5_12GenericArrayhINtNtCs9T39WwoIZ0p_7typenum4uint4UIntIBU_IBU_IBU_IBU_NtBW_5UTermNtNtBY_3bit2B1ENtB1X_2B0EB2a_EB2a_EB2a_EE10from_sliceCs4oicsBtN6nJ_15spiral_protocol.exit.i.bb59.i_crit_edge ], [ 6, %.bb59.i_crit_edge ], [ 0, %.bb59.i_crit_edge20 ], [ 0, %bb45.i.bb59.i_crit_edge ]
  %495 = ptrtoint ptr %result to i64, !dbg !49465
  %496 = lshr i64 %495, 3, !dbg !49465
  %497 = add i64 %496, 2147450880, !dbg !49465
  %498 = inttoptr i64 %497 to ptr, !dbg !49465
  %499 = load i8, ptr %498, align 1, !dbg !49465
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %499), !dbg !49465
  %500 = icmp ne i8 %499, 0, !dbg !49465
  br i1 %500, label %503, label %bb59.i._crit_edge, !dbg !49465, !prof !4181

bb59.i._crit_edge:                                ; preds = %bb59.i
  %501 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 83), align 1, !dbg !49465, !nosanitize !4110
  %502 = add i8 %501, 1, !dbg !49465
  store i8 %502, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 83), align 1, !dbg !49465, !nosanitize !4110
  br label %512, !dbg !49465

503:                                              ; preds = %bb59.i
  %504 = and i64 %495, 7, !dbg !49465
  %505 = trunc i64 %504 to i8, !dbg !49465
  call void @__sanitizer_cov_trace_cmp1(i8 %505, i8 %499), !dbg !49465
  %506 = icmp sge i8 %505, %499, !dbg !49465
  br i1 %506, label %509, label %._crit_edge21, !dbg !49465

._crit_edge21:                                    ; preds = %503
  %507 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 84), align 1, !dbg !49465, !nosanitize !4110
  %508 = add i8 %507, 1, !dbg !49465
  store i8 %508, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 84), align 1, !dbg !49465, !nosanitize !4110
  br label %512, !dbg !49465

509:                                              ; preds = %503
  %510 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 85), align 1, !dbg !49465, !nosanitize !4110
  %511 = add i8 %510, 1, !dbg !49465
  store i8 %511, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 85), align 1, !dbg !49465, !nosanitize !4110
  call void @__asan_report_store1(i64 %495) #42, !dbg !49465
  unreachable

512:                                              ; preds = %._crit_edge21, %bb59.i._crit_edge
  store i8 %.sink, ptr %result, align 8, !dbg !49465, !alias.scope !49253, !noalias !49256
  %513 = getelementptr inbounds nuw i8, ptr %result, i64 8, !dbg !49465
  %514 = ptrtoint ptr %513 to i64, !dbg !49465
  %515 = lshr i64 %514, 3, !dbg !49465
  %516 = add i64 %515, 2147450880, !dbg !49465
  %517 = inttoptr i64 %516 to ptr, !dbg !49465
  %518 = load i8, ptr %517, align 1, !dbg !49465
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %518), !dbg !49465
  %519 = icmp ne i8 %518, 0, !dbg !49465
  br i1 %519, label %520, label %523, !dbg !49465

520:                                              ; preds = %512
  %521 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 86), align 1, !dbg !49465, !nosanitize !4110
  %522 = add i8 %521, 1, !dbg !49465
  store i8 %522, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 86), align 1, !dbg !49465, !nosanitize !4110
  call void @__asan_report_store8(i64 %514) #42, !dbg !49465
  unreachable, !dbg !49465

523:                                              ; preds = %512
  %524 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 87), align 1, !dbg !49465, !nosanitize !4110
  %525 = add i8 %524, 1, !dbg !49465
  store i8 %525, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 87), align 1, !dbg !49465, !nosanitize !4110
  store i64 -1, ptr %513, align 8, !dbg !49465, !alias.scope !49253, !noalias !49256
  %526 = add i64 %32, 28, !dbg !49466
  %527 = inttoptr i64 %526 to ptr, !dbg !49466
  store i16 -1800, ptr %527, align 1, !dbg !49466
  br label %bb62.i, !dbg !49434

bb52.i:                                           ; preds = %471
  %_66.0.i = add nuw i64 %472, 1, !dbg !49463
  %528 = ptrtoint ptr %_8 to i64, !dbg !49463
  %529 = lshr i64 %528, 3, !dbg !49463
  %530 = add i64 %529, 2147450880, !dbg !49463
  %531 = inttoptr i64 %530 to ptr, !dbg !49463
  %532 = load i8, ptr %531, align 1, !dbg !49463
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %532), !dbg !49463
  %533 = icmp ne i8 %532, 0, !dbg !49463
  br i1 %533, label %534, label %537, !dbg !49463

534:                                              ; preds = %bb52.i
  %535 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 88), align 1, !dbg !49463, !nosanitize !4110
  %536 = add i8 %535, 1, !dbg !49463
  store i8 %536, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 88), align 1, !dbg !49463, !nosanitize !4110
  call void @__asan_report_store8(i64 %528) #42, !dbg !49463
  unreachable, !dbg !49463

537:                                              ; preds = %bb52.i
  store i64 %_66.0.i, ptr %_8, align 8, !dbg !49463, !noalias !49263
  br i1 %_26.i, label %bb53.i, label %bb55.i, !dbg !49467

panic5.i:                                         ; preds = %471
  %538 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 89), align 1, !dbg !49463, !nosanitize !4110
  %539 = add i8 %538, 1, !dbg !49463
  store i8 %539, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 89), align 1, !dbg !49463, !nosanitize !4110
  call void @__asan_handle_no_return(), !dbg !49463
; call core::panicking::panic_const::panic_const_add_overflow
  call void @_RNvNtNtCshZBO5P2NUJi_4core9panicking11panic_const24panic_const_add_overflow(ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_881ba8d135abe9e244d8fb9cb5c50b8f) #43, !dbg !49463, !noalias !49263
  unreachable, !dbg !49463

bb55.i:                                           ; preds = %537
  %540 = ptrtoint ptr %_10 to i64, !dbg !49468
  %541 = lshr i64 %540, 3, !dbg !49468
  %542 = add i64 %541, 2147450880, !dbg !49468
  %543 = inttoptr i64 %542 to ptr, !dbg !49468
  %544 = load i8, ptr %543, align 1, !dbg !49468
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %544), !dbg !49468
  %545 = icmp ne i8 %544, 0, !dbg !49468
  br i1 %545, label %548, label %bb55.i._crit_edge, !dbg !49468, !prof !4181

bb55.i._crit_edge:                                ; preds = %bb55.i
  %546 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 90), align 1, !dbg !49468, !nosanitize !4110
  %547 = add i8 %546, 1, !dbg !49468
  store i8 %547, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 90), align 1, !dbg !49468, !nosanitize !4110
  br label %557, !dbg !49468

548:                                              ; preds = %bb55.i
  %549 = and i64 %540, 7, !dbg !49468
  %550 = trunc i64 %549 to i8, !dbg !49468
  call void @__sanitizer_cov_trace_cmp1(i8 %550, i8 %544), !dbg !49468
  %551 = icmp sge i8 %550, %544, !dbg !49468
  br i1 %551, label %554, label %._crit_edge22, !dbg !49468

._crit_edge22:                                    ; preds = %548
  %552 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 91), align 1, !dbg !49468, !nosanitize !4110
  %553 = add i8 %552, 1, !dbg !49468
  store i8 %553, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 91), align 1, !dbg !49468, !nosanitize !4110
  br label %557, !dbg !49468

554:                                              ; preds = %548
  %555 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 92), align 1, !dbg !49468, !nosanitize !4110
  %556 = add i8 %555, 1, !dbg !49468
  store i8 %556, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 92), align 1, !dbg !49468, !nosanitize !4110
  call void @__asan_report_store1(i64 %540) #42, !dbg !49468
  unreachable

557:                                              ; preds = %._crit_edge22, %bb55.i._crit_edge
  store i8 1, ptr %_10, align 2, !dbg !49468, !noalias !49263
  %558 = ptrtoint ptr %_4 to i64, !dbg !49469
  %559 = lshr i64 %558, 3, !dbg !49469
  %560 = add i64 %559, 2147450880, !dbg !49469
  %561 = inttoptr i64 %560 to ptr, !dbg !49469
  %562 = load i8, ptr %561, align 1, !dbg !49469
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %562), !dbg !49469
  %563 = icmp ne i8 %562, 0, !dbg !49469
  br i1 %563, label %566, label %._crit_edge23, !dbg !49469, !prof !4181

._crit_edge23:                                    ; preds = %557
  %564 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 93), align 1, !dbg !49469, !nosanitize !4110
  %565 = add i8 %564, 1, !dbg !49469
  store i8 %565, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 93), align 1, !dbg !49469, !nosanitize !4110
  br label %575, !dbg !49469

566:                                              ; preds = %557
  %567 = and i64 %558, 7, !dbg !49469
  %568 = trunc i64 %567 to i8, !dbg !49469
  call void @__sanitizer_cov_trace_cmp1(i8 %568, i8 %562), !dbg !49469
  %569 = icmp sge i8 %568, %562, !dbg !49469
  br i1 %569, label %572, label %._crit_edge24, !dbg !49469

._crit_edge24:                                    ; preds = %566
  %570 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 94), align 1, !dbg !49469, !nosanitize !4110
  %571 = add i8 %570, 1, !dbg !49469
  store i8 %571, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 94), align 1, !dbg !49469, !nosanitize !4110
  br label %575, !dbg !49469

572:                                              ; preds = %566
  %573 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 95), align 1, !dbg !49469, !nosanitize !4110
  %574 = add i8 %573, 1, !dbg !49469
  store i8 %574, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 95), align 1, !dbg !49469, !nosanitize !4110
  call void @__asan_report_load1(i64 %558) #42, !dbg !49469
  unreachable

575:                                              ; preds = %._crit_edge24, %._crit_edge23
  %576 = load i8, ptr %_4, align 1, !dbg !49469, !range !4348, !alias.scope !49471, !noalias !49263, !noundef !4110
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %576), !dbg !49469
  %577 = icmp eq i8 %576, 0, !dbg !49469
  br i1 %577, label %._RINvNtCshZBO5P2NUJi_4core3ptr9drop_glueINtNtB4_6option6OptionINtCskG2NEjLuYj5_16chacha20poly130514ChaChaPoly1305INtNtCs3uTrKuTqj2Q_6cipher14stream_wrapper23StreamCipherCoreWrapperINtCslD4gSC9HkLH_8chacha2010ChaChaCoreINtNtCs9T39WwoIZ0p_7typenum4uint4UIntIB3u_IB3u_IB3u_NtB3w_5UTermNtNtB3y_3bit2B1ENtB4x_2B0EB4v_EB4L_EEEEEECs4oicsBtN6nJ_15spiral_protocol.exit.i_crit_edge, label %bb2.i50.i, !dbg !49469

._RINvNtCshZBO5P2NUJi_4core3ptr9drop_glueINtNtB4_6option6OptionINtCskG2NEjLuYj5_16chacha20poly130514ChaChaPoly1305INtNtCs3uTrKuTqj2Q_6cipher14stream_wrapper23StreamCipherCoreWrapperINtCslD4gSC9HkLH_8chacha2010ChaChaCoreINtNtCs9T39WwoIZ0p_7typenum4uint4UIntIB3u_IB3u_IB3u_NtB3w_5UTermNtNtB3y_3bit2B1ENtB4x_2B0EB4v_EB4L_EEEEEECs4oicsBtN6nJ_15spiral_protocol.exit.i_crit_edge: ; preds = %575
  %578 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 96), align 1, !dbg !49469, !nosanitize !4110
  %579 = add i8 %578, 1, !dbg !49469
  store i8 %579, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 96), align 1, !dbg !49469, !nosanitize !4110
  br label %_RINvNtCshZBO5P2NUJi_4core3ptr9drop_glueINtNtB4_6option6OptionINtCskG2NEjLuYj5_16chacha20poly130514ChaChaPoly1305INtNtCs3uTrKuTqj2Q_6cipher14stream_wrapper23StreamCipherCoreWrapperINtCslD4gSC9HkLH_8chacha2010ChaChaCoreINtNtCs9T39WwoIZ0p_7typenum4uint4UIntIB3u_IB3u_IB3u_NtB3w_5UTermNtNtB3y_3bit2B1ENtB4x_2B0EB4v_EB4L_EEEEEECs4oicsBtN6nJ_15spiral_protocol.exit.i, !dbg !49469

bb2.i50.i:                                        ; preds = %575
  %580 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 97), align 1, !dbg !49474, !nosanitize !4110
  %581 = add i8 %580, 1, !dbg !49474
  store i8 %581, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 97), align 1, !dbg !49474, !nosanitize !4110
; call <[u8] as zeroize::Zeroize>::zeroize
  call void @_RNvXs9_Cs5e7aMHj0NTS_7zeroizeShNtB5_7Zeroize7zeroizeB5_(ptr noalias nofree noundef nonnull dereferenceable(32) %x.i.i, i64 noundef 32) #35, !dbg !49474, !noalias !49263
  br label %_RINvNtCshZBO5P2NUJi_4core3ptr9drop_glueINtNtB4_6option6OptionINtCskG2NEjLuYj5_16chacha20poly130514ChaChaPoly1305INtNtCs3uTrKuTqj2Q_6cipher14stream_wrapper23StreamCipherCoreWrapperINtCslD4gSC9HkLH_8chacha2010ChaChaCoreINtNtCs9T39WwoIZ0p_7typenum4uint4UIntIB3u_IB3u_IB3u_NtB3w_5UTermNtNtB3y_3bit2B1ENtB4x_2B0EB4v_EB4L_EEEEEECs4oicsBtN6nJ_15spiral_protocol.exit.i, !dbg !49469

_RINvNtCshZBO5P2NUJi_4core3ptr9drop_glueINtNtB4_6option6OptionINtCskG2NEjLuYj5_16chacha20poly130514ChaChaPoly1305INtNtCs3uTrKuTqj2Q_6cipher14stream_wrapper23StreamCipherCoreWrapperINtCslD4gSC9HkLH_8chacha2010ChaChaCoreINtNtCs9T39WwoIZ0p_7typenum4uint4UIntIB3u_IB3u_IB3u_NtB3w_5UTermNtNtB3y_3bit2B1ENtB4x_2B0EB4v_EB4L_EEEEEECs4oicsBtN6nJ_15spiral_protocol.exit.i: ; preds = %._RINvNtCshZBO5P2NUJi_4core3ptr9drop_glueINtNtB4_6option6OptionINtCskG2NEjLuYj5_16chacha20poly130514ChaChaPoly1305INtNtCs3uTrKuTqj2Q_6cipher14stream_wrapper23StreamCipherCoreWrapperINtCslD4gSC9HkLH_8chacha2010ChaChaCoreINtNtCs9T39WwoIZ0p_7typenum4uint4UIntIB3u_IB3u_IB3u_NtB3w_5UTermNtNtB3y_3bit2B1ENtB4x_2B0EB4v_EB4L_EEEEEECs4oicsBtN6nJ_15spiral_protocol.exit.i_crit_edge, %bb2.i50.i
  %582 = ptrtoint ptr %_4 to i64, !dbg !49477
  %583 = lshr i64 %582, 3, !dbg !49477
  %584 = add i64 %583, 2147450880, !dbg !49477
  %585 = inttoptr i64 %584 to ptr, !dbg !49477
  %586 = load i8, ptr %585, align 1, !dbg !49477
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %586), !dbg !49477
  %587 = icmp ne i8 %586, 0, !dbg !49477
  br i1 %587, label %590, label %_RINvNtCshZBO5P2NUJi_4core3ptr9drop_glueINtNtB4_6option6OptionINtCskG2NEjLuYj5_16chacha20poly130514ChaChaPoly1305INtNtCs3uTrKuTqj2Q_6cipher14stream_wrapper23StreamCipherCoreWrapperINtCslD4gSC9HkLH_8chacha2010ChaChaCoreINtNtCs9T39WwoIZ0p_7typenum4uint4UIntIB3u_IB3u_IB3u_NtB3w_5UTermNtNtB3y_3bit2B1ENtB4x_2B0EB4v_EB4L_EEEEEECs4oicsBtN6nJ_15spiral_protocol.exit.i._crit_edge, !dbg !49477, !prof !4181

_RINvNtCshZBO5P2NUJi_4core3ptr9drop_glueINtNtB4_6option6OptionINtCskG2NEjLuYj5_16chacha20poly130514ChaChaPoly1305INtNtCs3uTrKuTqj2Q_6cipher14stream_wrapper23StreamCipherCoreWrapperINtCslD4gSC9HkLH_8chacha2010ChaChaCoreINtNtCs9T39WwoIZ0p_7typenum4uint4UIntIB3u_IB3u_IB3u_NtB3w_5UTermNtNtB3y_3bit2B1ENtB4x_2B0EB4v_EB4L_EEEEEECs4oicsBtN6nJ_15spiral_protocol.exit.i._crit_edge: ; preds = %_RINvNtCshZBO5P2NUJi_4core3ptr9drop_glueINtNtB4_6option6OptionINtCskG2NEjLuYj5_16chacha20poly130514ChaChaPoly1305INtNtCs3uTrKuTqj2Q_6cipher14stream_wrapper23StreamCipherCoreWrapperINtCslD4gSC9HkLH_8chacha2010ChaChaCoreINtNtCs9T39WwoIZ0p_7typenum4uint4UIntIB3u_IB3u_IB3u_NtB3w_5UTermNtNtB3y_3bit2B1ENtB4x_2B0EB4v_EB4L_EEEEEECs4oicsBtN6nJ_15spiral_protocol.exit.i
  %588 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 98), align 1, !dbg !49477, !nosanitize !4110
  %589 = add i8 %588, 1, !dbg !49477
  store i8 %589, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 98), align 1, !dbg !49477, !nosanitize !4110
  br label %599, !dbg !49477

590:                                              ; preds = %_RINvNtCshZBO5P2NUJi_4core3ptr9drop_glueINtNtB4_6option6OptionINtCskG2NEjLuYj5_16chacha20poly130514ChaChaPoly1305INtNtCs3uTrKuTqj2Q_6cipher14stream_wrapper23StreamCipherCoreWrapperINtCslD4gSC9HkLH_8chacha2010ChaChaCoreINtNtCs9T39WwoIZ0p_7typenum4uint4UIntIB3u_IB3u_IB3u_NtB3w_5UTermNtNtB3y_3bit2B1ENtB4x_2B0EB4v_EB4L_EEEEEECs4oicsBtN6nJ_15spiral_protocol.exit.i
  %591 = and i64 %582, 7, !dbg !49477
  %592 = trunc i64 %591 to i8, !dbg !49477
  call void @__sanitizer_cov_trace_cmp1(i8 %592, i8 %586), !dbg !49477
  %593 = icmp sge i8 %592, %586, !dbg !49477
  br i1 %593, label %596, label %._crit_edge25, !dbg !49477

._crit_edge25:                                    ; preds = %590
  %594 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 99), align 1, !dbg !49477, !nosanitize !4110
  %595 = add i8 %594, 1, !dbg !49477
  store i8 %595, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 99), align 1, !dbg !49477, !nosanitize !4110
  br label %599, !dbg !49477

596:                                              ; preds = %590
  %597 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 100), align 1, !dbg !49477, !nosanitize !4110
  %598 = add i8 %597, 1, !dbg !49477
  store i8 %598, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 100), align 1, !dbg !49477, !nosanitize !4110
  call void @__asan_report_store1(i64 %582) #42, !dbg !49477
  unreachable

599:                                              ; preds = %._crit_edge25, %_RINvNtCshZBO5P2NUJi_4core3ptr9drop_glueINtNtB4_6option6OptionINtCskG2NEjLuYj5_16chacha20poly130514ChaChaPoly1305INtNtCs3uTrKuTqj2Q_6cipher14stream_wrapper23StreamCipherCoreWrapperINtCslD4gSC9HkLH_8chacha2010ChaChaCoreINtNtCs9T39WwoIZ0p_7typenum4uint4UIntIB3u_IB3u_IB3u_NtB3w_5UTermNtNtB3y_3bit2B1ENtB4x_2B0EB4v_EB4L_EEEEEECs4oicsBtN6nJ_15spiral_protocol.exit.i._crit_edge
  store i8 0, ptr %_4, align 1, !dbg !49477, !noalias !49263
  br label %bb57.i, !dbg !49478

bb53.i:                                           ; preds = %537
  %600 = ptrtoint ptr %_9 to i64, !dbg !49479
  %601 = lshr i64 %600, 3, !dbg !49479
  %602 = add i64 %601, 2147450880, !dbg !49479
  %603 = inttoptr i64 %602 to ptr, !dbg !49479
  %604 = load i8, ptr %603, align 1, !dbg !49479
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %604), !dbg !49479
  %605 = icmp ne i8 %604, 0, !dbg !49479
  br i1 %605, label %606, label %609, !dbg !49479

606:                                              ; preds = %bb53.i
  %607 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 101), align 1, !dbg !49479, !nosanitize !4110
  %608 = add i8 %607, 1, !dbg !49479
  store i8 %608, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 101), align 1, !dbg !49479, !nosanitize !4110
  call void @__asan_report_load8(i64 %600) #42, !dbg !49479
  unreachable, !dbg !49479

609:                                              ; preds = %bb53.i
  %610 = load i64, ptr %_9, align 8, !dbg !49479, !noalias !49263, !noundef !4110
  %_68.0.i = add i64 %610, %_25.0.i, !dbg !49479
  call void @__sanitizer_cov_trace_cmp8(i64 %_68.0.i, i64 %_25.0.i), !dbg !49479
  %_68.1.i = icmp ult i64 %_68.0.i, %_25.0.i, !dbg !49479
  br i1 %_68.1.i, label %panic6.i, label %bb54.i, !dbg !49479

bb57.i:                                           ; preds = %664, %599
  call void @llvm.lifetime.start.p0(ptr nonnull %_70.sroa.4.sroa.0.i), !dbg !49480
  %_70.sroa.4.sroa.0.7..sroa_idx.i = getelementptr inbounds nuw i8, ptr %_70.sroa.4.sroa.0.i, i64 7, !dbg !49480
  %611 = call ptr @__asan_memcpy(ptr %_70.sroa.4.sroa.0.7..sroa_idx.i, ptr %buf, i64 32), !dbg !49480
  %612 = ptrtoint ptr %result to i64, !dbg !49481
  %613 = lshr i64 %612, 3, !dbg !49481
  %614 = add i64 %613, 2147450880, !dbg !49481
  %615 = inttoptr i64 %614 to ptr, !dbg !49481
  %616 = load i8, ptr %615, align 1, !dbg !49481
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %616), !dbg !49481
  %617 = icmp ne i8 %616, 0, !dbg !49481
  br i1 %617, label %620, label %bb57.i._crit_edge, !dbg !49481, !prof !4181

bb57.i._crit_edge:                                ; preds = %bb57.i
  %618 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 102), align 1, !dbg !49481, !nosanitize !4110
  %619 = add i8 %618, 1, !dbg !49481
  store i8 %619, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 102), align 1, !dbg !49481, !nosanitize !4110
  br label %629, !dbg !49481

620:                                              ; preds = %bb57.i
  %621 = and i64 %612, 7, !dbg !49481
  %622 = trunc i64 %621 to i8, !dbg !49481
  call void @__sanitizer_cov_trace_cmp1(i8 %622, i8 %616), !dbg !49481
  %623 = icmp sge i8 %622, %616, !dbg !49481
  br i1 %623, label %626, label %._crit_edge26, !dbg !49481

._crit_edge26:                                    ; preds = %620
  %624 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 103), align 1, !dbg !49481, !nosanitize !4110
  %625 = add i8 %624, 1, !dbg !49481
  store i8 %625, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 103), align 1, !dbg !49481, !nosanitize !4110
  br label %629, !dbg !49481

626:                                              ; preds = %620
  %627 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 104), align 1, !dbg !49481, !nosanitize !4110
  %628 = add i8 %627, 1, !dbg !49481
  store i8 %628, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 104), align 1, !dbg !49481, !nosanitize !4110
  call void @__asan_report_store1(i64 %612) #42, !dbg !49481
  unreachable

629:                                              ; preds = %._crit_edge26, %bb57.i._crit_edge
  store i8 %_7.sroa.14.32.extract.trunc.i, ptr %result, align 8, !dbg !49481, !alias.scope !49253, !noalias !49256
  %_70.sroa.4.0._0.sroa_idx.i = getelementptr inbounds nuw i8, ptr %result, i64 1, !dbg !49481
  %630 = call ptr @__asan_memcpy(ptr %_70.sroa.4.0._0.sroa_idx.i, ptr %_70.sroa.4.sroa.0.i, i64 39), !dbg !49481
  %_70.sroa.4.sroa.4.0._70.sroa.4.0._0.sroa_idx.sroa_idx.i = getelementptr inbounds nuw i8, ptr %result, i64 40, !dbg !49481
  %631 = ptrtoint ptr %_70.sroa.4.sroa.4.0._70.sroa.4.0._0.sroa_idx.sroa_idx.i to i64, !dbg !49481
  %632 = lshr i64 %631, 3, !dbg !49481
  %633 = add i64 %632, 2147450880, !dbg !49481
  %634 = inttoptr i64 %633 to ptr, !dbg !49481
  %635 = load i8, ptr %634, align 1, !dbg !49481
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %635), !dbg !49481
  %636 = icmp ne i8 %635, 0, !dbg !49481
  br i1 %636, label %637, label %640, !dbg !49481

637:                                              ; preds = %629
  %638 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 105), align 1, !dbg !49481, !nosanitize !4110
  %639 = add i8 %638, 1, !dbg !49481
  store i8 %639, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 105), align 1, !dbg !49481, !nosanitize !4110
  call void @__asan_report_store8(i64 %631) #42, !dbg !49481
  unreachable, !dbg !49481

640:                                              ; preds = %629
  store i64 40, ptr %_70.sroa.4.sroa.4.0._70.sroa.4.0._0.sroa_idx.sroa_idx.i, align 8, !dbg !49481, !alias.scope !49253, !noalias !49256
  %_70.sroa.4.sroa.5.0._70.sroa.4.0._0.sroa_idx.sroa_idx.i = getelementptr inbounds nuw i8, ptr %result, i64 48, !dbg !49481
  %641 = ptrtoint ptr %_70.sroa.4.sroa.5.0._70.sroa.4.0._0.sroa_idx.sroa_idx.i to i64, !dbg !49481
  %642 = lshr i64 %641, 3, !dbg !49481
  %643 = add i64 %642, 2147450880, !dbg !49481
  %644 = inttoptr i64 %643 to ptr, !dbg !49481
  %645 = load i8, ptr %644, align 1, !dbg !49481
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %645), !dbg !49481
  %646 = icmp ne i8 %645, 0, !dbg !49481
  br i1 %646, label %647, label %650, !dbg !49481

647:                                              ; preds = %640
  %648 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 106), align 1, !dbg !49481, !nosanitize !4110
  %649 = add i8 %648, 1, !dbg !49481
  store i8 %649, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 106), align 1, !dbg !49481, !nosanitize !4110
  call void @__asan_report_store8(i64 %641) #42, !dbg !49481
  unreachable, !dbg !49481

650:                                              ; preds = %640
  %651 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 107), align 1, !dbg !49481, !nosanitize !4110
  %652 = add i8 %651, 1, !dbg !49481
  store i8 %652, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 107), align 1, !dbg !49481, !nosanitize !4110
  store i64 %_25.0.i, ptr %_70.sroa.4.sroa.5.0._70.sroa.4.0._0.sroa_idx.sroa_idx.i, align 8, !dbg !49481, !alias.scope !49253, !noalias !49256
  call void @llvm.lifetime.end.p0(ptr nonnull %_70.sroa.4.sroa.0.i), !dbg !49482
  %653 = add i64 %32, 28, !dbg !49466
  %654 = inttoptr i64 %653 to ptr, !dbg !49466
  store i16 -1800, ptr %654, align 1, !dbg !49466
  br label %_RNCNvMs_NtCs4oicsBtN6nJ_15spiral_protocol7recordsNtB6_2Rx6decode0B8_.exit, !dbg !49483

bb54.i:                                           ; preds = %609
  %655 = ptrtoint ptr %_9 to i64, !dbg !49479
  %656 = lshr i64 %655, 3, !dbg !49479
  %657 = add i64 %656, 2147450880, !dbg !49479
  %658 = inttoptr i64 %657 to ptr, !dbg !49479
  %659 = load i8, ptr %658, align 1, !dbg !49479
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %659), !dbg !49479
  %660 = icmp ne i8 %659, 0, !dbg !49479
  br i1 %660, label %661, label %664, !dbg !49479

661:                                              ; preds = %bb54.i
  %662 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 108), align 1, !dbg !49479, !nosanitize !4110
  %663 = add i8 %662, 1, !dbg !49479
  store i8 %663, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 108), align 1, !dbg !49479, !nosanitize !4110
  call void @__asan_report_store8(i64 %655) #42, !dbg !49479
  unreachable, !dbg !49479

664:                                              ; preds = %bb54.i
  %665 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 109), align 1, !dbg !49479, !nosanitize !4110
  %666 = add i8 %665, 1, !dbg !49479
  store i8 %666, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 109), align 1, !dbg !49479, !nosanitize !4110
  store i64 %_68.0.i, ptr %_9, align 8, !dbg !49479, !noalias !49263
  br label %bb57.i, !dbg !49478

panic6.i:                                         ; preds = %609
  %667 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 110), align 1, !dbg !49479, !nosanitize !4110
  %668 = add i8 %667, 1, !dbg !49479
  store i8 %668, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 110), align 1, !dbg !49479, !nosanitize !4110
  call void @__asan_handle_no_return(), !dbg !49479
; call core::panicking::panic_const::panic_const_add_overflow
  call void @_RNvNtNtCshZBO5P2NUJi_4core9panicking11panic_const24panic_const_add_overflow(ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_1576694eced9d0df98b4e42bd20113da) #43, !dbg !49479, !noalias !49263
  unreachable, !dbg !49479

bb62.i:                                           ; preds = %523, %445, %316, %282, %227, %130
; call <spiral_protocol::buffer::Buffer as core::ops::drop::Drop>::drop
  call void @_RNvXs1_NtCs4oicsBtN6nJ_15spiral_protocol6bufferNtB5_6BufferNtNtNtCshZBO5P2NUJi_4core3ops4drop4Drop4drop(ptr noalias nofree noundef nonnull align 8 dereferenceable(88) %27) #35, !dbg !49484, !noalias !49253
; call <alloc::vec::Vec<u8> as core::ops::drop::Drop>::drop
  call void @_RNvXsp_NtCs95TQQ7nxHrj_5alloc3vecINtB5_3VechENtNtNtCshZBO5P2NUJi_4core3ops4drop4Drop4dropCs7jJvS58pafZ_4ring(ptr noalias nofree noundef nonnull align 8 dereferenceable(88) %27) #35, !dbg !49488, !noalias !49253
; call <alloc::raw_vec::RawVec<u8> as core::ops::drop::Drop>::drop
  call void @_RNvXs4_NtCs95TQQ7nxHrj_5alloc7raw_vecINtB5_6RawVechENtNtNtCshZBO5P2NUJi_4core3ops4drop4Drop4dropCs7jJvS58pafZ_4ring(ptr noalias nofree noundef nonnull align 8 dereferenceable(88) %27) #35, !dbg !49490, !noalias !49253
  %669 = getelementptr inbounds nuw i8, ptr %27, i64 24, !dbg !49484
  call void @llvm.experimental.noalias.scope.decl(metadata !49492), !dbg !49484
  %670 = load ptr, ptr %669, align 8, !dbg !49495, !alias.scope !49497, !noalias !49253, !noundef !4110
  %671 = icmp eq ptr %670, null, !dbg !49495
  br i1 %671, label %bb62.i._RNCNvMs_NtCs4oicsBtN6nJ_15spiral_protocol7recordsNtB6_2Rx6decode0B8_.exit_crit_edge, label %bb2.i.i.i52.i, !dbg !49495

bb62.i._RNCNvMs_NtCs4oicsBtN6nJ_15spiral_protocol7recordsNtB6_2Rx6decode0B8_.exit_crit_edge: ; preds = %bb62.i
  %672 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 111), align 1, !dbg !49495, !nosanitize !4110
  %673 = add i8 %672, 1, !dbg !49495
  store i8 %673, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 111), align 1, !dbg !49495, !nosanitize !4110
  br label %_RNCNvMs_NtCs4oicsBtN6nJ_15spiral_protocol7recordsNtB6_2Rx6decode0B8_.exit, !dbg !49495

bb2.i.i.i52.i:                                    ; preds = %bb62.i
  %674 = ptrtoint ptr %670 to i64, !dbg !49502
  %675 = lshr i64 %674, 3, !dbg !49502
  %676 = add i64 %675, 2147450880, !dbg !49502
  %677 = inttoptr i64 %676 to ptr, !dbg !49502
  %678 = load i8, ptr %677, align 1, !dbg !49502
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %678), !dbg !49502
  %679 = icmp ne i8 %678, 0, !dbg !49502
  br i1 %679, label %680, label %683, !dbg !49502

680:                                              ; preds = %bb2.i.i.i52.i
  %681 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 112), align 1, !dbg !49502, !nosanitize !4110
  %682 = add i8 %681, 1, !dbg !49502
  store i8 %682, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 112), align 1, !dbg !49502, !nosanitize !4110
  call void @__asan_report_store8(i64 %674) #42, !dbg !49502
  unreachable, !dbg !49502

683:                                              ; preds = %bb2.i.i.i52.i
  %_2.i.i.i.i.i.i = atomicrmw sub ptr %670, i64 1 release, align 8, !dbg !49502, !noalias !49507
  call void @__sanitizer_cov_trace_const_cmp8(i64 1, i64 %_2.i.i.i.i.i.i), !dbg !49512
  %684 = icmp eq i64 %_2.i.i.i.i.i.i, 1, !dbg !49512
  br i1 %684, label %bb2.i.i.i.i.i.i, label %._RNCNvMs_NtCs4oicsBtN6nJ_15spiral_protocol7recordsNtB6_2Rx6decode0B8_.exit_crit_edge, !dbg !49512

._RNCNvMs_NtCs4oicsBtN6nJ_15spiral_protocol7recordsNtB6_2Rx6decode0B8_.exit_crit_edge: ; preds = %683
  %685 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 113), align 1, !dbg !49512, !nosanitize !4110
  %686 = add i8 %685, 1, !dbg !49512
  store i8 %686, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 113), align 1, !dbg !49512, !nosanitize !4110
  br label %_RNCNvMs_NtCs4oicsBtN6nJ_15spiral_protocol7recordsNtB6_2Rx6decode0B8_.exit, !dbg !49512

bb2.i.i.i.i.i.i:                                  ; preds = %683
  %687 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 114), align 1, !dbg !49513, !nosanitize !4110
  %688 = add i8 %687, 1, !dbg !49513
  store i8 %688, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 114), align 1, !dbg !49513, !nosanitize !4110
  fence acquire, !dbg !49513
; call <alloc::rcs::arc::Arc<spiral_protocol::buffer::Pool>>::drop_slow
  call void @_RNvMsn_NtNtCs95TQQ7nxHrj_5alloc3rcs3arcINtB5_3ArcNtNtCs4oicsBtN6nJ_15spiral_protocol6buffer4PoolE9drop_slowBP_(ptr noalias nofree noundef nonnull readonly align 8 dereferenceable(8) %669) #35, !dbg !49515, !noalias !49253
  br label %_RNCNvMs_NtCs4oicsBtN6nJ_15spiral_protocol7recordsNtB6_2Rx6decode0B8_.exit, !dbg !49516

_RNCNvMs_NtCs4oicsBtN6nJ_15spiral_protocol7recordsNtB6_2Rx6decode0B8_.exit: ; preds = %._RNCNvMs_NtCs4oicsBtN6nJ_15spiral_protocol7recordsNtB6_2Rx6decode0B8_.exit_crit_edge, %bb62.i._RNCNvMs_NtCs4oicsBtN6nJ_15spiral_protocol7recordsNtB6_2Rx6decode0B8_.exit_crit_edge, %650, %bb2.i.i.i.i.i.i
  %689 = add i64 %32, 32, !dbg !49517
  %690 = inttoptr i64 %689 to ptr, !dbg !49517
  store i64 -506381209866536712, ptr %690, align 1, !dbg !49517
  %691 = add i64 %32, 40, !dbg !49517
  %692 = inttoptr i64 %691 to ptr, !dbg !49517
  store i16 -1800, ptr %692, align 1, !dbg !49517
  %693 = add i64 %32, 42, !dbg !49517
  %694 = inttoptr i64 %693 to ptr, !dbg !49517
  store i8 -8, ptr %694, align 1, !dbg !49517
  %695 = getelementptr inbounds nuw i8, ptr %result, i64 8, !dbg !49518
  %696 = ptrtoint ptr %695 to i64, !dbg !49518
  %697 = lshr i64 %696, 3, !dbg !49518
  %698 = add i64 %697, 2147450880, !dbg !49518
  %699 = inttoptr i64 %698 to ptr, !dbg !49518
  %700 = load i8, ptr %699, align 1, !dbg !49518
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %700), !dbg !49518
  %701 = icmp ne i8 %700, 0, !dbg !49518
  br i1 %701, label %702, label %705, !dbg !49518

702:                                              ; preds = %_RNCNvMs_NtCs4oicsBtN6nJ_15spiral_protocol7recordsNtB6_2Rx6decode0B8_.exit
  %703 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 115), align 1, !dbg !49518, !nosanitize !4110
  %704 = add i8 %703, 1, !dbg !49518
  store i8 %704, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 115), align 1, !dbg !49518, !nosanitize !4110
  call void @__asan_report_load8(i64 %696) #42, !dbg !49518
  unreachable, !dbg !49518

705:                                              ; preds = %_RNCNvMs_NtCs4oicsBtN6nJ_15spiral_protocol7recordsNtB6_2Rx6decode0B8_.exit
  %706 = load i64, ptr %695, align 8, !dbg !49518, !range !11586, !alias.scope !49526, !noundef !4110
  call void @__sanitizer_cov_trace_const_cmp8(i64 -1, i64 %706), !dbg !49518
  %.not.i = icmp eq i64 %706, -1, !dbg !49518
  br i1 %.not.i, label %bb3, label %.bb6_crit_edge, !dbg !49529

.bb6_crit_edge:                                   ; preds = %705
  %707 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 116), align 1, !dbg !49529, !nosanitize !4110
  %708 = add i8 %707, 1, !dbg !49529
  store i8 %708, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 116), align 1, !dbg !49529, !nosanitize !4110
  br label %bb6, !dbg !49529

bb3:                                              ; preds = %705
  %709 = ptrtoint ptr %_4 to i64, !dbg !49530
  %710 = lshr i64 %709, 3, !dbg !49530
  %711 = add i64 %710, 2147450880, !dbg !49530
  %712 = inttoptr i64 %711 to ptr, !dbg !49530
  %713 = load i8, ptr %712, align 1, !dbg !49530
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %713), !dbg !49530
  %714 = icmp ne i8 %713, 0, !dbg !49530
  br i1 %714, label %717, label %bb3._crit_edge, !dbg !49530, !prof !4181

bb3._crit_edge:                                   ; preds = %bb3
  %715 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 117), align 1, !dbg !49530, !nosanitize !4110
  %716 = add i8 %715, 1, !dbg !49530
  store i8 %716, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 117), align 1, !dbg !49530, !nosanitize !4110
  br label %726, !dbg !49530

717:                                              ; preds = %bb3
  %718 = and i64 %709, 7, !dbg !49530
  %719 = trunc i64 %718 to i8, !dbg !49530
  call void @__sanitizer_cov_trace_cmp1(i8 %719, i8 %713), !dbg !49530
  %720 = icmp sge i8 %719, %713, !dbg !49530
  br i1 %720, label %723, label %._crit_edge27, !dbg !49530

._crit_edge27:                                    ; preds = %717
  %721 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 118), align 1, !dbg !49530, !nosanitize !4110
  %722 = add i8 %721, 1, !dbg !49530
  store i8 %722, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 118), align 1, !dbg !49530, !nosanitize !4110
  br label %726, !dbg !49530

723:                                              ; preds = %717
  %724 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 119), align 1, !dbg !49530, !nosanitize !4110
  %725 = add i8 %724, 1, !dbg !49530
  store i8 %725, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 119), align 1, !dbg !49530, !nosanitize !4110
  call void @__asan_report_load1(i64 %709) #42, !dbg !49530
  unreachable

726:                                              ; preds = %._crit_edge27, %bb3._crit_edge
  %727 = load i8, ptr %_4, align 1, !dbg !49530, !range !4348, !alias.scope !49532, !noundef !4110
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %727), !dbg !49530
  %728 = icmp eq i8 %727, 0, !dbg !49530
  br i1 %728, label %._RINvNtCshZBO5P2NUJi_4core3ptr9drop_glueINtNtB4_6option6OptionINtCskG2NEjLuYj5_16chacha20poly130514ChaChaPoly1305INtNtCs3uTrKuTqj2Q_6cipher14stream_wrapper23StreamCipherCoreWrapperINtCslD4gSC9HkLH_8chacha2010ChaChaCoreINtNtCs9T39WwoIZ0p_7typenum4uint4UIntIB3u_IB3u_IB3u_NtB3w_5UTermNtNtB3y_3bit2B1ENtB4x_2B0EB4v_EB4L_EEEEEECs4oicsBtN6nJ_15spiral_protocol.exit_crit_edge, label %bb2.i, !dbg !49530

._RINvNtCshZBO5P2NUJi_4core3ptr9drop_glueINtNtB4_6option6OptionINtCskG2NEjLuYj5_16chacha20poly130514ChaChaPoly1305INtNtCs3uTrKuTqj2Q_6cipher14stream_wrapper23StreamCipherCoreWrapperINtCslD4gSC9HkLH_8chacha2010ChaChaCoreINtNtCs9T39WwoIZ0p_7typenum4uint4UIntIB3u_IB3u_IB3u_NtB3w_5UTermNtNtB3y_3bit2B1ENtB4x_2B0EB4v_EB4L_EEEEEECs4oicsBtN6nJ_15spiral_protocol.exit_crit_edge: ; preds = %726
  %729 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 120), align 1, !dbg !49530, !nosanitize !4110
  %730 = add i8 %729, 1, !dbg !49530
  store i8 %730, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 120), align 1, !dbg !49530, !nosanitize !4110
  br label %_RINvNtCshZBO5P2NUJi_4core3ptr9drop_glueINtNtB4_6option6OptionINtCskG2NEjLuYj5_16chacha20poly130514ChaChaPoly1305INtNtCs3uTrKuTqj2Q_6cipher14stream_wrapper23StreamCipherCoreWrapperINtCslD4gSC9HkLH_8chacha2010ChaChaCoreINtNtCs9T39WwoIZ0p_7typenum4uint4UIntIB3u_IB3u_IB3u_NtB3w_5UTermNtNtB3y_3bit2B1ENtB4x_2B0EB4v_EB4L_EEEEEECs4oicsBtN6nJ_15spiral_protocol.exit, !dbg !49530

bb2.i:                                            ; preds = %726
  %731 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 121), align 1, !dbg !49530, !nosanitize !4110
  %732 = add i8 %731, 1, !dbg !49530
  store i8 %732, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 121), align 1, !dbg !49530, !nosanitize !4110
  %733 = getelementptr inbounds nuw i8, ptr %self, i64 38, !dbg !49530
; call <[u8] as zeroize::Zeroize>::zeroize
  call void @_RNvXs9_Cs5e7aMHj0NTS_7zeroizeShNtB5_7Zeroize7zeroizeB5_(ptr noalias nofree noundef nonnull dereferenceable(32) %733, i64 noundef 32) #35, !dbg !49535
  br label %_RINvNtCshZBO5P2NUJi_4core3ptr9drop_glueINtNtB4_6option6OptionINtCskG2NEjLuYj5_16chacha20poly130514ChaChaPoly1305INtNtCs3uTrKuTqj2Q_6cipher14stream_wrapper23StreamCipherCoreWrapperINtCslD4gSC9HkLH_8chacha2010ChaChaCoreINtNtCs9T39WwoIZ0p_7typenum4uint4UIntIB3u_IB3u_IB3u_NtB3w_5UTermNtNtB3y_3bit2B1ENtB4x_2B0EB4v_EB4L_EEEEEECs4oicsBtN6nJ_15spiral_protocol.exit, !dbg !49530

_RINvNtCshZBO5P2NUJi_4core3ptr9drop_glueINtNtB4_6option6OptionINtCskG2NEjLuYj5_16chacha20poly130514ChaChaPoly1305INtNtCs3uTrKuTqj2Q_6cipher14stream_wrapper23StreamCipherCoreWrapperINtCslD4gSC9HkLH_8chacha2010ChaChaCoreINtNtCs9T39WwoIZ0p_7typenum4uint4UIntIB3u_IB3u_IB3u_NtB3w_5UTermNtNtB3y_3bit2B1ENtB4x_2B0EB4v_EB4L_EEEEEECs4oicsBtN6nJ_15spiral_protocol.exit: ; preds = %._RINvNtCshZBO5P2NUJi_4core3ptr9drop_glueINtNtB4_6option6OptionINtCskG2NEjLuYj5_16chacha20poly130514ChaChaPoly1305INtNtCs3uTrKuTqj2Q_6cipher14stream_wrapper23StreamCipherCoreWrapperINtCslD4gSC9HkLH_8chacha2010ChaChaCoreINtNtCs9T39WwoIZ0p_7typenum4uint4UIntIB3u_IB3u_IB3u_NtB3w_5UTermNtNtB3y_3bit2B1ENtB4x_2B0EB4v_EB4L_EEEEEECs4oicsBtN6nJ_15spiral_protocol.exit_crit_edge, %bb2.i
  %734 = ptrtoint ptr %_4 to i64, !dbg !49538
  %735 = lshr i64 %734, 3, !dbg !49538
  %736 = add i64 %735, 2147450880, !dbg !49538
  %737 = inttoptr i64 %736 to ptr, !dbg !49538
  %738 = load i8, ptr %737, align 1, !dbg !49538
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %738), !dbg !49538
  %739 = icmp ne i8 %738, 0, !dbg !49538
  br i1 %739, label %742, label %_RINvNtCshZBO5P2NUJi_4core3ptr9drop_glueINtNtB4_6option6OptionINtCskG2NEjLuYj5_16chacha20poly130514ChaChaPoly1305INtNtCs3uTrKuTqj2Q_6cipher14stream_wrapper23StreamCipherCoreWrapperINtCslD4gSC9HkLH_8chacha2010ChaChaCoreINtNtCs9T39WwoIZ0p_7typenum4uint4UIntIB3u_IB3u_IB3u_NtB3w_5UTermNtNtB3y_3bit2B1ENtB4x_2B0EB4v_EB4L_EEEEEECs4oicsBtN6nJ_15spiral_protocol.exit._crit_edge, !dbg !49538, !prof !4181

_RINvNtCshZBO5P2NUJi_4core3ptr9drop_glueINtNtB4_6option6OptionINtCskG2NEjLuYj5_16chacha20poly130514ChaChaPoly1305INtNtCs3uTrKuTqj2Q_6cipher14stream_wrapper23StreamCipherCoreWrapperINtCslD4gSC9HkLH_8chacha2010ChaChaCoreINtNtCs9T39WwoIZ0p_7typenum4uint4UIntIB3u_IB3u_IB3u_NtB3w_5UTermNtNtB3y_3bit2B1ENtB4x_2B0EB4v_EB4L_EEEEEECs4oicsBtN6nJ_15spiral_protocol.exit._crit_edge: ; preds = %_RINvNtCshZBO5P2NUJi_4core3ptr9drop_glueINtNtB4_6option6OptionINtCskG2NEjLuYj5_16chacha20poly130514ChaChaPoly1305INtNtCs3uTrKuTqj2Q_6cipher14stream_wrapper23StreamCipherCoreWrapperINtCslD4gSC9HkLH_8chacha2010ChaChaCoreINtNtCs9T39WwoIZ0p_7typenum4uint4UIntIB3u_IB3u_IB3u_NtB3w_5UTermNtNtB3y_3bit2B1ENtB4x_2B0EB4v_EB4L_EEEEEECs4oicsBtN6nJ_15spiral_protocol.exit
  %740 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 122), align 1, !dbg !49538, !nosanitize !4110
  %741 = add i8 %740, 1, !dbg !49538
  store i8 %741, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 122), align 1, !dbg !49538, !nosanitize !4110
  br label %751, !dbg !49538

742:                                              ; preds = %_RINvNtCshZBO5P2NUJi_4core3ptr9drop_glueINtNtB4_6option6OptionINtCskG2NEjLuYj5_16chacha20poly130514ChaChaPoly1305INtNtCs3uTrKuTqj2Q_6cipher14stream_wrapper23StreamCipherCoreWrapperINtCslD4gSC9HkLH_8chacha2010ChaChaCoreINtNtCs9T39WwoIZ0p_7typenum4uint4UIntIB3u_IB3u_IB3u_NtB3w_5UTermNtNtB3y_3bit2B1ENtB4x_2B0EB4v_EB4L_EEEEEECs4oicsBtN6nJ_15spiral_protocol.exit
  %743 = and i64 %734, 7, !dbg !49538
  %744 = trunc i64 %743 to i8, !dbg !49538
  call void @__sanitizer_cov_trace_cmp1(i8 %744, i8 %738), !dbg !49538
  %745 = icmp sge i8 %744, %738, !dbg !49538
  br i1 %745, label %748, label %._crit_edge28, !dbg !49538

._crit_edge28:                                    ; preds = %742
  %746 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 123), align 1, !dbg !49538, !nosanitize !4110
  %747 = add i8 %746, 1, !dbg !49538
  store i8 %747, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 123), align 1, !dbg !49538, !nosanitize !4110
  br label %751, !dbg !49538

748:                                              ; preds = %742
  %749 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 124), align 1, !dbg !49538, !nosanitize !4110
  %750 = add i8 %749, 1, !dbg !49538
  store i8 %750, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 124), align 1, !dbg !49538, !nosanitize !4110
  call void @__asan_report_store1(i64 %734) #42, !dbg !49538
  unreachable

751:                                              ; preds = %._crit_edge28, %_RINvNtCshZBO5P2NUJi_4core3ptr9drop_glueINtNtB4_6option6OptionINtCskG2NEjLuYj5_16chacha20poly130514ChaChaPoly1305INtNtCs3uTrKuTqj2Q_6cipher14stream_wrapper23StreamCipherCoreWrapperINtCslD4gSC9HkLH_8chacha2010ChaChaCoreINtNtCs9T39WwoIZ0p_7typenum4uint4UIntIB3u_IB3u_IB3u_NtB3w_5UTermNtNtB3y_3bit2B1ENtB4x_2B0EB4v_EB4L_EEEEEECs4oicsBtN6nJ_15spiral_protocol.exit._crit_edge
  store i8 0, ptr %_4, align 1, !dbg !49538
  %752 = ptrtoint ptr %_10 to i64, !dbg !49539
  %753 = lshr i64 %752, 3, !dbg !49539
  %754 = add i64 %753, 2147450880, !dbg !49539
  %755 = inttoptr i64 %754 to ptr, !dbg !49539
  %756 = load i8, ptr %755, align 1, !dbg !49539
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %756), !dbg !49539
  %757 = icmp ne i8 %756, 0, !dbg !49539
  br i1 %757, label %760, label %._crit_edge29, !dbg !49539, !prof !4181

._crit_edge29:                                    ; preds = %751
  %758 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 125), align 1, !dbg !49539, !nosanitize !4110
  %759 = add i8 %758, 1, !dbg !49539
  store i8 %759, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 125), align 1, !dbg !49539, !nosanitize !4110
  br label %769, !dbg !49539

760:                                              ; preds = %751
  %761 = and i64 %752, 7, !dbg !49539
  %762 = trunc i64 %761 to i8, !dbg !49539
  call void @__sanitizer_cov_trace_cmp1(i8 %762, i8 %756), !dbg !49539
  %763 = icmp sge i8 %762, %756, !dbg !49539
  br i1 %763, label %766, label %._crit_edge30, !dbg !49539

._crit_edge30:                                    ; preds = %760
  %764 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 126), align 1, !dbg !49539, !nosanitize !4110
  %765 = add i8 %764, 1, !dbg !49539
  store i8 %765, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 126), align 1, !dbg !49539, !nosanitize !4110
  br label %769, !dbg !49539

766:                                              ; preds = %760
  %767 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 127), align 1, !dbg !49539, !nosanitize !4110
  %768 = add i8 %767, 1, !dbg !49539
  store i8 %768, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 127), align 1, !dbg !49539, !nosanitize !4110
  call void @__asan_report_store1(i64 %752) #42, !dbg !49539
  unreachable

769:                                              ; preds = %._crit_edge30, %._crit_edge29
  store i8 1, ptr %_10, align 2, !dbg !49539
  br label %bb6, !dbg !49540

bb6:                                              ; preds = %.bb6_crit_edge, %769
  store i64 1172321806, ptr %20, align 8, !dbg !49541
  call void @__sanitizer_cov_trace_const_cmp8(i64 0, i64 %11), !dbg !49541
  %770 = icmp ne i64 %11, 0, !dbg !49541
  br i1 %770, label %771, label %778, !dbg !49541

771:                                              ; preds = %bb6
  %772 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 128), align 1, !dbg !49541, !nosanitize !4110
  %773 = add i8 %772, 1, !dbg !49541
  store i8 %773, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 128), align 1, !dbg !49541, !nosanitize !4110
  %774 = add i64 %32, 0, !dbg !49541
  call void @__asan_set_shadow_f5(i64 %774, i64 64), !dbg !49541
  %775 = getelementptr i8, ptr %12, i64 504, !dbg !49541
  %776 = load i64, ptr %775, align 8, !dbg !49541
  %777 = inttoptr i64 %776 to ptr, !dbg !49541
  store i8 0, ptr %777, align 1, !dbg !49541
  br label %793, !dbg !49541

778:                                              ; preds = %bb6
  %779 = load i8, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 129), align 1, !dbg !49541, !nosanitize !4110
  %780 = add i8 %779, 1, !dbg !49541
  store i8 %780, ptr getelementptr ([130 x i8], ptr @__sancov_gen_.2018, i64 0, i64 129), align 1, !dbg !49541, !nosanitize !4110
  %781 = add i64 %32, 0, !dbg !49541
  %782 = inttoptr i64 %781 to ptr, !dbg !49541
  store i64 0, ptr %782, align 1, !dbg !49541
  %783 = add i64 %32, 8, !dbg !49541
  %784 = inttoptr i64 %783 to ptr, !dbg !49541
  store i64 0, ptr %784, align 1, !dbg !49541
  %785 = add i64 %32, 16, !dbg !49541
  %786 = inttoptr i64 %785 to ptr, !dbg !49541
  store i64 0, ptr %786, align 1, !dbg !49541
  %787 = add i64 %32, 24, !dbg !49541
  %788 = inttoptr i64 %787 to ptr, !dbg !49541
  store i64 0, ptr %788, align 1, !dbg !49541
  %789 = add i64 %32, 32, !dbg !49541
  %790 = inttoptr i64 %789 to ptr, !dbg !49541
  store i64 0, ptr %790, align 1, !dbg !49541
  %791 = add i64 %32, 40, !dbg !49541
  %792 = inttoptr i64 %791 to ptr, !dbg !49541
  store i64 0, ptr %792, align 1, !dbg !49541
  br label %793, !dbg !49541

793:                                              ; preds = %778, %771
  ret void, !dbg !49541
}

