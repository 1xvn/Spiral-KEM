; Verified production function: header_parse
define void @_RNvMNtCsiKgSYIST2hs_15spiral_protocol4wireNtB2_6Header5parse(ptr dead_on_unwind noalias nofree noundef writable writeonly sret([48 x i8]) align 8 captures(none) dereferenceable(48) initializes((0, 1)) %_0, ptr noalias nofree noundef nonnull readonly captures(none) %raw.0, i64 noundef range(i64 0, -9223372036854775808) %raw.1) unnamed_addr #17 comdat !dbg !29961 !guid !29963 {
start:
  %0 = load i8, ptr @__sancov_gen_.1449, align 1, !dbg !29964, !nosanitize !4137
  %1 = add i8 %0, 1, !dbg !29964
  store i8 %1, ptr @__sancov_gen_.1449, align 1, !dbg !29964, !nosanitize !4137
  call void @__sanitizer_cov_trace_const_cmp8(i64 40, i64 %raw.1), !dbg !29965
  %2 = icmp eq i64 %raw.1, 40, !dbg !29965
  br i1 %2, label %bb1, label %start.bb98_crit_edge, !dbg !29965

start.bb98_crit_edge:                             ; preds = %start
  %3 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 1), align 1, !dbg !29965, !nosanitize !4137
  %4 = add i8 %3, 1, !dbg !29965
  store i8 %4, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 1), align 1, !dbg !29965, !nosanitize !4137
  br label %bb98, !dbg !29965

bb1:                                              ; preds = %start
  %5 = ptrtoint ptr %raw.0 to i64, !dbg !29966
  %6 = add i64 %5, 3, !dbg !29966
  %7 = inttoptr i64 %6 to ptr, !dbg !29966
  %8 = ptrtoint ptr %raw.0 to i64, !dbg !29966
  %9 = lshr i64 %8, 3, !dbg !29966
  %10 = add i64 %9, 2147450880, !dbg !29966
  %11 = inttoptr i64 %10 to ptr, !dbg !29966
  %12 = load i8, ptr %11, align 1, !dbg !29966
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %12), !dbg !29966
  %13 = icmp ne i8 %12, 0, !dbg !29966
  br i1 %13, label %16, label %bb1._crit_edge, !dbg !29966, !prof !4285

bb1._crit_edge:                                   ; preds = %bb1
  %14 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 2), align 1, !dbg !29966, !nosanitize !4137
  %15 = add i8 %14, 1, !dbg !29966
  store i8 %15, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 2), align 1, !dbg !29966, !nosanitize !4137
  br label %25, !dbg !29966

16:                                               ; preds = %bb1
  %17 = and i64 %8, 7, !dbg !29966
  %18 = trunc i64 %17 to i8, !dbg !29966
  call void @__sanitizer_cov_trace_cmp1(i8 %18, i8 %12), !dbg !29966
  %19 = icmp sge i8 %18, %12, !dbg !29966
  br i1 %19, label %22, label %._crit_edge, !dbg !29966

._crit_edge:                                      ; preds = %16
  %20 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 3), align 1, !dbg !29966, !nosanitize !4137
  %21 = add i8 %20, 1, !dbg !29966
  store i8 %21, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 3), align 1, !dbg !29966, !nosanitize !4137
  br label %25, !dbg !29966

22:                                               ; preds = %16
  %23 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 4), align 1, !dbg !29966, !nosanitize !4137
  %24 = add i8 %23, 1, !dbg !29966
  store i8 %24, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 4), align 1, !dbg !29966, !nosanitize !4137
  call void @__asan_report_load_n(i64 %8, i64 4) #42, !dbg !29966
  unreachable

25:                                               ; preds = %._crit_edge, %bb1._crit_edge
  %26 = ptrtoint ptr %7 to i64, !dbg !29966
  %27 = lshr i64 %26, 3, !dbg !29966
  %28 = add i64 %27, 2147450880, !dbg !29966
  %29 = inttoptr i64 %28 to ptr, !dbg !29966
  %30 = load i8, ptr %29, align 1, !dbg !29966
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %30), !dbg !29966
  %31 = icmp ne i8 %30, 0, !dbg !29966
  br i1 %31, label %34, label %._crit_edge70, !dbg !29966, !prof !4285

._crit_edge70:                                    ; preds = %25
  %32 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 5), align 1, !dbg !29966, !nosanitize !4137
  %33 = add i8 %32, 1, !dbg !29966
  store i8 %33, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 5), align 1, !dbg !29966, !nosanitize !4137
  br label %43, !dbg !29966

34:                                               ; preds = %25
  %35 = and i64 %26, 7, !dbg !29966
  %36 = trunc i64 %35 to i8, !dbg !29966
  call void @__sanitizer_cov_trace_cmp1(i8 %36, i8 %30), !dbg !29966
  %37 = icmp sge i8 %36, %30, !dbg !29966
  br i1 %37, label %40, label %._crit_edge71, !dbg !29966

._crit_edge71:                                    ; preds = %34
  %38 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 6), align 1, !dbg !29966, !nosanitize !4137
  %39 = add i8 %38, 1, !dbg !29966
  store i8 %39, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 6), align 1, !dbg !29966, !nosanitize !4137
  br label %43, !dbg !29966

40:                                               ; preds = %34
  %41 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 7), align 1, !dbg !29966, !nosanitize !4137
  %42 = add i8 %41, 1, !dbg !29966
  store i8 %42, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 7), align 1, !dbg !29966, !nosanitize !4137
  call void @__asan_report_load_n(i64 %26, i64 4) #42, !dbg !29966
  unreachable

43:                                               ; preds = %._crit_edge71, %._crit_edge70
  %44 = load i32, ptr %raw.0, align 1, !dbg !29966, !alias.scope !29979, !noalias !29984
  call void @__sanitizer_cov_trace_const_cmp4(i32 827019347, i32 %44), !dbg !29966
  %_3.i.i.i.not = icmp eq i32 %44, 827019347, !dbg !29966
  br i1 %_3.i.i.i.not, label %bb5, label %.bb98_crit_edge, !dbg !29987

.bb98_crit_edge:                                  ; preds = %43
  %45 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 8), align 1, !dbg !29987, !nosanitize !4137
  %46 = add i8 %45, 1, !dbg !29987
  store i8 %46, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 8), align 1, !dbg !29987, !nosanitize !4137
  br label %bb98, !dbg !29987

bb5:                                              ; preds = %43
  %_16.i = getelementptr inbounds nuw i8, ptr %raw.0, i64 4, !dbg !29988
  %47 = ptrtoint ptr %_16.i to i64, !dbg !29996
  %48 = add i64 %47, 1, !dbg !29996
  %49 = inttoptr i64 %48 to ptr, !dbg !29996
  %50 = ptrtoint ptr %_16.i to i64, !dbg !29996
  %51 = lshr i64 %50, 3, !dbg !29996
  %52 = add i64 %51, 2147450880, !dbg !29996
  %53 = inttoptr i64 %52 to ptr, !dbg !29996
  %54 = load i8, ptr %53, align 1, !dbg !29996
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %54), !dbg !29996
  %55 = icmp ne i8 %54, 0, !dbg !29996
  br i1 %55, label %58, label %bb5._crit_edge, !dbg !29996, !prof !4285

bb5._crit_edge:                                   ; preds = %bb5
  %56 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 9), align 1, !dbg !29996, !nosanitize !4137
  %57 = add i8 %56, 1, !dbg !29996
  store i8 %57, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 9), align 1, !dbg !29996, !nosanitize !4137
  br label %67, !dbg !29996

58:                                               ; preds = %bb5
  %59 = and i64 %50, 7, !dbg !29996
  %60 = trunc i64 %59 to i8, !dbg !29996
  call void @__sanitizer_cov_trace_cmp1(i8 %60, i8 %54), !dbg !29996
  %61 = icmp sge i8 %60, %54, !dbg !29996
  br i1 %61, label %64, label %._crit_edge72, !dbg !29996

._crit_edge72:                                    ; preds = %58
  %62 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 10), align 1, !dbg !29996, !nosanitize !4137
  %63 = add i8 %62, 1, !dbg !29996
  store i8 %63, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 10), align 1, !dbg !29996, !nosanitize !4137
  br label %67, !dbg !29996

64:                                               ; preds = %58
  %65 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 11), align 1, !dbg !29996, !nosanitize !4137
  %66 = add i8 %65, 1, !dbg !29996
  store i8 %66, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 11), align 1, !dbg !29996, !nosanitize !4137
  call void @__asan_report_load_n(i64 %50, i64 2) #42, !dbg !29996
  unreachable

67:                                               ; preds = %._crit_edge72, %bb5._crit_edge
  %68 = ptrtoint ptr %49 to i64, !dbg !29996
  %69 = lshr i64 %68, 3, !dbg !29996
  %70 = add i64 %69, 2147450880, !dbg !29996
  %71 = inttoptr i64 %70 to ptr, !dbg !29996
  %72 = load i8, ptr %71, align 1, !dbg !29996
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %72), !dbg !29996
  %73 = icmp ne i8 %72, 0, !dbg !29996
  br i1 %73, label %76, label %._crit_edge73, !dbg !29996, !prof !4285

._crit_edge73:                                    ; preds = %67
  %74 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 12), align 1, !dbg !29996, !nosanitize !4137
  %75 = add i8 %74, 1, !dbg !29996
  store i8 %75, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 12), align 1, !dbg !29996, !nosanitize !4137
  br label %85, !dbg !29996

76:                                               ; preds = %67
  %77 = and i64 %68, 7, !dbg !29996
  %78 = trunc i64 %77 to i8, !dbg !29996
  call void @__sanitizer_cov_trace_cmp1(i8 %78, i8 %72), !dbg !29996
  %79 = icmp sge i8 %78, %72, !dbg !29996
  br i1 %79, label %82, label %._crit_edge74, !dbg !29996

._crit_edge74:                                    ; preds = %76
  %80 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 13), align 1, !dbg !29996, !nosanitize !4137
  %81 = add i8 %80, 1, !dbg !29996
  store i8 %81, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 13), align 1, !dbg !29996, !nosanitize !4137
  br label %85, !dbg !29996

82:                                               ; preds = %76
  %83 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 14), align 1, !dbg !29996, !nosanitize !4137
  %84 = add i8 %83, 1, !dbg !29996
  store i8 %84, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 14), align 1, !dbg !29996, !nosanitize !4137
  call void @__asan_report_load_n(i64 %68, i64 2) #42, !dbg !29996
  unreachable

85:                                               ; preds = %._crit_edge74, %._crit_edge73
  %86 = load i16, ptr %_16.i, align 1, !dbg !29996, !alias.scope !30006, !noalias !30011
  call void @__sanitizer_cov_trace_const_cmp2(i16 256, i16 %86), !dbg !29996
  %_3.i.i.not = icmp eq i16 %86, 256, !dbg !29996
  br i1 %_3.i.i.not, label %bb9, label %.bb98_crit_edge75, !dbg !30014

.bb98_crit_edge75:                                ; preds = %85
  %87 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 15), align 1, !dbg !30014, !nosanitize !4137
  %88 = add i8 %87, 1, !dbg !30014
  store i8 %88, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 15), align 1, !dbg !30014, !nosanitize !4137
  br label %bb98, !dbg !30014

bb9:                                              ; preds = %85
  %_16.i26 = getelementptr inbounds nuw i8, ptr %raw.0, i64 10, !dbg !30015
  %89 = ptrtoint ptr %_16.i26 to i64, !dbg !30019
  %90 = add i64 %89, 1, !dbg !30019
  %91 = inttoptr i64 %90 to ptr, !dbg !30019
  %92 = ptrtoint ptr %_16.i26 to i64, !dbg !30019
  %93 = lshr i64 %92, 3, !dbg !30019
  %94 = add i64 %93, 2147450880, !dbg !30019
  %95 = inttoptr i64 %94 to ptr, !dbg !30019
  %96 = load i8, ptr %95, align 1, !dbg !30019
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %96), !dbg !30019
  %97 = icmp ne i8 %96, 0, !dbg !30019
  br i1 %97, label %100, label %bb9._crit_edge, !dbg !30019, !prof !4285

bb9._crit_edge:                                   ; preds = %bb9
  %98 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 16), align 1, !dbg !30019, !nosanitize !4137
  %99 = add i8 %98, 1, !dbg !30019
  store i8 %99, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 16), align 1, !dbg !30019, !nosanitize !4137
  br label %109, !dbg !30019

100:                                              ; preds = %bb9
  %101 = and i64 %92, 7, !dbg !30019
  %102 = trunc i64 %101 to i8, !dbg !30019
  call void @__sanitizer_cov_trace_cmp1(i8 %102, i8 %96), !dbg !30019
  %103 = icmp sge i8 %102, %96, !dbg !30019
  br i1 %103, label %106, label %._crit_edge76, !dbg !30019

._crit_edge76:                                    ; preds = %100
  %104 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 17), align 1, !dbg !30019, !nosanitize !4137
  %105 = add i8 %104, 1, !dbg !30019
  store i8 %105, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 17), align 1, !dbg !30019, !nosanitize !4137
  br label %109, !dbg !30019

106:                                              ; preds = %100
  %107 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 18), align 1, !dbg !30019, !nosanitize !4137
  %108 = add i8 %107, 1, !dbg !30019
  store i8 %108, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 18), align 1, !dbg !30019, !nosanitize !4137
  call void @__asan_report_load_n(i64 %92, i64 2) #42, !dbg !30019
  unreachable

109:                                              ; preds = %._crit_edge76, %bb9._crit_edge
  %110 = ptrtoint ptr %91 to i64, !dbg !30019
  %111 = lshr i64 %110, 3, !dbg !30019
  %112 = add i64 %111, 2147450880, !dbg !30019
  %113 = inttoptr i64 %112 to ptr, !dbg !30019
  %114 = load i8, ptr %113, align 1, !dbg !30019
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %114), !dbg !30019
  %115 = icmp ne i8 %114, 0, !dbg !30019
  br i1 %115, label %118, label %._crit_edge77, !dbg !30019, !prof !4285

._crit_edge77:                                    ; preds = %109
  %116 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 19), align 1, !dbg !30019, !nosanitize !4137
  %117 = add i8 %116, 1, !dbg !30019
  store i8 %117, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 19), align 1, !dbg !30019, !nosanitize !4137
  br label %127, !dbg !30019

118:                                              ; preds = %109
  %119 = and i64 %110, 7, !dbg !30019
  %120 = trunc i64 %119 to i8, !dbg !30019
  call void @__sanitizer_cov_trace_cmp1(i8 %120, i8 %114), !dbg !30019
  %121 = icmp sge i8 %120, %114, !dbg !30019
  br i1 %121, label %124, label %._crit_edge78, !dbg !30019

._crit_edge78:                                    ; preds = %118
  %122 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 20), align 1, !dbg !30019, !nosanitize !4137
  %123 = add i8 %122, 1, !dbg !30019
  store i8 %123, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 20), align 1, !dbg !30019, !nosanitize !4137
  br label %127, !dbg !30019

124:                                              ; preds = %118
  %125 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 21), align 1, !dbg !30019, !nosanitize !4137
  %126 = add i8 %125, 1, !dbg !30019
  store i8 %126, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 21), align 1, !dbg !30019, !nosanitize !4137
  call void @__asan_report_load_n(i64 %110, i64 2) #42, !dbg !30019
  unreachable

127:                                              ; preds = %._crit_edge78, %._crit_edge77
  %128 = load i16, ptr %_16.i26, align 1, !dbg !30019, !alias.scope !30024, !noalias !30029
  call void @__sanitizer_cov_trace_const_cmp2(i16 0, i16 %128), !dbg !30019
  %_3.i.i35.not = icmp eq i16 %128, 0, !dbg !30019
  br i1 %_3.i.i35.not, label %bb14, label %.bb98_crit_edge79, !dbg !30032

.bb98_crit_edge79:                                ; preds = %127
  %129 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 22), align 1, !dbg !30032, !nosanitize !4137
  %130 = add i8 %129, 1, !dbg !30032
  store i8 %130, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 22), align 1, !dbg !30032, !nosanitize !4137
  br label %bb98, !dbg !30032

bb14:                                             ; preds = %127
  %131 = getelementptr inbounds nuw i8, ptr %raw.0, i64 6, !dbg !30033
  %132 = ptrtoint ptr %131 to i64, !dbg !30033
  %133 = lshr i64 %132, 3, !dbg !30033
  %134 = add i64 %133, 2147450880, !dbg !30033
  %135 = inttoptr i64 %134 to ptr, !dbg !30033
  %136 = load i8, ptr %135, align 1, !dbg !30033
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %136), !dbg !30033
  %137 = icmp ne i8 %136, 0, !dbg !30033
  br i1 %137, label %140, label %bb14._crit_edge, !dbg !30033, !prof !4285

bb14._crit_edge:                                  ; preds = %bb14
  %138 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 23), align 1, !dbg !30033, !nosanitize !4137
  %139 = add i8 %138, 1, !dbg !30033
  store i8 %139, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 23), align 1, !dbg !30033, !nosanitize !4137
  br label %149, !dbg !30033

140:                                              ; preds = %bb14
  %141 = and i64 %132, 7, !dbg !30033
  %142 = trunc i64 %141 to i8, !dbg !30033
  call void @__sanitizer_cov_trace_cmp1(i8 %142, i8 %136), !dbg !30033
  %143 = icmp sge i8 %142, %136, !dbg !30033
  br i1 %143, label %146, label %._crit_edge80, !dbg !30033

._crit_edge80:                                    ; preds = %140
  %144 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 24), align 1, !dbg !30033, !nosanitize !4137
  %145 = add i8 %144, 1, !dbg !30033
  store i8 %145, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 24), align 1, !dbg !30033, !nosanitize !4137
  br label %149, !dbg !30033

146:                                              ; preds = %140
  %147 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 25), align 1, !dbg !30033, !nosanitize !4137
  %148 = add i8 %147, 1, !dbg !30033
  store i8 %148, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 25), align 1, !dbg !30033, !nosanitize !4137
  call void @__asan_report_load1(i64 %132) #42, !dbg !30033
  unreachable

149:                                              ; preds = %._crit_edge80, %bb14._crit_edge
  %_12 = load i8, ptr %131, align 1, !dbg !30033, !noundef !4137
  %150 = getelementptr inbounds nuw i8, ptr %raw.0, i64 7, !dbg !30034
  %151 = ptrtoint ptr %150 to i64, !dbg !30034
  %152 = lshr i64 %151, 3, !dbg !30034
  %153 = add i64 %152, 2147450880, !dbg !30034
  %154 = inttoptr i64 %153 to ptr, !dbg !30034
  %155 = load i8, ptr %154, align 1, !dbg !30034
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %155), !dbg !30034
  %156 = icmp ne i8 %155, 0, !dbg !30034
  br i1 %156, label %159, label %._crit_edge81, !dbg !30034, !prof !4285

._crit_edge81:                                    ; preds = %149
  %157 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 26), align 1, !dbg !30034, !nosanitize !4137
  %158 = add i8 %157, 1, !dbg !30034
  store i8 %158, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 26), align 1, !dbg !30034, !nosanitize !4137
  br label %168, !dbg !30034

159:                                              ; preds = %149
  %160 = and i64 %151, 7, !dbg !30034
  %161 = trunc i64 %160 to i8, !dbg !30034
  call void @__sanitizer_cov_trace_cmp1(i8 %161, i8 %155), !dbg !30034
  %162 = icmp sge i8 %161, %155, !dbg !30034
  br i1 %162, label %165, label %._crit_edge82, !dbg !30034

._crit_edge82:                                    ; preds = %159
  %163 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 27), align 1, !dbg !30034, !nosanitize !4137
  %164 = add i8 %163, 1, !dbg !30034
  store i8 %164, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 27), align 1, !dbg !30034, !nosanitize !4137
  br label %168, !dbg !30034

165:                                              ; preds = %159
  %166 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 28), align 1, !dbg !30034, !nosanitize !4137
  %167 = add i8 %166, 1, !dbg !30034
  store i8 %167, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 28), align 1, !dbg !30034, !nosanitize !4137
  call void @__asan_report_load1(i64 %151) #42, !dbg !30034
  unreachable

168:                                              ; preds = %._crit_edge82, %._crit_edge81
  %_14 = load i8, ptr %150, align 1, !dbg !30034, !noundef !4137
  %_16.i27 = getelementptr inbounds nuw i8, ptr %raw.0, i64 12, !dbg !30035
  %169 = ptrtoint ptr %_16.i27 to i64, !dbg !30039
  %170 = add i64 %169, 15, !dbg !30039
  %171 = inttoptr i64 %170 to ptr, !dbg !30039
  %172 = ptrtoint ptr %_16.i27 to i64, !dbg !30039
  %173 = lshr i64 %172, 3, !dbg !30039
  %174 = add i64 %173, 2147450880, !dbg !30039
  %175 = inttoptr i64 %174 to ptr, !dbg !30039
  %176 = load i8, ptr %175, align 1, !dbg !30039
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %176), !dbg !30039
  %177 = icmp ne i8 %176, 0, !dbg !30039
  br i1 %177, label %180, label %._crit_edge83, !dbg !30039, !prof !4285

._crit_edge83:                                    ; preds = %168
  %178 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 29), align 1, !dbg !30039, !nosanitize !4137
  %179 = add i8 %178, 1, !dbg !30039
  store i8 %179, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 29), align 1, !dbg !30039, !nosanitize !4137
  br label %189, !dbg !30039

180:                                              ; preds = %168
  %181 = and i64 %172, 7, !dbg !30039
  %182 = trunc i64 %181 to i8, !dbg !30039
  call void @__sanitizer_cov_trace_cmp1(i8 %182, i8 %176), !dbg !30039
  %183 = icmp sge i8 %182, %176, !dbg !30039
  br i1 %183, label %186, label %._crit_edge84, !dbg !30039

._crit_edge84:                                    ; preds = %180
  %184 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 30), align 1, !dbg !30039, !nosanitize !4137
  %185 = add i8 %184, 1, !dbg !30039
  store i8 %185, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 30), align 1, !dbg !30039, !nosanitize !4137
  br label %189, !dbg !30039

186:                                              ; preds = %180
  %187 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 31), align 1, !dbg !30039, !nosanitize !4137
  %188 = add i8 %187, 1, !dbg !30039
  store i8 %188, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 31), align 1, !dbg !30039, !nosanitize !4137
  call void @__asan_report_load_n(i64 %172, i64 16) #42, !dbg !30039
  unreachable

189:                                              ; preds = %._crit_edge84, %._crit_edge83
  %190 = ptrtoint ptr %171 to i64, !dbg !30039
  %191 = lshr i64 %190, 3, !dbg !30039
  %192 = add i64 %191, 2147450880, !dbg !30039
  %193 = inttoptr i64 %192 to ptr, !dbg !30039
  %194 = load i8, ptr %193, align 1, !dbg !30039
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %194), !dbg !30039
  %195 = icmp ne i8 %194, 0, !dbg !30039
  br i1 %195, label %198, label %._crit_edge85, !dbg !30039, !prof !4285

._crit_edge85:                                    ; preds = %189
  %196 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 32), align 1, !dbg !30039, !nosanitize !4137
  %197 = add i8 %196, 1, !dbg !30039
  store i8 %197, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 32), align 1, !dbg !30039, !nosanitize !4137
  br label %207, !dbg !30039

198:                                              ; preds = %189
  %199 = and i64 %190, 7, !dbg !30039
  %200 = trunc i64 %199 to i8, !dbg !30039
  call void @__sanitizer_cov_trace_cmp1(i8 %200, i8 %194), !dbg !30039
  %201 = icmp sge i8 %200, %194, !dbg !30039
  br i1 %201, label %204, label %._crit_edge86, !dbg !30039

._crit_edge86:                                    ; preds = %198
  %202 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 33), align 1, !dbg !30039, !nosanitize !4137
  %203 = add i8 %202, 1, !dbg !30039
  store i8 %203, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 33), align 1, !dbg !30039, !nosanitize !4137
  br label %207, !dbg !30039

204:                                              ; preds = %198
  %205 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 34), align 1, !dbg !30039, !nosanitize !4137
  %206 = add i8 %205, 1, !dbg !30039
  store i8 %206, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 34), align 1, !dbg !30039, !nosanitize !4137
  call void @__asan_report_load_n(i64 %190, i64 16) #42, !dbg !30039
  unreachable

207:                                              ; preds = %._crit_edge86, %._crit_edge85
  %_17.sroa.4.1.copyload = load i128, ptr %_16.i27, align 1, !dbg !30039, !alias.scope !30047
  %_16.i28 = getelementptr inbounds nuw i8, ptr %raw.0, i64 28, !dbg !30054
  %208 = ptrtoint ptr %_16.i28 to i64, !dbg !30058
  %209 = add i64 %208, 7, !dbg !30058
  %210 = inttoptr i64 %209 to ptr, !dbg !30058
  %211 = ptrtoint ptr %_16.i28 to i64, !dbg !30058
  %212 = lshr i64 %211, 3, !dbg !30058
  %213 = add i64 %212, 2147450880, !dbg !30058
  %214 = inttoptr i64 %213 to ptr, !dbg !30058
  %215 = load i8, ptr %214, align 1, !dbg !30058
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %215), !dbg !30058
  %216 = icmp ne i8 %215, 0, !dbg !30058
  br i1 %216, label %219, label %._crit_edge87, !dbg !30058, !prof !4285

._crit_edge87:                                    ; preds = %207
  %217 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 35), align 1, !dbg !30058, !nosanitize !4137
  %218 = add i8 %217, 1, !dbg !30058
  store i8 %218, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 35), align 1, !dbg !30058, !nosanitize !4137
  br label %228, !dbg !30058

219:                                              ; preds = %207
  %220 = and i64 %211, 7, !dbg !30058
  %221 = trunc i64 %220 to i8, !dbg !30058
  call void @__sanitizer_cov_trace_cmp1(i8 %221, i8 %215), !dbg !30058
  %222 = icmp sge i8 %221, %215, !dbg !30058
  br i1 %222, label %225, label %._crit_edge88, !dbg !30058

._crit_edge88:                                    ; preds = %219
  %223 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 36), align 1, !dbg !30058, !nosanitize !4137
  %224 = add i8 %223, 1, !dbg !30058
  store i8 %224, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 36), align 1, !dbg !30058, !nosanitize !4137
  br label %228, !dbg !30058

225:                                              ; preds = %219
  %226 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 37), align 1, !dbg !30058, !nosanitize !4137
  %227 = add i8 %226, 1, !dbg !30058
  store i8 %227, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 37), align 1, !dbg !30058, !nosanitize !4137
  call void @__asan_report_load_n(i64 %211, i64 8) #42, !dbg !30058
  unreachable

228:                                              ; preds = %._crit_edge88, %._crit_edge87
  %229 = ptrtoint ptr %210 to i64, !dbg !30058
  %230 = lshr i64 %229, 3, !dbg !30058
  %231 = add i64 %230, 2147450880, !dbg !30058
  %232 = inttoptr i64 %231 to ptr, !dbg !30058
  %233 = load i8, ptr %232, align 1, !dbg !30058
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %233), !dbg !30058
  %234 = icmp ne i8 %233, 0, !dbg !30058
  br i1 %234, label %237, label %._crit_edge89, !dbg !30058, !prof !4285

._crit_edge89:                                    ; preds = %228
  %235 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 38), align 1, !dbg !30058, !nosanitize !4137
  %236 = add i8 %235, 1, !dbg !30058
  store i8 %236, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 38), align 1, !dbg !30058, !nosanitize !4137
  br label %246, !dbg !30058

237:                                              ; preds = %228
  %238 = and i64 %229, 7, !dbg !30058
  %239 = trunc i64 %238 to i8, !dbg !30058
  call void @__sanitizer_cov_trace_cmp1(i8 %239, i8 %233), !dbg !30058
  %240 = icmp sge i8 %239, %233, !dbg !30058
  br i1 %240, label %243, label %._crit_edge90, !dbg !30058

._crit_edge90:                                    ; preds = %237
  %241 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 39), align 1, !dbg !30058, !nosanitize !4137
  %242 = add i8 %241, 1, !dbg !30058
  store i8 %242, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 39), align 1, !dbg !30058, !nosanitize !4137
  br label %246, !dbg !30058

243:                                              ; preds = %237
  %244 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 40), align 1, !dbg !30058, !nosanitize !4137
  %245 = add i8 %244, 1, !dbg !30058
  store i8 %245, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 40), align 1, !dbg !30058, !nosanitize !4137
  call void @__asan_report_load_n(i64 %229, i64 8) #42, !dbg !30058
  unreachable

246:                                              ; preds = %._crit_edge90, %._crit_edge89
  %v.sroa.0.0.copyload.i.i = load i64, ptr %_16.i28, align 1, !dbg !30058, !alias.scope !30065, !noalias !30070
  %_0.i = tail call noundef i64 @llvm.bswap.i64(i64 %v.sroa.0.0.copyload.i.i), !dbg !30073
  %_16.i29 = getelementptr inbounds nuw i8, ptr %raw.0, i64 36, !dbg !30080
  %247 = ptrtoint ptr %_16.i29 to i64, !dbg !30084
  %248 = add i64 %247, 3, !dbg !30084
  %249 = inttoptr i64 %248 to ptr, !dbg !30084
  %250 = ptrtoint ptr %_16.i29 to i64, !dbg !30084
  %251 = lshr i64 %250, 3, !dbg !30084
  %252 = add i64 %251, 2147450880, !dbg !30084
  %253 = inttoptr i64 %252 to ptr, !dbg !30084
  %254 = load i8, ptr %253, align 1, !dbg !30084
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %254), !dbg !30084
  %255 = icmp ne i8 %254, 0, !dbg !30084
  br i1 %255, label %258, label %._crit_edge91, !dbg !30084, !prof !4285

._crit_edge91:                                    ; preds = %246
  %256 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 41), align 1, !dbg !30084, !nosanitize !4137
  %257 = add i8 %256, 1, !dbg !30084
  store i8 %257, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 41), align 1, !dbg !30084, !nosanitize !4137
  br label %267, !dbg !30084

258:                                              ; preds = %246
  %259 = and i64 %250, 7, !dbg !30084
  %260 = trunc i64 %259 to i8, !dbg !30084
  call void @__sanitizer_cov_trace_cmp1(i8 %260, i8 %254), !dbg !30084
  %261 = icmp sge i8 %260, %254, !dbg !30084
  br i1 %261, label %264, label %._crit_edge92, !dbg !30084

._crit_edge92:                                    ; preds = %258
  %262 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 42), align 1, !dbg !30084, !nosanitize !4137
  %263 = add i8 %262, 1, !dbg !30084
  store i8 %263, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 42), align 1, !dbg !30084, !nosanitize !4137
  br label %267, !dbg !30084

264:                                              ; preds = %258
  %265 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 43), align 1, !dbg !30084, !nosanitize !4137
  %266 = add i8 %265, 1, !dbg !30084
  store i8 %266, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 43), align 1, !dbg !30084, !nosanitize !4137
  call void @__asan_report_load_n(i64 %250, i64 4) #42, !dbg !30084
  unreachable

267:                                              ; preds = %._crit_edge92, %._crit_edge91
  %268 = ptrtoint ptr %249 to i64, !dbg !30084
  %269 = lshr i64 %268, 3, !dbg !30084
  %270 = add i64 %269, 2147450880, !dbg !30084
  %271 = inttoptr i64 %270 to ptr, !dbg !30084
  %272 = load i8, ptr %271, align 1, !dbg !30084
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %272), !dbg !30084
  %273 = icmp ne i8 %272, 0, !dbg !30084
  br i1 %273, label %276, label %._crit_edge93, !dbg !30084, !prof !4285

._crit_edge93:                                    ; preds = %267
  %274 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 44), align 1, !dbg !30084, !nosanitize !4137
  %275 = add i8 %274, 1, !dbg !30084
  store i8 %275, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 44), align 1, !dbg !30084, !nosanitize !4137
  br label %285, !dbg !30084

276:                                              ; preds = %267
  %277 = and i64 %268, 7, !dbg !30084
  %278 = trunc i64 %277 to i8, !dbg !30084
  call void @__sanitizer_cov_trace_cmp1(i8 %278, i8 %272), !dbg !30084
  %279 = icmp sge i8 %278, %272, !dbg !30084
  br i1 %279, label %282, label %._crit_edge94, !dbg !30084

._crit_edge94:                                    ; preds = %276
  %280 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 45), align 1, !dbg !30084, !nosanitize !4137
  %281 = add i8 %280, 1, !dbg !30084
  store i8 %281, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 45), align 1, !dbg !30084, !nosanitize !4137
  br label %285, !dbg !30084

282:                                              ; preds = %276
  %283 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 46), align 1, !dbg !30084, !nosanitize !4137
  %284 = add i8 %283, 1, !dbg !30084
  store i8 %284, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 46), align 1, !dbg !30084, !nosanitize !4137
  call void @__asan_report_load_n(i64 %268, i64 4) #42, !dbg !30084
  unreachable

285:                                              ; preds = %._crit_edge94, %._crit_edge93
  %v.sroa.0.0.copyload.i.i43 = load i32, ptr %_16.i29, align 1, !dbg !30084, !alias.scope !30091
  %_0.i44 = tail call noundef i32 @llvm.bswap.i32(i32 %v.sroa.0.0.copyload.i.i43), !dbg !30096
  %_23 = zext i32 %_0.i44 to i64, !dbg !30103
  %switch.tableidx = add i8 %_12, -1, !dbg !30104
  call void @__sanitizer_cov_trace_const_cmp1(i8 17, i8 %switch.tableidx), !dbg !30104
  %286 = icmp ult i8 %switch.tableidx, 17, !dbg !30104
  br i1 %286, label %switch.hole_check, label %.bb98_crit_edge95, !dbg !30104

.bb98_crit_edge95:                                ; preds = %285
  %287 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 47), align 1, !dbg !30104, !nosanitize !4137
  %288 = add i8 %287, 1, !dbg !30104
  store i8 %288, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 47), align 1, !dbg !30104, !nosanitize !4137
  br label %bb98, !dbg !30104

switch.hole_check:                                ; preds = %285
  %switch.maskindex = zext nneg i8 %switch.tableidx to i32, !dbg !30104
  %switch.shifted = lshr i32 98319, %switch.maskindex, !dbg !30104
  %switch.lobit = trunc i32 %switch.shifted to i1, !dbg !30104
  %switch.lobit.not = xor i1 %switch.lobit, true, !dbg !30104
  call void @__sanitizer_cov_trace_const_cmp1(i8 1, i8 %_14), !dbg !30106
  %_28 = icmp ugt i8 %_14, 1
  %or.cond69 = or i1 %switch.lobit.not, %_28, !dbg !30104
  br i1 %or.cond69, label %switch.hole_check.bb98_crit_edge, label %bb36, !dbg !30104

switch.hole_check.bb98_crit_edge:                 ; preds = %switch.hole_check
  %289 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 48), align 1, !dbg !30104, !nosanitize !4137
  %290 = add i8 %289, 1, !dbg !30104
  store i8 %290, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 48), align 1, !dbg !30104, !nosanitize !4137
  br label %bb98, !dbg !30104

bb36:                                             ; preds = %switch.hole_check
  %291 = zext nneg i8 %switch.tableidx to i64, !dbg !30104
  %switch.gep62 = getelementptr inbounds nuw [2 x i8], ptr @switch.table._RNvMNtCsiKgSYIST2hs_15spiral_protocol4wireNtB2_6Header5parse.1, i64 %291, !dbg !30104
  %292 = ptrtoint ptr %switch.gep62 to i64, !dbg !30104
  %293 = lshr i64 %292, 3, !dbg !30104
  %294 = add i64 %293, 2147450880, !dbg !30104
  %295 = inttoptr i64 %294 to ptr, !dbg !30104
  %296 = load i8, ptr %295, align 1, !dbg !30104
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %296), !dbg !30104
  %297 = icmp ne i8 %296, 0, !dbg !30104
  br i1 %297, label %300, label %bb36._crit_edge, !dbg !30104, !prof !4285

bb36._crit_edge:                                  ; preds = %bb36
  %298 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 49), align 1, !dbg !30104, !nosanitize !4137
  %299 = add i8 %298, 1, !dbg !30104
  store i8 %299, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 49), align 1, !dbg !30104, !nosanitize !4137
  br label %310, !dbg !30104

300:                                              ; preds = %bb36
  %301 = and i64 %292, 7, !dbg !30104
  %302 = add i64 %301, 1, !dbg !30104
  %303 = trunc i64 %302 to i8, !dbg !30104
  call void @__sanitizer_cov_trace_cmp1(i8 %303, i8 %296), !dbg !30104
  %304 = icmp sge i8 %303, %296, !dbg !30104
  br i1 %304, label %307, label %._crit_edge96, !dbg !30104

._crit_edge96:                                    ; preds = %300
  %305 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 50), align 1, !dbg !30104, !nosanitize !4137
  %306 = add i8 %305, 1, !dbg !30104
  store i8 %306, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 50), align 1, !dbg !30104, !nosanitize !4137
  br label %310, !dbg !30104

307:                                              ; preds = %300
  %308 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 51), align 1, !dbg !30104, !nosanitize !4137
  %309 = add i8 %308, 1, !dbg !30104
  store i8 %309, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 51), align 1, !dbg !30104, !nosanitize !4137
  call void @__asan_report_load2(i64 %292) #42, !dbg !30104
  unreachable

310:                                              ; preds = %._crit_edge96, %bb36._crit_edge
  %switch.load63 = load i16, ptr %switch.gep62, align 2, !dbg !30104
  %311 = zext nneg i8 %switch.tableidx to i64, !dbg !30104
  %switch.gep = getelementptr inbounds nuw [2 x i8], ptr @switch.table._RNvMNtCsiKgSYIST2hs_15spiral_protocol4wireNtB2_6Header5parse, i64 %311, !dbg !30104
  %312 = ptrtoint ptr %switch.gep to i64, !dbg !30104
  %313 = lshr i64 %312, 3, !dbg !30104
  %314 = add i64 %313, 2147450880, !dbg !30104
  %315 = inttoptr i64 %314 to ptr, !dbg !30104
  %316 = load i8, ptr %315, align 1, !dbg !30104
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %316), !dbg !30104
  %317 = icmp ne i8 %316, 0, !dbg !30104
  br i1 %317, label %320, label %._crit_edge97, !dbg !30104, !prof !4285

._crit_edge97:                                    ; preds = %310
  %318 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 52), align 1, !dbg !30104, !nosanitize !4137
  %319 = add i8 %318, 1, !dbg !30104
  store i8 %319, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 52), align 1, !dbg !30104, !nosanitize !4137
  br label %330, !dbg !30104

320:                                              ; preds = %310
  %321 = and i64 %312, 7, !dbg !30104
  %322 = add i64 %321, 1, !dbg !30104
  %323 = trunc i64 %322 to i8, !dbg !30104
  call void @__sanitizer_cov_trace_cmp1(i8 %323, i8 %316), !dbg !30104
  %324 = icmp sge i8 %323, %316, !dbg !30104
  br i1 %324, label %327, label %._crit_edge98, !dbg !30104

._crit_edge98:                                    ; preds = %320
  %325 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 53), align 1, !dbg !30104, !nosanitize !4137
  %326 = add i8 %325, 1, !dbg !30104
  store i8 %326, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 53), align 1, !dbg !30104, !nosanitize !4137
  br label %330, !dbg !30104

327:                                              ; preds = %320
  %328 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 54), align 1, !dbg !30104, !nosanitize !4137
  %329 = add i8 %328, 1, !dbg !30104
  store i8 %329, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 54), align 1, !dbg !30104, !nosanitize !4137
  call void @__asan_report_load2(i64 %312) #42, !dbg !30104
  unreachable

330:                                              ; preds = %._crit_edge98, %._crit_edge97
  %switch.load = load i16, ptr %switch.gep, align 2, !dbg !30104
  %331 = zext i16 %switch.load to i32, !dbg !30107
  call void @__sanitizer_cov_trace_cmp4(i32 %_0.i44, i32 %331), !dbg !30107
  %_0.i6.not.i.i = icmp uge i32 %_0.i44, %331, !dbg !30107
  %332 = zext i16 %switch.load63 to i32, !dbg !30123
  call void @__sanitizer_cov_trace_cmp4(i32 %_0.i44, i32 %332), !dbg !30123
  %_0.i.i.i = icmp ule i32 %_0.i44, %332, !dbg !30123
  %_0.sroa.0.0.i.i45 = select i1 %_0.i6.not.i.i, i1 %_0.i.i.i, i1 false, !dbg !30123
  br i1 %_0.sroa.0.0.i.i45, label %_RNvMNtCshZBO5P2NUJi_4core6resultINtB2_6ResultAhj2_NtNtB4_5array17TryFromSliceErrorE6unwrapCsiKgSYIST2hs_15spiral_protocol.exit, label %.bb98_crit_edge99, !dbg !30124

.bb98_crit_edge99:                                ; preds = %330
  %333 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 55), align 1, !dbg !30124, !nosanitize !4137
  %334 = add i8 %333, 1, !dbg !30124
  store i8 %334, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 55), align 1, !dbg !30124, !nosanitize !4137
  br label %bb98, !dbg !30124

_RNvMNtCshZBO5P2NUJi_4core6resultINtB2_6ResultAhj2_NtNtB4_5array17TryFromSliceErrorE6unwrapCsiKgSYIST2hs_15spiral_protocol.exit: ; preds = %330
  %_16.i30 = getelementptr inbounds nuw i8, ptr %raw.0, i64 8, !dbg !30125
  %335 = ptrtoint ptr %_16.i30 to i64, !dbg !30129
  %336 = add i64 %335, 1, !dbg !30129
  %337 = inttoptr i64 %336 to ptr, !dbg !30129
  %338 = ptrtoint ptr %_16.i30 to i64, !dbg !30129
  %339 = lshr i64 %338, 3, !dbg !30129
  %340 = add i64 %339, 2147450880, !dbg !30129
  %341 = inttoptr i64 %340 to ptr, !dbg !30129
  %342 = load i8, ptr %341, align 1, !dbg !30129
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %342), !dbg !30129
  %343 = icmp ne i8 %342, 0, !dbg !30129
  br i1 %343, label %346, label %_RNvMNtCshZBO5P2NUJi_4core6resultINtB2_6ResultAhj2_NtNtB4_5array17TryFromSliceErrorE6unwrapCsiKgSYIST2hs_15spiral_protocol.exit._crit_edge, !dbg !30129, !prof !4285

_RNvMNtCshZBO5P2NUJi_4core6resultINtB2_6ResultAhj2_NtNtB4_5array17TryFromSliceErrorE6unwrapCsiKgSYIST2hs_15spiral_protocol.exit._crit_edge: ; preds = %_RNvMNtCshZBO5P2NUJi_4core6resultINtB2_6ResultAhj2_NtNtB4_5array17TryFromSliceErrorE6unwrapCsiKgSYIST2hs_15spiral_protocol.exit
  %344 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 56), align 1, !dbg !30129, !nosanitize !4137
  %345 = add i8 %344, 1, !dbg !30129
  store i8 %345, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 56), align 1, !dbg !30129, !nosanitize !4137
  br label %355, !dbg !30129

346:                                              ; preds = %_RNvMNtCshZBO5P2NUJi_4core6resultINtB2_6ResultAhj2_NtNtB4_5array17TryFromSliceErrorE6unwrapCsiKgSYIST2hs_15spiral_protocol.exit
  %347 = and i64 %338, 7, !dbg !30129
  %348 = trunc i64 %347 to i8, !dbg !30129
  call void @__sanitizer_cov_trace_cmp1(i8 %348, i8 %342), !dbg !30129
  %349 = icmp sge i8 %348, %342, !dbg !30129
  br i1 %349, label %352, label %._crit_edge100, !dbg !30129

._crit_edge100:                                   ; preds = %346
  %350 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 57), align 1, !dbg !30129, !nosanitize !4137
  %351 = add i8 %350, 1, !dbg !30129
  store i8 %351, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 57), align 1, !dbg !30129, !nosanitize !4137
  br label %355, !dbg !30129

352:                                              ; preds = %346
  %353 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 58), align 1, !dbg !30129, !nosanitize !4137
  %354 = add i8 %353, 1, !dbg !30129
  store i8 %354, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 58), align 1, !dbg !30129, !nosanitize !4137
  call void @__asan_report_load_n(i64 %338, i64 2) #42, !dbg !30129
  unreachable

355:                                              ; preds = %._crit_edge100, %_RNvMNtCshZBO5P2NUJi_4core6resultINtB2_6ResultAhj2_NtNtB4_5array17TryFromSliceErrorE6unwrapCsiKgSYIST2hs_15spiral_protocol.exit._crit_edge
  %356 = ptrtoint ptr %337 to i64, !dbg !30129
  %357 = lshr i64 %356, 3, !dbg !30129
  %358 = add i64 %357, 2147450880, !dbg !30129
  %359 = inttoptr i64 %358 to ptr, !dbg !30129
  %360 = load i8, ptr %359, align 1, !dbg !30129
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %360), !dbg !30129
  %361 = icmp ne i8 %360, 0, !dbg !30129
  br i1 %361, label %364, label %._crit_edge101, !dbg !30129, !prof !4285

._crit_edge101:                                   ; preds = %355
  %362 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 59), align 1, !dbg !30129, !nosanitize !4137
  %363 = add i8 %362, 1, !dbg !30129
  store i8 %363, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 59), align 1, !dbg !30129, !nosanitize !4137
  br label %373, !dbg !30129

364:                                              ; preds = %355
  %365 = and i64 %356, 7, !dbg !30129
  %366 = trunc i64 %365 to i8, !dbg !30129
  call void @__sanitizer_cov_trace_cmp1(i8 %366, i8 %360), !dbg !30129
  %367 = icmp sge i8 %366, %360, !dbg !30129
  br i1 %367, label %370, label %._crit_edge102, !dbg !30129

._crit_edge102:                                   ; preds = %364
  %368 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 60), align 1, !dbg !30129, !nosanitize !4137
  %369 = add i8 %368, 1, !dbg !30129
  store i8 %369, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 60), align 1, !dbg !30129, !nosanitize !4137
  br label %373, !dbg !30129

370:                                              ; preds = %364
  %371 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 61), align 1, !dbg !30129, !nosanitize !4137
  %372 = add i8 %371, 1, !dbg !30129
  store i8 %372, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 61), align 1, !dbg !30129, !nosanitize !4137
  call void @__asan_report_load_n(i64 %356, i64 2) #42, !dbg !30129
  unreachable

373:                                              ; preds = %._crit_edge102, %._crit_edge101
  %v.sroa.0.0.copyload.i.i54 = load i16, ptr %_16.i30, align 1, !dbg !30129, !alias.scope !30136
  %_0.i55 = tail call noundef i16 @llvm.bswap.i16(i16 %v.sroa.0.0.copyload.i.i54), !dbg !30141
  call void @__sanitizer_cov_trace_const_cmp1(i8 1, i8 %_12), !dbg !30148
  %_39 = icmp eq i8 %_12, 1, !dbg !30148
  %. = select i1 %_39, i16 0, i16 -4095, !dbg !30149
  call void @__sanitizer_cov_trace_cmp2(i16 %_0.i55, i16 %.), !dbg !30150
  %_33.not = icmp eq i16 %_0.i55, %., !dbg !30150
  %_3.i.i56 = icmp ne i128 %_17.sroa.4.1.copyload, 0
  %374 = xor i1 %_39, %_3.i.i56
  %or.cond68 = select i1 %_33.not, i1 %374, i1 false, !dbg !30150
  br i1 %or.cond68, label %bb53, label %.bb98_crit_edge103, !dbg !30150

.bb98_crit_edge103:                               ; preds = %373
  %375 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 62), align 1, !dbg !30150, !nosanitize !4137
  %376 = add i8 %375, 1, !dbg !30150
  store i8 %376, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 62), align 1, !dbg !30150, !nosanitize !4137
  br label %bb98, !dbg !30150

bb53:                                             ; preds = %373
  %377 = zext i8 %_12 to i64, !dbg !30151
  call void @__sanitizer_cov_trace_switch(i64 %377, ptr @__sancov_gen_cov_switch_values.1451), !dbg !30151
  switch i8 %_12, label %bb53.bb54_crit_edge [
    i8 1, label %bb60
    i8 2, label %bb59
    i8 3, label %bb58
    i8 4, label %bb57
    i8 16, label %bb56
    i8 17, label %bb55
  ], !dbg !30151

bb53.bb54_crit_edge:                              ; preds = %bb53
  %378 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 63), align 1, !dbg !30151, !nosanitize !4137
  %379 = add i8 %378, 1, !dbg !30151
  store i8 %379, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 63), align 1, !dbg !30151, !nosanitize !4137
  br label %bb54, !dbg !30151

bb54:                                             ; preds = %bb55.bb54_crit_edge, %bb56.bb54_crit_edge, %bb57.bb54_crit_edge, %bb58.bb54_crit_edge, %bb59.bb54_crit_edge, %bb60.bb54_crit_edge, %bb53.bb54_crit_edge
  %380 = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !30152
  %381 = ptrtoint ptr %380 to i64, !dbg !30152
  %382 = lshr i64 %381, 3, !dbg !30152
  %383 = add i64 %382, 2147450880, !dbg !30152
  %384 = inttoptr i64 %383 to ptr, !dbg !30152
  %385 = load i16, ptr %384, align 1, !dbg !30152
  call void @__sanitizer_cov_trace_const_cmp2(i16 0, i16 %385), !dbg !30152
  %386 = icmp ne i16 %385, 0, !dbg !30152
  br i1 %386, label %387, label %390, !dbg !30152

387:                                              ; preds = %bb54
  %388 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 64), align 1, !dbg !30152, !nosanitize !4137
  %389 = add i8 %388, 1, !dbg !30152
  store i8 %389, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 64), align 1, !dbg !30152, !nosanitize !4137
  call void @__asan_report_store16(i64 %381) #42, !dbg !30152
  unreachable, !dbg !30152

390:                                              ; preds = %bb54
  store i128 %_17.sroa.4.1.copyload, ptr %380, align 8, !dbg !30152
  %h.sroa.6.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 24, !dbg !30152
  %391 = ptrtoint ptr %h.sroa.6.0..sroa_idx to i64, !dbg !30152
  %392 = lshr i64 %391, 3, !dbg !30152
  %393 = add i64 %392, 2147450880, !dbg !30152
  %394 = inttoptr i64 %393 to ptr, !dbg !30152
  %395 = load i8, ptr %394, align 1, !dbg !30152
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %395), !dbg !30152
  %396 = icmp ne i8 %395, 0, !dbg !30152
  br i1 %396, label %397, label %400, !dbg !30152

397:                                              ; preds = %390
  %398 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 65), align 1, !dbg !30152, !nosanitize !4137
  %399 = add i8 %398, 1, !dbg !30152
  store i8 %399, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 65), align 1, !dbg !30152, !nosanitize !4137
  call void @__asan_report_store8(i64 %391) #42, !dbg !30152
  unreachable, !dbg !30152

400:                                              ; preds = %390
  store i64 %_0.i, ptr %h.sroa.6.0..sroa_idx, align 8, !dbg !30152
  %h.sroa.7.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 32, !dbg !30152
  %401 = ptrtoint ptr %h.sroa.7.0..sroa_idx to i64, !dbg !30152
  %402 = lshr i64 %401, 3, !dbg !30152
  %403 = add i64 %402, 2147450880, !dbg !30152
  %404 = inttoptr i64 %403 to ptr, !dbg !30152
  %405 = load i8, ptr %404, align 1, !dbg !30152
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %405), !dbg !30152
  %406 = icmp ne i8 %405, 0, !dbg !30152
  br i1 %406, label %407, label %410, !dbg !30152

407:                                              ; preds = %400
  %408 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 66), align 1, !dbg !30152, !nosanitize !4137
  %409 = add i8 %408, 1, !dbg !30152
  store i8 %409, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 66), align 1, !dbg !30152, !nosanitize !4137
  call void @__asan_report_store8(i64 %401) #42, !dbg !30152
  unreachable, !dbg !30152

410:                                              ; preds = %400
  store i64 %_23, ptr %h.sroa.7.0..sroa_idx, align 8, !dbg !30152
  %h.sroa.9.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 40, !dbg !30152
  %411 = ptrtoint ptr %h.sroa.9.0..sroa_idx to i64, !dbg !30152
  %412 = lshr i64 %411, 3, !dbg !30152
  %413 = add i64 %412, 2147450880, !dbg !30152
  %414 = inttoptr i64 %413 to ptr, !dbg !30152
  %415 = load i8, ptr %414, align 1, !dbg !30152
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %415), !dbg !30152
  %416 = icmp ne i8 %415, 0, !dbg !30152
  br i1 %416, label %419, label %._crit_edge104, !dbg !30152, !prof !4285

._crit_edge104:                                   ; preds = %410
  %417 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 67), align 1, !dbg !30152, !nosanitize !4137
  %418 = add i8 %417, 1, !dbg !30152
  store i8 %418, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 67), align 1, !dbg !30152, !nosanitize !4137
  br label %428, !dbg !30152

419:                                              ; preds = %410
  %420 = and i64 %411, 7, !dbg !30152
  %421 = trunc i64 %420 to i8, !dbg !30152
  call void @__sanitizer_cov_trace_cmp1(i8 %421, i8 %415), !dbg !30152
  %422 = icmp sge i8 %421, %415, !dbg !30152
  br i1 %422, label %425, label %._crit_edge105, !dbg !30152

._crit_edge105:                                   ; preds = %419
  %423 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 68), align 1, !dbg !30152, !nosanitize !4137
  %424 = add i8 %423, 1, !dbg !30152
  store i8 %424, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 68), align 1, !dbg !30152, !nosanitize !4137
  br label %428, !dbg !30152

425:                                              ; preds = %419
  %426 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 69), align 1, !dbg !30152, !nosanitize !4137
  %427 = add i8 %426, 1, !dbg !30152
  store i8 %427, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 69), align 1, !dbg !30152, !nosanitize !4137
  call void @__asan_report_store1(i64 %411) #42, !dbg !30152
  unreachable

428:                                              ; preds = %._crit_edge105, %._crit_edge104
  store i8 %_12, ptr %h.sroa.9.0..sroa_idx, align 8, !dbg !30152
  br label %bb98, !dbg !30153

bb60:                                             ; preds = %bb53
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %_14), !dbg !30154
  %_46 = icmp eq i8 %_14, 0, !dbg !30154
  call void @__sanitizer_cov_trace_const_cmp8(i64 0, i64 %v.sroa.0.0.copyload.i.i), !dbg !30106
  %429 = icmp eq i64 %v.sroa.0.0.copyload.i.i, 0
  %or.cond = and i1 %_46, %429, !dbg !30154
  br i1 %or.cond, label %bb60.bb54_crit_edge, label %bb60.bb98_crit_edge, !dbg !30154

bb60.bb98_crit_edge:                              ; preds = %bb60
  %430 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 70), align 1, !dbg !30154, !nosanitize !4137
  %431 = add i8 %430, 1, !dbg !30154
  store i8 %431, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 70), align 1, !dbg !30154, !nosanitize !4137
  br label %bb98, !dbg !30154

bb60.bb54_crit_edge:                              ; preds = %bb60
  %432 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 71), align 1, !dbg !30154, !nosanitize !4137
  %433 = add i8 %432, 1, !dbg !30154
  store i8 %433, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 71), align 1, !dbg !30154, !nosanitize !4137
  br label %bb54, !dbg !30154

bb59:                                             ; preds = %bb53
  call void @__sanitizer_cov_trace_const_cmp1(i8 1, i8 %_14), !dbg !30154
  %_43 = icmp eq i8 %_14, 1, !dbg !30154
  call void @__sanitizer_cov_trace_const_cmp8(i64 0, i64 %v.sroa.0.0.copyload.i.i), !dbg !30106
  %434 = icmp eq i64 %v.sroa.0.0.copyload.i.i, 0
  %or.cond2 = and i1 %_43, %434, !dbg !30154
  br i1 %or.cond2, label %bb59.bb54_crit_edge, label %bb59.bb98_crit_edge, !dbg !30154

bb59.bb98_crit_edge:                              ; preds = %bb59
  %435 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 72), align 1, !dbg !30154, !nosanitize !4137
  %436 = add i8 %435, 1, !dbg !30154
  store i8 %436, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 72), align 1, !dbg !30154, !nosanitize !4137
  br label %bb98, !dbg !30154

bb59.bb54_crit_edge:                              ; preds = %bb59
  %437 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 73), align 1, !dbg !30154, !nosanitize !4137
  %438 = add i8 %437, 1, !dbg !30154
  store i8 %438, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 73), align 1, !dbg !30154, !nosanitize !4137
  br label %bb54, !dbg !30154

bb58:                                             ; preds = %bb53
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %_14), !dbg !30155
  %_52 = icmp eq i8 %_14, 0, !dbg !30155
  call void @__sanitizer_cov_trace_const_cmp8(i64 72057594037927936, i64 %v.sroa.0.0.copyload.i.i), !dbg !30106
  %439 = icmp eq i64 %v.sroa.0.0.copyload.i.i, 72057594037927936
  %or.cond3 = and i1 %_52, %439, !dbg !30155
  br i1 %or.cond3, label %bb58.bb54_crit_edge, label %bb58.bb98_crit_edge, !dbg !30155

bb58.bb98_crit_edge:                              ; preds = %bb58
  %440 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 74), align 1, !dbg !30155, !nosanitize !4137
  %441 = add i8 %440, 1, !dbg !30155
  store i8 %441, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 74), align 1, !dbg !30155, !nosanitize !4137
  br label %bb98, !dbg !30155

bb58.bb54_crit_edge:                              ; preds = %bb58
  %442 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 75), align 1, !dbg !30155, !nosanitize !4137
  %443 = add i8 %442, 1, !dbg !30155
  store i8 %443, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 75), align 1, !dbg !30155, !nosanitize !4137
  br label %bb54, !dbg !30155

bb57:                                             ; preds = %bb53
  call void @__sanitizer_cov_trace_const_cmp1(i8 1, i8 %_14), !dbg !30155
  %_49 = icmp eq i8 %_14, 1, !dbg !30155
  call void @__sanitizer_cov_trace_const_cmp8(i64 72057594037927936, i64 %v.sroa.0.0.copyload.i.i), !dbg !30106
  %444 = icmp eq i64 %v.sroa.0.0.copyload.i.i, 72057594037927936
  %or.cond4 = and i1 %_49, %444, !dbg !30155
  br i1 %or.cond4, label %bb57.bb54_crit_edge, label %bb57.bb98_crit_edge, !dbg !30155

bb57.bb98_crit_edge:                              ; preds = %bb57
  %445 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 76), align 1, !dbg !30155, !nosanitize !4137
  %446 = add i8 %445, 1, !dbg !30155
  store i8 %446, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 76), align 1, !dbg !30155, !nosanitize !4137
  br label %bb98, !dbg !30155

bb57.bb54_crit_edge:                              ; preds = %bb57
  %447 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 77), align 1, !dbg !30155, !nosanitize !4137
  %448 = add i8 %447, 1, !dbg !30155
  store i8 %448, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 77), align 1, !dbg !30155, !nosanitize !4137
  br label %bb54, !dbg !30155

bb56:                                             ; preds = %bb53
  call void @__sanitizer_cov_trace_const_cmp8(i64 1048574, i64 %_0.i), !dbg !30156
  %or.cond5 = icmp ugt i64 %_0.i, 1048574, !dbg !30156
  br i1 %or.cond5, label %bb56.bb98_crit_edge, label %bb56.bb54_crit_edge, !dbg !30156

bb56.bb54_crit_edge:                              ; preds = %bb56
  %449 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 78), align 1, !dbg !30156, !nosanitize !4137
  %450 = add i8 %449, 1, !dbg !30156
  store i8 %450, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 78), align 1, !dbg !30156, !nosanitize !4137
  br label %bb54, !dbg !30156

bb56.bb98_crit_edge:                              ; preds = %bb56
  %451 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 79), align 1, !dbg !30156, !nosanitize !4137
  %452 = add i8 %451, 1, !dbg !30156
  store i8 %452, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 79), align 1, !dbg !30156, !nosanitize !4137
  br label %bb98, !dbg !30156

bb55:                                             ; preds = %bb53
  call void @__sanitizer_cov_trace_const_cmp8(i64 1048575, i64 %_0.i), !dbg !30156
  %_55 = icmp ugt i64 %_0.i, 1048575, !dbg !30156
  br i1 %_55, label %bb55.bb98_crit_edge, label %bb55.bb54_crit_edge, !dbg !30156

bb55.bb54_crit_edge:                              ; preds = %bb55
  %453 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 80), align 1, !dbg !30156, !nosanitize !4137
  %454 = add i8 %453, 1, !dbg !30156
  store i8 %454, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 80), align 1, !dbg !30156, !nosanitize !4137
  br label %bb54, !dbg !30156

bb55.bb98_crit_edge:                              ; preds = %bb55
  %455 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 81), align 1, !dbg !30156, !nosanitize !4137
  %456 = add i8 %455, 1, !dbg !30156
  store i8 %456, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 81), align 1, !dbg !30156, !nosanitize !4137
  br label %bb98, !dbg !30156

bb98:                                             ; preds = %bb55.bb98_crit_edge, %bb56.bb98_crit_edge, %bb57.bb98_crit_edge, %bb58.bb98_crit_edge, %bb59.bb98_crit_edge, %bb60.bb98_crit_edge, %.bb98_crit_edge103, %.bb98_crit_edge99, %switch.hole_check.bb98_crit_edge, %.bb98_crit_edge95, %.bb98_crit_edge79, %.bb98_crit_edge75, %.bb98_crit_edge, %start.bb98_crit_edge, %428
  %.sink67 = phi i64 [ 1, %start.bb98_crit_edge ], [ 1, %.bb98_crit_edge95 ], [ 1, %bb55.bb98_crit_edge ], [ 1, %bb58.bb98_crit_edge ], [ 1, %bb60.bb98_crit_edge ], [ 1, %bb56.bb98_crit_edge ], [ 41, %428 ], [ 1, %.bb98_crit_edge ], [ 1, %.bb98_crit_edge79 ], [ 1, %.bb98_crit_edge75 ], [ 1, %switch.hole_check.bb98_crit_edge ], [ 1, %.bb98_crit_edge99 ], [ 1, %.bb98_crit_edge103 ], [ 1, %bb59.bb98_crit_edge ], [ 1, %bb57.bb98_crit_edge ]
  %.sink65 = phi i8 [ 0, %start.bb98_crit_edge ], [ 0, %.bb98_crit_edge95 ], [ 0, %bb55.bb98_crit_edge ], [ 0, %bb58.bb98_crit_edge ], [ 0, %bb60.bb98_crit_edge ], [ 0, %bb56.bb98_crit_edge ], [ %_14, %428 ], [ 0, %.bb98_crit_edge ], [ 0, %.bb98_crit_edge79 ], [ 0, %.bb98_crit_edge75 ], [ 0, %switch.hole_check.bb98_crit_edge ], [ 0, %.bb98_crit_edge99 ], [ 0, %.bb98_crit_edge103 ], [ 0, %bb59.bb98_crit_edge ], [ 0, %bb57.bb98_crit_edge ]
  %.sink = phi i8 [ 1, %start.bb98_crit_edge ], [ 1, %.bb98_crit_edge95 ], [ 1, %bb55.bb98_crit_edge ], [ 1, %bb58.bb98_crit_edge ], [ 1, %bb60.bb98_crit_edge ], [ 1, %bb56.bb98_crit_edge ], [ 0, %428 ], [ 1, %.bb98_crit_edge ], [ 1, %.bb98_crit_edge79 ], [ 1, %.bb98_crit_edge75 ], [ 1, %switch.hole_check.bb98_crit_edge ], [ 1, %.bb98_crit_edge99 ], [ 1, %.bb98_crit_edge103 ], [ 1, %bb59.bb98_crit_edge ], [ 1, %bb57.bb98_crit_edge ]
  %457 = getelementptr inbounds nuw i8, ptr %_0, i64 %.sink67, !dbg !30106
  %458 = ptrtoint ptr %457 to i64, !dbg !30106
  %459 = lshr i64 %458, 3, !dbg !30106
  %460 = add i64 %459, 2147450880, !dbg !30106
  %461 = inttoptr i64 %460 to ptr, !dbg !30106
  %462 = load i8, ptr %461, align 1, !dbg !30106
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %462), !dbg !30106
  %463 = icmp ne i8 %462, 0, !dbg !30106
  br i1 %463, label %466, label %bb98._crit_edge, !dbg !30106, !prof !4285

bb98._crit_edge:                                  ; preds = %bb98
  %464 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 82), align 1, !dbg !30106, !nosanitize !4137
  %465 = add i8 %464, 1, !dbg !30106
  store i8 %465, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 82), align 1, !dbg !30106, !nosanitize !4137
  br label %475, !dbg !30106

466:                                              ; preds = %bb98
  %467 = and i64 %458, 7, !dbg !30106
  %468 = trunc i64 %467 to i8, !dbg !30106
  call void @__sanitizer_cov_trace_cmp1(i8 %468, i8 %462), !dbg !30106
  %469 = icmp sge i8 %468, %462, !dbg !30106
  br i1 %469, label %472, label %._crit_edge106, !dbg !30106

._crit_edge106:                                   ; preds = %466
  %470 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 83), align 1, !dbg !30106, !nosanitize !4137
  %471 = add i8 %470, 1, !dbg !30106
  store i8 %471, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 83), align 1, !dbg !30106, !nosanitize !4137
  br label %475, !dbg !30106

472:                                              ; preds = %466
  %473 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 84), align 1, !dbg !30106, !nosanitize !4137
  %474 = add i8 %473, 1, !dbg !30106
  store i8 %474, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 84), align 1, !dbg !30106, !nosanitize !4137
  call void @__asan_report_store1(i64 %458) #42, !dbg !30106
  unreachable

475:                                              ; preds = %._crit_edge106, %bb98._crit_edge
  store i8 %.sink65, ptr %457, align 1, !dbg !30106
  %476 = ptrtoint ptr %_0 to i64, !dbg !30106
  %477 = lshr i64 %476, 3, !dbg !30106
  %478 = add i64 %477, 2147450880, !dbg !30106
  %479 = inttoptr i64 %478 to ptr, !dbg !30106
  %480 = load i8, ptr %479, align 1, !dbg !30106
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %480), !dbg !30106
  %481 = icmp ne i8 %480, 0, !dbg !30106
  br i1 %481, label %484, label %._crit_edge107, !dbg !30106, !prof !4285

._crit_edge107:                                   ; preds = %475
  %482 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 85), align 1, !dbg !30106, !nosanitize !4137
  %483 = add i8 %482, 1, !dbg !30106
  store i8 %483, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 85), align 1, !dbg !30106, !nosanitize !4137
  br label %493, !dbg !30106

484:                                              ; preds = %475
  %485 = and i64 %476, 7, !dbg !30106
  %486 = trunc i64 %485 to i8, !dbg !30106
  call void @__sanitizer_cov_trace_cmp1(i8 %486, i8 %480), !dbg !30106
  %487 = icmp sge i8 %486, %480, !dbg !30106
  br i1 %487, label %490, label %._crit_edge108, !dbg !30106

._crit_edge108:                                   ; preds = %484
  %488 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 86), align 1, !dbg !30106, !nosanitize !4137
  %489 = add i8 %488, 1, !dbg !30106
  store i8 %489, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 86), align 1, !dbg !30106, !nosanitize !4137
  br label %493, !dbg !30106

490:                                              ; preds = %484
  %491 = load i8, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 87), align 1, !dbg !30106, !nosanitize !4137
  %492 = add i8 %491, 1, !dbg !30106
  store i8 %492, ptr getelementptr ([88 x i8], ptr @__sancov_gen_.1449, i64 0, i64 87), align 1, !dbg !30106, !nosanitize !4137
  call void @__asan_report_store1(i64 %476) #42, !dbg !30106
  unreachable

493:                                              ; preds = %._crit_edge108, %._crit_edge107
  store i8 %.sink, ptr %_0, align 8, !dbg !30106
  ret void, !dbg !30153
}

; Verified production function: wire_parse
define void @_RNvNtCsiKgSYIST2hs_15spiral_protocol4wire5parse(ptr dead_on_unwind noalias nofree noundef writable writeonly sret([56 x i8]) align 8 captures(none) dereferenceable(56) %_0, ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) %raw.0, i64 noundef range(i64 0, -9223372036854775808) %raw.1) unnamed_addr #0 comdat !dbg !28926 !guid !54631 {
start:
  %h.sroa.0 = alloca [24 x i8], align 8
  %_4.sroa.9 = alloca [29 x i8], align 1
  %asan_local_stack_base = alloca i64, align 8
  %0 = load i8, ptr @__sancov_gen_.2164, align 1, !dbg !54632, !nosanitize !4137
  %1 = add i8 %0, 1, !dbg !54632
  store i8 %1, ptr @__sancov_gen_.2164, align 1, !dbg !54632, !nosanitize !4137
  %2 = load i32, ptr @__asan_option_detect_stack_use_after_return, align 4
  call void @__sanitizer_cov_trace_const_cmp4(i32 0, i32 %2), !dbg !54633
  %3 = icmp ne i32 %2, 0
  br i1 %3, label %6, label %start._crit_edge

start._crit_edge:                                 ; preds = %start
  %4 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2164, i64 0, i64 1), align 1, !dbg !54633, !nosanitize !4137
  %5 = add i8 %4, 1, !dbg !54633
  store i8 %5, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2164, i64 0, i64 1), align 1, !dbg !54633, !nosanitize !4137
  br label %10

6:                                                ; preds = %start
  %7 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2164, i64 0, i64 2), align 1, !dbg !54633, !nosanitize !4137
  %8 = add i8 %7, 1, !dbg !54633
  store i8 %8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2164, i64 0, i64 2), align 1, !dbg !54633, !nosanitize !4137
  %9 = call i64 @__asan_stack_malloc_1(i64 128)
  br label %10

10:                                               ; preds = %start._crit_edge, %6
  %11 = phi i64 [ 0, %start._crit_edge ], [ %9, %6 ]
  %12 = inttoptr i64 %11 to ptr
  call void @__sanitizer_cov_trace_const_cmp8(i64 0, i64 %11), !dbg !54633
  %13 = icmp eq i64 %11, 0
  br i1 %13, label %16, label %._crit_edge

._crit_edge:                                      ; preds = %10
  %14 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2164, i64 0, i64 3), align 1, !dbg !54633, !nosanitize !4137
  %15 = add i8 %14, 1, !dbg !54633
  store i8 %15, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2164, i64 0, i64 3), align 1, !dbg !54633, !nosanitize !4137
  br label %19

16:                                               ; preds = %10
  %17 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2164, i64 0, i64 4), align 1, !dbg !54633, !nosanitize !4137
  %18 = add i8 %17, 1, !dbg !54633
  store i8 %18, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2164, i64 0, i64 4), align 1, !dbg !54633, !nosanitize !4137
  %MyAlloca = alloca i8, i64 128, align 32
  br label %19

19:                                               ; preds = %._crit_edge, %16
  %20 = phi ptr [ %12, %._crit_edge ], [ %MyAlloca, %16 ]
  store ptr %20, ptr %asan_local_stack_base, align 8
  %21 = getelementptr i8, ptr %20, i64 32
  store i64 1102416563, ptr %20, align 8
  %22 = getelementptr i8, ptr %20, i64 8
  store i64 ptrtoint (ptr @___asan_gen_stack.241 to i64), ptr %22, align 8
  %23 = getelementptr i8, ptr %20, i64 16
  store i64 ptrtoint (ptr @_RNvNtCsiKgSYIST2hs_15spiral_protocol4wire5parse to i64), ptr %23, align 8
  %24 = ptrtoint ptr %20 to i64
  %25 = lshr i64 %24, 3
  %26 = add i64 %25, 2147450880
  %27 = add i64 %26, 0
  %28 = inttoptr i64 %27 to ptr
  store i64 -506381209984437775, ptr %28, align 1
  %29 = add i64 %26, 8
  %30 = inttoptr i64 %29 to ptr
  store i64 -868082074056918792, ptr %30, align 1
  call void @__sanitizer_cov_trace_const_cmp8(i64 40, i64 %raw.1), !dbg !54634
  %_2 = icmp samesign ult i64 %raw.1, 40, !dbg !54634
  br i1 %_2, label %bb1, label %bb2, !dbg !54634

bb2:                                              ; preds = %19
  call void @llvm.lifetime.start.p0(ptr nonnull %_4.sroa.9), !dbg !54635
  %31 = add i64 %26, 4, !dbg !54635
  %32 = inttoptr i64 %31 to ptr, !dbg !54635
  store i32 0, ptr %32, align 1, !dbg !54635
  %33 = add i64 %26, 8, !dbg !54635
  %34 = inttoptr i64 %33 to ptr, !dbg !54635
  store i16 0, ptr %34, align 1, !dbg !54635
; call <spiral_protocol::wire::Header>::parse
  call void @_RNvMNtCsiKgSYIST2hs_15spiral_protocol4wireNtB2_6Header5parse(ptr noalias nofree noundef sret([48 x i8]) align 8 captures(none) dereferenceable(48) %21, ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) %raw.0, i64 noundef 40) #35, !dbg !54635
  tail call void @llvm.experimental.noalias.scope.decl(metadata !54636), !dbg !54635
  %35 = load i8, ptr %21, align 8, !dbg !54639, !range !4452, !alias.scope !54641, !noalias !54636, !noundef !4137
  %36 = trunc nuw i8 %35 to i1, !dbg !54639
  br i1 %36, label %bb2.i, label %bb3.i, !dbg !54643

bb2.i:                                            ; preds = %bb2
  %37 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2164, i64 0, i64 5), align 1, !dbg !54644, !nosanitize !4137
  %38 = add i8 %37, 1, !dbg !54644
  store i8 %38, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2164, i64 0, i64 5), align 1, !dbg !54644, !nosanitize !4137
  %39 = getelementptr inbounds nuw i8, ptr %21, i64 1, !dbg !54644
  %e.0.i = load i8, ptr %39, align 1, !dbg !54644, !range !19556, !alias.scope !54641, !noalias !54636, !noundef !4137
  %40 = getelementptr inbounds nuw i8, ptr %21, i64 2, !dbg !54644
  %e.1.i = load i8, ptr %40, align 2, !dbg !54644, !alias.scope !54641, !noalias !54636
  br label %_RNvXsp_NtCshZBO5P2NUJi_4core6resultINtB5_6ResultNtNtCsiKgSYIST2hs_15spiral_protocol4wire6HeaderNtNtBO_5error5ErrorENtNtNtB7_3ops9try_trait3Try6branchBO_.exit, !dbg !54645

bb3.i:                                            ; preds = %bb2
  %41 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2164, i64 0, i64 6), align 1, !dbg !54646, !nosanitize !4137
  %42 = add i8 %41, 1, !dbg !54646
  store i8 %42, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2164, i64 0, i64 6), align 1, !dbg !54646, !nosanitize !4137
  %43 = getelementptr inbounds nuw i8, ptr %21, i64 8, !dbg !54646
  %_4.sroa.9.8..sroa_idx = getelementptr inbounds nuw i8, ptr %_4.sroa.9, i64 5, !dbg !54646
  %44 = call ptr @__asan_memcpy(ptr %_4.sroa.9.8..sroa_idx, ptr %43, i64 24), !dbg !54646
  %_4.sroa.11.8..sroa_idx = getelementptr inbounds nuw i8, ptr %21, i64 32, !dbg !54646
  %_4.sroa.11.8.copyload = load i64, ptr %_4.sroa.11.8..sroa_idx, align 8, !dbg !54646, !alias.scope !54647
  %_4.sroa.12.8..sroa_idx = getelementptr inbounds nuw i8, ptr %21, i64 40, !dbg !54646
  %_4.sroa.12.8.copyload = load i64, ptr %_4.sroa.12.8..sroa_idx, align 8, !dbg !54646, !alias.scope !54647
  br label %_RNvXsp_NtCshZBO5P2NUJi_4core6resultINtB5_6ResultNtNtCsiKgSYIST2hs_15spiral_protocol4wire6HeaderNtNtBO_5error5ErrorENtNtNtB7_3ops9try_trait3Try6branchBO_.exit, !dbg !54648

_RNvXsp_NtCshZBO5P2NUJi_4core6resultINtB5_6ResultNtNtCsiKgSYIST2hs_15spiral_protocol4wire6HeaderNtNtBO_5error5ErrorENtNtNtB7_3ops9try_trait3Try6branchBO_.exit: ; preds = %bb2.i, %bb3.i
  %_4.sroa.11.0 = phi i64 [ undef, %bb2.i ], [ %_4.sroa.11.8.copyload, %bb3.i ]
  %_4.sroa.7.0 = phi i8 [ %e.1.i, %bb2.i ], [ undef, %bb3.i ]
  %_4.sroa.5.0 = phi i8 [ %e.0.i, %bb2.i ], [ undef, %bb3.i ]
  %_4.sroa.12.0 = phi i64 [ undef, %bb2.i ], [ %_4.sroa.12.8.copyload, %bb3.i ]
  %45 = add i64 %26, 4, !dbg !54649
  %46 = inttoptr i64 %45 to ptr, !dbg !54649
  store i32 -117901064, ptr %46, align 1, !dbg !54649
  %47 = add i64 %26, 8, !dbg !54649
  %48 = inttoptr i64 %47 to ptr, !dbg !54649
  store i16 -1800, ptr %48, align 1, !dbg !54649
  br i1 %36, label %bb8, label %bb7, !dbg !54635

bb1:                                              ; preds = %19
  %49 = ptrtoint ptr %_0 to i64, !dbg !54650
  %50 = lshr i64 %49, 3, !dbg !54650
  %51 = add i64 %50, 2147450880, !dbg !54650
  %52 = inttoptr i64 %51 to ptr, !dbg !54650
  %53 = load i8, ptr %52, align 1, !dbg !54650
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %53), !dbg !54650
  %54 = icmp ne i8 %53, 0, !dbg !54650
  br i1 %54, label %57, label %bb1._crit_edge, !dbg !54650, !prof !4285

bb1._crit_edge:                                   ; preds = %bb1
  %55 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2164, i64 0, i64 7), align 1, !dbg !54650, !nosanitize !4137
  %56 = add i8 %55, 1, !dbg !54650
  store i8 %56, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2164, i64 0, i64 7), align 1, !dbg !54650, !nosanitize !4137
  br label %66, !dbg !54650

57:                                               ; preds = %bb1
  %58 = and i64 %49, 7, !dbg !54650
  %59 = trunc i64 %58 to i8, !dbg !54650
  call void @__sanitizer_cov_trace_cmp1(i8 %59, i8 %53), !dbg !54650
  %60 = icmp sge i8 %59, %53, !dbg !54650
  br i1 %60, label %63, label %._crit_edge5, !dbg !54650

._crit_edge5:                                     ; preds = %57
  %61 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2164, i64 0, i64 8), align 1, !dbg !54650, !nosanitize !4137
  %62 = add i8 %61, 1, !dbg !54650
  store i8 %62, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2164, i64 0, i64 8), align 1, !dbg !54650, !nosanitize !4137
  br label %66, !dbg !54650

63:                                               ; preds = %57
  %64 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2164, i64 0, i64 9), align 1, !dbg !54650, !nosanitize !4137
  %65 = add i8 %64, 1, !dbg !54650
  store i8 %65, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2164, i64 0, i64 9), align 1, !dbg !54650, !nosanitize !4137
  call void @__asan_report_store1(i64 %49) #42, !dbg !54650
  unreachable

66:                                               ; preds = %._crit_edge5, %bb1._crit_edge
  store i8 0, ptr %_0, align 8, !dbg !54650
  %67 = getelementptr inbounds nuw i8, ptr %_0, i64 40, !dbg !54650
  %68 = ptrtoint ptr %67 to i64, !dbg !54650
  %69 = lshr i64 %68, 3, !dbg !54650
  %70 = add i64 %69, 2147450880, !dbg !54650
  %71 = inttoptr i64 %70 to ptr, !dbg !54650
  %72 = load i8, ptr %71, align 1, !dbg !54650
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %72), !dbg !54650
  %73 = icmp ne i8 %72, 0, !dbg !54650
  br i1 %73, label %74, label %77, !dbg !54650

74:                                               ; preds = %66
  %75 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2164, i64 0, i64 10), align 1, !dbg !54650, !nosanitize !4137
  %76 = add i8 %75, 1, !dbg !54650
  store i8 %76, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2164, i64 0, i64 10), align 1, !dbg !54650, !nosanitize !4137
  call void @__asan_report_store8(i64 %68) #42, !dbg !54650
  unreachable, !dbg !54650

77:                                               ; preds = %66
  %78 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2164, i64 0, i64 11), align 1, !dbg !54650, !nosanitize !4137
  %79 = add i8 %78, 1, !dbg !54650
  store i8 %79, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2164, i64 0, i64 11), align 1, !dbg !54650, !nosanitize !4137
  store ptr null, ptr %67, align 8, !dbg !54650
  br label %bb15, !dbg !54651

bb8:                                              ; preds = %_RNvXsp_NtCshZBO5P2NUJi_4core6resultINtB5_6ResultNtNtCsiKgSYIST2hs_15spiral_protocol4wire6HeaderNtNtBO_5error5ErrorENtNtNtB7_3ops9try_trait3Try6branchBO_.exit
  %80 = ptrtoint ptr %_0 to i64, !dbg !54652
  %81 = lshr i64 %80, 3, !dbg !54652
  %82 = add i64 %81, 2147450880, !dbg !54652
  %83 = inttoptr i64 %82 to ptr, !dbg !54652
  %84 = load i8, ptr %83, align 1, !dbg !54652
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %84), !dbg !54652
  %85 = icmp ne i8 %84, 0, !dbg !54652
  br i1 %85, label %88, label %bb8._crit_edge, !dbg !54652, !prof !4285

bb8._crit_edge:                                   ; preds = %bb8
  %86 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2164, i64 0, i64 12), align 1, !dbg !54652, !nosanitize !4137
  %87 = add i8 %86, 1, !dbg !54652
  store i8 %87, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2164, i64 0, i64 12), align 1, !dbg !54652, !nosanitize !4137
  br label %97, !dbg !54652

88:                                               ; preds = %bb8
  %89 = and i64 %80, 7, !dbg !54652
  %90 = trunc i64 %89 to i8, !dbg !54652
  call void @__sanitizer_cov_trace_cmp1(i8 %90, i8 %84), !dbg !54652
  %91 = icmp sge i8 %90, %84, !dbg !54652
  br i1 %91, label %94, label %._crit_edge6, !dbg !54652

._crit_edge6:                                     ; preds = %88
  %92 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2164, i64 0, i64 13), align 1, !dbg !54652, !nosanitize !4137
  %93 = add i8 %92, 1, !dbg !54652
  store i8 %93, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2164, i64 0, i64 13), align 1, !dbg !54652, !nosanitize !4137
  br label %97, !dbg !54652

94:                                               ; preds = %88
  %95 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2164, i64 0, i64 14), align 1, !dbg !54652, !nosanitize !4137
  %96 = add i8 %95, 1, !dbg !54652
  store i8 %96, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2164, i64 0, i64 14), align 1, !dbg !54652, !nosanitize !4137
  call void @__asan_report_store1(i64 %80) #42, !dbg !54652
  unreachable

97:                                               ; preds = %._crit_edge6, %bb8._crit_edge
  store i8 %_4.sroa.5.0, ptr %_0, align 8, !dbg !54652, !alias.scope !54654
  %98 = getelementptr inbounds nuw i8, ptr %_0, i64 1, !dbg !54652
  %99 = ptrtoint ptr %98 to i64, !dbg !54652
  %100 = lshr i64 %99, 3, !dbg !54652
  %101 = add i64 %100, 2147450880, !dbg !54652
  %102 = inttoptr i64 %101 to ptr, !dbg !54652
  %103 = load i8, ptr %102, align 1, !dbg !54652
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %103), !dbg !54652
  %104 = icmp ne i8 %103, 0, !dbg !54652
  br i1 %104, label %107, label %._crit_edge7, !dbg !54652, !prof !4285

._crit_edge7:                                     ; preds = %97
  %105 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2164, i64 0, i64 15), align 1, !dbg !54652, !nosanitize !4137
  %106 = add i8 %105, 1, !dbg !54652
  store i8 %106, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2164, i64 0, i64 15), align 1, !dbg !54652, !nosanitize !4137
  br label %116, !dbg !54652

107:                                              ; preds = %97
  %108 = and i64 %99, 7, !dbg !54652
  %109 = trunc i64 %108 to i8, !dbg !54652
  call void @__sanitizer_cov_trace_cmp1(i8 %109, i8 %103), !dbg !54652
  %110 = icmp sge i8 %109, %103, !dbg !54652
  br i1 %110, label %113, label %._crit_edge8, !dbg !54652

._crit_edge8:                                     ; preds = %107
  %111 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2164, i64 0, i64 16), align 1, !dbg !54652, !nosanitize !4137
  %112 = add i8 %111, 1, !dbg !54652
  store i8 %112, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2164, i64 0, i64 16), align 1, !dbg !54652, !nosanitize !4137
  br label %116, !dbg !54652

113:                                              ; preds = %107
  %114 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2164, i64 0, i64 17), align 1, !dbg !54652, !nosanitize !4137
  %115 = add i8 %114, 1, !dbg !54652
  store i8 %115, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2164, i64 0, i64 17), align 1, !dbg !54652, !nosanitize !4137
  call void @__asan_report_store1(i64 %99) #42, !dbg !54652
  unreachable

116:                                              ; preds = %._crit_edge8, %._crit_edge7
  store i8 %_4.sroa.7.0, ptr %98, align 1, !dbg !54652, !alias.scope !54654
  %117 = getelementptr inbounds nuw i8, ptr %_0, i64 40, !dbg !54652
  %118 = ptrtoint ptr %117 to i64, !dbg !54652
  %119 = lshr i64 %118, 3, !dbg !54652
  %120 = add i64 %119, 2147450880, !dbg !54652
  %121 = inttoptr i64 %120 to ptr, !dbg !54652
  %122 = load i8, ptr %121, align 1, !dbg !54652
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %122), !dbg !54652
  %123 = icmp ne i8 %122, 0, !dbg !54652
  br i1 %123, label %124, label %127, !dbg !54652

124:                                              ; preds = %116
  %125 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2164, i64 0, i64 18), align 1, !dbg !54652, !nosanitize !4137
  %126 = add i8 %125, 1, !dbg !54652
  store i8 %126, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2164, i64 0, i64 18), align 1, !dbg !54652, !nosanitize !4137
  call void @__asan_report_store8(i64 %118) #42, !dbg !54652
  unreachable, !dbg !54652

127:                                              ; preds = %116
  %128 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2164, i64 0, i64 19), align 1, !dbg !54652, !nosanitize !4137
  %129 = add i8 %128, 1, !dbg !54652
  store i8 %129, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2164, i64 0, i64 19), align 1, !dbg !54652, !nosanitize !4137
  store ptr null, ptr %117, align 8, !dbg !54652, !alias.scope !54654
  call void @llvm.lifetime.end.p0(ptr nonnull %_4.sroa.9), !dbg !54657
  br label %bb15, !dbg !54651

bb7:                                              ; preds = %_RNvXsp_NtCshZBO5P2NUJi_4core6resultINtB5_6ResultNtNtCsiKgSYIST2hs_15spiral_protocol4wire6HeaderNtNtBO_5error5ErrorENtNtNtB7_3ops9try_trait3Try6branchBO_.exit
  %_4.sroa.9.8..sroa_idx4 = getelementptr inbounds nuw i8, ptr %_4.sroa.9, i64 5, !dbg !54635
  %130 = call ptr @__asan_memcpy(ptr %h.sroa.0, ptr %_4.sroa.9.8..sroa_idx4, i64 24), !dbg !54635
  call void @llvm.lifetime.end.p0(ptr nonnull %_4.sroa.9), !dbg !54657
  call void @__sanitizer_cov_trace_const_cmp8(i64 -41, i64 %_4.sroa.11.0), !dbg !54658
  %_13.1 = icmp ugt i64 %_4.sroa.11.0, -41, !dbg !54658
  br i1 %_13.1, label %panic, label %bb10, !dbg !54658

bb10:                                             ; preds = %bb7
  %_13.0 = add nuw i64 %_4.sroa.11.0, 40, !dbg !54658
  call void @__sanitizer_cov_trace_cmp8(i64 %raw.1, i64 %_13.0), !dbg !54659
  %_10.not = icmp eq i64 %raw.1, %_13.0, !dbg !54659
  br i1 %_10.not, label %bb12, label %bb11, !dbg !54659

panic:                                            ; preds = %bb7
  %131 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2164, i64 0, i64 20), align 1, !dbg !54658, !nosanitize !4137
  %132 = add i8 %131, 1, !dbg !54658
  store i8 %132, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2164, i64 0, i64 20), align 1, !dbg !54658, !nosanitize !4137
  call void @__asan_handle_no_return(), !dbg !54658
; call core::panicking::panic_const::panic_const_add_overflow
  tail call void @_RNvNtNtCshZBO5P2NUJi_4core9panicking11panic_const24panic_const_add_overflow(ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_8261cc9843ad33371a73da063aa10507) #43, !dbg !54658
  unreachable, !dbg !54658

bb12:                                             ; preds = %bb10
  %new_len.i = add nsw i64 %raw.1, -40, !dbg !54660
  %_11.i = getelementptr inbounds nuw i8, ptr %raw.0, i64 40, !dbg !54663
  %133 = call ptr @__asan_memcpy(ptr %_0, ptr %h.sroa.0, i64 24), !dbg !54665
  %_14.sroa.4.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 24, !dbg !54666
  %134 = ptrtoint ptr %_14.sroa.4.0._0.sroa_idx to i64, !dbg !54666
  %135 = lshr i64 %134, 3, !dbg !54666
  %136 = add i64 %135, 2147450880, !dbg !54666
  %137 = inttoptr i64 %136 to ptr, !dbg !54666
  %138 = load i8, ptr %137, align 1, !dbg !54666
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %138), !dbg !54666
  %139 = icmp ne i8 %138, 0, !dbg !54666
  br i1 %139, label %140, label %143, !dbg !54666

140:                                              ; preds = %bb12
  %141 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2164, i64 0, i64 21), align 1, !dbg !54666, !nosanitize !4137
  %142 = add i8 %141, 1, !dbg !54666
  store i8 %142, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2164, i64 0, i64 21), align 1, !dbg !54666, !nosanitize !4137
  call void @__asan_report_store8(i64 %134) #42, !dbg !54666
  unreachable, !dbg !54666

143:                                              ; preds = %bb12
  store i64 %_4.sroa.11.0, ptr %_14.sroa.4.0._0.sroa_idx, align 8, !dbg !54666
  %_14.sroa.5.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 32, !dbg !54666
  %144 = ptrtoint ptr %_14.sroa.5.0._0.sroa_idx to i64, !dbg !54666
  %145 = lshr i64 %144, 3, !dbg !54666
  %146 = add i64 %145, 2147450880, !dbg !54666
  %147 = inttoptr i64 %146 to ptr, !dbg !54666
  %148 = load i8, ptr %147, align 1, !dbg !54666
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %148), !dbg !54666
  %149 = icmp ne i8 %148, 0, !dbg !54666
  br i1 %149, label %150, label %153, !dbg !54666

150:                                              ; preds = %143
  %151 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2164, i64 0, i64 22), align 1, !dbg !54666, !nosanitize !4137
  %152 = add i8 %151, 1, !dbg !54666
  store i8 %152, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2164, i64 0, i64 22), align 1, !dbg !54666, !nosanitize !4137
  call void @__asan_report_store8(i64 %144) #42, !dbg !54666
  unreachable, !dbg !54666

153:                                              ; preds = %143
  store i64 %_4.sroa.12.0, ptr %_14.sroa.5.0._0.sroa_idx, align 8, !dbg !54666
  %_14.sroa.6.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 40, !dbg !54666
  %154 = ptrtoint ptr %_14.sroa.6.0._0.sroa_idx to i64, !dbg !54666
  %155 = lshr i64 %154, 3, !dbg !54666
  %156 = add i64 %155, 2147450880, !dbg !54666
  %157 = inttoptr i64 %156 to ptr, !dbg !54666
  %158 = load i8, ptr %157, align 1, !dbg !54666
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %158), !dbg !54666
  %159 = icmp ne i8 %158, 0, !dbg !54666
  br i1 %159, label %160, label %163, !dbg !54666

160:                                              ; preds = %153
  %161 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2164, i64 0, i64 23), align 1, !dbg !54666, !nosanitize !4137
  %162 = add i8 %161, 1, !dbg !54666
  store i8 %162, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2164, i64 0, i64 23), align 1, !dbg !54666, !nosanitize !4137
  call void @__asan_report_store8(i64 %154) #42, !dbg !54666
  unreachable, !dbg !54666

163:                                              ; preds = %153
  store ptr %_11.i, ptr %_14.sroa.6.0._0.sroa_idx, align 8, !dbg !54666
  %_14.sroa.7.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 48, !dbg !54666
  %164 = ptrtoint ptr %_14.sroa.7.0._0.sroa_idx to i64, !dbg !54666
  %165 = lshr i64 %164, 3, !dbg !54666
  %166 = add i64 %165, 2147450880, !dbg !54666
  %167 = inttoptr i64 %166 to ptr, !dbg !54666
  %168 = load i8, ptr %167, align 1, !dbg !54666
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %168), !dbg !54666
  %169 = icmp ne i8 %168, 0, !dbg !54666
  br i1 %169, label %170, label %173, !dbg !54666

170:                                              ; preds = %163
  %171 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2164, i64 0, i64 24), align 1, !dbg !54666, !nosanitize !4137
  %172 = add i8 %171, 1, !dbg !54666
  store i8 %172, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2164, i64 0, i64 24), align 1, !dbg !54666, !nosanitize !4137
  call void @__asan_report_store8(i64 %164) #42, !dbg !54666
  unreachable, !dbg !54666

173:                                              ; preds = %163
  %174 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2164, i64 0, i64 25), align 1, !dbg !54666, !nosanitize !4137
  %175 = add i8 %174, 1, !dbg !54666
  store i8 %175, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2164, i64 0, i64 25), align 1, !dbg !54666, !nosanitize !4137
  store i64 %new_len.i, ptr %_14.sroa.7.0._0.sroa_idx, align 8, !dbg !54666
  br label %bb15, !dbg !54667

bb11:                                             ; preds = %bb10
  %176 = ptrtoint ptr %_0 to i64, !dbg !54668
  %177 = lshr i64 %176, 3, !dbg !54668
  %178 = add i64 %177, 2147450880, !dbg !54668
  %179 = inttoptr i64 %178 to ptr, !dbg !54668
  %180 = load i8, ptr %179, align 1, !dbg !54668
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %180), !dbg !54668
  %181 = icmp ne i8 %180, 0, !dbg !54668
  br i1 %181, label %184, label %bb11._crit_edge, !dbg !54668, !prof !4285

bb11._crit_edge:                                  ; preds = %bb11
  %182 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2164, i64 0, i64 26), align 1, !dbg !54668, !nosanitize !4137
  %183 = add i8 %182, 1, !dbg !54668
  store i8 %183, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2164, i64 0, i64 26), align 1, !dbg !54668, !nosanitize !4137
  br label %193, !dbg !54668

184:                                              ; preds = %bb11
  %185 = and i64 %176, 7, !dbg !54668
  %186 = trunc i64 %185 to i8, !dbg !54668
  call void @__sanitizer_cov_trace_cmp1(i8 %186, i8 %180), !dbg !54668
  %187 = icmp sge i8 %186, %180, !dbg !54668
  br i1 %187, label %190, label %._crit_edge9, !dbg !54668

._crit_edge9:                                     ; preds = %184
  %188 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2164, i64 0, i64 27), align 1, !dbg !54668, !nosanitize !4137
  %189 = add i8 %188, 1, !dbg !54668
  store i8 %189, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2164, i64 0, i64 27), align 1, !dbg !54668, !nosanitize !4137
  br label %193, !dbg !54668

190:                                              ; preds = %184
  %191 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2164, i64 0, i64 28), align 1, !dbg !54668, !nosanitize !4137
  %192 = add i8 %191, 1, !dbg !54668
  store i8 %192, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2164, i64 0, i64 28), align 1, !dbg !54668, !nosanitize !4137
  call void @__asan_report_store1(i64 %176) #42, !dbg !54668
  unreachable

193:                                              ; preds = %._crit_edge9, %bb11._crit_edge
  store i8 0, ptr %_0, align 8, !dbg !54668
  %194 = getelementptr inbounds nuw i8, ptr %_0, i64 40, !dbg !54668
  %195 = ptrtoint ptr %194 to i64, !dbg !54668
  %196 = lshr i64 %195, 3, !dbg !54668
  %197 = add i64 %196, 2147450880, !dbg !54668
  %198 = inttoptr i64 %197 to ptr, !dbg !54668
  %199 = load i8, ptr %198, align 1, !dbg !54668
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %199), !dbg !54668
  %200 = icmp ne i8 %199, 0, !dbg !54668
  br i1 %200, label %201, label %204, !dbg !54668

201:                                              ; preds = %193
  %202 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2164, i64 0, i64 29), align 1, !dbg !54668, !nosanitize !4137
  %203 = add i8 %202, 1, !dbg !54668
  store i8 %203, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2164, i64 0, i64 29), align 1, !dbg !54668, !nosanitize !4137
  call void @__asan_report_store8(i64 %195) #42, !dbg !54668
  unreachable, !dbg !54668

204:                                              ; preds = %193
  %205 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2164, i64 0, i64 30), align 1, !dbg !54668, !nosanitize !4137
  %206 = add i8 %205, 1, !dbg !54668
  store i8 %206, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2164, i64 0, i64 30), align 1, !dbg !54668, !nosanitize !4137
  store ptr null, ptr %194, align 8, !dbg !54668
  br label %bb15, !dbg !54669

bb15:                                             ; preds = %204, %127, %77, %173
  store i64 1172321806, ptr %20, align 8, !dbg !54667
  call void @__sanitizer_cov_trace_const_cmp8(i64 0, i64 %11), !dbg !54667
  %207 = icmp ne i64 %11, 0, !dbg !54667
  br i1 %207, label %208, label %218, !dbg !54667

208:                                              ; preds = %bb15
  %209 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2164, i64 0, i64 31), align 1, !dbg !54667, !nosanitize !4137
  %210 = add i8 %209, 1, !dbg !54667
  store i8 %210, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2164, i64 0, i64 31), align 1, !dbg !54667, !nosanitize !4137
  %211 = add i64 %26, 0, !dbg !54667
  %212 = inttoptr i64 %211 to ptr, !dbg !54667
  store i64 -723401728380766731, ptr %212, align 1, !dbg !54667
  %213 = add i64 %26, 8, !dbg !54667
  %214 = inttoptr i64 %213 to ptr, !dbg !54667
  store i64 -723401728380766731, ptr %214, align 1, !dbg !54667
  %215 = getelementptr i8, ptr %12, i64 120, !dbg !54667
  %216 = load i64, ptr %215, align 8, !dbg !54667
  %217 = inttoptr i64 %216 to ptr, !dbg !54667
  store i8 0, ptr %217, align 1, !dbg !54667
  br label %225, !dbg !54667

218:                                              ; preds = %bb15
  %219 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2164, i64 0, i64 32), align 1, !dbg !54667, !nosanitize !4137
  %220 = add i8 %219, 1, !dbg !54667
  store i8 %220, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2164, i64 0, i64 32), align 1, !dbg !54667, !nosanitize !4137
  %221 = add i64 %26, 0, !dbg !54667
  %222 = inttoptr i64 %221 to ptr, !dbg !54667
  store i64 0, ptr %222, align 1, !dbg !54667
  %223 = add i64 %26, 8, !dbg !54667
  %224 = inttoptr i64 %223 to ptr, !dbg !54667
  store i64 0, ptr %224, align 1, !dbg !54667
  br label %225, !dbg !54667

225:                                              ; preds = %218, %208
  ret void, !dbg !54667
}

; Verified production function: parse_frame
define void @_RNvNtCsiKgSYIST2hs_15spiral_protocol12test_support11parse_frame(ptr dead_on_unwind noalias nofree noundef writable writeonly sret([56 x i8]) align 8 captures(none) dereferenceable(56) %_0, ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) %data.0, i64 noundef range(i64 0, -9223372036854775808) %data.1) unnamed_addr #12 comdat !dbg !54503 !guid !54506 {
start:
  %h.sroa.0.i = alloca [24 x i8], align 8
  %_4.sroa.9.i = alloca [29 x i8], align 1
  %asan_local_stack_base = alloca i64, align 8
  %0 = load i8, ptr @__sancov_gen_.2158, align 1, !dbg !54507, !nosanitize !4137
  %1 = add i8 %0, 1, !dbg !54507
  store i8 %1, ptr @__sancov_gen_.2158, align 1, !dbg !54507, !nosanitize !4137
  %2 = load i32, ptr @__asan_option_detect_stack_use_after_return, align 4
  call void @__sanitizer_cov_trace_const_cmp4(i32 0, i32 %2), !dbg !54508
  %3 = icmp ne i32 %2, 0
  br i1 %3, label %6, label %start._crit_edge

start._crit_edge:                                 ; preds = %start
  %4 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2158, i64 0, i64 1), align 1, !dbg !54508, !nosanitize !4137
  %5 = add i8 %4, 1, !dbg !54508
  store i8 %5, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2158, i64 0, i64 1), align 1, !dbg !54508, !nosanitize !4137
  br label %10

6:                                                ; preds = %start
  %7 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2158, i64 0, i64 2), align 1, !dbg !54508, !nosanitize !4137
  %8 = add i8 %7, 1, !dbg !54508
  store i8 %8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2158, i64 0, i64 2), align 1, !dbg !54508, !nosanitize !4137
  %9 = call i64 @__asan_stack_malloc_1(i64 128)
  br label %10

10:                                               ; preds = %start._crit_edge, %6
  %11 = phi i64 [ 0, %start._crit_edge ], [ %9, %6 ]
  %12 = inttoptr i64 %11 to ptr
  call void @__sanitizer_cov_trace_const_cmp8(i64 0, i64 %11), !dbg !54508
  %13 = icmp eq i64 %11, 0
  br i1 %13, label %16, label %._crit_edge

._crit_edge:                                      ; preds = %10
  %14 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2158, i64 0, i64 3), align 1, !dbg !54508, !nosanitize !4137
  %15 = add i8 %14, 1, !dbg !54508
  store i8 %15, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2158, i64 0, i64 3), align 1, !dbg !54508, !nosanitize !4137
  br label %19

16:                                               ; preds = %10
  %17 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2158, i64 0, i64 4), align 1, !dbg !54508, !nosanitize !4137
  %18 = add i8 %17, 1, !dbg !54508
  store i8 %18, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2158, i64 0, i64 4), align 1, !dbg !54508, !nosanitize !4137
  %MyAlloca = alloca i8, i64 128, align 32
  br label %19

19:                                               ; preds = %._crit_edge, %16
  %20 = phi ptr [ %12, %._crit_edge ], [ %MyAlloca, %16 ]
  store ptr %20, ptr %asan_local_stack_base, align 8
  %21 = getelementptr i8, ptr %20, i64 32
  store i64 1102416563, ptr %20, align 8
  %22 = getelementptr i8, ptr %20, i64 8
  store i64 ptrtoint (ptr @___asan_gen_stack.239 to i64), ptr %22, align 8
  %23 = getelementptr i8, ptr %20, i64 16
  store i64 ptrtoint (ptr @_RNvNtCsiKgSYIST2hs_15spiral_protocol12test_support11parse_frame to i64), ptr %23, align 8
  %24 = ptrtoint ptr %20 to i64
  %25 = lshr i64 %24, 3
  %26 = add i64 %25, 2147450880
  %27 = add i64 %26, 0
  %28 = inttoptr i64 %27 to ptr
  store i64 -506381209984437775, ptr %28, align 1
  %29 = add i64 %26, 8
  %30 = inttoptr i64 %29 to ptr
  store i64 -868082074056918792, ptr %30, align 1
  tail call void @llvm.experimental.noalias.scope.decl(metadata !54509), !dbg !54512
  call void @llvm.lifetime.start.p0(ptr nonnull %h.sroa.0.i), !dbg !54513
  call void @__sanitizer_cov_trace_const_cmp8(i64 40, i64 %data.1), !dbg !54513
  %_2.i = icmp samesign ult i64 %data.1, 40, !dbg !54513
  br i1 %_2.i, label %bb1.i, label %bb2.i, !dbg !54513

bb2.i:                                            ; preds = %19
  call void @llvm.lifetime.start.p0(ptr nonnull %_4.sroa.9.i), !dbg !54515
  %31 = add i64 %26, 4, !dbg !54515
  %32 = inttoptr i64 %31 to ptr, !dbg !54515
  store i32 0, ptr %32, align 1, !dbg !54515
  %33 = add i64 %26, 8, !dbg !54515
  %34 = inttoptr i64 %33 to ptr, !dbg !54515
  store i16 0, ptr %34, align 1, !dbg !54515
; call <spiral_protocol::wire::Header>::parse
  call void @_RNvMNtCsiKgSYIST2hs_15spiral_protocol4wireNtB2_6Header5parse(ptr noalias nofree noundef sret([48 x i8]) align 8 captures(none) dereferenceable(48) %21, ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) %data.0, i64 noundef 40) #35, !dbg !54515, !noalias !54509
  tail call void @llvm.experimental.noalias.scope.decl(metadata !54516), !dbg !54515
  %35 = load i8, ptr %21, align 8, !dbg !54519, !range !4452, !alias.scope !54521, !noalias !54523, !noundef !4137
  %36 = trunc nuw i8 %35 to i1, !dbg !54519
  br i1 %36, label %bb2.i.i, label %bb3.i.i, !dbg !54525

bb2.i.i:                                          ; preds = %bb2.i
  %37 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2158, i64 0, i64 5), align 1, !dbg !54526, !nosanitize !4137
  %38 = add i8 %37, 1, !dbg !54526
  store i8 %38, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2158, i64 0, i64 5), align 1, !dbg !54526, !nosanitize !4137
  %39 = getelementptr inbounds nuw i8, ptr %21, i64 1, !dbg !54526
  %e.0.i.i = load i8, ptr %39, align 1, !dbg !54526, !range !19556, !alias.scope !54521, !noalias !54523, !noundef !4137
  %40 = getelementptr inbounds nuw i8, ptr %21, i64 2, !dbg !54526
  %e.1.i.i = load i8, ptr %40, align 2, !dbg !54526, !alias.scope !54521, !noalias !54523
  br label %_RNvXsp_NtCshZBO5P2NUJi_4core6resultINtB5_6ResultNtNtCsiKgSYIST2hs_15spiral_protocol4wire6HeaderNtNtBO_5error5ErrorENtNtNtB7_3ops9try_trait3Try6branchBO_.exit.i, !dbg !54527

bb3.i.i:                                          ; preds = %bb2.i
  %41 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2158, i64 0, i64 6), align 1, !dbg !54528, !nosanitize !4137
  %42 = add i8 %41, 1, !dbg !54528
  store i8 %42, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2158, i64 0, i64 6), align 1, !dbg !54528, !nosanitize !4137
  %43 = getelementptr inbounds nuw i8, ptr %21, i64 8, !dbg !54528
  %_4.sroa.9.8..sroa_idx.i = getelementptr inbounds nuw i8, ptr %_4.sroa.9.i, i64 5, !dbg !54528
  %44 = call ptr @__asan_memcpy(ptr %_4.sroa.9.8..sroa_idx.i, ptr %43, i64 24), !dbg !54528
  %_4.sroa.11.8..sroa_idx.i = getelementptr inbounds nuw i8, ptr %21, i64 32, !dbg !54528
  %_4.sroa.11.8.copyload.i = load i64, ptr %_4.sroa.11.8..sroa_idx.i, align 8, !dbg !54528, !alias.scope !54529, !noalias !54530
  %_4.sroa.12.8..sroa_idx.i = getelementptr inbounds nuw i8, ptr %21, i64 40, !dbg !54528
  %_4.sroa.12.8.copyload.i = load i64, ptr %_4.sroa.12.8..sroa_idx.i, align 8, !dbg !54528, !alias.scope !54529, !noalias !54530
  br label %_RNvXsp_NtCshZBO5P2NUJi_4core6resultINtB5_6ResultNtNtCsiKgSYIST2hs_15spiral_protocol4wire6HeaderNtNtBO_5error5ErrorENtNtNtB7_3ops9try_trait3Try6branchBO_.exit.i, !dbg !54531

_RNvXsp_NtCshZBO5P2NUJi_4core6resultINtB5_6ResultNtNtCsiKgSYIST2hs_15spiral_protocol4wire6HeaderNtNtBO_5error5ErrorENtNtNtB7_3ops9try_trait3Try6branchBO_.exit.i: ; preds = %bb3.i.i, %bb2.i.i
  %_4.sroa.11.0.i = phi i64 [ undef, %bb2.i.i ], [ %_4.sroa.11.8.copyload.i, %bb3.i.i ]
  %_4.sroa.7.0.i = phi i8 [ %e.1.i.i, %bb2.i.i ], [ undef, %bb3.i.i ]
  %_4.sroa.5.0.i = phi i8 [ %e.0.i.i, %bb2.i.i ], [ undef, %bb3.i.i ]
  %_4.sroa.12.0.i = phi i64 [ undef, %bb2.i.i ], [ %_4.sroa.12.8.copyload.i, %bb3.i.i ]
  %45 = add i64 %26, 4, !dbg !54532
  %46 = inttoptr i64 %45 to ptr, !dbg !54532
  store i32 -117901064, ptr %46, align 1, !dbg !54532
  %47 = add i64 %26, 8, !dbg !54532
  %48 = inttoptr i64 %47 to ptr, !dbg !54532
  store i16 -1800, ptr %48, align 1, !dbg !54532
  br i1 %36, label %bb8.i, label %bb7.i, !dbg !54515

bb1.i:                                            ; preds = %19
  %49 = ptrtoint ptr %_0 to i64, !dbg !54533
  %50 = lshr i64 %49, 3, !dbg !54533
  %51 = add i64 %50, 2147450880, !dbg !54533
  %52 = inttoptr i64 %51 to ptr, !dbg !54533
  %53 = load i8, ptr %52, align 1, !dbg !54533
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %53), !dbg !54533
  %54 = icmp ne i8 %53, 0, !dbg !54533
  br i1 %54, label %57, label %bb1.i._crit_edge, !dbg !54533, !prof !4285

bb1.i._crit_edge:                                 ; preds = %bb1.i
  %55 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2158, i64 0, i64 7), align 1, !dbg !54533, !nosanitize !4137
  %56 = add i8 %55, 1, !dbg !54533
  store i8 %56, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2158, i64 0, i64 7), align 1, !dbg !54533, !nosanitize !4137
  br label %66, !dbg !54533

57:                                               ; preds = %bb1.i
  %58 = and i64 %49, 7, !dbg !54533
  %59 = trunc i64 %58 to i8, !dbg !54533
  call void @__sanitizer_cov_trace_cmp1(i8 %59, i8 %53), !dbg !54533
  %60 = icmp sge i8 %59, %53, !dbg !54533
  br i1 %60, label %63, label %._crit_edge1, !dbg !54533

._crit_edge1:                                     ; preds = %57
  %61 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2158, i64 0, i64 8), align 1, !dbg !54533, !nosanitize !4137
  %62 = add i8 %61, 1, !dbg !54533
  store i8 %62, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2158, i64 0, i64 8), align 1, !dbg !54533, !nosanitize !4137
  br label %66, !dbg !54533

63:                                               ; preds = %57
  %64 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2158, i64 0, i64 9), align 1, !dbg !54533, !nosanitize !4137
  %65 = add i8 %64, 1, !dbg !54533
  store i8 %65, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2158, i64 0, i64 9), align 1, !dbg !54533, !nosanitize !4137
  call void @__asan_report_store1(i64 %49) #42, !dbg !54533
  unreachable

66:                                               ; preds = %._crit_edge1, %bb1.i._crit_edge
  store i8 0, ptr %_0, align 8, !dbg !54533, !alias.scope !54509, !noalias !54534
  %67 = getelementptr inbounds nuw i8, ptr %_0, i64 40, !dbg !54533
  %68 = ptrtoint ptr %67 to i64, !dbg !54533
  %69 = lshr i64 %68, 3, !dbg !54533
  %70 = add i64 %69, 2147450880, !dbg !54533
  %71 = inttoptr i64 %70 to ptr, !dbg !54533
  %72 = load i8, ptr %71, align 1, !dbg !54533
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %72), !dbg !54533
  %73 = icmp ne i8 %72, 0, !dbg !54533
  br i1 %73, label %74, label %77, !dbg !54533

74:                                               ; preds = %66
  %75 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2158, i64 0, i64 10), align 1, !dbg !54533, !nosanitize !4137
  %76 = add i8 %75, 1, !dbg !54533
  store i8 %76, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2158, i64 0, i64 10), align 1, !dbg !54533, !nosanitize !4137
  call void @__asan_report_store8(i64 %68) #42, !dbg !54533
  unreachable, !dbg !54533

77:                                               ; preds = %66
  %78 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2158, i64 0, i64 11), align 1, !dbg !54533, !nosanitize !4137
  %79 = add i8 %78, 1, !dbg !54533
  store i8 %79, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2158, i64 0, i64 11), align 1, !dbg !54533, !nosanitize !4137
  store ptr null, ptr %67, align 8, !dbg !54533, !alias.scope !54509, !noalias !54534
  br label %_RNvNtCsiKgSYIST2hs_15spiral_protocol4wire5parse.exit, !dbg !54535

bb8.i:                                            ; preds = %_RNvXsp_NtCshZBO5P2NUJi_4core6resultINtB5_6ResultNtNtCsiKgSYIST2hs_15spiral_protocol4wire6HeaderNtNtBO_5error5ErrorENtNtNtB7_3ops9try_trait3Try6branchBO_.exit.i
  %80 = ptrtoint ptr %_0 to i64, !dbg !54537
  %81 = lshr i64 %80, 3, !dbg !54537
  %82 = add i64 %81, 2147450880, !dbg !54537
  %83 = inttoptr i64 %82 to ptr, !dbg !54537
  %84 = load i8, ptr %83, align 1, !dbg !54537
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %84), !dbg !54537
  %85 = icmp ne i8 %84, 0, !dbg !54537
  br i1 %85, label %88, label %bb8.i._crit_edge, !dbg !54537, !prof !4285

bb8.i._crit_edge:                                 ; preds = %bb8.i
  %86 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2158, i64 0, i64 12), align 1, !dbg !54537, !nosanitize !4137
  %87 = add i8 %86, 1, !dbg !54537
  store i8 %87, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2158, i64 0, i64 12), align 1, !dbg !54537, !nosanitize !4137
  br label %97, !dbg !54537

88:                                               ; preds = %bb8.i
  %89 = and i64 %80, 7, !dbg !54537
  %90 = trunc i64 %89 to i8, !dbg !54537
  call void @__sanitizer_cov_trace_cmp1(i8 %90, i8 %84), !dbg !54537
  %91 = icmp sge i8 %90, %84, !dbg !54537
  br i1 %91, label %94, label %._crit_edge2, !dbg !54537

._crit_edge2:                                     ; preds = %88
  %92 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2158, i64 0, i64 13), align 1, !dbg !54537, !nosanitize !4137
  %93 = add i8 %92, 1, !dbg !54537
  store i8 %93, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2158, i64 0, i64 13), align 1, !dbg !54537, !nosanitize !4137
  br label %97, !dbg !54537

94:                                               ; preds = %88
  %95 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2158, i64 0, i64 14), align 1, !dbg !54537, !nosanitize !4137
  %96 = add i8 %95, 1, !dbg !54537
  store i8 %96, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2158, i64 0, i64 14), align 1, !dbg !54537, !nosanitize !4137
  call void @__asan_report_store1(i64 %80) #42, !dbg !54537
  unreachable

97:                                               ; preds = %._crit_edge2, %bb8.i._crit_edge
  store i8 %_4.sroa.5.0.i, ptr %_0, align 8, !dbg !54537, !alias.scope !54542, !noalias !54534
  %98 = getelementptr inbounds nuw i8, ptr %_0, i64 1, !dbg !54537
  %99 = ptrtoint ptr %98 to i64, !dbg !54537
  %100 = lshr i64 %99, 3, !dbg !54537
  %101 = add i64 %100, 2147450880, !dbg !54537
  %102 = inttoptr i64 %101 to ptr, !dbg !54537
  %103 = load i8, ptr %102, align 1, !dbg !54537
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %103), !dbg !54537
  %104 = icmp ne i8 %103, 0, !dbg !54537
  br i1 %104, label %107, label %._crit_edge3, !dbg !54537, !prof !4285

._crit_edge3:                                     ; preds = %97
  %105 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2158, i64 0, i64 15), align 1, !dbg !54537, !nosanitize !4137
  %106 = add i8 %105, 1, !dbg !54537
  store i8 %106, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2158, i64 0, i64 15), align 1, !dbg !54537, !nosanitize !4137
  br label %116, !dbg !54537

107:                                              ; preds = %97
  %108 = and i64 %99, 7, !dbg !54537
  %109 = trunc i64 %108 to i8, !dbg !54537
  call void @__sanitizer_cov_trace_cmp1(i8 %109, i8 %103), !dbg !54537
  %110 = icmp sge i8 %109, %103, !dbg !54537
  br i1 %110, label %113, label %._crit_edge4, !dbg !54537

._crit_edge4:                                     ; preds = %107
  %111 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2158, i64 0, i64 16), align 1, !dbg !54537, !nosanitize !4137
  %112 = add i8 %111, 1, !dbg !54537
  store i8 %112, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2158, i64 0, i64 16), align 1, !dbg !54537, !nosanitize !4137
  br label %116, !dbg !54537

113:                                              ; preds = %107
  %114 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2158, i64 0, i64 17), align 1, !dbg !54537, !nosanitize !4137
  %115 = add i8 %114, 1, !dbg !54537
  store i8 %115, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2158, i64 0, i64 17), align 1, !dbg !54537, !nosanitize !4137
  call void @__asan_report_store1(i64 %99) #42, !dbg !54537
  unreachable

116:                                              ; preds = %._crit_edge4, %._crit_edge3
  store i8 %_4.sroa.7.0.i, ptr %98, align 1, !dbg !54537, !alias.scope !54542, !noalias !54534
  %117 = getelementptr inbounds nuw i8, ptr %_0, i64 40, !dbg !54537
  %118 = ptrtoint ptr %117 to i64, !dbg !54537
  %119 = lshr i64 %118, 3, !dbg !54537
  %120 = add i64 %119, 2147450880, !dbg !54537
  %121 = inttoptr i64 %120 to ptr, !dbg !54537
  %122 = load i8, ptr %121, align 1, !dbg !54537
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %122), !dbg !54537
  %123 = icmp ne i8 %122, 0, !dbg !54537
  br i1 %123, label %124, label %127, !dbg !54537

124:                                              ; preds = %116
  %125 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2158, i64 0, i64 18), align 1, !dbg !54537, !nosanitize !4137
  %126 = add i8 %125, 1, !dbg !54537
  store i8 %126, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2158, i64 0, i64 18), align 1, !dbg !54537, !nosanitize !4137
  call void @__asan_report_store8(i64 %118) #42, !dbg !54537
  unreachable, !dbg !54537

127:                                              ; preds = %116
  %128 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2158, i64 0, i64 19), align 1, !dbg !54537, !nosanitize !4137
  %129 = add i8 %128, 1, !dbg !54537
  store i8 %129, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2158, i64 0, i64 19), align 1, !dbg !54537, !nosanitize !4137
  store ptr null, ptr %117, align 8, !dbg !54537, !alias.scope !54542, !noalias !54534
  call void @llvm.lifetime.end.p0(ptr nonnull %_4.sroa.9.i), !dbg !54545
  br label %_RNvNtCsiKgSYIST2hs_15spiral_protocol4wire5parse.exit, !dbg !54535

bb7.i:                                            ; preds = %_RNvXsp_NtCshZBO5P2NUJi_4core6resultINtB5_6ResultNtNtCsiKgSYIST2hs_15spiral_protocol4wire6HeaderNtNtBO_5error5ErrorENtNtNtB7_3ops9try_trait3Try6branchBO_.exit.i
  %_4.sroa.9.8..sroa_idx4.i = getelementptr inbounds nuw i8, ptr %_4.sroa.9.i, i64 5, !dbg !54515
  %130 = call ptr @__asan_memcpy(ptr %h.sroa.0.i, ptr %_4.sroa.9.8..sroa_idx4.i, i64 24), !dbg !54515
  call void @llvm.lifetime.end.p0(ptr nonnull %_4.sroa.9.i), !dbg !54545
  call void @__sanitizer_cov_trace_const_cmp8(i64 -41, i64 %_4.sroa.11.0.i), !dbg !54546
  %_13.1.i = icmp ugt i64 %_4.sroa.11.0.i, -41, !dbg !54546
  br i1 %_13.1.i, label %panic.i, label %bb10.i, !dbg !54546

bb10.i:                                           ; preds = %bb7.i
  %_13.0.i = add nuw i64 %_4.sroa.11.0.i, 40, !dbg !54546
  call void @__sanitizer_cov_trace_cmp8(i64 %data.1, i64 %_13.0.i), !dbg !54547
  %_10.not.i = icmp eq i64 %data.1, %_13.0.i, !dbg !54547
  br i1 %_10.not.i, label %bb12.i, label %bb11.i, !dbg !54547

panic.i:                                          ; preds = %bb7.i
  %131 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2158, i64 0, i64 20), align 1, !dbg !54546, !nosanitize !4137
  %132 = add i8 %131, 1, !dbg !54546
  store i8 %132, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2158, i64 0, i64 20), align 1, !dbg !54546, !nosanitize !4137
  call void @__asan_handle_no_return(), !dbg !54546
; call core::panicking::panic_const::panic_const_add_overflow
  tail call void @_RNvNtNtCshZBO5P2NUJi_4core9panicking11panic_const24panic_const_add_overflow(ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_8261cc9843ad33371a73da063aa10507) #43, !dbg !54546, !noalias !54530
  unreachable, !dbg !54546

bb12.i:                                           ; preds = %bb10.i
  %new_len.i.i = add nsw i64 %data.1, -40, !dbg !54548
  %_11.i.i = getelementptr inbounds nuw i8, ptr %data.0, i64 40, !dbg !54553
  %133 = call ptr @__asan_memcpy(ptr %_0, ptr %h.sroa.0.i, i64 24), !dbg !54558
  %_14.sroa.4.0._0.sroa_idx.i = getelementptr inbounds nuw i8, ptr %_0, i64 24, !dbg !54559
  %134 = ptrtoint ptr %_14.sroa.4.0._0.sroa_idx.i to i64, !dbg !54559
  %135 = lshr i64 %134, 3, !dbg !54559
  %136 = add i64 %135, 2147450880, !dbg !54559
  %137 = inttoptr i64 %136 to ptr, !dbg !54559
  %138 = load i8, ptr %137, align 1, !dbg !54559
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %138), !dbg !54559
  %139 = icmp ne i8 %138, 0, !dbg !54559
  br i1 %139, label %140, label %143, !dbg !54559

140:                                              ; preds = %bb12.i
  %141 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2158, i64 0, i64 21), align 1, !dbg !54559, !nosanitize !4137
  %142 = add i8 %141, 1, !dbg !54559
  store i8 %142, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2158, i64 0, i64 21), align 1, !dbg !54559, !nosanitize !4137
  call void @__asan_report_store8(i64 %134) #42, !dbg !54559
  unreachable, !dbg !54559

143:                                              ; preds = %bb12.i
  store i64 %_4.sroa.11.0.i, ptr %_14.sroa.4.0._0.sroa_idx.i, align 8, !dbg !54559, !alias.scope !54509, !noalias !54534
  %_14.sroa.5.0._0.sroa_idx.i = getelementptr inbounds nuw i8, ptr %_0, i64 32, !dbg !54559
  %144 = ptrtoint ptr %_14.sroa.5.0._0.sroa_idx.i to i64, !dbg !54559
  %145 = lshr i64 %144, 3, !dbg !54559
  %146 = add i64 %145, 2147450880, !dbg !54559
  %147 = inttoptr i64 %146 to ptr, !dbg !54559
  %148 = load i8, ptr %147, align 1, !dbg !54559
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %148), !dbg !54559
  %149 = icmp ne i8 %148, 0, !dbg !54559
  br i1 %149, label %150, label %153, !dbg !54559

150:                                              ; preds = %143
  %151 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2158, i64 0, i64 22), align 1, !dbg !54559, !nosanitize !4137
  %152 = add i8 %151, 1, !dbg !54559
  store i8 %152, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2158, i64 0, i64 22), align 1, !dbg !54559, !nosanitize !4137
  call void @__asan_report_store8(i64 %144) #42, !dbg !54559
  unreachable, !dbg !54559

153:                                              ; preds = %143
  store i64 %_4.sroa.12.0.i, ptr %_14.sroa.5.0._0.sroa_idx.i, align 8, !dbg !54559, !alias.scope !54509, !noalias !54534
  %_14.sroa.6.0._0.sroa_idx.i = getelementptr inbounds nuw i8, ptr %_0, i64 40, !dbg !54559
  %154 = ptrtoint ptr %_14.sroa.6.0._0.sroa_idx.i to i64, !dbg !54559
  %155 = lshr i64 %154, 3, !dbg !54559
  %156 = add i64 %155, 2147450880, !dbg !54559
  %157 = inttoptr i64 %156 to ptr, !dbg !54559
  %158 = load i8, ptr %157, align 1, !dbg !54559
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %158), !dbg !54559
  %159 = icmp ne i8 %158, 0, !dbg !54559
  br i1 %159, label %160, label %163, !dbg !54559

160:                                              ; preds = %153
  %161 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2158, i64 0, i64 23), align 1, !dbg !54559, !nosanitize !4137
  %162 = add i8 %161, 1, !dbg !54559
  store i8 %162, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2158, i64 0, i64 23), align 1, !dbg !54559, !nosanitize !4137
  call void @__asan_report_store8(i64 %154) #42, !dbg !54559
  unreachable, !dbg !54559

163:                                              ; preds = %153
  store ptr %_11.i.i, ptr %_14.sroa.6.0._0.sroa_idx.i, align 8, !dbg !54559, !alias.scope !54509, !noalias !54534
  %_14.sroa.7.0._0.sroa_idx.i = getelementptr inbounds nuw i8, ptr %_0, i64 48, !dbg !54559
  %164 = ptrtoint ptr %_14.sroa.7.0._0.sroa_idx.i to i64, !dbg !54559
  %165 = lshr i64 %164, 3, !dbg !54559
  %166 = add i64 %165, 2147450880, !dbg !54559
  %167 = inttoptr i64 %166 to ptr, !dbg !54559
  %168 = load i8, ptr %167, align 1, !dbg !54559
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %168), !dbg !54559
  %169 = icmp ne i8 %168, 0, !dbg !54559
  br i1 %169, label %170, label %173, !dbg !54559

170:                                              ; preds = %163
  %171 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2158, i64 0, i64 24), align 1, !dbg !54559, !nosanitize !4137
  %172 = add i8 %171, 1, !dbg !54559
  store i8 %172, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2158, i64 0, i64 24), align 1, !dbg !54559, !nosanitize !4137
  call void @__asan_report_store8(i64 %164) #42, !dbg !54559
  unreachable, !dbg !54559

173:                                              ; preds = %163
  %174 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2158, i64 0, i64 25), align 1, !dbg !54559, !nosanitize !4137
  %175 = add i8 %174, 1, !dbg !54559
  store i8 %175, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2158, i64 0, i64 25), align 1, !dbg !54559, !nosanitize !4137
  store i64 %new_len.i.i, ptr %_14.sroa.7.0._0.sroa_idx.i, align 8, !dbg !54559, !alias.scope !54509, !noalias !54534
  br label %_RNvNtCsiKgSYIST2hs_15spiral_protocol4wire5parse.exit, !dbg !54560

bb11.i:                                           ; preds = %bb10.i
  %176 = ptrtoint ptr %_0 to i64, !dbg !54561
  %177 = lshr i64 %176, 3, !dbg !54561
  %178 = add i64 %177, 2147450880, !dbg !54561
  %179 = inttoptr i64 %178 to ptr, !dbg !54561
  %180 = load i8, ptr %179, align 1, !dbg !54561
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %180), !dbg !54561
  %181 = icmp ne i8 %180, 0, !dbg !54561
  br i1 %181, label %184, label %bb11.i._crit_edge, !dbg !54561, !prof !4285

bb11.i._crit_edge:                                ; preds = %bb11.i
  %182 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2158, i64 0, i64 26), align 1, !dbg !54561, !nosanitize !4137
  %183 = add i8 %182, 1, !dbg !54561
  store i8 %183, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2158, i64 0, i64 26), align 1, !dbg !54561, !nosanitize !4137
  br label %193, !dbg !54561

184:                                              ; preds = %bb11.i
  %185 = and i64 %176, 7, !dbg !54561
  %186 = trunc i64 %185 to i8, !dbg !54561
  call void @__sanitizer_cov_trace_cmp1(i8 %186, i8 %180), !dbg !54561
  %187 = icmp sge i8 %186, %180, !dbg !54561
  br i1 %187, label %190, label %._crit_edge5, !dbg !54561

._crit_edge5:                                     ; preds = %184
  %188 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2158, i64 0, i64 27), align 1, !dbg !54561, !nosanitize !4137
  %189 = add i8 %188, 1, !dbg !54561
  store i8 %189, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2158, i64 0, i64 27), align 1, !dbg !54561, !nosanitize !4137
  br label %193, !dbg !54561

190:                                              ; preds = %184
  %191 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2158, i64 0, i64 28), align 1, !dbg !54561, !nosanitize !4137
  %192 = add i8 %191, 1, !dbg !54561
  store i8 %192, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2158, i64 0, i64 28), align 1, !dbg !54561, !nosanitize !4137
  call void @__asan_report_store1(i64 %176) #42, !dbg !54561
  unreachable

193:                                              ; preds = %._crit_edge5, %bb11.i._crit_edge
  store i8 0, ptr %_0, align 8, !dbg !54561, !alias.scope !54509, !noalias !54534
  %194 = getelementptr inbounds nuw i8, ptr %_0, i64 40, !dbg !54561
  %195 = ptrtoint ptr %194 to i64, !dbg !54561
  %196 = lshr i64 %195, 3, !dbg !54561
  %197 = add i64 %196, 2147450880, !dbg !54561
  %198 = inttoptr i64 %197 to ptr, !dbg !54561
  %199 = load i8, ptr %198, align 1, !dbg !54561
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %199), !dbg !54561
  %200 = icmp ne i8 %199, 0, !dbg !54561
  br i1 %200, label %201, label %204, !dbg !54561

201:                                              ; preds = %193
  %202 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2158, i64 0, i64 29), align 1, !dbg !54561, !nosanitize !4137
  %203 = add i8 %202, 1, !dbg !54561
  store i8 %203, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2158, i64 0, i64 29), align 1, !dbg !54561, !nosanitize !4137
  call void @__asan_report_store8(i64 %195) #42, !dbg !54561
  unreachable, !dbg !54561

204:                                              ; preds = %193
  %205 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2158, i64 0, i64 30), align 1, !dbg !54561, !nosanitize !4137
  %206 = add i8 %205, 1, !dbg !54561
  store i8 %206, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2158, i64 0, i64 30), align 1, !dbg !54561, !nosanitize !4137
  store ptr null, ptr %194, align 8, !dbg !54561, !alias.scope !54509, !noalias !54534
  br label %_RNvNtCsiKgSYIST2hs_15spiral_protocol4wire5parse.exit, !dbg !54562

_RNvNtCsiKgSYIST2hs_15spiral_protocol4wire5parse.exit: ; preds = %77, %127, %173, %204
  call void @llvm.lifetime.end.p0(ptr nonnull %h.sroa.0.i), !dbg !54560
  store i64 1172321806, ptr %20, align 8, !dbg !54564
  call void @__sanitizer_cov_trace_const_cmp8(i64 0, i64 %11), !dbg !54564
  %207 = icmp ne i64 %11, 0, !dbg !54564
  br i1 %207, label %208, label %218, !dbg !54564

208:                                              ; preds = %_RNvNtCsiKgSYIST2hs_15spiral_protocol4wire5parse.exit
  %209 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2158, i64 0, i64 31), align 1, !dbg !54564, !nosanitize !4137
  %210 = add i8 %209, 1, !dbg !54564
  store i8 %210, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2158, i64 0, i64 31), align 1, !dbg !54564, !nosanitize !4137
  %211 = add i64 %26, 0, !dbg !54564
  %212 = inttoptr i64 %211 to ptr, !dbg !54564
  store i64 -723401728380766731, ptr %212, align 1, !dbg !54564
  %213 = add i64 %26, 8, !dbg !54564
  %214 = inttoptr i64 %213 to ptr, !dbg !54564
  store i64 -723401728380766731, ptr %214, align 1, !dbg !54564
  %215 = getelementptr i8, ptr %12, i64 120, !dbg !54564
  %216 = load i64, ptr %215, align 8, !dbg !54564
  %217 = inttoptr i64 %216 to ptr, !dbg !54564
  store i8 0, ptr %217, align 1, !dbg !54564
  br label %225, !dbg !54564

218:                                              ; preds = %_RNvNtCsiKgSYIST2hs_15spiral_protocol4wire5parse.exit
  %219 = load i8, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2158, i64 0, i64 32), align 1, !dbg !54564, !nosanitize !4137
  %220 = add i8 %219, 1, !dbg !54564
  store i8 %220, ptr getelementptr ([33 x i8], ptr @__sancov_gen_.2158, i64 0, i64 32), align 1, !dbg !54564, !nosanitize !4137
  %221 = add i64 %26, 0, !dbg !54564
  %222 = inttoptr i64 %221 to ptr, !dbg !54564
  store i64 0, ptr %222, align 1, !dbg !54564
  %223 = add i64 %26, 8, !dbg !54564
  %224 = inttoptr i64 %223 to ptr, !dbg !54564
  store i64 0, ptr %224, align 1, !dbg !54564
  br label %225, !dbg !54564

225:                                              ; preds = %218, %208
  ret void, !dbg !54564
}

; Verified production function: parse_client_hello
define void @_RNvNtCsiKgSYIST2hs_15spiral_protocol12test_support18parse_client_hello(ptr dead_on_unwind noalias nofree noundef writable writeonly sret([32 x i8]) align 8 captures(none) dereferenceable(32) %_0, ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) %data.0, i64 noundef range(i64 0, -9223372036854775808) %data.1) unnamed_addr #12 comdat !dbg !54565 !guid !54566 {
start:
  %0 = load i8, ptr @__sancov_gen_.2160, align 1, !dbg !54567, !nosanitize !4137
  %1 = add i8 %0, 1, !dbg !54567
  store i8 %1, ptr @__sancov_gen_.2160, align 1, !dbg !54567, !nosanitize !4137
; call spiral_protocol::handshake::parse_hello
  tail call void @_RNvNtCsiKgSYIST2hs_15spiral_protocol9handshake11parse_hello(ptr noalias nofree noundef sret([32 x i8]) align 8 captures(address) dereferenceable(32) %_0, ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) %data.0, i64 noundef %data.1) #35, !dbg !54568
  ret void, !dbg !54569
}

; Verified production function: parse_hello
define void @_RNvNtCsiKgSYIST2hs_15spiral_protocol9handshake11parse_hello(ptr dead_on_unwind noalias nofree noundef writable writeonly sret([32 x i8]) align 8 captures(none) dereferenceable(32) %_0, ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) %p.0, i64 noundef range(i64 0, -9223372036854775808) %p.1) unnamed_addr #0 comdat !dbg !55704 !guid !55705 {
start:
  %asan_local_stack_base = alloca i64, align 8
  %0 = load i8, ptr @__sancov_gen_.2178, align 1, !dbg !55706, !nosanitize !4137
  %1 = add i8 %0, 1, !dbg !55706
  store i8 %1, ptr @__sancov_gen_.2178, align 1, !dbg !55706, !nosanitize !4137
  %2 = load i32, ptr @__asan_option_detect_stack_use_after_return, align 4
  call void @__sanitizer_cov_trace_const_cmp4(i32 0, i32 %2), !dbg !55707
  %3 = icmp ne i32 %2, 0
  br i1 %3, label %6, label %start._crit_edge

start._crit_edge:                                 ; preds = %start
  %4 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 1), align 1, !dbg !55707, !nosanitize !4137
  %5 = add i8 %4, 1, !dbg !55707
  store i8 %5, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 1), align 1, !dbg !55707, !nosanitize !4137
  br label %10

6:                                                ; preds = %start
  %7 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 2), align 1, !dbg !55707, !nosanitize !4137
  %8 = add i8 %7, 1, !dbg !55707
  store i8 %8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 2), align 1, !dbg !55707, !nosanitize !4137
  %9 = call i64 @__asan_stack_malloc_2(i64 160)
  br label %10

10:                                               ; preds = %start._crit_edge, %6
  %11 = phi i64 [ 0, %start._crit_edge ], [ %9, %6 ]
  %12 = inttoptr i64 %11 to ptr
  call void @__sanitizer_cov_trace_const_cmp8(i64 0, i64 %11), !dbg !55707
  %13 = icmp eq i64 %11, 0
  br i1 %13, label %16, label %._crit_edge

._crit_edge:                                      ; preds = %10
  %14 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 3), align 1, !dbg !55707, !nosanitize !4137
  %15 = add i8 %14, 1, !dbg !55707
  store i8 %15, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 3), align 1, !dbg !55707, !nosanitize !4137
  br label %19

16:                                               ; preds = %10
  %17 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 4), align 1, !dbg !55707, !nosanitize !4137
  %18 = add i8 %17, 1, !dbg !55707
  store i8 %18, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 4), align 1, !dbg !55707, !nosanitize !4137
  %MyAlloca = alloca i8, i64 160, align 32
  br label %19

19:                                               ; preds = %._crit_edge, %16
  %20 = phi ptr [ %12, %._crit_edge ], [ %MyAlloca, %16 ]
  store ptr %20, ptr %asan_local_stack_base, align 8
  %21 = getelementptr i8, ptr %20, i64 32
  %22 = getelementptr i8, ptr %20, i64 96
  store i64 1102416563, ptr %20, align 8
  %23 = getelementptr i8, ptr %20, i64 8
  store i64 ptrtoint (ptr @___asan_gen_stack.248 to i64), ptr %23, align 8
  %24 = getelementptr i8, ptr %20, i64 16
  store i64 ptrtoint (ptr @_RNvNtCsiKgSYIST2hs_15spiral_protocol9handshake11parse_hello to i64), ptr %24, align 8
  %25 = ptrtoint ptr %20 to i64
  %26 = lshr i64 %25, 3
  %27 = add i64 %26, 2147450880
  %28 = add i64 %27, 0
  %29 = inttoptr i64 %28 to ptr
  store i64 -938726774212005391, ptr %29, align 1
  %30 = add i64 %27, 8
  %31 = inttoptr i64 %30 to ptr
  store i64 -866669180157234446, ptr %31, align 1
  %32 = add i64 %27, 16
  %33 = inttoptr i64 %32 to ptr
  store i32 -202116109, ptr %33, align 1
  %34 = add nsw i64 %p.1, -75, !dbg !55708
  call void @__sanitizer_cov_trace_const_cmp8(i64 344, i64 %34), !dbg !55708
  %spec.select = icmp ult i64 %34, 344, !dbg !55708
  br i1 %spec.select, label %bb5.i, label %bb3, !dbg !55711

bb3:                                              ; preds = %19
  %35 = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !55712
  %36 = ptrtoint ptr %35 to i64, !dbg !55712
  %37 = lshr i64 %36, 3, !dbg !55712
  %38 = add i64 %37, 2147450880, !dbg !55712
  %39 = inttoptr i64 %38 to ptr, !dbg !55712
  %40 = load i8, ptr %39, align 1, !dbg !55712
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %40), !dbg !55712
  %41 = icmp ne i8 %40, 0, !dbg !55712
  br i1 %41, label %44, label %bb3._crit_edge, !dbg !55712, !prof !4285

bb3._crit_edge:                                   ; preds = %bb3
  %42 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 5), align 1, !dbg !55712, !nosanitize !4137
  %43 = add i8 %42, 1, !dbg !55712
  store i8 %43, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 5), align 1, !dbg !55712, !nosanitize !4137
  br label %53, !dbg !55712

44:                                               ; preds = %bb3
  %45 = and i64 %36, 7, !dbg !55712
  %46 = trunc i64 %45 to i8, !dbg !55712
  call void @__sanitizer_cov_trace_cmp1(i8 %46, i8 %40), !dbg !55712
  %47 = icmp sge i8 %46, %40, !dbg !55712
  br i1 %47, label %50, label %._crit_edge435, !dbg !55712

._crit_edge435:                                   ; preds = %44
  %48 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 6), align 1, !dbg !55712, !nosanitize !4137
  %49 = add i8 %48, 1, !dbg !55712
  store i8 %49, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 6), align 1, !dbg !55712, !nosanitize !4137
  br label %53, !dbg !55712

50:                                               ; preds = %44
  %51 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 7), align 1, !dbg !55712, !nosanitize !4137
  %52 = add i8 %51, 1, !dbg !55712
  store i8 %52, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 7), align 1, !dbg !55712, !nosanitize !4137
  call void @__asan_report_store1(i64 %36) #42, !dbg !55712
  unreachable

53:                                               ; preds = %._crit_edge435, %bb3._crit_edge
  store i8 0, ptr %35, align 8, !dbg !55712
  %54 = ptrtoint ptr %_0 to i64, !dbg !55712
  %55 = lshr i64 %54, 3, !dbg !55712
  %56 = add i64 %55, 2147450880, !dbg !55712
  %57 = inttoptr i64 %56 to ptr, !dbg !55712
  %58 = load i8, ptr %57, align 1, !dbg !55712
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %58), !dbg !55712
  %59 = icmp ne i8 %58, 0, !dbg !55712
  br i1 %59, label %60, label %63, !dbg !55712

60:                                               ; preds = %53
  %61 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 8), align 1, !dbg !55712, !nosanitize !4137
  %62 = add i8 %61, 1, !dbg !55712
  store i8 %62, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 8), align 1, !dbg !55712, !nosanitize !4137
  call void @__asan_report_store8(i64 %54) #42, !dbg !55712
  unreachable, !dbg !55712

63:                                               ; preds = %53
  %64 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 9), align 1, !dbg !55712, !nosanitize !4137
  %65 = add i8 %64, 1, !dbg !55712
  store i8 %65, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 9), align 1, !dbg !55712, !nosanitize !4137
  store ptr null, ptr %_0, align 8, !dbg !55712
  br label %bb89, !dbg !55713

bb89:                                             ; preds = %804, %667, %636, %459, %241, %536, %603, %341, %408, %709, %63
  store i64 1172321806, ptr %20, align 8, !dbg !55715
  call void @__sanitizer_cov_trace_const_cmp8(i64 0, i64 %11), !dbg !55715
  %66 = icmp ne i64 %11, 0, !dbg !55715
  br i1 %66, label %67, label %81, !dbg !55715

67:                                               ; preds = %bb89
  %68 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 10), align 1, !dbg !55715, !nosanitize !4137
  %69 = add i8 %68, 1, !dbg !55715
  store i8 %69, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 10), align 1, !dbg !55715, !nosanitize !4137
  %70 = add i64 %27, 0, !dbg !55715
  %71 = inttoptr i64 %70 to ptr, !dbg !55715
  store i64 -723401728380766731, ptr %71, align 1, !dbg !55715
  %72 = add i64 %27, 8, !dbg !55715
  %73 = inttoptr i64 %72 to ptr, !dbg !55715
  store i64 -723401728380766731, ptr %73, align 1, !dbg !55715
  %74 = add i64 %27, 16, !dbg !55715
  %75 = inttoptr i64 %74 to ptr, !dbg !55715
  store i64 -723401728380766731, ptr %75, align 1, !dbg !55715
  %76 = add i64 %27, 24, !dbg !55715
  %77 = inttoptr i64 %76 to ptr, !dbg !55715
  store i64 -723401728380766731, ptr %77, align 1, !dbg !55715
  %78 = getelementptr i8, ptr %12, i64 248, !dbg !55715
  %79 = load i64, ptr %78, align 8, !dbg !55715
  %80 = inttoptr i64 %79 to ptr, !dbg !55715
  store i8 0, ptr %80, align 1, !dbg !55715
  br label %90, !dbg !55715

81:                                               ; preds = %bb89
  %82 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 11), align 1, !dbg !55715, !nosanitize !4137
  %83 = add i8 %82, 1, !dbg !55715
  store i8 %83, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 11), align 1, !dbg !55715, !nosanitize !4137
  %84 = add i64 %27, 0, !dbg !55715
  %85 = inttoptr i64 %84 to ptr, !dbg !55715
  store i64 0, ptr %85, align 1, !dbg !55715
  %86 = add i64 %27, 8, !dbg !55715
  %87 = inttoptr i64 %86 to ptr, !dbg !55715
  store i64 0, ptr %87, align 1, !dbg !55715
  %88 = add i64 %27, 16, !dbg !55715
  %89 = inttoptr i64 %88 to ptr, !dbg !55715
  store i32 0, ptr %89, align 1, !dbg !55715
  br label %90, !dbg !55715

90:                                               ; preds = %81, %67
  ret void, !dbg !55715

bb5:                                              ; preds = %bb23
  %_4.0.i.i.1 = add i64 %i.sroa.0.7, 1, !dbg !55716
  call void @__sanitizer_cov_trace_const_cmp8(i64 -1, i64 %i.sroa.0.7), !dbg !55716
  %_4.1.i.not.i.1 = icmp eq i64 %i.sroa.0.7, -1, !dbg !55716
  br i1 %_4.1.i.not.i.1, label %bb5._RNvNvNtCsiKgSYIST2hs_15spiral_protocol9handshake11parse_hello4take.exit.1_crit_edge, label %bb5.i.1, !dbg !55725

bb5._RNvNvNtCsiKgSYIST2hs_15spiral_protocol9handshake11parse_hello4take.exit.1_crit_edge: ; preds = %bb5
  %91 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 12), align 1, !dbg !55725, !nosanitize !4137
  %92 = add i8 %91, 1, !dbg !55725
  store i8 %92, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 12), align 1, !dbg !55725, !nosanitize !4137
  br label %_RNvNvNtCsiKgSYIST2hs_15spiral_protocol9handshake11parse_hello4take.exit.1, !dbg !55725

bb5.i.1:                                          ; preds = %bb5
  call void @__sanitizer_cov_trace_cmp8(i64 %_4.0.i.i.1, i64 %p.1), !dbg !55707
  %_7.not.i.i.i.not.1 = icmp ugt i64 %_4.0.i.i.1, %p.1
  br i1 %_7.not.i.i.i.not.1, label %bb5.i.1._RNvNvNtCsiKgSYIST2hs_15spiral_protocol9handshake11parse_hello4take.exit.1_crit_edge, label %bb11.i.1, !dbg !55726

bb5.i.1._RNvNvNtCsiKgSYIST2hs_15spiral_protocol9handshake11parse_hello4take.exit.1_crit_edge: ; preds = %bb5.i.1
  %93 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 13), align 1, !dbg !55726, !nosanitize !4137
  %94 = add i8 %93, 1, !dbg !55726
  store i8 %94, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 13), align 1, !dbg !55726, !nosanitize !4137
  br label %_RNvNvNtCsiKgSYIST2hs_15spiral_protocol9handshake11parse_hello4take.exit.1, !dbg !55726

bb11.i.1:                                         ; preds = %bb5.i.1
  %95 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 14), align 1, !dbg !55728, !nosanitize !4137
  %96 = add i8 %95, 1, !dbg !55728
  store i8 %96, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 14), align 1, !dbg !55728, !nosanitize !4137
  %_15.i.i.i.1 = getelementptr inbounds nuw i8, ptr %p.0, i64 %i.sroa.0.7, !dbg !55728
  br label %_RNvNvNtCsiKgSYIST2hs_15spiral_protocol9handshake11parse_hello4take.exit.1, !dbg !55735

_RNvNvNtCsiKgSYIST2hs_15spiral_protocol9handshake11parse_hello4take.exit.1: ; preds = %bb5.i.1._RNvNvNtCsiKgSYIST2hs_15spiral_protocol9handshake11parse_hello4take.exit.1_crit_edge, %bb5._RNvNvNtCsiKgSYIST2hs_15spiral_protocol9handshake11parse_hello4take.exit.1_crit_edge, %bb11.i.1
  %_22.not.1 = phi i1 [ true, %bb5.i.1._RNvNvNtCsiKgSYIST2hs_15spiral_protocol9handshake11parse_hello4take.exit.1_crit_edge ], [ false, %bb11.i.1 ], [ true, %bb5._RNvNvNtCsiKgSYIST2hs_15spiral_protocol9handshake11parse_hello4take.exit.1_crit_edge ], !dbg !55736
  %_16.sroa.6.1.1 = phi i64 [ 0, %bb5.i.1._RNvNvNtCsiKgSYIST2hs_15spiral_protocol9handshake11parse_hello4take.exit.1_crit_edge ], [ 1, %bb11.i.1 ], [ 0, %bb5._RNvNvNtCsiKgSYIST2hs_15spiral_protocol9handshake11parse_hello4take.exit.1_crit_edge ], !dbg !55736
  %_16.sroa.0.0.1 = phi ptr [ null, %bb5.i.1._RNvNvNtCsiKgSYIST2hs_15spiral_protocol9handshake11parse_hello4take.exit.1_crit_edge ], [ %_15.i.i.i.1, %bb11.i.1 ], [ null, %bb5._RNvNvNtCsiKgSYIST2hs_15spiral_protocol9handshake11parse_hello4take.exit.1_crit_edge ], !dbg !55736
  %i.sroa.0.2.1 = phi i64 [ %i.sroa.0.7, %bb5.i.1._RNvNvNtCsiKgSYIST2hs_15spiral_protocol9handshake11parse_hello4take.exit.1_crit_edge ], [ %_4.0.i.i.1, %bb11.i.1 ], [ -1, %bb5._RNvNvNtCsiKgSYIST2hs_15spiral_protocol9handshake11parse_hello4take.exit.1_crit_edge ], !dbg !55707
  %97 = icmp eq ptr %_16.sroa.0.0.1, null, !dbg !55737
  br i1 %97, label %_RNvNvNtCsiKgSYIST2hs_15spiral_protocol9handshake11parse_hello4take.exit.1.bb13_crit_edge, label %bb12.1, !dbg !55737

_RNvNvNtCsiKgSYIST2hs_15spiral_protocol9handshake11parse_hello4take.exit.1.bb13_crit_edge: ; preds = %_RNvNvNtCsiKgSYIST2hs_15spiral_protocol9handshake11parse_hello4take.exit.1
  %98 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 15), align 1, !dbg !55737, !nosanitize !4137
  %99 = add i8 %98, 1, !dbg !55737
  store i8 %99, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 15), align 1, !dbg !55737, !nosanitize !4137
  br label %bb13, !dbg !55737

bb12.1:                                           ; preds = %_RNvNvNtCsiKgSYIST2hs_15spiral_protocol9handshake11parse_hello4take.exit.1
  br i1 %_22.not.1, label %bb12.1.panic24_crit_edge, label %bb15.1, !dbg !55737

bb12.1.panic24_crit_edge:                         ; preds = %bb12.1
  %100 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 16), align 1, !dbg !55737, !nosanitize !4137
  %101 = add i8 %100, 1, !dbg !55737
  store i8 %101, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 16), align 1, !dbg !55737, !nosanitize !4137
  br label %panic24, !dbg !55737

bb15.1:                                           ; preds = %bb12.1
  %102 = ptrtoint ptr %_16.sroa.0.0.1 to i64, !dbg !55737
  %103 = lshr i64 %102, 3, !dbg !55737
  %104 = add i64 %103, 2147450880, !dbg !55737
  %105 = inttoptr i64 %104 to ptr, !dbg !55737
  %106 = load i8, ptr %105, align 1, !dbg !55737
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %106), !dbg !55737
  %107 = icmp ne i8 %106, 0, !dbg !55737
  br i1 %107, label %110, label %bb15.1._crit_edge, !dbg !55737, !prof !4285

bb15.1._crit_edge:                                ; preds = %bb15.1
  %108 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 17), align 1, !dbg !55737, !nosanitize !4137
  %109 = add i8 %108, 1, !dbg !55737
  store i8 %109, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 17), align 1, !dbg !55737, !nosanitize !4137
  br label %119, !dbg !55737

110:                                              ; preds = %bb15.1
  %111 = and i64 %102, 7, !dbg !55737
  %112 = trunc i64 %111 to i8, !dbg !55737
  call void @__sanitizer_cov_trace_cmp1(i8 %112, i8 %106), !dbg !55737
  %113 = icmp sge i8 %112, %106, !dbg !55737
  br i1 %113, label %116, label %._crit_edge436, !dbg !55737

._crit_edge436:                                   ; preds = %110
  %114 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 18), align 1, !dbg !55737, !nosanitize !4137
  %115 = add i8 %114, 1, !dbg !55737
  store i8 %115, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 18), align 1, !dbg !55737, !nosanitize !4137
  br label %119, !dbg !55737

116:                                              ; preds = %110
  %117 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 19), align 1, !dbg !55737, !nosanitize !4137
  %118 = add i8 %117, 1, !dbg !55737
  store i8 %118, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 19), align 1, !dbg !55737, !nosanitize !4137
  call void @__asan_report_load1(i64 %102) #42, !dbg !55737
  unreachable

119:                                              ; preds = %._crit_edge436, %bb15.1._crit_edge
  %_14.1 = load i8, ptr %_16.sroa.0.0.1, align 1, !dbg !55737, !noundef !4137
  %120 = zext i8 %_14.1 to i64, !dbg !55737
  %121 = add i8 %_14.1, -1, !dbg !55738
  call void @__sanitizer_cov_trace_const_cmp1(i8 8, i8 %121), !dbg !55738
  %spec.select237.1 = icmp ult i8 %121, 8, !dbg !55738
  br i1 %spec.select237.1, label %bb20.preheader.1, label %.bb18_crit_edge, !dbg !55742

.bb18_crit_edge:                                  ; preds = %119
  %122 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 20), align 1, !dbg !55742, !nosanitize !4137
  %123 = add i8 %122, 1, !dbg !55742
  store i8 %123, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 20), align 1, !dbg !55742, !nosanitize !4137
  br label %bb18, !dbg !55742

bb20.preheader.1:                                 ; preds = %119
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %_14.1), !dbg !55743
  %_0.i.i.i162287.not.1 = icmp eq i8 %_14.1, 0, !dbg !55743
  br i1 %_0.i.i.i162287.not.1, label %bb20.preheader.1.bb35_crit_edge, label %bb20.preheader.1.bb22.1_crit_edge, !dbg !55750

bb20.preheader.1.bb22.1_crit_edge:                ; preds = %bb20.preheader.1
  br label %bb22.1, !dbg !55750

bb20.preheader.1.bb35_crit_edge:                  ; preds = %bb20.preheader.1
  %124 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 21), align 1, !dbg !55750, !nosanitize !4137
  %125 = add i8 %124, 1, !dbg !55750
  store i8 %125, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 21), align 1, !dbg !55750, !nosanitize !4137
  br label %bb35, !dbg !55750

bb22.1:                                           ; preds = %bb33.1.bb22.1_crit_edge, %bb20.preheader.1.bb22.1_crit_edge
  %spec.select238294.1 = phi i64 [ %spec.select238.1, %bb33.1.bb22.1_crit_edge ], [ 1, %bb20.preheader.1.bb22.1_crit_edge ]
  %found.sroa.0.0293.1 = phi i1 [ %181, %bb33.1.bb22.1_crit_edge ], [ false, %bb20.preheader.1.bb22.1_crit_edge ]
  %last.sroa.0.0292.1 = phi i16 [ %178, %bb33.1.bb22.1_crit_edge ], [ 0, %bb20.preheader.1.bb22.1_crit_edge ]
  %i.sroa.0.1291.1 = phi i64 [ %i.sroa.0.7.1, %bb33.1.bb22.1_crit_edge ], [ %i.sroa.0.2.1, %bb20.preheader.1.bb22.1_crit_edge ]
  %_37.sroa.6.1289.1 = phi i64 [ %_37.sroa.6.2.1, %bb33.1.bb22.1_crit_edge ], [ %_37.sroa.6.2, %bb20.preheader.1.bb22.1_crit_edge ]
  %_4.0.i.i165.1 = add i64 %i.sroa.0.1291.1, 2, !dbg !55751
  call void @__sanitizer_cov_trace_const_cmp8(i64 -3, i64 %i.sroa.0.1291.1), !dbg !55751
  %_4.1.i.not.i166.1 = icmp ugt i64 %i.sroa.0.1291.1, -3, !dbg !55751
  br i1 %_4.1.i.not.i166.1, label %bb6.i176.1, label %bb5.i167.1, !dbg !55754

bb5.i167.1:                                       ; preds = %bb22.1
  call void @__sanitizer_cov_trace_cmp8(i64 %_4.0.i.i165.1, i64 %p.1), !dbg !55707
  %_7.not.i.i.i168.1 = icmp ugt i64 %_4.0.i.i165.1, %p.1
  %.n.i169.1 = select i1 %_7.not.i.i.i168.1, i64 0, i64 2, !dbg !55755
  br i1 %_7.not.i.i.i168.1, label %bb12.i172.1, label %bb11.i170.1, !dbg !55758

bb11.i170.1:                                      ; preds = %bb5.i167.1
  %126 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 22), align 1, !dbg !55759, !nosanitize !4137
  %127 = add i8 %126, 1, !dbg !55759
  store i8 %127, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 22), align 1, !dbg !55759, !nosanitize !4137
  %_15.i.i.i171.1 = getelementptr inbounds nuw i8, ptr %p.0, i64 %i.sroa.0.1291.1, !dbg !55759
  br label %_RNvNvNtCsiKgSYIST2hs_15spiral_protocol9handshake11parse_hello4take.exit177.1, !dbg !55763

bb12.i172.1:                                      ; preds = %bb5.i167.1
  %128 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 23), align 1, !dbg !55764, !nosanitize !4137
  %129 = add i8 %128, 1, !dbg !55764
  store i8 %129, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 23), align 1, !dbg !55764, !nosanitize !4137
  %_37.sroa.6.8.insert.mask.1 = and i64 %_37.sroa.6.1289.1, -65536, !dbg !55764
  %_37.sroa.6.8.insert.insert.1 = or disjoint i64 %.n.i169.1, %_37.sroa.6.8.insert.mask.1, !dbg !55764
  br label %_RNvNvNtCsiKgSYIST2hs_15spiral_protocol9handshake11parse_hello4take.exit177.1, !dbg !55769

bb6.i176.1:                                       ; preds = %bb22.1
  %130 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 24), align 1, !dbg !55771, !nosanitize !4137
  %131 = add i8 %130, 1, !dbg !55771
  store i8 %131, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 24), align 1, !dbg !55771, !nosanitize !4137
  %_37.sroa.6.8.insert.mask210.1 = and i64 %_37.sroa.6.1289.1, -256, !dbg !55771
  br label %_RNvNvNtCsiKgSYIST2hs_15spiral_protocol9handshake11parse_hello4take.exit177.1, !dbg !55774

_RNvNvNtCsiKgSYIST2hs_15spiral_protocol9handshake11parse_hello4take.exit177.1: ; preds = %bb6.i176.1, %bb12.i172.1, %bb11.i170.1
  %_37.sroa.6.2.1 = phi i64 [ %_37.sroa.6.8.insert.mask210.1, %bb6.i176.1 ], [ %_37.sroa.6.8.insert.insert.1, %bb12.i172.1 ], [ %.n.i169.1, %bb11.i170.1 ], !dbg !55776
  %_37.sroa.0.0.1 = phi ptr [ null, %bb6.i176.1 ], [ null, %bb12.i172.1 ], [ %_15.i.i.i171.1, %bb11.i170.1 ], !dbg !55776
  %i.sroa.0.7.1 = phi i64 [ %i.sroa.0.1291.1, %bb6.i176.1 ], [ %i.sroa.0.1291.1, %bb12.i172.1 ], [ %_4.0.i.i165.1, %bb11.i170.1 ], !dbg !55707
  %132 = icmp eq ptr %_37.sroa.0.0.1, null, !dbg !55777
  %133 = and i64 %_37.sroa.6.2.1, 65535, !dbg !55780
  %_36.sroa.6.2.1 = select i1 %132, i64 %133, i64 %_37.sroa.6.2.1, !dbg !55780
  %134 = icmp eq ptr %_37.sroa.0.0.1, null, !dbg !55781
  br i1 %134, label %_RNvNvNtCsiKgSYIST2hs_15spiral_protocol9handshake11parse_hello4take.exit177.1.bb27_crit_edge, label %bb26.1, !dbg !55781

_RNvNvNtCsiKgSYIST2hs_15spiral_protocol9handshake11parse_hello4take.exit177.1.bb27_crit_edge: ; preds = %_RNvNvNtCsiKgSYIST2hs_15spiral_protocol9handshake11parse_hello4take.exit177.1
  %135 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 25), align 1, !dbg !55781, !nosanitize !4137
  %136 = add i8 %135, 1, !dbg !55781
  store i8 %136, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 25), align 1, !dbg !55781, !nosanitize !4137
  br label %bb27, !dbg !55781

bb26.1:                                           ; preds = %_RNvNvNtCsiKgSYIST2hs_15spiral_protocol9handshake11parse_hello4take.exit177.1
  call void @__sanitizer_cov_trace_const_cmp8(i64 2, i64 %_36.sroa.6.2.1), !dbg !55782
  %_4.i.i184.not.1 = icmp eq i64 %_36.sroa.6.2.1, 2, !dbg !55782
  br i1 %_4.i.i184.not.1, label %bb1.i.i191.1, label %bb26.1.bb2.i_crit_edge, !dbg !55782

bb26.1.bb2.i_crit_edge:                           ; preds = %bb26.1
  %137 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 26), align 1, !dbg !55782, !nosanitize !4137
  %138 = add i8 %137, 1, !dbg !55782
  store i8 %138, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 26), align 1, !dbg !55782, !nosanitize !4137
  br label %bb2.i, !dbg !55782

bb1.i.i191.1:                                     ; preds = %bb26.1
  %139 = ptrtoint ptr %_37.sroa.0.0.1 to i64, !dbg !55790
  %140 = add i64 %139, 1, !dbg !55790
  %141 = inttoptr i64 %140 to ptr, !dbg !55790
  %142 = ptrtoint ptr %_37.sroa.0.0.1 to i64, !dbg !55790
  %143 = lshr i64 %142, 3, !dbg !55790
  %144 = add i64 %143, 2147450880, !dbg !55790
  %145 = inttoptr i64 %144 to ptr, !dbg !55790
  %146 = load i8, ptr %145, align 1, !dbg !55790
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %146), !dbg !55790
  %147 = icmp ne i8 %146, 0, !dbg !55790
  br i1 %147, label %150, label %bb1.i.i191.1._crit_edge, !dbg !55790, !prof !4285

bb1.i.i191.1._crit_edge:                          ; preds = %bb1.i.i191.1
  %148 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 27), align 1, !dbg !55790, !nosanitize !4137
  %149 = add i8 %148, 1, !dbg !55790
  store i8 %149, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 27), align 1, !dbg !55790, !nosanitize !4137
  br label %159, !dbg !55790

150:                                              ; preds = %bb1.i.i191.1
  %151 = and i64 %142, 7, !dbg !55790
  %152 = trunc i64 %151 to i8, !dbg !55790
  call void @__sanitizer_cov_trace_cmp1(i8 %152, i8 %146), !dbg !55790
  %153 = icmp sge i8 %152, %146, !dbg !55790
  br i1 %153, label %156, label %._crit_edge437, !dbg !55790

._crit_edge437:                                   ; preds = %150
  %154 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 28), align 1, !dbg !55790, !nosanitize !4137
  %155 = add i8 %154, 1, !dbg !55790
  store i8 %155, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 28), align 1, !dbg !55790, !nosanitize !4137
  br label %159, !dbg !55790

156:                                              ; preds = %150
  %157 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 29), align 1, !dbg !55790, !nosanitize !4137
  %158 = add i8 %157, 1, !dbg !55790
  store i8 %158, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 29), align 1, !dbg !55790, !nosanitize !4137
  call void @__asan_report_load_n(i64 %142, i64 2) #42, !dbg !55790
  unreachable

159:                                              ; preds = %._crit_edge437, %bb1.i.i191.1._crit_edge
  %160 = ptrtoint ptr %141 to i64, !dbg !55790
  %161 = lshr i64 %160, 3, !dbg !55790
  %162 = add i64 %161, 2147450880, !dbg !55790
  %163 = inttoptr i64 %162 to ptr, !dbg !55790
  %164 = load i8, ptr %163, align 1, !dbg !55790
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %164), !dbg !55790
  %165 = icmp ne i8 %164, 0, !dbg !55790
  br i1 %165, label %168, label %._crit_edge438, !dbg !55790, !prof !4285

._crit_edge438:                                   ; preds = %159
  %166 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 30), align 1, !dbg !55790, !nosanitize !4137
  %167 = add i8 %166, 1, !dbg !55790
  store i8 %167, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 30), align 1, !dbg !55790, !nosanitize !4137
  br label %177, !dbg !55790

168:                                              ; preds = %159
  %169 = and i64 %160, 7, !dbg !55790
  %170 = trunc i64 %169 to i8, !dbg !55790
  call void @__sanitizer_cov_trace_cmp1(i8 %170, i8 %164), !dbg !55790
  %171 = icmp sge i8 %170, %164, !dbg !55790
  br i1 %171, label %174, label %._crit_edge439, !dbg !55790

._crit_edge439:                                   ; preds = %168
  %172 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 31), align 1, !dbg !55790, !nosanitize !4137
  %173 = add i8 %172, 1, !dbg !55790
  store i8 %173, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 31), align 1, !dbg !55790, !nosanitize !4137
  br label %177, !dbg !55790

174:                                              ; preds = %168
  %175 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 32), align 1, !dbg !55790, !nosanitize !4137
  %176 = add i8 %175, 1, !dbg !55790
  store i8 %176, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 32), align 1, !dbg !55790, !nosanitize !4137
  call void @__asan_report_load_n(i64 %160, i64 2) #42, !dbg !55790
  unreachable

177:                                              ; preds = %._crit_edge439, %._crit_edge438
  %v.sroa.0.0.copyload.i.i192.1 = load i16, ptr %_37.sroa.0.0.1, align 1, !dbg !55790, !alias.scope !55792
  %178 = tail call i16 @llvm.bswap.i16(i16 %v.sroa.0.0.copyload.i.i192.1), !dbg !55797
  call void @__sanitizer_cov_trace_cmp2(i16 %178, i16 %last.sroa.0.0292.1), !dbg !55801
  %_42.not.1 = icmp ugt i16 %178, %last.sroa.0.0292.1, !dbg !55801
  br i1 %_42.not.1, label %bb33.1, label %.bb32_crit_edge, !dbg !55801

.bb32_crit_edge:                                  ; preds = %177
  %179 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 33), align 1, !dbg !55801, !nosanitize !4137
  %180 = add i8 %179, 1, !dbg !55801
  store i8 %180, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 33), align 1, !dbg !55801, !nosanitize !4137
  br label %bb32, !dbg !55801

bb33.1:                                           ; preds = %177
  call void @__sanitizer_cov_trace_const_cmp2(i16 496, i16 %v.sroa.0.0.copyload.i.i192.1), !dbg !55803
  %_43.1 = icmp eq i16 %v.sroa.0.0.copyload.i.i192.1, 496, !dbg !55803
  %181 = or i1 %found.sroa.0.0293.1, %_43.1, !dbg !55804
  call void @__sanitizer_cov_trace_cmp8(i64 %spec.select238294.1, i64 %120), !dbg !55743
  %_0.i.i.i162.1 = icmp samesign ult i64 %spec.select238294.1, %120, !dbg !55743
  %_0.i1.i.i.1 = zext i1 %_0.i.i.i162.1 to i64, !dbg !55805
  %spec.select238.1 = add nuw i64 %spec.select238294.1, %_0.i1.i.i.1, !dbg !55805
  br i1 %_0.i.i.i162.1, label %bb33.1.bb22.1_crit_edge, label %bb23.1, !dbg !55750

bb33.1.bb22.1_crit_edge:                          ; preds = %bb33.1
  %182 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 34), align 1, !dbg !55750, !nosanitize !4137
  %183 = add i8 %182, 1, !dbg !55750
  store i8 %183, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 34), align 1, !dbg !55750, !nosanitize !4137
  br label %bb22.1, !dbg !55750

bb23.1:                                           ; preds = %bb33.1
  br i1 %181, label %bb5.1, label %bb23.1.bb35_crit_edge, !dbg !55806

bb23.1.bb35_crit_edge:                            ; preds = %bb23.1
  %184 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 35), align 1, !dbg !55806, !nosanitize !4137
  %185 = add i8 %184, 1, !dbg !55806
  store i8 %185, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 35), align 1, !dbg !55806, !nosanitize !4137
  br label %bb35, !dbg !55806

bb5.1:                                            ; preds = %bb23.1
  %_4.0.i.i56 = add i64 %i.sroa.0.7.1, 2, !dbg !55807
  call void @__sanitizer_cov_trace_const_cmp8(i64 -3, i64 %i.sroa.0.7.1), !dbg !55807
  %_4.1.i.not.i57 = icmp ugt i64 %i.sroa.0.7.1, -3, !dbg !55807
  call void @__sanitizer_cov_trace_cmp8(i64 %_4.0.i.i56, i64 %p.1), !dbg !55810
  %_7.not.i.i.i59 = icmp ugt i64 %_4.0.i.i56, %p.1, !dbg !55810
  %_15.i.i.i62 = getelementptr inbounds nuw i8, ptr %p.0, i64 %i.sroa.0.7.1, !dbg !55810
  %186 = or i1 %_4.1.i.not.i57, %_7.not.i.i.i59, !dbg !55810
  %187 = or i1 %_4.1.i.not.i57, %_7.not.i.i.i59, !dbg !55810
  %188 = or i1 %_4.1.i.not.i57, %_7.not.i.i.i59, !dbg !55810
  %i.sroa.0.3 = select i1 %188, i64 %i.sroa.0.7.1, i64 %_4.0.i.i56, !dbg !55810
  br i1 %187, label %bb40, label %bb39, !dbg !55811

bb5.i:                                            ; preds = %19
  call void @__sanitizer_cov_trace_const_cmp8(i64 65, i64 %p.1), !dbg !55707
  %_7.not.i.i.i.not = icmp samesign ult i64 %p.1, 65
  %_15.i.i.i = getelementptr inbounds nuw i8, ptr %p.0, i64 64, !dbg !55726
  %_16.sroa.6.1 = select i1 %_7.not.i.i.i.not, i64 0, i64 1, !dbg !55726
  %_16.sroa.0.0 = select i1 %_7.not.i.i.i.not, ptr null, ptr %_15.i.i.i, !dbg !55726
  %i.sroa.0.2 = select i1 %_7.not.i.i.i.not, i64 64, i64 65, !dbg !55726
  %189 = icmp eq ptr %_16.sroa.0.0, null, !dbg !55812
  %190 = and i64 %_16.sroa.6.1, 65281, !dbg !55814
  %_15.sroa.6.1 = select i1 %189, i64 %190, i64 %_16.sroa.6.1, !dbg !55814
  %191 = icmp eq ptr %_16.sroa.0.0, null, !dbg !55737
  br i1 %191, label %bb5.i.bb13_crit_edge, label %bb12, !dbg !55737

bb5.i.bb13_crit_edge:                             ; preds = %bb5.i
  %192 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 36), align 1, !dbg !55737, !nosanitize !4137
  %193 = add i8 %192, 1, !dbg !55737
  store i8 %193, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 36), align 1, !dbg !55737, !nosanitize !4137
  br label %bb13, !dbg !55737

bb40:                                             ; preds = %bb5.1
  %_48.sroa.6.8.extract.trunc = select i1 %186, i8 0, i8 2, !dbg !55810
  %194 = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !55815
  %195 = ptrtoint ptr %194 to i64, !dbg !55815
  %196 = lshr i64 %195, 3, !dbg !55815
  %197 = add i64 %196, 2147450880, !dbg !55815
  %198 = inttoptr i64 %197 to ptr, !dbg !55815
  %199 = load i8, ptr %198, align 1, !dbg !55815
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %199), !dbg !55815
  %200 = icmp ne i8 %199, 0, !dbg !55815
  br i1 %200, label %203, label %bb40._crit_edge, !dbg !55815, !prof !4285

bb40._crit_edge:                                  ; preds = %bb40
  %201 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 37), align 1, !dbg !55815, !nosanitize !4137
  %202 = add i8 %201, 1, !dbg !55815
  store i8 %202, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 37), align 1, !dbg !55815, !nosanitize !4137
  br label %212, !dbg !55815

203:                                              ; preds = %bb40
  %204 = and i64 %195, 7, !dbg !55815
  %205 = trunc i64 %204 to i8, !dbg !55815
  call void @__sanitizer_cov_trace_cmp1(i8 %205, i8 %199), !dbg !55815
  %206 = icmp sge i8 %205, %199, !dbg !55815
  br i1 %206, label %209, label %._crit_edge440, !dbg !55815

._crit_edge440:                                   ; preds = %203
  %207 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 38), align 1, !dbg !55815, !nosanitize !4137
  %208 = add i8 %207, 1, !dbg !55815
  store i8 %208, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 38), align 1, !dbg !55815, !nosanitize !4137
  br label %212, !dbg !55815

209:                                              ; preds = %203
  %210 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 39), align 1, !dbg !55815, !nosanitize !4137
  %211 = add i8 %210, 1, !dbg !55815
  store i8 %211, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 39), align 1, !dbg !55815, !nosanitize !4137
  call void @__asan_report_store1(i64 %195) #42, !dbg !55815
  unreachable

212:                                              ; preds = %._crit_edge440, %bb40._crit_edge
  store i8 %_48.sroa.6.8.extract.trunc, ptr %194, align 8, !dbg !55815, !alias.scope !55820
  %213 = getelementptr inbounds nuw i8, ptr %_0, i64 9, !dbg !55815
  %214 = ptrtoint ptr %213 to i64, !dbg !55815
  %215 = lshr i64 %214, 3, !dbg !55815
  %216 = add i64 %215, 2147450880, !dbg !55815
  %217 = inttoptr i64 %216 to ptr, !dbg !55815
  %218 = load i8, ptr %217, align 1, !dbg !55815
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %218), !dbg !55815
  %219 = icmp ne i8 %218, 0, !dbg !55815
  br i1 %219, label %222, label %._crit_edge441, !dbg !55815, !prof !4285

._crit_edge441:                                   ; preds = %212
  %220 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 40), align 1, !dbg !55815, !nosanitize !4137
  %221 = add i8 %220, 1, !dbg !55815
  store i8 %221, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 40), align 1, !dbg !55815, !nosanitize !4137
  br label %231, !dbg !55815

222:                                              ; preds = %212
  %223 = and i64 %214, 7, !dbg !55815
  %224 = trunc i64 %223 to i8, !dbg !55815
  call void @__sanitizer_cov_trace_cmp1(i8 %224, i8 %218), !dbg !55815
  %225 = icmp sge i8 %224, %218, !dbg !55815
  br i1 %225, label %228, label %._crit_edge442, !dbg !55815

._crit_edge442:                                   ; preds = %222
  %226 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 41), align 1, !dbg !55815, !nosanitize !4137
  %227 = add i8 %226, 1, !dbg !55815
  store i8 %227, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 41), align 1, !dbg !55815, !nosanitize !4137
  br label %231, !dbg !55815

228:                                              ; preds = %222
  %229 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 42), align 1, !dbg !55815, !nosanitize !4137
  %230 = add i8 %229, 1, !dbg !55815
  store i8 %230, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 42), align 1, !dbg !55815, !nosanitize !4137
  call void @__asan_report_store1(i64 %214) #42, !dbg !55815
  unreachable

231:                                              ; preds = %._crit_edge442, %._crit_edge441
  store i8 0, ptr %213, align 1, !dbg !55815, !alias.scope !55820
  %232 = ptrtoint ptr %_0 to i64, !dbg !55815
  %233 = lshr i64 %232, 3, !dbg !55815
  %234 = add i64 %233, 2147450880, !dbg !55815
  %235 = inttoptr i64 %234 to ptr, !dbg !55815
  %236 = load i8, ptr %235, align 1, !dbg !55815
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %236), !dbg !55815
  %237 = icmp ne i8 %236, 0, !dbg !55815
  br i1 %237, label %238, label %241, !dbg !55815

238:                                              ; preds = %231
  %239 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 43), align 1, !dbg !55815, !nosanitize !4137
  %240 = add i8 %239, 1, !dbg !55815
  store i8 %240, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 43), align 1, !dbg !55815, !nosanitize !4137
  call void @__asan_report_store8(i64 %232) #42, !dbg !55815
  unreachable, !dbg !55815

241:                                              ; preds = %231
  %242 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 44), align 1, !dbg !55815, !nosanitize !4137
  %243 = add i8 %242, 1, !dbg !55815
  store i8 %243, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 44), align 1, !dbg !55815, !nosanitize !4137
  store ptr null, ptr %_0, align 8, !dbg !55815, !alias.scope !55820
  br label %bb89, !dbg !55823

bb39:                                             ; preds = %bb5.1
  br i1 %186, label %bb2.i51, label %bb1.i.i75, !dbg !55825

bb1.i.i75:                                        ; preds = %bb39
  %244 = ptrtoint ptr %_15.i.i.i62 to i64, !dbg !55830
  %245 = add i64 %244, 1, !dbg !55830
  %246 = inttoptr i64 %245 to ptr, !dbg !55830
  %247 = ptrtoint ptr %_15.i.i.i62 to i64, !dbg !55830
  %248 = lshr i64 %247, 3, !dbg !55830
  %249 = add i64 %248, 2147450880, !dbg !55830
  %250 = inttoptr i64 %249 to ptr, !dbg !55830
  %251 = load i8, ptr %250, align 1, !dbg !55830
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %251), !dbg !55830
  %252 = icmp ne i8 %251, 0, !dbg !55830
  br i1 %252, label %255, label %bb1.i.i75._crit_edge, !dbg !55830, !prof !4285

bb1.i.i75._crit_edge:                             ; preds = %bb1.i.i75
  %253 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 45), align 1, !dbg !55830, !nosanitize !4137
  %254 = add i8 %253, 1, !dbg !55830
  store i8 %254, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 45), align 1, !dbg !55830, !nosanitize !4137
  br label %264, !dbg !55830

255:                                              ; preds = %bb1.i.i75
  %256 = and i64 %247, 7, !dbg !55830
  %257 = trunc i64 %256 to i8, !dbg !55830
  call void @__sanitizer_cov_trace_cmp1(i8 %257, i8 %251), !dbg !55830
  %258 = icmp sge i8 %257, %251, !dbg !55830
  br i1 %258, label %261, label %._crit_edge443, !dbg !55830

._crit_edge443:                                   ; preds = %255
  %259 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 46), align 1, !dbg !55830, !nosanitize !4137
  %260 = add i8 %259, 1, !dbg !55830
  store i8 %260, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 46), align 1, !dbg !55830, !nosanitize !4137
  br label %264, !dbg !55830

261:                                              ; preds = %255
  %262 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 47), align 1, !dbg !55830, !nosanitize !4137
  %263 = add i8 %262, 1, !dbg !55830
  store i8 %263, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 47), align 1, !dbg !55830, !nosanitize !4137
  call void @__asan_report_load_n(i64 %247, i64 2) #42, !dbg !55830
  unreachable

264:                                              ; preds = %._crit_edge443, %bb1.i.i75._crit_edge
  %265 = ptrtoint ptr %246 to i64, !dbg !55830
  %266 = lshr i64 %265, 3, !dbg !55830
  %267 = add i64 %266, 2147450880, !dbg !55830
  %268 = inttoptr i64 %267 to ptr, !dbg !55830
  %269 = load i8, ptr %268, align 1, !dbg !55830
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %269), !dbg !55830
  %270 = icmp ne i8 %269, 0, !dbg !55830
  br i1 %270, label %273, label %._crit_edge444, !dbg !55830, !prof !4285

._crit_edge444:                                   ; preds = %264
  %271 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 48), align 1, !dbg !55830, !nosanitize !4137
  %272 = add i8 %271, 1, !dbg !55830
  store i8 %272, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 48), align 1, !dbg !55830, !nosanitize !4137
  br label %282, !dbg !55830

273:                                              ; preds = %264
  %274 = and i64 %265, 7, !dbg !55830
  %275 = trunc i64 %274 to i8, !dbg !55830
  call void @__sanitizer_cov_trace_cmp1(i8 %275, i8 %269), !dbg !55830
  %276 = icmp sge i8 %275, %269, !dbg !55830
  br i1 %276, label %279, label %._crit_edge445, !dbg !55830

._crit_edge445:                                   ; preds = %273
  %277 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 49), align 1, !dbg !55830, !nosanitize !4137
  %278 = add i8 %277, 1, !dbg !55830
  store i8 %278, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 49), align 1, !dbg !55830, !nosanitize !4137
  br label %282, !dbg !55830

279:                                              ; preds = %273
  %280 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 50), align 1, !dbg !55830, !nosanitize !4137
  %281 = add i8 %280, 1, !dbg !55830
  store i8 %281, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 50), align 1, !dbg !55830, !nosanitize !4137
  call void @__asan_report_load_n(i64 %265, i64 2) #42, !dbg !55830
  unreachable

282:                                              ; preds = %._crit_edge445, %._crit_edge444
  %v.sroa.0.0.copyload.i.i = load i16, ptr %_15.i.i.i62, align 1, !dbg !55830, !alias.scope !55832
  %283 = tail call i16 @llvm.bswap.i16(i16 %v.sroa.0.0.copyload.i.i), !dbg !55837
  %284 = zext i16 %283 to i64, !dbg !55841
  %285 = add i64 %27, 12, !dbg !55842
  %286 = inttoptr i64 %285 to ptr, !dbg !55842
  store i16 0, ptr %286, align 1, !dbg !55842
  %287 = add i64 %27, 14, !dbg !55842
  %288 = inttoptr i64 %287 to ptr, !dbg !55842
  store i8 0, ptr %288, align 1, !dbg !55842
  %_4.0.i.i77 = add i64 %i.sroa.0.3, %284, !dbg !55844
  call void @__sanitizer_cov_trace_cmp8(i64 %_4.0.i.i77, i64 %i.sroa.0.3), !dbg !55844
  %_4.1.i.not.i78 = icmp ult i64 %_4.0.i.i77, %i.sroa.0.3, !dbg !55844
  call void @__sanitizer_cov_trace_cmp8(i64 %_4.0.i.i77, i64 %p.1), !dbg !55847
  %_7.not.i.i.i80 = icmp ugt i64 %_4.0.i.i77, %p.1, !dbg !55847
  %289 = or i1 %_4.1.i.not.i78, %_7.not.i.i.i80, !dbg !55847
  %_58.sroa.6.0 = select i1 %289, i64 0, i64 %284, !dbg !55847
  %290 = or i1 %_4.1.i.not.i78, %_7.not.i.i.i80, !dbg !55847
  %291 = tail call i64 @llvm.umax.i64(i64 %_4.0.i.i77, i64 %i.sroa.0.3), !dbg !55847
  %i.sroa.0.4 = select i1 %_7.not.i.i.i80, i64 %i.sroa.0.3, i64 %291, !dbg !55847
  br i1 %290, label %bb48, label %bb47, !dbg !55848

bb2.i51:                                          ; preds = %bb39
  %292 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 51), align 1, !dbg !55849, !nosanitize !4137
  %293 = add i8 %292, 1, !dbg !55849
  store i8 %293, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 51), align 1, !dbg !55849, !nosanitize !4137
  call void @__asan_handle_no_return(), !dbg !55849
; call core::result::unwrap_failed::<core::array::TryFromSliceError>
  tail call void @_RINvNtCshZBO5P2NUJi_4core6result13unwrap_failedNtNtB4_5array17TryFromSliceErrorECs7jJvS58pafZ_4ring(ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) @alloc_00ae4b301f7fab8ac9617c03fcbd7274, i64 noundef 43, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_4ad12800010026e41c01b9765009d71f) #43, !dbg !55849
  unreachable, !dbg !55849

bb48:                                             ; preds = %282
  %_57.sroa.6.8.extract.trunc = trunc i64 %_58.sroa.6.0 to i8, !dbg !55853
  %_57.sroa.6.9.extract.shift = lshr i64 %_58.sroa.6.0, 8, !dbg !55853
  %_57.sroa.6.9.extract.trunc = trunc nuw i64 %_57.sroa.6.9.extract.shift to i8, !dbg !55853
  %294 = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !55854
  %295 = ptrtoint ptr %294 to i64, !dbg !55854
  %296 = lshr i64 %295, 3, !dbg !55854
  %297 = add i64 %296, 2147450880, !dbg !55854
  %298 = inttoptr i64 %297 to ptr, !dbg !55854
  %299 = load i8, ptr %298, align 1, !dbg !55854
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %299), !dbg !55854
  %300 = icmp ne i8 %299, 0, !dbg !55854
  br i1 %300, label %303, label %bb48._crit_edge, !dbg !55854, !prof !4285

bb48._crit_edge:                                  ; preds = %bb48
  %301 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 52), align 1, !dbg !55854, !nosanitize !4137
  %302 = add i8 %301, 1, !dbg !55854
  store i8 %302, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 52), align 1, !dbg !55854, !nosanitize !4137
  br label %312, !dbg !55854

303:                                              ; preds = %bb48
  %304 = and i64 %295, 7, !dbg !55854
  %305 = trunc i64 %304 to i8, !dbg !55854
  call void @__sanitizer_cov_trace_cmp1(i8 %305, i8 %299), !dbg !55854
  %306 = icmp sge i8 %305, %299, !dbg !55854
  br i1 %306, label %309, label %._crit_edge446, !dbg !55854

._crit_edge446:                                   ; preds = %303
  %307 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 53), align 1, !dbg !55854, !nosanitize !4137
  %308 = add i8 %307, 1, !dbg !55854
  store i8 %308, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 53), align 1, !dbg !55854, !nosanitize !4137
  br label %312, !dbg !55854

309:                                              ; preds = %303
  %310 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 54), align 1, !dbg !55854, !nosanitize !4137
  %311 = add i8 %310, 1, !dbg !55854
  store i8 %311, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 54), align 1, !dbg !55854, !nosanitize !4137
  call void @__asan_report_store1(i64 %295) #42, !dbg !55854
  unreachable

312:                                              ; preds = %._crit_edge446, %bb48._crit_edge
  store i8 %_57.sroa.6.8.extract.trunc, ptr %294, align 8, !dbg !55854, !alias.scope !55857
  %313 = getelementptr inbounds nuw i8, ptr %_0, i64 9, !dbg !55854
  %314 = ptrtoint ptr %313 to i64, !dbg !55854
  %315 = lshr i64 %314, 3, !dbg !55854
  %316 = add i64 %315, 2147450880, !dbg !55854
  %317 = inttoptr i64 %316 to ptr, !dbg !55854
  %318 = load i8, ptr %317, align 1, !dbg !55854
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %318), !dbg !55854
  %319 = icmp ne i8 %318, 0, !dbg !55854
  br i1 %319, label %322, label %._crit_edge447, !dbg !55854, !prof !4285

._crit_edge447:                                   ; preds = %312
  %320 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 55), align 1, !dbg !55854, !nosanitize !4137
  %321 = add i8 %320, 1, !dbg !55854
  store i8 %321, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 55), align 1, !dbg !55854, !nosanitize !4137
  br label %331, !dbg !55854

322:                                              ; preds = %312
  %323 = and i64 %314, 7, !dbg !55854
  %324 = trunc i64 %323 to i8, !dbg !55854
  call void @__sanitizer_cov_trace_cmp1(i8 %324, i8 %318), !dbg !55854
  %325 = icmp sge i8 %324, %318, !dbg !55854
  br i1 %325, label %328, label %._crit_edge448, !dbg !55854

._crit_edge448:                                   ; preds = %322
  %326 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 56), align 1, !dbg !55854, !nosanitize !4137
  %327 = add i8 %326, 1, !dbg !55854
  store i8 %327, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 56), align 1, !dbg !55854, !nosanitize !4137
  br label %331, !dbg !55854

328:                                              ; preds = %322
  %329 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 57), align 1, !dbg !55854, !nosanitize !4137
  %330 = add i8 %329, 1, !dbg !55854
  store i8 %330, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 57), align 1, !dbg !55854, !nosanitize !4137
  call void @__asan_report_store1(i64 %314) #42, !dbg !55854
  unreachable

331:                                              ; preds = %._crit_edge448, %._crit_edge447
  store i8 %_57.sroa.6.9.extract.trunc, ptr %313, align 1, !dbg !55854, !alias.scope !55857
  %332 = ptrtoint ptr %_0 to i64, !dbg !55854
  %333 = lshr i64 %332, 3, !dbg !55854
  %334 = add i64 %333, 2147450880, !dbg !55854
  %335 = inttoptr i64 %334 to ptr, !dbg !55854
  %336 = load i8, ptr %335, align 1, !dbg !55854
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %336), !dbg !55854
  %337 = icmp ne i8 %336, 0, !dbg !55854
  br i1 %337, label %338, label %341, !dbg !55854

338:                                              ; preds = %331
  %339 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 58), align 1, !dbg !55854, !nosanitize !4137
  %340 = add i8 %339, 1, !dbg !55854
  store i8 %340, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 58), align 1, !dbg !55854, !nosanitize !4137
  call void @__asan_report_store8(i64 %332) #42, !dbg !55854
  unreachable, !dbg !55854

341:                                              ; preds = %331
  %342 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 59), align 1, !dbg !55854, !nosanitize !4137
  %343 = add i8 %342, 1, !dbg !55854
  store i8 %343, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 59), align 1, !dbg !55854, !nosanitize !4137
  store ptr null, ptr %_0, align 8, !dbg !55854, !alias.scope !55857
  %344 = add i64 %27, 12, !dbg !55860
  %345 = inttoptr i64 %344 to ptr, !dbg !55860
  store i16 -1800, ptr %345, align 1, !dbg !55860
  %346 = add i64 %27, 14, !dbg !55860
  %347 = inttoptr i64 %346 to ptr, !dbg !55860
  store i8 -8, ptr %347, align 1, !dbg !55860
  br label %bb89, !dbg !55861

bb47:                                             ; preds = %282
  %_15.i.i.i83 = getelementptr inbounds nuw i8, ptr %p.0, i64 %i.sroa.0.3, !dbg !55847
; call core::str::converts::from_utf8
  call void @_RNvNtNtCshZBO5P2NUJi_4core3str8converts9from_utf8(ptr noalias nofree noundef sret([24 x i8]) align 8 captures(none) dereferenceable(24) %22, ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) %_15.i.i.i83, i64 noundef %_58.sroa.6.0) #35, !dbg !55842
  %_3.i = load i64, ptr %22, align 8, !dbg !55863, !range !5011, !alias.scope !55866, !noalias !55869, !noundef !4137
  %348 = trunc nuw i64 %_3.i to i1, !dbg !55871
  br i1 %348, label %bb47._RINvMNtCshZBO5P2NUJi_4core6resultINtB3_6ResultReNtNtNtB5_3str5error9Utf8ErrorE7map_errNtNtCsiKgSYIST2hs_15spiral_protocol5error5ErrorNCNvNtB1q_9handshake11parse_hello0EB1q_.exit_crit_edge, label %bb3.i94, !dbg !55871

bb47._RINvMNtCshZBO5P2NUJi_4core6resultINtB3_6ResultReNtNtNtB5_3str5error9Utf8ErrorE7map_errNtNtCsiKgSYIST2hs_15spiral_protocol5error5ErrorNCNvNtB1q_9handshake11parse_hello0EB1q_.exit_crit_edge: ; preds = %bb47
  %349 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 60), align 1, !dbg !55871, !nosanitize !4137
  %350 = add i8 %349, 1, !dbg !55871
  store i8 %350, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 60), align 1, !dbg !55871, !nosanitize !4137
  br label %_RINvMNtCshZBO5P2NUJi_4core6resultINtB3_6ResultReNtNtNtB5_3str5error9Utf8ErrorE7map_errNtNtCsiKgSYIST2hs_15spiral_protocol5error5ErrorNCNvNtB1q_9handshake11parse_hello0EB1q_.exit, !dbg !55871

bb3.i94:                                          ; preds = %bb47
  %351 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 61), align 1, !dbg !55872, !nosanitize !4137
  %352 = add i8 %351, 1, !dbg !55872
  store i8 %352, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 61), align 1, !dbg !55872, !nosanitize !4137
  %353 = getelementptr inbounds nuw i8, ptr %22, i64 8, !dbg !55872
  %t.0.i = load ptr, ptr %353, align 8, !dbg !55872, !alias.scope !55866, !noalias !55869, !nonnull !4137, !noundef !4137
  %354 = getelementptr inbounds nuw i8, ptr %22, i64 16, !dbg !55872
  %t.1.i = load i64, ptr %354, align 8, !dbg !55872, !alias.scope !55866, !noalias !55869, !noundef !4137
  br label %_RINvMNtCshZBO5P2NUJi_4core6resultINtB3_6ResultReNtNtNtB5_3str5error9Utf8ErrorE7map_errNtNtCsiKgSYIST2hs_15spiral_protocol5error5ErrorNCNvNtB1q_9handshake11parse_hello0EB1q_.exit, !dbg !55873

_RINvMNtCshZBO5P2NUJi_4core6resultINtB3_6ResultReNtNtNtB5_3str5error9Utf8ErrorE7map_errNtNtCsiKgSYIST2hs_15spiral_protocol5error5ErrorNCNvNtB1q_9handshake11parse_hello0EB1q_.exit: ; preds = %bb47._RINvMNtCshZBO5P2NUJi_4core6resultINtB3_6ResultReNtNtNtB5_3str5error9Utf8ErrorE7map_errNtNtCsiKgSYIST2hs_15spiral_protocol5error5ErrorNCNvNtB1q_9handshake11parse_hello0EB1q_.exit_crit_edge, %bb3.i94
  %_55.sroa.6.0 = phi i64 [ %t.1.i, %bb3.i94 ], [ 0, %bb47._RINvMNtCshZBO5P2NUJi_4core6resultINtB3_6ResultReNtNtNtB5_3str5error9Utf8ErrorE7map_errNtNtCsiKgSYIST2hs_15spiral_protocol5error5ErrorNCNvNtB1q_9handshake11parse_hello0EB1q_.exit_crit_edge ], !dbg !55874
  %_55.sroa.0.0 = phi ptr [ %t.0.i, %bb3.i94 ], [ null, %bb47._RINvMNtCshZBO5P2NUJi_4core6resultINtB3_6ResultReNtNtNtB5_3str5error9Utf8ErrorE7map_errNtNtCsiKgSYIST2hs_15spiral_protocol5error5ErrorNCNvNtB1q_9handshake11parse_hello0EB1q_.exit_crit_edge ], !dbg !55874
  %355 = add i64 %27, 12, !dbg !55860
  %356 = inttoptr i64 %355 to ptr, !dbg !55860
  store i16 -1800, ptr %356, align 1, !dbg !55860
  %357 = add i64 %27, 14, !dbg !55860
  %358 = inttoptr i64 %357 to ptr, !dbg !55860
  store i8 -8, ptr %358, align 1, !dbg !55860
  %359 = icmp eq ptr %_55.sroa.0.0, null, !dbg !55875
  %_54.sroa.6.9.insert.insert = and i64 %_55.sroa.6.0, 65535
  %spec.select243 = select i1 %359, i64 %_54.sroa.6.9.insert.insert, i64 %_55.sroa.6.0, !dbg !55878
  %360 = icmp eq ptr %_55.sroa.0.0, null, !dbg !55842
  br i1 %360, label %bb54, label %bb53, !dbg !55842

bb54:                                             ; preds = %_RINvMNtCshZBO5P2NUJi_4core6resultINtB3_6ResultReNtNtNtB5_3str5error9Utf8ErrorE7map_errNtNtCsiKgSYIST2hs_15spiral_protocol5error5ErrorNCNvNtB1q_9handshake11parse_hello0EB1q_.exit
  %_54.sroa.6.8.extract.trunc = trunc i64 %spec.select243 to i8, !dbg !55879
  %_54.sroa.6.9.extract.shift = lshr i64 %spec.select243, 8, !dbg !55879
  %_54.sroa.6.9.extract.trunc = trunc i64 %_54.sroa.6.9.extract.shift to i8, !dbg !55879
  %361 = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !55880
  %362 = ptrtoint ptr %361 to i64, !dbg !55880
  %363 = lshr i64 %362, 3, !dbg !55880
  %364 = add i64 %363, 2147450880, !dbg !55880
  %365 = inttoptr i64 %364 to ptr, !dbg !55880
  %366 = load i8, ptr %365, align 1, !dbg !55880
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %366), !dbg !55880
  %367 = icmp ne i8 %366, 0, !dbg !55880
  br i1 %367, label %370, label %bb54._crit_edge, !dbg !55880, !prof !4285

bb54._crit_edge:                                  ; preds = %bb54
  %368 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 62), align 1, !dbg !55880, !nosanitize !4137
  %369 = add i8 %368, 1, !dbg !55880
  store i8 %369, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 62), align 1, !dbg !55880, !nosanitize !4137
  br label %379, !dbg !55880

370:                                              ; preds = %bb54
  %371 = and i64 %362, 7, !dbg !55880
  %372 = trunc i64 %371 to i8, !dbg !55880
  call void @__sanitizer_cov_trace_cmp1(i8 %372, i8 %366), !dbg !55880
  %373 = icmp sge i8 %372, %366, !dbg !55880
  br i1 %373, label %376, label %._crit_edge449, !dbg !55880

._crit_edge449:                                   ; preds = %370
  %374 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 63), align 1, !dbg !55880, !nosanitize !4137
  %375 = add i8 %374, 1, !dbg !55880
  store i8 %375, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 63), align 1, !dbg !55880, !nosanitize !4137
  br label %379, !dbg !55880

376:                                              ; preds = %370
  %377 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 64), align 1, !dbg !55880, !nosanitize !4137
  %378 = add i8 %377, 1, !dbg !55880
  store i8 %378, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 64), align 1, !dbg !55880, !nosanitize !4137
  call void @__asan_report_store1(i64 %362) #42, !dbg !55880
  unreachable

379:                                              ; preds = %._crit_edge449, %bb54._crit_edge
  store i8 %_54.sroa.6.8.extract.trunc, ptr %361, align 8, !dbg !55880, !alias.scope !55883
  %380 = getelementptr inbounds nuw i8, ptr %_0, i64 9, !dbg !55880
  %381 = ptrtoint ptr %380 to i64, !dbg !55880
  %382 = lshr i64 %381, 3, !dbg !55880
  %383 = add i64 %382, 2147450880, !dbg !55880
  %384 = inttoptr i64 %383 to ptr, !dbg !55880
  %385 = load i8, ptr %384, align 1, !dbg !55880
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %385), !dbg !55880
  %386 = icmp ne i8 %385, 0, !dbg !55880
  br i1 %386, label %389, label %._crit_edge450, !dbg !55880, !prof !4285

._crit_edge450:                                   ; preds = %379
  %387 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 65), align 1, !dbg !55880, !nosanitize !4137
  %388 = add i8 %387, 1, !dbg !55880
  store i8 %388, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 65), align 1, !dbg !55880, !nosanitize !4137
  br label %398, !dbg !55880

389:                                              ; preds = %379
  %390 = and i64 %381, 7, !dbg !55880
  %391 = trunc i64 %390 to i8, !dbg !55880
  call void @__sanitizer_cov_trace_cmp1(i8 %391, i8 %385), !dbg !55880
  %392 = icmp sge i8 %391, %385, !dbg !55880
  br i1 %392, label %395, label %._crit_edge451, !dbg !55880

._crit_edge451:                                   ; preds = %389
  %393 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 66), align 1, !dbg !55880, !nosanitize !4137
  %394 = add i8 %393, 1, !dbg !55880
  store i8 %394, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 66), align 1, !dbg !55880, !nosanitize !4137
  br label %398, !dbg !55880

395:                                              ; preds = %389
  %396 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 67), align 1, !dbg !55880, !nosanitize !4137
  %397 = add i8 %396, 1, !dbg !55880
  store i8 %397, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 67), align 1, !dbg !55880, !nosanitize !4137
  call void @__asan_report_store1(i64 %381) #42, !dbg !55880
  unreachable

398:                                              ; preds = %._crit_edge451, %._crit_edge450
  store i8 %_54.sroa.6.9.extract.trunc, ptr %380, align 1, !dbg !55880, !alias.scope !55883
  %399 = ptrtoint ptr %_0 to i64, !dbg !55880
  %400 = lshr i64 %399, 3, !dbg !55880
  %401 = add i64 %400, 2147450880, !dbg !55880
  %402 = inttoptr i64 %401 to ptr, !dbg !55880
  %403 = load i8, ptr %402, align 1, !dbg !55880
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %403), !dbg !55880
  %404 = icmp ne i8 %403, 0, !dbg !55880
  br i1 %404, label %405, label %408, !dbg !55880

405:                                              ; preds = %398
  %406 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 68), align 1, !dbg !55880, !nosanitize !4137
  %407 = add i8 %406, 1, !dbg !55880
  store i8 %407, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 68), align 1, !dbg !55880, !nosanitize !4137
  call void @__asan_report_store8(i64 %399) #42, !dbg !55880
  unreachable, !dbg !55880

408:                                              ; preds = %398
  %409 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 69), align 1, !dbg !55880, !nosanitize !4137
  %410 = add i8 %409, 1, !dbg !55880
  store i8 %410, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 69), align 1, !dbg !55880, !nosanitize !4137
  store ptr null, ptr %_0, align 8, !dbg !55880, !alias.scope !55883
  br label %bb89, !dbg !55861

bb53:                                             ; preds = %_RINvMNtCshZBO5P2NUJi_4core6resultINtB3_6ResultReNtNtNtB5_3str5error9Utf8ErrorE7map_errNtNtCsiKgSYIST2hs_15spiral_protocol5error5ErrorNCNvNtB1q_9handshake11parse_hello0EB1q_.exit
  %_4.0.i.i103 = add i64 %i.sroa.0.4, 1, !dbg !55886
  call void @__sanitizer_cov_trace_const_cmp8(i64 -1, i64 %i.sroa.0.4), !dbg !55886
  %_4.1.i.not.i104 = icmp ne i64 %i.sroa.0.4, -1, !dbg !55886
  call void @__sanitizer_cov_trace_cmp8(i64 %_4.0.i.i103, i64 %p.1), !dbg !55890
  %_7.not.i.i.i106 = icmp ule i64 %_4.0.i.i103, %p.1, !dbg !55890
  %_15.i.i.i109 = getelementptr inbounds nuw i8, ptr %p.0, i64 %i.sroa.0.4, !dbg !55890
  %spec.select255 = select i1 %_7.not.i.i.i106, i64 %_4.0.i.i103, i64 %i.sroa.0.4, !dbg !55890
  %_69.sroa.6.0.shrunk = and i1 %_4.1.i.not.i104, %_7.not.i.i.i106, !dbg !55890
  %411 = and i1 %_4.1.i.not.i104, %_7.not.i.i.i106, !dbg !55890
  %i.sroa.0.5 = select i1 %_4.1.i.not.i104, i64 %spec.select255, i64 -1, !dbg !55890
  br i1 %411, label %bb58, label %bb59, !dbg !55891

bb59:                                             ; preds = %bb53
  %_68.sroa.6.8.extract.trunc = zext i1 %_69.sroa.6.0.shrunk to i8, !dbg !55892
  %412 = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !55893
  %413 = ptrtoint ptr %412 to i64, !dbg !55893
  %414 = lshr i64 %413, 3, !dbg !55893
  %415 = add i64 %414, 2147450880, !dbg !55893
  %416 = inttoptr i64 %415 to ptr, !dbg !55893
  %417 = load i8, ptr %416, align 1, !dbg !55893
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %417), !dbg !55893
  %418 = icmp ne i8 %417, 0, !dbg !55893
  br i1 %418, label %421, label %bb59._crit_edge, !dbg !55893, !prof !4285

bb59._crit_edge:                                  ; preds = %bb59
  %419 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 70), align 1, !dbg !55893, !nosanitize !4137
  %420 = add i8 %419, 1, !dbg !55893
  store i8 %420, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 70), align 1, !dbg !55893, !nosanitize !4137
  br label %430, !dbg !55893

421:                                              ; preds = %bb59
  %422 = and i64 %413, 7, !dbg !55893
  %423 = trunc i64 %422 to i8, !dbg !55893
  call void @__sanitizer_cov_trace_cmp1(i8 %423, i8 %417), !dbg !55893
  %424 = icmp sge i8 %423, %417, !dbg !55893
  br i1 %424, label %427, label %._crit_edge452, !dbg !55893

._crit_edge452:                                   ; preds = %421
  %425 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 71), align 1, !dbg !55893, !nosanitize !4137
  %426 = add i8 %425, 1, !dbg !55893
  store i8 %426, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 71), align 1, !dbg !55893, !nosanitize !4137
  br label %430, !dbg !55893

427:                                              ; preds = %421
  %428 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 72), align 1, !dbg !55893, !nosanitize !4137
  %429 = add i8 %428, 1, !dbg !55893
  store i8 %429, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 72), align 1, !dbg !55893, !nosanitize !4137
  call void @__asan_report_store1(i64 %413) #42, !dbg !55893
  unreachable

430:                                              ; preds = %._crit_edge452, %bb59._crit_edge
  store i8 %_68.sroa.6.8.extract.trunc, ptr %412, align 8, !dbg !55893, !alias.scope !55896
  %431 = getelementptr inbounds nuw i8, ptr %_0, i64 9, !dbg !55893
  %432 = ptrtoint ptr %431 to i64, !dbg !55893
  %433 = lshr i64 %432, 3, !dbg !55893
  %434 = add i64 %433, 2147450880, !dbg !55893
  %435 = inttoptr i64 %434 to ptr, !dbg !55893
  %436 = load i8, ptr %435, align 1, !dbg !55893
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %436), !dbg !55893
  %437 = icmp ne i8 %436, 0, !dbg !55893
  br i1 %437, label %440, label %._crit_edge453, !dbg !55893, !prof !4285

._crit_edge453:                                   ; preds = %430
  %438 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 73), align 1, !dbg !55893, !nosanitize !4137
  %439 = add i8 %438, 1, !dbg !55893
  store i8 %439, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 73), align 1, !dbg !55893, !nosanitize !4137
  br label %449, !dbg !55893

440:                                              ; preds = %430
  %441 = and i64 %432, 7, !dbg !55893
  %442 = trunc i64 %441 to i8, !dbg !55893
  call void @__sanitizer_cov_trace_cmp1(i8 %442, i8 %436), !dbg !55893
  %443 = icmp sge i8 %442, %436, !dbg !55893
  br i1 %443, label %446, label %._crit_edge454, !dbg !55893

._crit_edge454:                                   ; preds = %440
  %444 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 74), align 1, !dbg !55893, !nosanitize !4137
  %445 = add i8 %444, 1, !dbg !55893
  store i8 %445, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 74), align 1, !dbg !55893, !nosanitize !4137
  br label %449, !dbg !55893

446:                                              ; preds = %440
  %447 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 75), align 1, !dbg !55893, !nosanitize !4137
  %448 = add i8 %447, 1, !dbg !55893
  store i8 %448, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 75), align 1, !dbg !55893, !nosanitize !4137
  call void @__asan_report_store1(i64 %432) #42, !dbg !55893
  unreachable

449:                                              ; preds = %._crit_edge454, %._crit_edge453
  store i8 0, ptr %431, align 1, !dbg !55893, !alias.scope !55896
  %450 = ptrtoint ptr %_0 to i64, !dbg !55893
  %451 = lshr i64 %450, 3, !dbg !55893
  %452 = add i64 %451, 2147450880, !dbg !55893
  %453 = inttoptr i64 %452 to ptr, !dbg !55893
  %454 = load i8, ptr %453, align 1, !dbg !55893
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %454), !dbg !55893
  %455 = icmp ne i8 %454, 0, !dbg !55893
  br i1 %455, label %456, label %459, !dbg !55893

456:                                              ; preds = %449
  %457 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 76), align 1, !dbg !55893, !nosanitize !4137
  %458 = add i8 %457, 1, !dbg !55893
  store i8 %458, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 76), align 1, !dbg !55893, !nosanitize !4137
  call void @__asan_report_store8(i64 %450) #42, !dbg !55893
  unreachable, !dbg !55893

459:                                              ; preds = %449
  %460 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 77), align 1, !dbg !55893, !nosanitize !4137
  %461 = add i8 %460, 1, !dbg !55893
  store i8 %461, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 77), align 1, !dbg !55893, !nosanitize !4137
  store ptr null, ptr %_0, align 8, !dbg !55893, !alias.scope !55896
  br label %bb89, !dbg !55899

bb58:                                             ; preds = %bb53
  br i1 %_69.sroa.6.0.shrunk, label %bb61, label %panic, !dbg !55891

bb61:                                             ; preds = %bb58
  %462 = ptrtoint ptr %_15.i.i.i109 to i64, !dbg !55891
  %463 = lshr i64 %462, 3, !dbg !55891
  %464 = add i64 %463, 2147450880, !dbg !55891
  %465 = inttoptr i64 %464 to ptr, !dbg !55891
  %466 = load i8, ptr %465, align 1, !dbg !55891
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %466), !dbg !55891
  %467 = icmp ne i8 %466, 0, !dbg !55891
  br i1 %467, label %470, label %bb61._crit_edge, !dbg !55891, !prof !4285

bb61._crit_edge:                                  ; preds = %bb61
  %468 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 78), align 1, !dbg !55891, !nosanitize !4137
  %469 = add i8 %468, 1, !dbg !55891
  store i8 %469, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 78), align 1, !dbg !55891, !nosanitize !4137
  br label %479, !dbg !55891

470:                                              ; preds = %bb61
  %471 = and i64 %462, 7, !dbg !55891
  %472 = trunc i64 %471 to i8, !dbg !55891
  call void @__sanitizer_cov_trace_cmp1(i8 %472, i8 %466), !dbg !55891
  %473 = icmp sge i8 %472, %466, !dbg !55891
  br i1 %473, label %476, label %._crit_edge455, !dbg !55891

._crit_edge455:                                   ; preds = %470
  %474 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 79), align 1, !dbg !55891, !nosanitize !4137
  %475 = add i8 %474, 1, !dbg !55891
  store i8 %475, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 79), align 1, !dbg !55891, !nosanitize !4137
  br label %479, !dbg !55891

476:                                              ; preds = %470
  %477 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 80), align 1, !dbg !55891, !nosanitize !4137
  %478 = add i8 %477, 1, !dbg !55891
  store i8 %478, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 80), align 1, !dbg !55891, !nosanitize !4137
  call void @__asan_report_load1(i64 %462) #42, !dbg !55891
  unreachable

479:                                              ; preds = %._crit_edge455, %bb61._crit_edge
  %_67 = load i8, ptr %_15.i.i.i109, align 1, !dbg !55891, !noundef !4137
  %n7 = zext i8 %_67 to i64, !dbg !55891
  %480 = add i64 %27, 4, !dbg !55901
  %481 = inttoptr i64 %480 to ptr, !dbg !55901
  store i16 0, ptr %481, align 1, !dbg !55901
  %482 = add i64 %27, 6, !dbg !55901
  %483 = inttoptr i64 %482 to ptr, !dbg !55901
  store i8 0, ptr %483, align 1, !dbg !55901
  %_4.0.i.i123 = add i64 %i.sroa.0.5, %n7, !dbg !55903
  call void @__sanitizer_cov_trace_cmp8(i64 %_4.0.i.i123, i64 %i.sroa.0.5), !dbg !55903
  %_4.1.i.not.i124 = icmp ult i64 %_4.0.i.i123, %i.sroa.0.5, !dbg !55903
  call void @__sanitizer_cov_trace_cmp8(i64 %_4.0.i.i123, i64 %p.1), !dbg !55906
  %_7.not.i.i.i126 = icmp ugt i64 %_4.0.i.i123, %p.1, !dbg !55906
  %484 = or i1 %_4.1.i.not.i124, %_7.not.i.i.i126, !dbg !55906
  %485 = tail call i64 @llvm.umax.i64(i64 %_4.0.i.i123, i64 %i.sroa.0.5), !dbg !55906
  %i.sroa.0.6 = select i1 %_7.not.i.i.i126, i64 %i.sroa.0.5, i64 %485, !dbg !55906
  %486 = or i1 %_4.1.i.not.i124, %_7.not.i.i.i126, !dbg !55906
  %_80.sroa.6.0 = select i1 %486, i64 0, i64 %n7, !dbg !55906
  br i1 %484, label %bb65, label %bb64, !dbg !55907

panic:                                            ; preds = %bb58
  %487 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 81), align 1, !dbg !55891, !nosanitize !4137
  %488 = add i8 %487, 1, !dbg !55891
  store i8 %488, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 81), align 1, !dbg !55891, !nosanitize !4137
  call void @__asan_handle_no_return(), !dbg !55891
; call core::panicking::panic_bounds_check
  tail call void @_RNvNtCshZBO5P2NUJi_4core9panicking18panic_bounds_check(i64 noundef 0, i64 noundef 0, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_d6c74d069b8a320483cb2db8b70fcf58) #43, !dbg !55891
  unreachable, !dbg !55891

bb65:                                             ; preds = %479
  %_79.sroa.6.8.extract.trunc = trunc nuw i64 %_80.sroa.6.0 to i8, !dbg !55908
  %489 = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !55909
  %490 = ptrtoint ptr %489 to i64, !dbg !55909
  %491 = lshr i64 %490, 3, !dbg !55909
  %492 = add i64 %491, 2147450880, !dbg !55909
  %493 = inttoptr i64 %492 to ptr, !dbg !55909
  %494 = load i8, ptr %493, align 1, !dbg !55909
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %494), !dbg !55909
  %495 = icmp ne i8 %494, 0, !dbg !55909
  br i1 %495, label %498, label %bb65._crit_edge, !dbg !55909, !prof !4285

bb65._crit_edge:                                  ; preds = %bb65
  %496 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 82), align 1, !dbg !55909, !nosanitize !4137
  %497 = add i8 %496, 1, !dbg !55909
  store i8 %497, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 82), align 1, !dbg !55909, !nosanitize !4137
  br label %507, !dbg !55909

498:                                              ; preds = %bb65
  %499 = and i64 %490, 7, !dbg !55909
  %500 = trunc i64 %499 to i8, !dbg !55909
  call void @__sanitizer_cov_trace_cmp1(i8 %500, i8 %494), !dbg !55909
  %501 = icmp sge i8 %500, %494, !dbg !55909
  br i1 %501, label %504, label %._crit_edge456, !dbg !55909

._crit_edge456:                                   ; preds = %498
  %502 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 83), align 1, !dbg !55909, !nosanitize !4137
  %503 = add i8 %502, 1, !dbg !55909
  store i8 %503, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 83), align 1, !dbg !55909, !nosanitize !4137
  br label %507, !dbg !55909

504:                                              ; preds = %498
  %505 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 84), align 1, !dbg !55909, !nosanitize !4137
  %506 = add i8 %505, 1, !dbg !55909
  store i8 %506, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 84), align 1, !dbg !55909, !nosanitize !4137
  call void @__asan_report_store1(i64 %490) #42, !dbg !55909
  unreachable

507:                                              ; preds = %._crit_edge456, %bb65._crit_edge
  store i8 %_79.sroa.6.8.extract.trunc, ptr %489, align 8, !dbg !55909, !alias.scope !55912
  %508 = getelementptr inbounds nuw i8, ptr %_0, i64 9, !dbg !55909
  %509 = ptrtoint ptr %508 to i64, !dbg !55909
  %510 = lshr i64 %509, 3, !dbg !55909
  %511 = add i64 %510, 2147450880, !dbg !55909
  %512 = inttoptr i64 %511 to ptr, !dbg !55909
  %513 = load i8, ptr %512, align 1, !dbg !55909
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %513), !dbg !55909
  %514 = icmp ne i8 %513, 0, !dbg !55909
  br i1 %514, label %517, label %._crit_edge457, !dbg !55909, !prof !4285

._crit_edge457:                                   ; preds = %507
  %515 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 85), align 1, !dbg !55909, !nosanitize !4137
  %516 = add i8 %515, 1, !dbg !55909
  store i8 %516, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 85), align 1, !dbg !55909, !nosanitize !4137
  br label %526, !dbg !55909

517:                                              ; preds = %507
  %518 = and i64 %509, 7, !dbg !55909
  %519 = trunc i64 %518 to i8, !dbg !55909
  call void @__sanitizer_cov_trace_cmp1(i8 %519, i8 %513), !dbg !55909
  %520 = icmp sge i8 %519, %513, !dbg !55909
  br i1 %520, label %523, label %._crit_edge458, !dbg !55909

._crit_edge458:                                   ; preds = %517
  %521 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 86), align 1, !dbg !55909, !nosanitize !4137
  %522 = add i8 %521, 1, !dbg !55909
  store i8 %522, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 86), align 1, !dbg !55909, !nosanitize !4137
  br label %526, !dbg !55909

523:                                              ; preds = %517
  %524 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 87), align 1, !dbg !55909, !nosanitize !4137
  %525 = add i8 %524, 1, !dbg !55909
  store i8 %525, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 87), align 1, !dbg !55909, !nosanitize !4137
  call void @__asan_report_store1(i64 %509) #42, !dbg !55909
  unreachable

526:                                              ; preds = %._crit_edge458, %._crit_edge457
  store i8 0, ptr %508, align 1, !dbg !55909, !alias.scope !55912
  %527 = ptrtoint ptr %_0 to i64, !dbg !55909
  %528 = lshr i64 %527, 3, !dbg !55909
  %529 = add i64 %528, 2147450880, !dbg !55909
  %530 = inttoptr i64 %529 to ptr, !dbg !55909
  %531 = load i8, ptr %530, align 1, !dbg !55909
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %531), !dbg !55909
  %532 = icmp ne i8 %531, 0, !dbg !55909
  br i1 %532, label %533, label %536, !dbg !55909

533:                                              ; preds = %526
  %534 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 88), align 1, !dbg !55909, !nosanitize !4137
  %535 = add i8 %534, 1, !dbg !55909
  store i8 %535, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 88), align 1, !dbg !55909, !nosanitize !4137
  call void @__asan_report_store8(i64 %527) #42, !dbg !55909
  unreachable, !dbg !55909

536:                                              ; preds = %526
  %537 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 89), align 1, !dbg !55909, !nosanitize !4137
  %538 = add i8 %537, 1, !dbg !55909
  store i8 %538, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 89), align 1, !dbg !55909, !nosanitize !4137
  store ptr null, ptr %_0, align 8, !dbg !55909, !alias.scope !55912
  %539 = add i64 %27, 4, !dbg !55915
  %540 = inttoptr i64 %539 to ptr, !dbg !55915
  store i16 -1800, ptr %540, align 1, !dbg !55915
  %541 = add i64 %27, 6, !dbg !55915
  %542 = inttoptr i64 %541 to ptr, !dbg !55915
  store i8 -8, ptr %542, align 1, !dbg !55915
  br label %bb89, !dbg !55916

bb64:                                             ; preds = %479
  %_15.i.i.i129 = getelementptr inbounds nuw i8, ptr %p.0, i64 %i.sroa.0.5, !dbg !55906
; call core::str::converts::from_utf8
  call void @_RNvNtNtCshZBO5P2NUJi_4core3str8converts9from_utf8(ptr noalias nofree noundef sret([24 x i8]) align 8 captures(none) dereferenceable(24) %21, ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) %_15.i.i.i129, i64 noundef %_80.sroa.6.0) #35, !dbg !55901
  %_3.i142 = load i64, ptr %21, align 8, !dbg !55918, !range !5011, !alias.scope !55921, !noalias !55924, !noundef !4137
  %543 = trunc nuw i64 %_3.i142 to i1, !dbg !55926
  br i1 %543, label %bb64._RINvMNtCshZBO5P2NUJi_4core6resultINtB3_6ResultReNtNtNtB5_3str5error9Utf8ErrorE7map_errNtNtCsiKgSYIST2hs_15spiral_protocol5error5ErrorNCNvNtB1q_9handshake11parse_hellos_0EB1q_.exit_crit_edge, label %bb3.i143, !dbg !55926

bb64._RINvMNtCshZBO5P2NUJi_4core6resultINtB3_6ResultReNtNtNtB5_3str5error9Utf8ErrorE7map_errNtNtCsiKgSYIST2hs_15spiral_protocol5error5ErrorNCNvNtB1q_9handshake11parse_hellos_0EB1q_.exit_crit_edge: ; preds = %bb64
  %544 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 90), align 1, !dbg !55926, !nosanitize !4137
  %545 = add i8 %544, 1, !dbg !55926
  store i8 %545, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 90), align 1, !dbg !55926, !nosanitize !4137
  br label %_RINvMNtCshZBO5P2NUJi_4core6resultINtB3_6ResultReNtNtNtB5_3str5error9Utf8ErrorE7map_errNtNtCsiKgSYIST2hs_15spiral_protocol5error5ErrorNCNvNtB1q_9handshake11parse_hellos_0EB1q_.exit, !dbg !55926

bb3.i143:                                         ; preds = %bb64
  %546 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 91), align 1, !dbg !55927, !nosanitize !4137
  %547 = add i8 %546, 1, !dbg !55927
  store i8 %547, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 91), align 1, !dbg !55927, !nosanitize !4137
  %548 = getelementptr inbounds nuw i8, ptr %21, i64 8, !dbg !55927
  %t.0.i144 = load ptr, ptr %548, align 8, !dbg !55927, !alias.scope !55921, !noalias !55924, !nonnull !4137, !noundef !4137
  %549 = getelementptr inbounds nuw i8, ptr %21, i64 16, !dbg !55927
  %t.1.i145 = load i64, ptr %549, align 8, !dbg !55927, !alias.scope !55921, !noalias !55924, !noundef !4137
  br label %_RINvMNtCshZBO5P2NUJi_4core6resultINtB3_6ResultReNtNtNtB5_3str5error9Utf8ErrorE7map_errNtNtCsiKgSYIST2hs_15spiral_protocol5error5ErrorNCNvNtB1q_9handshake11parse_hellos_0EB1q_.exit, !dbg !55928

_RINvMNtCshZBO5P2NUJi_4core6resultINtB3_6ResultReNtNtNtB5_3str5error9Utf8ErrorE7map_errNtNtCsiKgSYIST2hs_15spiral_protocol5error5ErrorNCNvNtB1q_9handshake11parse_hellos_0EB1q_.exit: ; preds = %bb64._RINvMNtCshZBO5P2NUJi_4core6resultINtB3_6ResultReNtNtNtB5_3str5error9Utf8ErrorE7map_errNtNtCsiKgSYIST2hs_15spiral_protocol5error5ErrorNCNvNtB1q_9handshake11parse_hellos_0EB1q_.exit_crit_edge, %bb3.i143
  %_77.sroa.0.0 = phi ptr [ %t.0.i144, %bb3.i143 ], [ null, %bb64._RINvMNtCshZBO5P2NUJi_4core6resultINtB3_6ResultReNtNtNtB5_3str5error9Utf8ErrorE7map_errNtNtCsiKgSYIST2hs_15spiral_protocol5error5ErrorNCNvNtB1q_9handshake11parse_hellos_0EB1q_.exit_crit_edge ], !dbg !55929
  %_77.sroa.6.0 = phi i64 [ %t.1.i145, %bb3.i143 ], [ 0, %bb64._RINvMNtCshZBO5P2NUJi_4core6resultINtB3_6ResultReNtNtNtB5_3str5error9Utf8ErrorE7map_errNtNtCsiKgSYIST2hs_15spiral_protocol5error5ErrorNCNvNtB1q_9handshake11parse_hellos_0EB1q_.exit_crit_edge ], !dbg !55929
  %550 = add i64 %27, 4, !dbg !55915
  %551 = inttoptr i64 %550 to ptr, !dbg !55915
  store i16 -1800, ptr %551, align 1, !dbg !55915
  %552 = add i64 %27, 6, !dbg !55915
  %553 = inttoptr i64 %552 to ptr, !dbg !55915
  store i8 -8, ptr %553, align 1, !dbg !55915
  %554 = icmp eq ptr %_77.sroa.0.0, null, !dbg !55930
  %_76.sroa.6.9.insert.insert = and i64 %_77.sroa.6.0, 65535
  %spec.select249 = select i1 %554, i64 %_76.sroa.6.9.insert.insert, i64 %_77.sroa.6.0, !dbg !55932
  %555 = icmp eq ptr %_77.sroa.0.0, null, !dbg !55901
  br i1 %555, label %bb71, label %bb70, !dbg !55901

bb71:                                             ; preds = %_RINvMNtCshZBO5P2NUJi_4core6resultINtB3_6ResultReNtNtNtB5_3str5error9Utf8ErrorE7map_errNtNtCsiKgSYIST2hs_15spiral_protocol5error5ErrorNCNvNtB1q_9handshake11parse_hellos_0EB1q_.exit
  %_76.sroa.6.8.extract.trunc = trunc i64 %spec.select249 to i8, !dbg !55933
  %_76.sroa.6.9.extract.shift = lshr i64 %spec.select249, 8, !dbg !55933
  %_76.sroa.6.9.extract.trunc = trunc i64 %_76.sroa.6.9.extract.shift to i8, !dbg !55933
  %556 = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !55934
  %557 = ptrtoint ptr %556 to i64, !dbg !55934
  %558 = lshr i64 %557, 3, !dbg !55934
  %559 = add i64 %558, 2147450880, !dbg !55934
  %560 = inttoptr i64 %559 to ptr, !dbg !55934
  %561 = load i8, ptr %560, align 1, !dbg !55934
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %561), !dbg !55934
  %562 = icmp ne i8 %561, 0, !dbg !55934
  br i1 %562, label %565, label %bb71._crit_edge, !dbg !55934, !prof !4285

bb71._crit_edge:                                  ; preds = %bb71
  %563 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 92), align 1, !dbg !55934, !nosanitize !4137
  %564 = add i8 %563, 1, !dbg !55934
  store i8 %564, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 92), align 1, !dbg !55934, !nosanitize !4137
  br label %574, !dbg !55934

565:                                              ; preds = %bb71
  %566 = and i64 %557, 7, !dbg !55934
  %567 = trunc i64 %566 to i8, !dbg !55934
  call void @__sanitizer_cov_trace_cmp1(i8 %567, i8 %561), !dbg !55934
  %568 = icmp sge i8 %567, %561, !dbg !55934
  br i1 %568, label %571, label %._crit_edge459, !dbg !55934

._crit_edge459:                                   ; preds = %565
  %569 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 93), align 1, !dbg !55934, !nosanitize !4137
  %570 = add i8 %569, 1, !dbg !55934
  store i8 %570, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 93), align 1, !dbg !55934, !nosanitize !4137
  br label %574, !dbg !55934

571:                                              ; preds = %565
  %572 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 94), align 1, !dbg !55934, !nosanitize !4137
  %573 = add i8 %572, 1, !dbg !55934
  store i8 %573, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 94), align 1, !dbg !55934, !nosanitize !4137
  call void @__asan_report_store1(i64 %557) #42, !dbg !55934
  unreachable

574:                                              ; preds = %._crit_edge459, %bb71._crit_edge
  store i8 %_76.sroa.6.8.extract.trunc, ptr %556, align 8, !dbg !55934, !alias.scope !55937
  %575 = getelementptr inbounds nuw i8, ptr %_0, i64 9, !dbg !55934
  %576 = ptrtoint ptr %575 to i64, !dbg !55934
  %577 = lshr i64 %576, 3, !dbg !55934
  %578 = add i64 %577, 2147450880, !dbg !55934
  %579 = inttoptr i64 %578 to ptr, !dbg !55934
  %580 = load i8, ptr %579, align 1, !dbg !55934
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %580), !dbg !55934
  %581 = icmp ne i8 %580, 0, !dbg !55934
  br i1 %581, label %584, label %._crit_edge460, !dbg !55934, !prof !4285

._crit_edge460:                                   ; preds = %574
  %582 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 95), align 1, !dbg !55934, !nosanitize !4137
  %583 = add i8 %582, 1, !dbg !55934
  store i8 %583, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 95), align 1, !dbg !55934, !nosanitize !4137
  br label %593, !dbg !55934

584:                                              ; preds = %574
  %585 = and i64 %576, 7, !dbg !55934
  %586 = trunc i64 %585 to i8, !dbg !55934
  call void @__sanitizer_cov_trace_cmp1(i8 %586, i8 %580), !dbg !55934
  %587 = icmp sge i8 %586, %580, !dbg !55934
  br i1 %587, label %590, label %._crit_edge461, !dbg !55934

._crit_edge461:                                   ; preds = %584
  %588 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 96), align 1, !dbg !55934, !nosanitize !4137
  %589 = add i8 %588, 1, !dbg !55934
  store i8 %589, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 96), align 1, !dbg !55934, !nosanitize !4137
  br label %593, !dbg !55934

590:                                              ; preds = %584
  %591 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 97), align 1, !dbg !55934, !nosanitize !4137
  %592 = add i8 %591, 1, !dbg !55934
  store i8 %592, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 97), align 1, !dbg !55934, !nosanitize !4137
  call void @__asan_report_store1(i64 %576) #42, !dbg !55934
  unreachable

593:                                              ; preds = %._crit_edge461, %._crit_edge460
  store i8 %_76.sroa.6.9.extract.trunc, ptr %575, align 1, !dbg !55934, !alias.scope !55937
  %594 = ptrtoint ptr %_0 to i64, !dbg !55934
  %595 = lshr i64 %594, 3, !dbg !55934
  %596 = add i64 %595, 2147450880, !dbg !55934
  %597 = inttoptr i64 %596 to ptr, !dbg !55934
  %598 = load i8, ptr %597, align 1, !dbg !55934
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %598), !dbg !55934
  %599 = icmp ne i8 %598, 0, !dbg !55934
  br i1 %599, label %600, label %603, !dbg !55934

600:                                              ; preds = %593
  %601 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 98), align 1, !dbg !55934, !nosanitize !4137
  %602 = add i8 %601, 1, !dbg !55934
  store i8 %602, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 98), align 1, !dbg !55934, !nosanitize !4137
  call void @__asan_report_store8(i64 %594) #42, !dbg !55934
  unreachable, !dbg !55934

603:                                              ; preds = %593
  %604 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 99), align 1, !dbg !55934, !nosanitize !4137
  %605 = add i8 %604, 1, !dbg !55934
  store i8 %605, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 99), align 1, !dbg !55934, !nosanitize !4137
  store ptr null, ptr %_0, align 8, !dbg !55934, !alias.scope !55937
  br label %bb89, !dbg !55916

bb70:                                             ; preds = %_RINvMNtCshZBO5P2NUJi_4core6resultINtB3_6ResultReNtNtNtB5_3str5error9Utf8ErrorE7map_errNtNtCsiKgSYIST2hs_15spiral_protocol5error5ErrorNCNvNtB1q_9handshake11parse_hellos_0EB1q_.exit
  call void @__sanitizer_cov_trace_cmp8(i64 %p.1, i64 %i.sroa.0.6), !dbg !55940
  %_88.not = icmp eq i64 %p.1, %i.sroa.0.6, !dbg !55940
  br i1 %_88.not, label %bb74, label %bb73, !dbg !55940

bb74:                                             ; preds = %bb70
; call spiral_protocol::handshake::validate_identity
  %606 = tail call { i8, i8 } @_RNvNtCsiKgSYIST2hs_15spiral_protocol9handshake17validate_identity(ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) %_55.sroa.0.0, i64 noundef %spec.select243, ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) %_77.sroa.0.0, i64 noundef %spec.select249) #35, !dbg !55942
  %607 = extractvalue { i8, i8 } %606, 0, !dbg !55942
  call void @__sanitizer_cov_trace_const_cmp1(i8 -1, i8 %607), !dbg !55942
  %.not = icmp eq i8 %607, -1, !dbg !55942
  br i1 %.not, label %bb77, label %bb78, !dbg !55942

bb73:                                             ; preds = %bb70
  %608 = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !55943
  %609 = ptrtoint ptr %608 to i64, !dbg !55943
  %610 = lshr i64 %609, 3, !dbg !55943
  %611 = add i64 %610, 2147450880, !dbg !55943
  %612 = inttoptr i64 %611 to ptr, !dbg !55943
  %613 = load i8, ptr %612, align 1, !dbg !55943
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %613), !dbg !55943
  %614 = icmp ne i8 %613, 0, !dbg !55943
  br i1 %614, label %617, label %bb73._crit_edge, !dbg !55943, !prof !4285

bb73._crit_edge:                                  ; preds = %bb73
  %615 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 100), align 1, !dbg !55943, !nosanitize !4137
  %616 = add i8 %615, 1, !dbg !55943
  store i8 %616, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 100), align 1, !dbg !55943, !nosanitize !4137
  br label %626, !dbg !55943

617:                                              ; preds = %bb73
  %618 = and i64 %609, 7, !dbg !55943
  %619 = trunc i64 %618 to i8, !dbg !55943
  call void @__sanitizer_cov_trace_cmp1(i8 %619, i8 %613), !dbg !55943
  %620 = icmp sge i8 %619, %613, !dbg !55943
  br i1 %620, label %623, label %._crit_edge462, !dbg !55943

._crit_edge462:                                   ; preds = %617
  %621 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 101), align 1, !dbg !55943, !nosanitize !4137
  %622 = add i8 %621, 1, !dbg !55943
  store i8 %622, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 101), align 1, !dbg !55943, !nosanitize !4137
  br label %626, !dbg !55943

623:                                              ; preds = %617
  %624 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 102), align 1, !dbg !55943, !nosanitize !4137
  %625 = add i8 %624, 1, !dbg !55943
  store i8 %625, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 102), align 1, !dbg !55943, !nosanitize !4137
  call void @__asan_report_store1(i64 %609) #42, !dbg !55943
  unreachable

626:                                              ; preds = %._crit_edge462, %bb73._crit_edge
  store i8 0, ptr %608, align 8, !dbg !55943
  %627 = ptrtoint ptr %_0 to i64, !dbg !55943
  %628 = lshr i64 %627, 3, !dbg !55943
  %629 = add i64 %628, 2147450880, !dbg !55943
  %630 = inttoptr i64 %629 to ptr, !dbg !55943
  %631 = load i8, ptr %630, align 1, !dbg !55943
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %631), !dbg !55943
  %632 = icmp ne i8 %631, 0, !dbg !55943
  br i1 %632, label %633, label %636, !dbg !55943

633:                                              ; preds = %626
  %634 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 103), align 1, !dbg !55943, !nosanitize !4137
  %635 = add i8 %634, 1, !dbg !55943
  store i8 %635, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 103), align 1, !dbg !55943, !nosanitize !4137
  call void @__asan_report_store8(i64 %627) #42, !dbg !55943
  unreachable, !dbg !55943

636:                                              ; preds = %626
  %637 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 104), align 1, !dbg !55943, !nosanitize !4137
  %638 = add i8 %637, 1, !dbg !55943
  store i8 %638, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 104), align 1, !dbg !55943, !nosanitize !4137
  store ptr null, ptr %_0, align 8, !dbg !55943
  br label %bb89, !dbg !55944

bb78:                                             ; preds = %bb74
  %639 = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !55946
  %640 = ptrtoint ptr %639 to i64, !dbg !55946
  %641 = lshr i64 %640, 3, !dbg !55946
  %642 = add i64 %641, 2147450880, !dbg !55946
  %643 = inttoptr i64 %642 to ptr, !dbg !55946
  %644 = load i8, ptr %643, align 1, !dbg !55946
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %644), !dbg !55946
  %645 = icmp ne i8 %644, 0, !dbg !55946
  br i1 %645, label %648, label %bb78._crit_edge, !dbg !55946, !prof !4285

bb78._crit_edge:                                  ; preds = %bb78
  %646 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 105), align 1, !dbg !55946, !nosanitize !4137
  %647 = add i8 %646, 1, !dbg !55946
  store i8 %647, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 105), align 1, !dbg !55946, !nosanitize !4137
  br label %657, !dbg !55946

648:                                              ; preds = %bb78
  %649 = and i64 %640, 7, !dbg !55946
  %650 = trunc i64 %649 to i8, !dbg !55946
  call void @__sanitizer_cov_trace_cmp1(i8 %650, i8 %644), !dbg !55946
  %651 = icmp sge i8 %650, %644, !dbg !55946
  br i1 %651, label %654, label %._crit_edge463, !dbg !55946

._crit_edge463:                                   ; preds = %648
  %652 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 106), align 1, !dbg !55946, !nosanitize !4137
  %653 = add i8 %652, 1, !dbg !55946
  store i8 %653, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 106), align 1, !dbg !55946, !nosanitize !4137
  br label %657, !dbg !55946

654:                                              ; preds = %648
  %655 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 107), align 1, !dbg !55946, !nosanitize !4137
  %656 = add i8 %655, 1, !dbg !55946
  store i8 %656, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 107), align 1, !dbg !55946, !nosanitize !4137
  call void @__asan_report_store1(i64 %640) #42, !dbg !55946
  unreachable

657:                                              ; preds = %._crit_edge463, %bb78._crit_edge
  store i8 %607, ptr %639, align 8, !dbg !55946, !alias.scope !55949
  %658 = ptrtoint ptr %_0 to i64, !dbg !55946
  %659 = lshr i64 %658, 3, !dbg !55946
  %660 = add i64 %659, 2147450880, !dbg !55946
  %661 = inttoptr i64 %660 to ptr, !dbg !55946
  %662 = load i8, ptr %661, align 1, !dbg !55946
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %662), !dbg !55946
  %663 = icmp ne i8 %662, 0, !dbg !55946
  br i1 %663, label %664, label %667, !dbg !55946

664:                                              ; preds = %657
  %665 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 108), align 1, !dbg !55946, !nosanitize !4137
  %666 = add i8 %665, 1, !dbg !55946
  store i8 %666, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 108), align 1, !dbg !55946, !nosanitize !4137
  call void @__asan_report_store8(i64 %658) #42, !dbg !55946
  unreachable, !dbg !55946

667:                                              ; preds = %657
  %668 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 109), align 1, !dbg !55946, !nosanitize !4137
  %669 = add i8 %668, 1, !dbg !55946
  store i8 %669, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 109), align 1, !dbg !55946, !nosanitize !4137
  store ptr null, ptr %_0, align 8, !dbg !55946, !alias.scope !55949
  br label %bb89, !dbg !55944

bb77:                                             ; preds = %bb74
  %670 = ptrtoint ptr %_0 to i64, !dbg !55952
  %671 = lshr i64 %670, 3, !dbg !55952
  %672 = add i64 %671, 2147450880, !dbg !55952
  %673 = inttoptr i64 %672 to ptr, !dbg !55952
  %674 = load i8, ptr %673, align 1, !dbg !55952
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %674), !dbg !55952
  %675 = icmp ne i8 %674, 0, !dbg !55952
  br i1 %675, label %676, label %679, !dbg !55952

676:                                              ; preds = %bb77
  %677 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 110), align 1, !dbg !55952, !nosanitize !4137
  %678 = add i8 %677, 1, !dbg !55952
  store i8 %678, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 110), align 1, !dbg !55952, !nosanitize !4137
  call void @__asan_report_store8(i64 %670) #42, !dbg !55952
  unreachable, !dbg !55952

679:                                              ; preds = %bb77
  store ptr %_55.sroa.0.0, ptr %_0, align 8, !dbg !55952
  %_94.sroa.4.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !55952
  %680 = ptrtoint ptr %_94.sroa.4.0._0.sroa_idx to i64, !dbg !55952
  %681 = lshr i64 %680, 3, !dbg !55952
  %682 = add i64 %681, 2147450880, !dbg !55952
  %683 = inttoptr i64 %682 to ptr, !dbg !55952
  %684 = load i8, ptr %683, align 1, !dbg !55952
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %684), !dbg !55952
  %685 = icmp ne i8 %684, 0, !dbg !55952
  br i1 %685, label %686, label %689, !dbg !55952

686:                                              ; preds = %679
  %687 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 111), align 1, !dbg !55952, !nosanitize !4137
  %688 = add i8 %687, 1, !dbg !55952
  store i8 %688, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 111), align 1, !dbg !55952, !nosanitize !4137
  call void @__asan_report_store8(i64 %680) #42, !dbg !55952
  unreachable, !dbg !55952

689:                                              ; preds = %679
  store i64 %spec.select243, ptr %_94.sroa.4.0._0.sroa_idx, align 8, !dbg !55952
  %_94.sroa.5.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !55952
  %690 = ptrtoint ptr %_94.sroa.5.0._0.sroa_idx to i64, !dbg !55952
  %691 = lshr i64 %690, 3, !dbg !55952
  %692 = add i64 %691, 2147450880, !dbg !55952
  %693 = inttoptr i64 %692 to ptr, !dbg !55952
  %694 = load i8, ptr %693, align 1, !dbg !55952
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %694), !dbg !55952
  %695 = icmp ne i8 %694, 0, !dbg !55952
  br i1 %695, label %696, label %699, !dbg !55952

696:                                              ; preds = %689
  %697 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 112), align 1, !dbg !55952, !nosanitize !4137
  %698 = add i8 %697, 1, !dbg !55952
  store i8 %698, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 112), align 1, !dbg !55952, !nosanitize !4137
  call void @__asan_report_store8(i64 %690) #42, !dbg !55952
  unreachable, !dbg !55952

699:                                              ; preds = %689
  store ptr %_77.sroa.0.0, ptr %_94.sroa.5.0._0.sroa_idx, align 8, !dbg !55952
  %_94.sroa.6.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 24, !dbg !55952
  %700 = ptrtoint ptr %_94.sroa.6.0._0.sroa_idx to i64, !dbg !55952
  %701 = lshr i64 %700, 3, !dbg !55952
  %702 = add i64 %701, 2147450880, !dbg !55952
  %703 = inttoptr i64 %702 to ptr, !dbg !55952
  %704 = load i8, ptr %703, align 1, !dbg !55952
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %704), !dbg !55952
  %705 = icmp ne i8 %704, 0, !dbg !55952
  br i1 %705, label %706, label %709, !dbg !55952

706:                                              ; preds = %699
  %707 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 113), align 1, !dbg !55952, !nosanitize !4137
  %708 = add i8 %707, 1, !dbg !55952
  store i8 %708, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 113), align 1, !dbg !55952, !nosanitize !4137
  call void @__asan_report_store8(i64 %700) #42, !dbg !55952
  unreachable, !dbg !55952

709:                                              ; preds = %699
  %710 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 114), align 1, !dbg !55952, !nosanitize !4137
  %711 = add i8 %710, 1, !dbg !55952
  store i8 %711, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 114), align 1, !dbg !55952, !nosanitize !4137
  store i64 %spec.select249, ptr %_94.sroa.6.0._0.sroa_idx, align 8, !dbg !55952
  br label %bb89, !dbg !55715

bb13:                                             ; preds = %bb5.i.bb13_crit_edge, %_RNvNvNtCsiKgSYIST2hs_15spiral_protocol9handshake11parse_hello4take.exit.1.bb13_crit_edge
  %_15.sroa.6.1.lcssa = phi i64 [ %_15.sroa.6.1, %bb5.i.bb13_crit_edge ], [ %_16.sroa.6.1.1, %_RNvNvNtCsiKgSYIST2hs_15spiral_protocol9handshake11parse_hello4take.exit.1.bb13_crit_edge ], !dbg !55814
  %_15.sroa.6.8.extract.trunc = trunc i64 %_15.sroa.6.1.lcssa to i8, !dbg !55953
  %_15.sroa.6.9.extract.shift = lshr i64 %_15.sroa.6.1.lcssa, 8, !dbg !55953
  %_15.sroa.6.9.extract.trunc = trunc i64 %_15.sroa.6.9.extract.shift to i8, !dbg !55953
  %712 = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !55954
  %713 = ptrtoint ptr %712 to i64, !dbg !55954
  %714 = lshr i64 %713, 3, !dbg !55954
  %715 = add i64 %714, 2147450880, !dbg !55954
  %716 = inttoptr i64 %715 to ptr, !dbg !55954
  %717 = load i8, ptr %716, align 1, !dbg !55954
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %717), !dbg !55954
  %718 = icmp ne i8 %717, 0, !dbg !55954
  br i1 %718, label %721, label %bb13._crit_edge, !dbg !55954, !prof !4285

bb13._crit_edge:                                  ; preds = %bb13
  %719 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 115), align 1, !dbg !55954, !nosanitize !4137
  %720 = add i8 %719, 1, !dbg !55954
  store i8 %720, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 115), align 1, !dbg !55954, !nosanitize !4137
  br label %730, !dbg !55954

721:                                              ; preds = %bb13
  %722 = and i64 %713, 7, !dbg !55954
  %723 = trunc i64 %722 to i8, !dbg !55954
  call void @__sanitizer_cov_trace_cmp1(i8 %723, i8 %717), !dbg !55954
  %724 = icmp sge i8 %723, %717, !dbg !55954
  br i1 %724, label %727, label %._crit_edge464, !dbg !55954

._crit_edge464:                                   ; preds = %721
  %725 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 116), align 1, !dbg !55954, !nosanitize !4137
  %726 = add i8 %725, 1, !dbg !55954
  store i8 %726, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 116), align 1, !dbg !55954, !nosanitize !4137
  br label %730, !dbg !55954

727:                                              ; preds = %721
  %728 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 117), align 1, !dbg !55954, !nosanitize !4137
  %729 = add i8 %728, 1, !dbg !55954
  store i8 %729, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 117), align 1, !dbg !55954, !nosanitize !4137
  call void @__asan_report_store1(i64 %713) #42, !dbg !55954
  unreachable

730:                                              ; preds = %._crit_edge464, %bb13._crit_edge
  store i8 %_15.sroa.6.8.extract.trunc, ptr %712, align 8, !dbg !55954, !alias.scope !55957
  %731 = getelementptr inbounds nuw i8, ptr %_0, i64 9, !dbg !55954
  %732 = ptrtoint ptr %731 to i64, !dbg !55954
  %733 = lshr i64 %732, 3, !dbg !55954
  %734 = add i64 %733, 2147450880, !dbg !55954
  %735 = inttoptr i64 %734 to ptr, !dbg !55954
  %736 = load i8, ptr %735, align 1, !dbg !55954
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %736), !dbg !55954
  %737 = icmp ne i8 %736, 0, !dbg !55954
  br i1 %737, label %740, label %._crit_edge465, !dbg !55954, !prof !4285

._crit_edge465:                                   ; preds = %730
  %738 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 118), align 1, !dbg !55954, !nosanitize !4137
  %739 = add i8 %738, 1, !dbg !55954
  store i8 %739, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 118), align 1, !dbg !55954, !nosanitize !4137
  br label %749, !dbg !55954

740:                                              ; preds = %730
  %741 = and i64 %732, 7, !dbg !55954
  %742 = trunc i64 %741 to i8, !dbg !55954
  call void @__sanitizer_cov_trace_cmp1(i8 %742, i8 %736), !dbg !55954
  %743 = icmp sge i8 %742, %736, !dbg !55954
  br i1 %743, label %746, label %._crit_edge466, !dbg !55954

._crit_edge466:                                   ; preds = %740
  %744 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 119), align 1, !dbg !55954, !nosanitize !4137
  %745 = add i8 %744, 1, !dbg !55954
  store i8 %745, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 119), align 1, !dbg !55954, !nosanitize !4137
  br label %749, !dbg !55954

746:                                              ; preds = %740
  %747 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 120), align 1, !dbg !55954, !nosanitize !4137
  %748 = add i8 %747, 1, !dbg !55954
  store i8 %748, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 120), align 1, !dbg !55954, !nosanitize !4137
  call void @__asan_report_store1(i64 %732) #42, !dbg !55954
  unreachable

749:                                              ; preds = %._crit_edge466, %._crit_edge465
  store i8 %_15.sroa.6.9.extract.trunc, ptr %731, align 1, !dbg !55954, !alias.scope !55957
  br label %bb86, !dbg !55960

bb12:                                             ; preds = %bb5.i
  call void @__sanitizer_cov_trace_const_cmp8(i64 0, i64 %_15.sroa.6.1), !dbg !55737
  %_22.not = icmp eq i64 %_15.sroa.6.1, 0, !dbg !55737
  br i1 %_22.not, label %bb12.panic24_crit_edge, label %bb15, !dbg !55737

bb12.panic24_crit_edge:                           ; preds = %bb12
  %750 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 121), align 1, !dbg !55737, !nosanitize !4137
  %751 = add i8 %750, 1, !dbg !55737
  store i8 %751, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 121), align 1, !dbg !55737, !nosanitize !4137
  br label %panic24, !dbg !55737

bb15:                                             ; preds = %bb12
  %752 = ptrtoint ptr %_16.sroa.0.0 to i64, !dbg !55737
  %753 = lshr i64 %752, 3, !dbg !55737
  %754 = add i64 %753, 2147450880, !dbg !55737
  %755 = inttoptr i64 %754 to ptr, !dbg !55737
  %756 = load i8, ptr %755, align 1, !dbg !55737
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %756), !dbg !55737
  %757 = icmp ne i8 %756, 0, !dbg !55737
  br i1 %757, label %760, label %bb15._crit_edge, !dbg !55737, !prof !4285

bb15._crit_edge:                                  ; preds = %bb15
  %758 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 122), align 1, !dbg !55737, !nosanitize !4137
  %759 = add i8 %758, 1, !dbg !55737
  store i8 %759, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 122), align 1, !dbg !55737, !nosanitize !4137
  br label %769, !dbg !55737

760:                                              ; preds = %bb15
  %761 = and i64 %752, 7, !dbg !55737
  %762 = trunc i64 %761 to i8, !dbg !55737
  call void @__sanitizer_cov_trace_cmp1(i8 %762, i8 %756), !dbg !55737
  %763 = icmp sge i8 %762, %756, !dbg !55737
  br i1 %763, label %766, label %._crit_edge467, !dbg !55737

._crit_edge467:                                   ; preds = %760
  %764 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 123), align 1, !dbg !55737, !nosanitize !4137
  %765 = add i8 %764, 1, !dbg !55737
  store i8 %765, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 123), align 1, !dbg !55737, !nosanitize !4137
  br label %769, !dbg !55737

766:                                              ; preds = %760
  %767 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 124), align 1, !dbg !55737, !nosanitize !4137
  %768 = add i8 %767, 1, !dbg !55737
  store i8 %768, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 124), align 1, !dbg !55737, !nosanitize !4137
  call void @__asan_report_load1(i64 %752) #42, !dbg !55737
  unreachable

769:                                              ; preds = %._crit_edge467, %bb15._crit_edge
  %_14 = load i8, ptr %_16.sroa.0.0, align 1, !dbg !55737, !noundef !4137
  %770 = zext i8 %_14 to i64, !dbg !55737
  %771 = add i8 %_14, -1, !dbg !55738
  call void @__sanitizer_cov_trace_const_cmp1(i8 8, i8 %771), !dbg !55738
  %spec.select237 = icmp ult i8 %771, 8, !dbg !55738
  br i1 %spec.select237, label %bb20.preheader, label %.bb18_crit_edge468, !dbg !55742

.bb18_crit_edge468:                               ; preds = %769
  %772 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 125), align 1, !dbg !55742, !nosanitize !4137
  %773 = add i8 %772, 1, !dbg !55742
  store i8 %773, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 125), align 1, !dbg !55742, !nosanitize !4137
  br label %bb18, !dbg !55742

bb20.preheader:                                   ; preds = %769
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %_14), !dbg !55743
  %_0.i.i.i162287.not = icmp eq i8 %_14, 0, !dbg !55743
  br i1 %_0.i.i.i162287.not, label %bb20.preheader.bb35_crit_edge, label %bb20.preheader.bb22_crit_edge, !dbg !55750

bb20.preheader.bb22_crit_edge:                    ; preds = %bb20.preheader
  br label %bb22, !dbg !55750

bb20.preheader.bb35_crit_edge:                    ; preds = %bb20.preheader
  %774 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 126), align 1, !dbg !55750, !nosanitize !4137
  %775 = add i8 %774, 1, !dbg !55750
  store i8 %775, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 126), align 1, !dbg !55750, !nosanitize !4137
  br label %bb35, !dbg !55750

panic24:                                          ; preds = %bb12.panic24_crit_edge, %bb12.1.panic24_crit_edge
  call void @__asan_handle_no_return(), !dbg !55737
; call core::panicking::panic_bounds_check
  tail call void @_RNvNtCshZBO5P2NUJi_4core9panicking18panic_bounds_check(i64 noundef 0, i64 noundef 0, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_c3e3cea0368c35de63434fc4b0d26070) #43, !dbg !55737
  unreachable, !dbg !55737

bb18:                                             ; preds = %.bb18_crit_edge468, %.bb18_crit_edge
  %776 = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !55962
  %777 = ptrtoint ptr %776 to i64, !dbg !55962
  %778 = lshr i64 %777, 3, !dbg !55962
  %779 = add i64 %778, 2147450880, !dbg !55962
  %780 = inttoptr i64 %779 to ptr, !dbg !55962
  %781 = load i8, ptr %780, align 1, !dbg !55962
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %781), !dbg !55962
  %782 = icmp ne i8 %781, 0, !dbg !55962
  br i1 %782, label %785, label %bb18._crit_edge, !dbg !55962, !prof !4285

bb18._crit_edge:                                  ; preds = %bb18
  %783 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 127), align 1, !dbg !55962, !nosanitize !4137
  %784 = add i8 %783, 1, !dbg !55962
  store i8 %784, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 127), align 1, !dbg !55962, !nosanitize !4137
  br label %794, !dbg !55962

785:                                              ; preds = %bb18
  %786 = and i64 %777, 7, !dbg !55962
  %787 = trunc i64 %786 to i8, !dbg !55962
  call void @__sanitizer_cov_trace_cmp1(i8 %787, i8 %781), !dbg !55962
  %788 = icmp sge i8 %787, %781, !dbg !55962
  br i1 %788, label %791, label %._crit_edge469, !dbg !55962

._crit_edge469:                                   ; preds = %785
  %789 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 128), align 1, !dbg !55962, !nosanitize !4137
  %790 = add i8 %789, 1, !dbg !55962
  store i8 %790, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 128), align 1, !dbg !55962, !nosanitize !4137
  br label %794, !dbg !55962

791:                                              ; preds = %785
  %792 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 129), align 1, !dbg !55962, !nosanitize !4137
  %793 = add i8 %792, 1, !dbg !55962
  store i8 %793, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 129), align 1, !dbg !55962, !nosanitize !4137
  call void @__asan_report_store1(i64 %777) #42, !dbg !55962
  unreachable

794:                                              ; preds = %._crit_edge469, %bb18._crit_edge
  store i8 0, ptr %776, align 8, !dbg !55962
  br label %bb86, !dbg !55963

bb86:                                             ; preds = %942, %876, %838, %749, %794
  %795 = ptrtoint ptr %_0 to i64, !dbg !55965
  %796 = lshr i64 %795, 3, !dbg !55965
  %797 = add i64 %796, 2147450880, !dbg !55965
  %798 = inttoptr i64 %797 to ptr, !dbg !55965
  %799 = load i8, ptr %798, align 1, !dbg !55965
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %799), !dbg !55965
  %800 = icmp ne i8 %799, 0, !dbg !55965
  br i1 %800, label %801, label %804, !dbg !55965

801:                                              ; preds = %bb86
  %802 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 130), align 1, !dbg !55965, !nosanitize !4137
  %803 = add i8 %802, 1, !dbg !55965
  store i8 %803, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 130), align 1, !dbg !55965, !nosanitize !4137
  call void @__asan_report_store8(i64 %795) #42, !dbg !55965
  unreachable, !dbg !55965

804:                                              ; preds = %bb86
  %805 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 131), align 1, !dbg !55965, !nosanitize !4137
  %806 = add i8 %805, 1, !dbg !55965
  store i8 %806, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 131), align 1, !dbg !55965, !nosanitize !4137
  store ptr null, ptr %_0, align 8, !dbg !55965
  br label %bb89, !dbg !55823

bb22:                                             ; preds = %bb33.bb22_crit_edge, %bb20.preheader.bb22_crit_edge
  %spec.select238294 = phi i64 [ %spec.select238, %bb33.bb22_crit_edge ], [ 1, %bb20.preheader.bb22_crit_edge ]
  %found.sroa.0.0293 = phi i1 [ %921, %bb33.bb22_crit_edge ], [ false, %bb20.preheader.bb22_crit_edge ]
  %last.sroa.0.0292 = phi i16 [ %918, %bb33.bb22_crit_edge ], [ 0, %bb20.preheader.bb22_crit_edge ]
  %i.sroa.0.1291 = phi i64 [ %i.sroa.0.7, %bb33.bb22_crit_edge ], [ %i.sroa.0.2, %bb20.preheader.bb22_crit_edge ]
  %_37.sroa.6.1289 = phi i64 [ %_37.sroa.6.2, %bb33.bb22_crit_edge ], [ undef, %bb20.preheader.bb22_crit_edge ]
  %_4.0.i.i165 = add i64 %i.sroa.0.1291, 2, !dbg !55751
  call void @__sanitizer_cov_trace_const_cmp8(i64 -3, i64 %i.sroa.0.1291), !dbg !55751
  %_4.1.i.not.i166 = icmp ugt i64 %i.sroa.0.1291, -3, !dbg !55751
  br i1 %_4.1.i.not.i166, label %bb6.i176, label %bb5.i167, !dbg !55754

bb6.i176:                                         ; preds = %bb22
  %807 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 132), align 1, !dbg !55771, !nosanitize !4137
  %808 = add i8 %807, 1, !dbg !55771
  store i8 %808, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 132), align 1, !dbg !55771, !nosanitize !4137
  %_37.sroa.6.8.insert.mask210 = and i64 %_37.sroa.6.1289, -256, !dbg !55771
  br label %_RNvNvNtCsiKgSYIST2hs_15spiral_protocol9handshake11parse_hello4take.exit177, !dbg !55774

bb5.i167:                                         ; preds = %bb22
  call void @__sanitizer_cov_trace_cmp8(i64 %_4.0.i.i165, i64 %p.1), !dbg !55707
  %_7.not.i.i.i168 = icmp ugt i64 %_4.0.i.i165, %p.1
  %.n.i169 = select i1 %_7.not.i.i.i168, i64 0, i64 2, !dbg !55755
  br i1 %_7.not.i.i.i168, label %bb12.i172, label %bb11.i170, !dbg !55758

bb12.i172:                                        ; preds = %bb5.i167
  %809 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 133), align 1, !dbg !55764, !nosanitize !4137
  %810 = add i8 %809, 1, !dbg !55764
  store i8 %810, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 133), align 1, !dbg !55764, !nosanitize !4137
  %_37.sroa.6.8.insert.mask = and i64 %_37.sroa.6.1289, -65536, !dbg !55764
  %_37.sroa.6.8.insert.insert = or disjoint i64 %.n.i169, %_37.sroa.6.8.insert.mask, !dbg !55764
  br label %_RNvNvNtCsiKgSYIST2hs_15spiral_protocol9handshake11parse_hello4take.exit177, !dbg !55769

bb11.i170:                                        ; preds = %bb5.i167
  %811 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 134), align 1, !dbg !55759, !nosanitize !4137
  %812 = add i8 %811, 1, !dbg !55759
  store i8 %812, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 134), align 1, !dbg !55759, !nosanitize !4137
  %_15.i.i.i171 = getelementptr inbounds nuw i8, ptr %p.0, i64 %i.sroa.0.1291, !dbg !55759
  br label %_RNvNvNtCsiKgSYIST2hs_15spiral_protocol9handshake11parse_hello4take.exit177, !dbg !55763

_RNvNvNtCsiKgSYIST2hs_15spiral_protocol9handshake11parse_hello4take.exit177: ; preds = %bb6.i176, %bb12.i172, %bb11.i170
  %_37.sroa.6.2 = phi i64 [ %_37.sroa.6.8.insert.mask210, %bb6.i176 ], [ %_37.sroa.6.8.insert.insert, %bb12.i172 ], [ %.n.i169, %bb11.i170 ], !dbg !55776
  %_37.sroa.0.0 = phi ptr [ null, %bb6.i176 ], [ null, %bb12.i172 ], [ %_15.i.i.i171, %bb11.i170 ], !dbg !55776
  %i.sroa.0.7 = phi i64 [ %i.sroa.0.1291, %bb6.i176 ], [ %i.sroa.0.1291, %bb12.i172 ], [ %_4.0.i.i165, %bb11.i170 ], !dbg !55707
  %813 = icmp eq ptr %_37.sroa.0.0, null, !dbg !55777
  %814 = and i64 %_37.sroa.6.2, 65535, !dbg !55780
  %_36.sroa.6.2 = select i1 %813, i64 %814, i64 %_37.sroa.6.2, !dbg !55780
  %815 = icmp eq ptr %_37.sroa.0.0, null, !dbg !55781
  br i1 %815, label %_RNvNvNtCsiKgSYIST2hs_15spiral_protocol9handshake11parse_hello4take.exit177.bb27_crit_edge, label %bb26, !dbg !55781

_RNvNvNtCsiKgSYIST2hs_15spiral_protocol9handshake11parse_hello4take.exit177.bb27_crit_edge: ; preds = %_RNvNvNtCsiKgSYIST2hs_15spiral_protocol9handshake11parse_hello4take.exit177
  %816 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 135), align 1, !dbg !55781, !nosanitize !4137
  %817 = add i8 %816, 1, !dbg !55781
  store i8 %817, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 135), align 1, !dbg !55781, !nosanitize !4137
  br label %bb27, !dbg !55781

bb23:                                             ; preds = %bb33
  br i1 %921, label %bb5, label %bb23.bb35_crit_edge, !dbg !55806

bb23.bb35_crit_edge:                              ; preds = %bb23
  %818 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 136), align 1, !dbg !55806, !nosanitize !4137
  %819 = add i8 %818, 1, !dbg !55806
  store i8 %819, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 136), align 1, !dbg !55806, !nosanitize !4137
  br label %bb35, !dbg !55806

bb35:                                             ; preds = %bb23.bb35_crit_edge, %bb20.preheader.bb35_crit_edge, %bb23.1.bb35_crit_edge, %bb20.preheader.1.bb35_crit_edge
  %820 = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !55966
  %821 = ptrtoint ptr %820 to i64, !dbg !55966
  %822 = lshr i64 %821, 3, !dbg !55966
  %823 = add i64 %822, 2147450880, !dbg !55966
  %824 = inttoptr i64 %823 to ptr, !dbg !55966
  %825 = load i8, ptr %824, align 1, !dbg !55966
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %825), !dbg !55966
  %826 = icmp ne i8 %825, 0, !dbg !55966
  br i1 %826, label %829, label %bb35._crit_edge, !dbg !55966, !prof !4285

bb35._crit_edge:                                  ; preds = %bb35
  %827 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 137), align 1, !dbg !55966, !nosanitize !4137
  %828 = add i8 %827, 1, !dbg !55966
  store i8 %828, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 137), align 1, !dbg !55966, !nosanitize !4137
  br label %838, !dbg !55966

829:                                              ; preds = %bb35
  %830 = and i64 %821, 7, !dbg !55966
  %831 = trunc i64 %830 to i8, !dbg !55966
  call void @__sanitizer_cov_trace_cmp1(i8 %831, i8 %825), !dbg !55966
  %832 = icmp sge i8 %831, %825, !dbg !55966
  br i1 %832, label %835, label %._crit_edge470, !dbg !55966

._crit_edge470:                                   ; preds = %829
  %833 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 138), align 1, !dbg !55966, !nosanitize !4137
  %834 = add i8 %833, 1, !dbg !55966
  store i8 %834, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 138), align 1, !dbg !55966, !nosanitize !4137
  br label %838, !dbg !55966

835:                                              ; preds = %829
  %836 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 139), align 1, !dbg !55966, !nosanitize !4137
  %837 = add i8 %836, 1, !dbg !55966
  store i8 %837, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 139), align 1, !dbg !55966, !nosanitize !4137
  call void @__asan_report_store1(i64 %821) #42, !dbg !55966
  unreachable

838:                                              ; preds = %._crit_edge470, %bb35._crit_edge
  store i8 0, ptr %820, align 8, !dbg !55966
  br label %bb86, !dbg !55967

bb27:                                             ; preds = %_RNvNvNtCsiKgSYIST2hs_15spiral_protocol9handshake11parse_hello4take.exit177.bb27_crit_edge, %_RNvNvNtCsiKgSYIST2hs_15spiral_protocol9handshake11parse_hello4take.exit177.1.bb27_crit_edge
  %_36.sroa.6.2.lcssa = phi i64 [ %_36.sroa.6.2, %_RNvNvNtCsiKgSYIST2hs_15spiral_protocol9handshake11parse_hello4take.exit177.bb27_crit_edge ], [ %_36.sroa.6.2.1, %_RNvNvNtCsiKgSYIST2hs_15spiral_protocol9handshake11parse_hello4take.exit177.1.bb27_crit_edge ], !dbg !55780
  %_36.sroa.6.8.extract.trunc = trunc i64 %_36.sroa.6.2.lcssa to i8, !dbg !55969
  %_36.sroa.6.9.extract.shift = lshr i64 %_36.sroa.6.2.lcssa, 8, !dbg !55969
  %_36.sroa.6.9.extract.trunc = trunc i64 %_36.sroa.6.9.extract.shift to i8, !dbg !55969
  %839 = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !55970
  %840 = ptrtoint ptr %839 to i64, !dbg !55970
  %841 = lshr i64 %840, 3, !dbg !55970
  %842 = add i64 %841, 2147450880, !dbg !55970
  %843 = inttoptr i64 %842 to ptr, !dbg !55970
  %844 = load i8, ptr %843, align 1, !dbg !55970
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %844), !dbg !55970
  %845 = icmp ne i8 %844, 0, !dbg !55970
  br i1 %845, label %848, label %bb27._crit_edge, !dbg !55970, !prof !4285

bb27._crit_edge:                                  ; preds = %bb27
  %846 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 140), align 1, !dbg !55970, !nosanitize !4137
  %847 = add i8 %846, 1, !dbg !55970
  store i8 %847, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 140), align 1, !dbg !55970, !nosanitize !4137
  br label %857, !dbg !55970

848:                                              ; preds = %bb27
  %849 = and i64 %840, 7, !dbg !55970
  %850 = trunc i64 %849 to i8, !dbg !55970
  call void @__sanitizer_cov_trace_cmp1(i8 %850, i8 %844), !dbg !55970
  %851 = icmp sge i8 %850, %844, !dbg !55970
  br i1 %851, label %854, label %._crit_edge471, !dbg !55970

._crit_edge471:                                   ; preds = %848
  %852 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 141), align 1, !dbg !55970, !nosanitize !4137
  %853 = add i8 %852, 1, !dbg !55970
  store i8 %853, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 141), align 1, !dbg !55970, !nosanitize !4137
  br label %857, !dbg !55970

854:                                              ; preds = %848
  %855 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 142), align 1, !dbg !55970, !nosanitize !4137
  %856 = add i8 %855, 1, !dbg !55970
  store i8 %856, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 142), align 1, !dbg !55970, !nosanitize !4137
  call void @__asan_report_store1(i64 %840) #42, !dbg !55970
  unreachable

857:                                              ; preds = %._crit_edge471, %bb27._crit_edge
  store i8 %_36.sroa.6.8.extract.trunc, ptr %839, align 8, !dbg !55970, !alias.scope !55973
  %858 = getelementptr inbounds nuw i8, ptr %_0, i64 9, !dbg !55970
  %859 = ptrtoint ptr %858 to i64, !dbg !55970
  %860 = lshr i64 %859, 3, !dbg !55970
  %861 = add i64 %860, 2147450880, !dbg !55970
  %862 = inttoptr i64 %861 to ptr, !dbg !55970
  %863 = load i8, ptr %862, align 1, !dbg !55970
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %863), !dbg !55970
  %864 = icmp ne i8 %863, 0, !dbg !55970
  br i1 %864, label %867, label %._crit_edge472, !dbg !55970, !prof !4285

._crit_edge472:                                   ; preds = %857
  %865 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 143), align 1, !dbg !55970, !nosanitize !4137
  %866 = add i8 %865, 1, !dbg !55970
  store i8 %866, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 143), align 1, !dbg !55970, !nosanitize !4137
  br label %876, !dbg !55970

867:                                              ; preds = %857
  %868 = and i64 %859, 7, !dbg !55970
  %869 = trunc i64 %868 to i8, !dbg !55970
  call void @__sanitizer_cov_trace_cmp1(i8 %869, i8 %863), !dbg !55970
  %870 = icmp sge i8 %869, %863, !dbg !55970
  br i1 %870, label %873, label %._crit_edge473, !dbg !55970

._crit_edge473:                                   ; preds = %867
  %871 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 144), align 1, !dbg !55970, !nosanitize !4137
  %872 = add i8 %871, 1, !dbg !55970
  store i8 %872, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 144), align 1, !dbg !55970, !nosanitize !4137
  br label %876, !dbg !55970

873:                                              ; preds = %867
  %874 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 145), align 1, !dbg !55970, !nosanitize !4137
  %875 = add i8 %874, 1, !dbg !55970
  store i8 %875, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 145), align 1, !dbg !55970, !nosanitize !4137
  call void @__asan_report_store1(i64 %859) #42, !dbg !55970
  unreachable

876:                                              ; preds = %._crit_edge473, %._crit_edge472
  store i8 %_36.sroa.6.9.extract.trunc, ptr %858, align 1, !dbg !55970, !alias.scope !55973
  br label %bb86, !dbg !55976

bb26:                                             ; preds = %_RNvNvNtCsiKgSYIST2hs_15spiral_protocol9handshake11parse_hello4take.exit177
  call void @__sanitizer_cov_trace_const_cmp8(i64 2, i64 %_36.sroa.6.2), !dbg !55782
  %_4.i.i184.not = icmp eq i64 %_36.sroa.6.2, 2, !dbg !55782
  br i1 %_4.i.i184.not, label %bb1.i.i191, label %bb26.bb2.i_crit_edge, !dbg !55782

bb26.bb2.i_crit_edge:                             ; preds = %bb26
  %877 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 146), align 1, !dbg !55782, !nosanitize !4137
  %878 = add i8 %877, 1, !dbg !55782
  store i8 %878, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 146), align 1, !dbg !55782, !nosanitize !4137
  br label %bb2.i, !dbg !55782

bb1.i.i191:                                       ; preds = %bb26
  %879 = ptrtoint ptr %_37.sroa.0.0 to i64, !dbg !55790
  %880 = add i64 %879, 1, !dbg !55790
  %881 = inttoptr i64 %880 to ptr, !dbg !55790
  %882 = ptrtoint ptr %_37.sroa.0.0 to i64, !dbg !55790
  %883 = lshr i64 %882, 3, !dbg !55790
  %884 = add i64 %883, 2147450880, !dbg !55790
  %885 = inttoptr i64 %884 to ptr, !dbg !55790
  %886 = load i8, ptr %885, align 1, !dbg !55790
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %886), !dbg !55790
  %887 = icmp ne i8 %886, 0, !dbg !55790
  br i1 %887, label %890, label %bb1.i.i191._crit_edge, !dbg !55790, !prof !4285

bb1.i.i191._crit_edge:                            ; preds = %bb1.i.i191
  %888 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 147), align 1, !dbg !55790, !nosanitize !4137
  %889 = add i8 %888, 1, !dbg !55790
  store i8 %889, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 147), align 1, !dbg !55790, !nosanitize !4137
  br label %899, !dbg !55790

890:                                              ; preds = %bb1.i.i191
  %891 = and i64 %882, 7, !dbg !55790
  %892 = trunc i64 %891 to i8, !dbg !55790
  call void @__sanitizer_cov_trace_cmp1(i8 %892, i8 %886), !dbg !55790
  %893 = icmp sge i8 %892, %886, !dbg !55790
  br i1 %893, label %896, label %._crit_edge474, !dbg !55790

._crit_edge474:                                   ; preds = %890
  %894 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 148), align 1, !dbg !55790, !nosanitize !4137
  %895 = add i8 %894, 1, !dbg !55790
  store i8 %895, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 148), align 1, !dbg !55790, !nosanitize !4137
  br label %899, !dbg !55790

896:                                              ; preds = %890
  %897 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 149), align 1, !dbg !55790, !nosanitize !4137
  %898 = add i8 %897, 1, !dbg !55790
  store i8 %898, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 149), align 1, !dbg !55790, !nosanitize !4137
  call void @__asan_report_load_n(i64 %882, i64 2) #42, !dbg !55790
  unreachable

899:                                              ; preds = %._crit_edge474, %bb1.i.i191._crit_edge
  %900 = ptrtoint ptr %881 to i64, !dbg !55790
  %901 = lshr i64 %900, 3, !dbg !55790
  %902 = add i64 %901, 2147450880, !dbg !55790
  %903 = inttoptr i64 %902 to ptr, !dbg !55790
  %904 = load i8, ptr %903, align 1, !dbg !55790
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %904), !dbg !55790
  %905 = icmp ne i8 %904, 0, !dbg !55790
  br i1 %905, label %908, label %._crit_edge475, !dbg !55790, !prof !4285

._crit_edge475:                                   ; preds = %899
  %906 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 150), align 1, !dbg !55790, !nosanitize !4137
  %907 = add i8 %906, 1, !dbg !55790
  store i8 %907, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 150), align 1, !dbg !55790, !nosanitize !4137
  br label %917, !dbg !55790

908:                                              ; preds = %899
  %909 = and i64 %900, 7, !dbg !55790
  %910 = trunc i64 %909 to i8, !dbg !55790
  call void @__sanitizer_cov_trace_cmp1(i8 %910, i8 %904), !dbg !55790
  %911 = icmp sge i8 %910, %904, !dbg !55790
  br i1 %911, label %914, label %._crit_edge476, !dbg !55790

._crit_edge476:                                   ; preds = %908
  %912 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 151), align 1, !dbg !55790, !nosanitize !4137
  %913 = add i8 %912, 1, !dbg !55790
  store i8 %913, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 151), align 1, !dbg !55790, !nosanitize !4137
  br label %917, !dbg !55790

914:                                              ; preds = %908
  %915 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 152), align 1, !dbg !55790, !nosanitize !4137
  %916 = add i8 %915, 1, !dbg !55790
  store i8 %916, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 152), align 1, !dbg !55790, !nosanitize !4137
  call void @__asan_report_load_n(i64 %900, i64 2) #42, !dbg !55790
  unreachable

917:                                              ; preds = %._crit_edge476, %._crit_edge475
  %v.sroa.0.0.copyload.i.i192 = load i16, ptr %_37.sroa.0.0, align 1, !dbg !55790, !alias.scope !55792
  %918 = tail call i16 @llvm.bswap.i16(i16 %v.sroa.0.0.copyload.i.i192), !dbg !55797
  call void @__sanitizer_cov_trace_cmp2(i16 %918, i16 %last.sroa.0.0292), !dbg !55801
  %_42.not = icmp ugt i16 %918, %last.sroa.0.0292, !dbg !55801
  br i1 %_42.not, label %bb33, label %.bb32_crit_edge477, !dbg !55801

.bb32_crit_edge477:                               ; preds = %917
  %919 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 153), align 1, !dbg !55801, !nosanitize !4137
  %920 = add i8 %919, 1, !dbg !55801
  store i8 %920, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 153), align 1, !dbg !55801, !nosanitize !4137
  br label %bb32, !dbg !55801

bb2.i:                                            ; preds = %bb26.bb2.i_crit_edge, %bb26.1.bb2.i_crit_edge
  call void @__asan_handle_no_return(), !dbg !55978
; call core::result::unwrap_failed::<core::array::TryFromSliceError>
  tail call void @_RINvNtCshZBO5P2NUJi_4core6result13unwrap_failedNtNtB4_5array17TryFromSliceErrorECs7jJvS58pafZ_4ring(ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) @alloc_00ae4b301f7fab8ac9617c03fcbd7274, i64 noundef 43, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_6ee38266fea7fbf6f1f069493332811d) #43, !dbg !55978
  unreachable, !dbg !55978

bb33:                                             ; preds = %917
  call void @__sanitizer_cov_trace_const_cmp2(i16 256, i16 %v.sroa.0.0.copyload.i.i192), !dbg !55803
  %_43 = icmp eq i16 %v.sroa.0.0.copyload.i.i192, 256, !dbg !55803
  %921 = or i1 %found.sroa.0.0293, %_43, !dbg !55804
  call void @__sanitizer_cov_trace_cmp8(i64 %spec.select238294, i64 %770), !dbg !55743
  %_0.i.i.i162 = icmp samesign ult i64 %spec.select238294, %770, !dbg !55743
  %_0.i1.i.i = zext i1 %_0.i.i.i162 to i64, !dbg !55805
  %spec.select238 = add nuw i64 %spec.select238294, %_0.i1.i.i, !dbg !55805
  br i1 %_0.i.i.i162, label %bb33.bb22_crit_edge, label %bb23, !dbg !55750

bb33.bb22_crit_edge:                              ; preds = %bb33
  %922 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 154), align 1, !dbg !55750, !nosanitize !4137
  %923 = add i8 %922, 1, !dbg !55750
  store i8 %923, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 154), align 1, !dbg !55750, !nosanitize !4137
  br label %bb22, !dbg !55750

bb32:                                             ; preds = %.bb32_crit_edge477, %.bb32_crit_edge
  %924 = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !55980
  %925 = ptrtoint ptr %924 to i64, !dbg !55980
  %926 = lshr i64 %925, 3, !dbg !55980
  %927 = add i64 %926, 2147450880, !dbg !55980
  %928 = inttoptr i64 %927 to ptr, !dbg !55980
  %929 = load i8, ptr %928, align 1, !dbg !55980
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %929), !dbg !55980
  %930 = icmp ne i8 %929, 0, !dbg !55980
  br i1 %930, label %933, label %bb32._crit_edge, !dbg !55980, !prof !4285

bb32._crit_edge:                                  ; preds = %bb32
  %931 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 155), align 1, !dbg !55980, !nosanitize !4137
  %932 = add i8 %931, 1, !dbg !55980
  store i8 %932, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 155), align 1, !dbg !55980, !nosanitize !4137
  br label %942, !dbg !55980

933:                                              ; preds = %bb32
  %934 = and i64 %925, 7, !dbg !55980
  %935 = trunc i64 %934 to i8, !dbg !55980
  call void @__sanitizer_cov_trace_cmp1(i8 %935, i8 %929), !dbg !55980
  %936 = icmp sge i8 %935, %929, !dbg !55980
  br i1 %936, label %939, label %._crit_edge478, !dbg !55980

._crit_edge478:                                   ; preds = %933
  %937 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 156), align 1, !dbg !55980, !nosanitize !4137
  %938 = add i8 %937, 1, !dbg !55980
  store i8 %938, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 156), align 1, !dbg !55980, !nosanitize !4137
  br label %942, !dbg !55980

939:                                              ; preds = %933
  %940 = load i8, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 157), align 1, !dbg !55980, !nosanitize !4137
  %941 = add i8 %940, 1, !dbg !55980
  store i8 %941, ptr getelementptr ([158 x i8], ptr @__sancov_gen_.2178, i64 0, i64 157), align 1, !dbg !55980, !nosanitize !4137
  call void @__asan_report_store1(i64 %925) #42, !dbg !55980
  unreachable

942:                                              ; preds = %._crit_edge478, %bb32._crit_edge
  store i8 0, ptr %924, align 8, !dbg !55980
  br label %bb86, !dbg !55981
}

; Verified production function: validate_identity
define { i8, i8 } @_RNvNtCsiKgSYIST2hs_15spiral_protocol9handshake17validate_identity(ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) %name.0, i64 noundef %name.1, ptr noalias nofree noundef nonnull readonly captures(address) %service.0, i64 noundef %service.1) unnamed_addr #0 comdat personality ptr @rust_eh_personality !dbg !56034 !guid !56035 {
start:
  %dst.i19.i.i.i = alloca [16 x i8], align 16
  %dst.i10.i.i.i = alloca [16 x i8], align 16
  %dst.i1.i.i.i = alloca [16 x i8], align 16
  %dst.i.i.i.i = alloca [16 x i8], align 16
  %asan_local_stack_base = alloca i64, align 8
  %0 = load i8, ptr @__sancov_gen_.2184, align 1, !dbg !56036, !nosanitize !4137
  %1 = add i8 %0, 1, !dbg !56036
  store i8 %1, ptr @__sancov_gen_.2184, align 1, !dbg !56036, !nosanitize !4137
  %2 = load i32, ptr @__asan_option_detect_stack_use_after_return, align 4
  call void @__sanitizer_cov_trace_const_cmp4(i32 0, i32 %2), !dbg !56037
  %3 = icmp ne i32 %2, 0
  br i1 %3, label %6, label %start._crit_edge

start._crit_edge:                                 ; preds = %start
  %4 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 1), align 1, !dbg !56037, !nosanitize !4137
  %5 = add i8 %4, 1, !dbg !56037
  store i8 %5, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 1), align 1, !dbg !56037, !nosanitize !4137
  br label %10

6:                                                ; preds = %start
  %7 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 2), align 1, !dbg !56037, !nosanitize !4137
  %8 = add i8 %7, 1, !dbg !56037
  store i8 %8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 2), align 1, !dbg !56037, !nosanitize !4137
  %9 = call i64 @__asan_stack_malloc_1(i64 96)
  br label %10

10:                                               ; preds = %start._crit_edge, %6
  %11 = phi i64 [ 0, %start._crit_edge ], [ %9, %6 ]
  %12 = inttoptr i64 %11 to ptr
  call void @__sanitizer_cov_trace_const_cmp8(i64 0, i64 %11), !dbg !56037
  %13 = icmp eq i64 %11, 0
  br i1 %13, label %16, label %._crit_edge

._crit_edge:                                      ; preds = %10
  %14 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 3), align 1, !dbg !56037, !nosanitize !4137
  %15 = add i8 %14, 1, !dbg !56037
  store i8 %15, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 3), align 1, !dbg !56037, !nosanitize !4137
  br label %19

16:                                               ; preds = %10
  %17 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 4), align 1, !dbg !56037, !nosanitize !4137
  %18 = add i8 %17, 1, !dbg !56037
  store i8 %18, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 4), align 1, !dbg !56037, !nosanitize !4137
  %MyAlloca = alloca i8, i64 96, align 32
  br label %19

19:                                               ; preds = %._crit_edge, %16
  %20 = phi ptr [ %12, %._crit_edge ], [ %MyAlloca, %16 ]
  store ptr %20, ptr %asan_local_stack_base, align 8
  %21 = getelementptr i8, ptr %20, i64 32
  store i64 1102416563, ptr %20, align 8
  %22 = getelementptr i8, ptr %20, i64 8
  store i64 ptrtoint (ptr @___asan_gen_stack.250 to i64), ptr %22, align 8
  %23 = getelementptr i8, ptr %20, i64 16
  store i64 ptrtoint (ptr @_RNvNtCsiKgSYIST2hs_15spiral_protocol9handshake17validate_identity to i64), ptr %23, align 8
  %24 = ptrtoint ptr %20 to i64
  %25 = lshr i64 %24, 3
  %26 = add i64 %25, 2147450880
  %27 = add i64 %26, 0
  %28 = inttoptr i64 %27 to ptr
  store i64 -866669180174077455, ptr %28, align 1
  %29 = add i64 %26, 8
  %30 = inttoptr i64 %29 to ptr
  store i32 -202116109, ptr %30, align 1
  %31 = add i64 %name.1, -254, !dbg !56038
  call void @__sanitizer_cov_trace_const_cmp8(i64 -253, i64 %31), !dbg !56038
  %or.cond = icmp ult i64 %31, -253, !dbg !56038
  br i1 %or.cond, label %.bb32_crit_edge, label %bb5, !dbg !56038

.bb32_crit_edge:                                  ; preds = %19
  %32 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 5), align 1, !dbg !56038, !nosanitize !4137
  %33 = add i8 %32, 1, !dbg !56038
  store i8 %33, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 5), align 1, !dbg !56038, !nosanitize !4137
  br label %bb32, !dbg !56038

bb5:                                              ; preds = %19
  tail call void @llvm.experimental.noalias.scope.decl(metadata !56040), !dbg !56043
  tail call void @llvm.experimental.noalias.scope.decl(metadata !56044), !dbg !56047
  call void @__sanitizer_cov_trace_const_cmp8(i64 64, i64 %name.1), !dbg !56058
  %_2.i.i = icmp samesign ult i64 %name.1, 64, !dbg !56058
  br i1 %_2.i.i, label %bb1.i.i, label %bb7.i.i, !dbg !56058

bb7.i.i:                                          ; preds = %bb5
  tail call void @llvm.experimental.noalias.scope.decl(metadata !56063), !dbg !56066
  %new_len2.i.i.i.i = and i64 %name.1, 192, !dbg !56067
  %data.i.i.i.i.i = getelementptr inbounds nuw i8, ptr %name.0, i64 %new_len2.i.i.i.i, !dbg !56081
  %len.i.i.i.i.i = and i64 %name.1, 63, !dbg !56091
  %_7.i6.i.i.i.i.i = ptrtoint ptr %dst.i.i.i.i to i64
  %_7.i6.i.i3.i.i.i = ptrtoint ptr %dst.i1.i.i.i to i64
  %_7.i6.i.i12.i.i.i = ptrtoint ptr %dst.i10.i.i.i to i64
  %_7.i6.i.i21.i.i.i = ptrtoint ptr %dst.i19.i.i.i to i64
  br label %bb16.i.i.i, !dbg !56092

bb2.i.i.i:                                        ; preds = %_RNvNtNtNtCshZBO5P2NUJi_4core9core_arch3x864sse215__mm_loadu_si128.exit27.i.i.i
  %_50.i.i.i = getelementptr inbounds nuw i8, ptr %iter.sroa.0.034.i.i.i, i64 64, !dbg !56099
  %_41.i.i.i = icmp eq ptr %_50.i.i.i, %data.i.i.i.i.i, !dbg !56102
  br i1 %_41.i.i.i, label %bb15.i.i.i, label %bb2.i.i.i.bb16.i.i.i_crit_edge, !dbg !56092

bb2.i.i.i.bb16.i.i.i_crit_edge:                   ; preds = %bb2.i.i.i
  %34 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 6), align 1, !dbg !56092, !nosanitize !4137
  %35 = add i8 %34, 1, !dbg !56092
  store i8 %35, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 6), align 1, !dbg !56092, !nosanitize !4137
  br label %bb16.i.i.i, !dbg !56092

bb16.i.i.i:                                       ; preds = %bb2.i.i.i.bb16.i.i.i_crit_edge, %bb7.i.i
  %iter.sroa.0.034.i.i.i = phi ptr [ %name.0, %bb7.i.i ], [ %_50.i.i.i, %bb2.i.i.i.bb16.i.i.i_crit_edge ]
  call void @llvm.lifetime.start.p0(ptr nonnull %dst.i.i.i.i), !dbg !56105, !noalias !56109
  store <2 x i64> zeroinitializer, ptr %dst.i.i.i.i, align 16, !dbg !56110, !noalias !56109
  %_7.i.i.i.i.i.i = ptrtoint ptr %iter.sroa.0.034.i.i.i to i64, !dbg !56112
  %_21.i.i.i.i.i.i = icmp ult ptr %iter.sroa.0.034.i.i.i, %dst.i.i.i.i, !dbg !56120
  %36 = sub i64 %_7.i6.i.i.i.i.i, %_7.i.i.i.i.i.i, !dbg !56120
  %37 = sub i64 %_7.i.i.i.i.i.i, %_7.i6.i.i.i.i.i, !dbg !56120
  %diff.sroa.0.0.i.i.i.i.i.i = select i1 %_21.i.i.i.i.i.i, i64 %36, i64 %37, !dbg !56120
  call void @__sanitizer_cov_trace_const_cmp8(i64 16, i64 %diff.sroa.0.0.i.i.i.i.i.i), !dbg !56124
  %_0.i11.not.i.i.i.i.i = icmp ult i64 %diff.sroa.0.0.i.i.i.i.i.i, 16, !dbg !56124
  br i1 %_0.i11.not.i.i.i.i.i, label %bb9.i.i.i.i.i, label %_RNvNtNtNtCshZBO5P2NUJi_4core9core_arch3x864sse215__mm_loadu_si128.exit.i.i.i, !dbg !56125, !prof !4511

bb9.i.i.i.i.i:                                    ; preds = %bb16.i.i.i
  %38 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 7), align 1, !dbg !56126, !nosanitize !4137
  %39 = add i8 %38, 1, !dbg !56126
  store i8 %39, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 7), align 1, !dbg !56126, !nosanitize !4137
  call void @__asan_handle_no_return(), !dbg !56126
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCshZBO5P2NUJi_4core9panicking18panic_nounwind_fmt(ptr noundef nonnull @alloc_bd3468a7b96187f70c1ce98a3e7a63bf, ptr noundef nonnull inttoptr (i64 567 to ptr), i1 noundef zeroext false, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_3491298c4f655629580c883b9f38e7e3) #43, !dbg !56126
  unreachable, !dbg !56126

_RNvNtNtNtCshZBO5P2NUJi_4core9core_arch3x864sse215__mm_loadu_si128.exit.i.i.i: ; preds = %bb16.i.i.i
  %40 = call ptr @__asan_memcpy(ptr %dst.i.i.i.i, ptr %iter.sroa.0.034.i.i.i, i64 16), !dbg !56127
  %_0.i.i.i.i = load <2 x i64>, ptr %dst.i.i.i.i, align 16, !dbg !56128, !noalias !56109
  call void @llvm.lifetime.end.p0(ptr nonnull %dst.i.i.i.i), !dbg !56129, !noalias !56109
  %_16.i.i.i = getelementptr inbounds nuw i8, ptr %iter.sroa.0.034.i.i.i, i64 16, !dbg !56130
  call void @llvm.lifetime.start.p0(ptr nonnull %dst.i1.i.i.i), !dbg !56134, !noalias !56109
  store <2 x i64> zeroinitializer, ptr %dst.i1.i.i.i, align 16, !dbg !56136, !noalias !56109
  %_7.i.i.i2.i.i.i = ptrtoint ptr %_16.i.i.i to i64, !dbg !56138
  %_21.i.i.i4.i.i.i = icmp ult ptr %_16.i.i.i, %dst.i1.i.i.i, !dbg !56146
  %41 = sub i64 %_7.i6.i.i3.i.i.i, %_7.i.i.i2.i.i.i, !dbg !56146
  %42 = sub i64 %_7.i.i.i2.i.i.i, %_7.i6.i.i3.i.i.i, !dbg !56146
  %diff.sroa.0.0.i.i.i5.i.i.i = select i1 %_21.i.i.i4.i.i.i, i64 %41, i64 %42, !dbg !56146
  call void @__sanitizer_cov_trace_const_cmp8(i64 16, i64 %diff.sroa.0.0.i.i.i5.i.i.i), !dbg !56150
  %_0.i11.not.i.i6.i.i.i = icmp ult i64 %diff.sroa.0.0.i.i.i5.i.i.i, 16, !dbg !56150
  br i1 %_0.i11.not.i.i6.i.i.i, label %bb9.i.i8.i.i.i, label %_RNvNtNtNtCshZBO5P2NUJi_4core9core_arch3x864sse215__mm_loadu_si128.exit9.i.i.i, !dbg !56151, !prof !4511

bb9.i.i8.i.i.i:                                   ; preds = %_RNvNtNtNtCshZBO5P2NUJi_4core9core_arch3x864sse215__mm_loadu_si128.exit.i.i.i
  %43 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 8), align 1, !dbg !56152, !nosanitize !4137
  %44 = add i8 %43, 1, !dbg !56152
  store i8 %44, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 8), align 1, !dbg !56152, !nosanitize !4137
  call void @__asan_handle_no_return(), !dbg !56152
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCshZBO5P2NUJi_4core9panicking18panic_nounwind_fmt(ptr noundef nonnull @alloc_bd3468a7b96187f70c1ce98a3e7a63bf, ptr noundef nonnull inttoptr (i64 567 to ptr), i1 noundef zeroext false, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_3491298c4f655629580c883b9f38e7e3) #43, !dbg !56152
  unreachable, !dbg !56152

_RNvNtNtNtCshZBO5P2NUJi_4core9core_arch3x864sse215__mm_loadu_si128.exit9.i.i.i: ; preds = %_RNvNtNtNtCshZBO5P2NUJi_4core9core_arch3x864sse215__mm_loadu_si128.exit.i.i.i
  %45 = call ptr @__asan_memcpy(ptr %dst.i1.i.i.i, ptr %_16.i.i.i, i64 16), !dbg !56153
  %_0.i7.i.i.i = load <2 x i64>, ptr %dst.i1.i.i.i, align 16, !dbg !56154, !noalias !56109
  call void @llvm.lifetime.end.p0(ptr nonnull %dst.i1.i.i.i), !dbg !56155, !noalias !56109
  %_19.i.i.i = getelementptr inbounds nuw i8, ptr %iter.sroa.0.034.i.i.i, i64 32, !dbg !56156
  call void @llvm.lifetime.start.p0(ptr nonnull %dst.i10.i.i.i), !dbg !56159, !noalias !56109
  store <2 x i64> zeroinitializer, ptr %dst.i10.i.i.i, align 16, !dbg !56161, !noalias !56109
  %_7.i.i.i11.i.i.i = ptrtoint ptr %_19.i.i.i to i64, !dbg !56163
  %_21.i.i.i13.i.i.i = icmp ult ptr %_19.i.i.i, %dst.i10.i.i.i, !dbg !56171
  %46 = sub i64 %_7.i6.i.i12.i.i.i, %_7.i.i.i11.i.i.i, !dbg !56171
  %47 = sub i64 %_7.i.i.i11.i.i.i, %_7.i6.i.i12.i.i.i, !dbg !56171
  %diff.sroa.0.0.i.i.i14.i.i.i = select i1 %_21.i.i.i13.i.i.i, i64 %46, i64 %47, !dbg !56171
  call void @__sanitizer_cov_trace_const_cmp8(i64 16, i64 %diff.sroa.0.0.i.i.i14.i.i.i), !dbg !56175
  %_0.i11.not.i.i15.i.i.i = icmp ult i64 %diff.sroa.0.0.i.i.i14.i.i.i, 16, !dbg !56175
  br i1 %_0.i11.not.i.i15.i.i.i, label %bb9.i.i17.i.i.i, label %_RNvNtNtNtCshZBO5P2NUJi_4core9core_arch3x864sse215__mm_loadu_si128.exit18.i.i.i, !dbg !56176, !prof !4511

bb9.i.i17.i.i.i:                                  ; preds = %_RNvNtNtNtCshZBO5P2NUJi_4core9core_arch3x864sse215__mm_loadu_si128.exit9.i.i.i
  %48 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 9), align 1, !dbg !56177, !nosanitize !4137
  %49 = add i8 %48, 1, !dbg !56177
  store i8 %49, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 9), align 1, !dbg !56177, !nosanitize !4137
  call void @__asan_handle_no_return(), !dbg !56177
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCshZBO5P2NUJi_4core9panicking18panic_nounwind_fmt(ptr noundef nonnull @alloc_bd3468a7b96187f70c1ce98a3e7a63bf, ptr noundef nonnull inttoptr (i64 567 to ptr), i1 noundef zeroext false, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_3491298c4f655629580c883b9f38e7e3) #43, !dbg !56177
  unreachable, !dbg !56177

_RNvNtNtNtCshZBO5P2NUJi_4core9core_arch3x864sse215__mm_loadu_si128.exit18.i.i.i: ; preds = %_RNvNtNtNtCshZBO5P2NUJi_4core9core_arch3x864sse215__mm_loadu_si128.exit9.i.i.i
  %50 = call ptr @__asan_memcpy(ptr %dst.i10.i.i.i, ptr %_19.i.i.i, i64 16), !dbg !56178
  %_0.i16.i.i.i = load <2 x i64>, ptr %dst.i10.i.i.i, align 16, !dbg !56179, !noalias !56109
  call void @llvm.lifetime.end.p0(ptr nonnull %dst.i10.i.i.i), !dbg !56180, !noalias !56109
  %_22.i.i.i = getelementptr inbounds nuw i8, ptr %iter.sroa.0.034.i.i.i, i64 48, !dbg !56181
  call void @llvm.lifetime.start.p0(ptr nonnull %dst.i19.i.i.i), !dbg !56184, !noalias !56109
  store <2 x i64> zeroinitializer, ptr %dst.i19.i.i.i, align 16, !dbg !56186, !noalias !56109
  %_7.i.i.i20.i.i.i = ptrtoint ptr %_22.i.i.i to i64, !dbg !56188
  %_21.i.i.i22.i.i.i = icmp ult ptr %_22.i.i.i, %dst.i19.i.i.i, !dbg !56196
  %51 = sub i64 %_7.i6.i.i21.i.i.i, %_7.i.i.i20.i.i.i, !dbg !56196
  %52 = sub i64 %_7.i.i.i20.i.i.i, %_7.i6.i.i21.i.i.i, !dbg !56196
  %diff.sroa.0.0.i.i.i23.i.i.i = select i1 %_21.i.i.i22.i.i.i, i64 %51, i64 %52, !dbg !56196
  call void @__sanitizer_cov_trace_const_cmp8(i64 16, i64 %diff.sroa.0.0.i.i.i23.i.i.i), !dbg !56200
  %_0.i11.not.i.i24.i.i.i = icmp ult i64 %diff.sroa.0.0.i.i.i23.i.i.i, 16, !dbg !56200
  br i1 %_0.i11.not.i.i24.i.i.i, label %bb9.i.i26.i.i.i, label %_RNvNtNtNtCshZBO5P2NUJi_4core9core_arch3x864sse215__mm_loadu_si128.exit27.i.i.i, !dbg !56201, !prof !4511

bb9.i.i26.i.i.i:                                  ; preds = %_RNvNtNtNtCshZBO5P2NUJi_4core9core_arch3x864sse215__mm_loadu_si128.exit18.i.i.i
  %53 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 10), align 1, !dbg !56202, !nosanitize !4137
  %54 = add i8 %53, 1, !dbg !56202
  store i8 %54, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 10), align 1, !dbg !56202, !nosanitize !4137
  call void @__asan_handle_no_return(), !dbg !56202
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCshZBO5P2NUJi_4core9panicking18panic_nounwind_fmt(ptr noundef nonnull @alloc_bd3468a7b96187f70c1ce98a3e7a63bf, ptr noundef nonnull inttoptr (i64 567 to ptr), i1 noundef zeroext false, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_3491298c4f655629580c883b9f38e7e3) #43, !dbg !56202
  unreachable, !dbg !56202

_RNvNtNtNtCshZBO5P2NUJi_4core9core_arch3x864sse215__mm_loadu_si128.exit27.i.i.i: ; preds = %_RNvNtNtNtCshZBO5P2NUJi_4core9core_arch3x864sse215__mm_loadu_si128.exit18.i.i.i
  %55 = call ptr @__asan_memcpy(ptr %dst.i19.i.i.i, ptr %_22.i.i.i, i64 16), !dbg !56203
  %_0.i25.i.i.i = load <2 x i64>, ptr %dst.i19.i.i.i, align 16, !dbg !56204, !noalias !56109
  call void @llvm.lifetime.end.p0(ptr nonnull %dst.i19.i.i.i), !dbg !56205, !noalias !56109
  %_0.i29.i.i.i = or <2 x i64> %_0.i7.i.i.i, %_0.i.i.i.i, !dbg !56206
  %_0.i28.i.i.i = or <2 x i64> %_0.i29.i.i.i, %_0.i16.i.i.i, !dbg !56209
  %_0.i30.i.i.i = or <2 x i64> %_0.i28.i.i.i, %_0.i25.i.i.i, !dbg !56211
  %_0.i.i.i.i.i = bitcast <2 x i64> %_0.i30.i.i.i to <16 x i8>, !dbg !56213
  %56 = icmp slt <16 x i8> %_0.i.i.i.i.i, zeroinitializer, !dbg !56218
  %_5.i.i.i.i = bitcast <16 x i1> %56 to i16, !dbg !56218
  call void @__sanitizer_cov_trace_const_cmp2(i16 0, i16 %_5.i.i.i.i), !dbg !56219
  %57 = icmp eq i16 %_5.i.i.i.i, 0, !dbg !56219
  br i1 %57, label %bb2.i.i.i, label %_RNvNtNtNtCshZBO5P2NUJi_4core9core_arch3x864sse215__mm_loadu_si128.exit27.i.i.i.bb32_crit_edge, !dbg !56219

_RNvNtNtNtCshZBO5P2NUJi_4core9core_arch3x864sse215__mm_loadu_si128.exit27.i.i.i.bb32_crit_edge: ; preds = %_RNvNtNtNtCshZBO5P2NUJi_4core9core_arch3x864sse215__mm_loadu_si128.exit27.i.i.i
  %58 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 11), align 1, !dbg !56219, !nosanitize !4137
  %59 = add i8 %58, 1, !dbg !56219
  store i8 %59, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 11), align 1, !dbg !56219, !nosanitize !4137
  br label %bb32, !dbg !56219

bb15.i.i.i:                                       ; preds = %bb2.i.i.i
  %_57.i.i.i = getelementptr inbounds nuw i8, ptr %data.i.i.i.i.i, i64 %len.i.i.i.i.i, !dbg !56221
  call void @__sanitizer_cov_trace_const_cmp8(i64 0, i64 %len.i.i.i.i.i), !dbg !56232
  %_12.i.i.i.i99 = icmp samesign eq i64 %len.i.i.i.i.i, 0, !dbg !56232
  br i1 %_12.i.i.i.i99, label %bb15.i.i.i.bb1.i.i1.preheader_crit_edge, label %bb15.i.i.i.bb13.i.i.i.i_crit_edge, !dbg !56242

bb15.i.i.i.bb13.i.i.i.i_crit_edge:                ; preds = %bb15.i.i.i
  br label %bb13.i.i.i.i, !dbg !56242

bb15.i.i.i.bb1.i.i1.preheader_crit_edge:          ; preds = %bb15.i.i.i
  %60 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 12), align 1, !dbg !56242, !nosanitize !4137
  %61 = add i8 %60, 1, !dbg !56242
  store i8 %61, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 12), align 1, !dbg !56242, !nosanitize !4137
  br label %bb1.i.i1.preheader, !dbg !56242

bb1.i.i.i.i:                                      ; preds = %83
  %_22.i.i.i.i = getelementptr inbounds nuw i8, ptr %_221.i.i.i.i100, i64 1, !dbg !56243
  %_12.i.i.i.i = icmp eq ptr %_22.i.i.i.i, %_57.i.i.i, !dbg !56232
  br i1 %_12.i.i.i.i, label %bb1.i.i.i.i.bb1.i.i1.preheader_crit_edge, label %bb1.i.i.i.i.bb13.i.i.i.i_crit_edge, !dbg !56242

bb1.i.i.i.i.bb13.i.i.i.i_crit_edge:               ; preds = %bb1.i.i.i.i
  %62 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 13), align 1, !dbg !56242, !nosanitize !4137
  %63 = add i8 %62, 1, !dbg !56242
  store i8 %63, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 13), align 1, !dbg !56242, !nosanitize !4137
  br label %bb13.i.i.i.i, !dbg !56242

bb1.i.i.i.i.bb1.i.i1.preheader_crit_edge:         ; preds = %bb1.i.i.i.i
  %64 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 14), align 1, !dbg !56242, !nosanitize !4137
  %65 = add i8 %64, 1, !dbg !56242
  store i8 %65, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 14), align 1, !dbg !56242, !nosanitize !4137
  br label %bb1.i.i1.preheader, !dbg !56242

bb13.i.i.i.i:                                     ; preds = %bb1.i.i.i.i.bb13.i.i.i.i_crit_edge, %bb15.i.i.i.bb13.i.i.i.i_crit_edge
  %_221.i.i.i.i100 = phi ptr [ %_22.i.i.i.i, %bb1.i.i.i.i.bb13.i.i.i.i_crit_edge ], [ %data.i.i.i.i.i, %bb15.i.i.i.bb13.i.i.i.i_crit_edge ]
  %66 = ptrtoint ptr %_221.i.i.i.i100 to i64, !dbg !56246
  %67 = lshr i64 %66, 3, !dbg !56246
  %68 = add i64 %67, 2147450880, !dbg !56246
  %69 = inttoptr i64 %68 to ptr, !dbg !56246
  %70 = load i8, ptr %69, align 1, !dbg !56246
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %70), !dbg !56246
  %71 = icmp ne i8 %70, 0, !dbg !56246
  br i1 %71, label %74, label %bb13.i.i.i.i._crit_edge, !dbg !56246, !prof !4285

bb13.i.i.i.i._crit_edge:                          ; preds = %bb13.i.i.i.i
  %72 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 15), align 1, !dbg !56246, !nosanitize !4137
  %73 = add i8 %72, 1, !dbg !56246
  store i8 %73, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 15), align 1, !dbg !56246, !nosanitize !4137
  br label %83, !dbg !56246

74:                                               ; preds = %bb13.i.i.i.i
  %75 = and i64 %66, 7, !dbg !56246
  %76 = trunc i64 %75 to i8, !dbg !56246
  call void @__sanitizer_cov_trace_cmp1(i8 %76, i8 %70), !dbg !56246
  %77 = icmp sge i8 %76, %70, !dbg !56246
  br i1 %77, label %80, label %._crit_edge119, !dbg !56246

._crit_edge119:                                   ; preds = %74
  %78 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 16), align 1, !dbg !56246, !nosanitize !4137
  %79 = add i8 %78, 1, !dbg !56246
  store i8 %79, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 16), align 1, !dbg !56246, !nosanitize !4137
  br label %83, !dbg !56246

80:                                               ; preds = %74
  %81 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 17), align 1, !dbg !56246, !nosanitize !4137
  %82 = add i8 %81, 1, !dbg !56246
  store i8 %82, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 17), align 1, !dbg !56246, !nosanitize !4137
  call void @__asan_report_load1(i64 %66) #42, !dbg !56246
  unreachable

83:                                               ; preds = %._crit_edge119, %bb13.i.i.i.i._crit_edge
  %_3.i.i.i.i.i = load i8, ptr %_221.i.i.i.i100, align 1, !dbg !56246, !alias.scope !56252, !noalias !56255, !noundef !4137
  call void @__sanitizer_cov_trace_const_cmp1(i8 -1, i8 %_3.i.i.i.i.i), !dbg !56246
  %_0.i.i31.i.i.i = icmp sgt i8 %_3.i.i.i.i.i, -1, !dbg !56246
  br i1 %_0.i.i31.i.i.i, label %bb1.i.i.i.i, label %.bb32_crit_edge120, !dbg !56258

.bb32_crit_edge120:                               ; preds = %83
  %84 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 18), align 1, !dbg !56258, !nosanitize !4137
  %85 = add i8 %84, 1, !dbg !56258
  store i8 %85, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 18), align 1, !dbg !56258, !nosanitize !4137
  br label %bb32, !dbg !56258

bb1.i.i:                                          ; preds = %bb5
  %new_len2.i.i.i = and i64 %name.1, 56, !dbg !56259
  %data.i.i.i.i = getelementptr inbounds nuw i8, ptr %name.0, i64 %new_len2.i.i.i, !dbg !56271
  %len.i.i.i.i = and i64 %name.1, 7, !dbg !56277
  call void @__sanitizer_cov_trace_const_cmp8(i64 0, i64 %new_len2.i.i.i), !dbg !56278
  %_297.i.i = icmp samesign eq i64 %new_len2.i.i.i, 0, !dbg !56278
  br i1 %_297.i.i, label %bb1.i.i.bb10.i.i_crit_edge, label %bb1.i.i.bb11.i.i_crit_edge, !dbg !56287

bb1.i.i.bb11.i.i_crit_edge:                       ; preds = %bb1.i.i
  br label %bb11.i.i, !dbg !56287

bb1.i.i.bb10.i.i_crit_edge:                       ; preds = %bb1.i.i
  %86 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 19), align 1, !dbg !56287, !nosanitize !4137
  %87 = add i8 %86, 1, !dbg !56287
  store i8 %87, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 19), align 1, !dbg !56287, !nosanitize !4137
  br label %bb10.i.i, !dbg !56287

bb3.i.i:                                          ; preds = %130
  %_38.i.i = getelementptr inbounds nuw i8, ptr %iter.sroa.0.08.i.i, i64 8, !dbg !56288
  %_29.i.i = icmp eq ptr %_38.i.i, %data.i.i.i.i, !dbg !56278
  br i1 %_29.i.i, label %bb3.i.i.bb10.i.i_crit_edge, label %bb3.i.i.bb11.i.i_crit_edge, !dbg !56287

bb3.i.i.bb11.i.i_crit_edge:                       ; preds = %bb3.i.i
  %88 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 20), align 1, !dbg !56287, !nosanitize !4137
  %89 = add i8 %88, 1, !dbg !56287
  store i8 %89, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 20), align 1, !dbg !56287, !nosanitize !4137
  br label %bb11.i.i, !dbg !56287

bb3.i.i.bb10.i.i_crit_edge:                       ; preds = %bb3.i.i
  %90 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 21), align 1, !dbg !56287, !nosanitize !4137
  %91 = add i8 %90, 1, !dbg !56287
  store i8 %91, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 21), align 1, !dbg !56287, !nosanitize !4137
  br label %bb10.i.i, !dbg !56287

bb11.i.i:                                         ; preds = %bb3.i.i.bb11.i.i_crit_edge, %bb1.i.i.bb11.i.i_crit_edge
  %iter.sroa.0.08.i.i = phi ptr [ %_38.i.i, %bb3.i.i.bb11.i.i_crit_edge ], [ %name.0, %bb1.i.i.bb11.i.i_crit_edge ]
  %92 = ptrtoint ptr %iter.sroa.0.08.i.i to i64, !dbg !56291
  %93 = add i64 %92, 7, !dbg !56291
  %94 = inttoptr i64 %93 to ptr, !dbg !56291
  %95 = ptrtoint ptr %iter.sroa.0.08.i.i to i64, !dbg !56291
  %96 = lshr i64 %95, 3, !dbg !56291
  %97 = add i64 %96, 2147450880, !dbg !56291
  %98 = inttoptr i64 %97 to ptr, !dbg !56291
  %99 = load i8, ptr %98, align 1, !dbg !56291
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %99), !dbg !56291
  %100 = icmp ne i8 %99, 0, !dbg !56291
  br i1 %100, label %103, label %bb11.i.i._crit_edge, !dbg !56291, !prof !4285

bb11.i.i._crit_edge:                              ; preds = %bb11.i.i
  %101 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 22), align 1, !dbg !56291, !nosanitize !4137
  %102 = add i8 %101, 1, !dbg !56291
  store i8 %102, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 22), align 1, !dbg !56291, !nosanitize !4137
  br label %112, !dbg !56291

103:                                              ; preds = %bb11.i.i
  %104 = and i64 %95, 7, !dbg !56291
  %105 = trunc i64 %104 to i8, !dbg !56291
  call void @__sanitizer_cov_trace_cmp1(i8 %105, i8 %99), !dbg !56291
  %106 = icmp sge i8 %105, %99, !dbg !56291
  br i1 %106, label %109, label %._crit_edge121, !dbg !56291

._crit_edge121:                                   ; preds = %103
  %107 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 23), align 1, !dbg !56291, !nosanitize !4137
  %108 = add i8 %107, 1, !dbg !56291
  store i8 %108, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 23), align 1, !dbg !56291, !nosanitize !4137
  br label %112, !dbg !56291

109:                                              ; preds = %103
  %110 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 24), align 1, !dbg !56291, !nosanitize !4137
  %111 = add i8 %110, 1, !dbg !56291
  store i8 %111, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 24), align 1, !dbg !56291, !nosanitize !4137
  call void @__asan_report_load_n(i64 %95, i64 8) #42, !dbg !56291
  unreachable

112:                                              ; preds = %._crit_edge121, %bb11.i.i._crit_edge
  %113 = ptrtoint ptr %94 to i64, !dbg !56291
  %114 = lshr i64 %113, 3, !dbg !56291
  %115 = add i64 %114, 2147450880, !dbg !56291
  %116 = inttoptr i64 %115 to ptr, !dbg !56291
  %117 = load i8, ptr %116, align 1, !dbg !56291
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %117), !dbg !56291
  %118 = icmp ne i8 %117, 0, !dbg !56291
  br i1 %118, label %121, label %._crit_edge122, !dbg !56291, !prof !4285

._crit_edge122:                                   ; preds = %112
  %119 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 25), align 1, !dbg !56291, !nosanitize !4137
  %120 = add i8 %119, 1, !dbg !56291
  store i8 %120, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 25), align 1, !dbg !56291, !nosanitize !4137
  br label %130, !dbg !56291

121:                                              ; preds = %112
  %122 = and i64 %113, 7, !dbg !56291
  %123 = trunc i64 %122 to i8, !dbg !56291
  call void @__sanitizer_cov_trace_cmp1(i8 %123, i8 %117), !dbg !56291
  %124 = icmp sge i8 %123, %117, !dbg !56291
  br i1 %124, label %127, label %._crit_edge123, !dbg !56291

._crit_edge123:                                   ; preds = %121
  %125 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 26), align 1, !dbg !56291, !nosanitize !4137
  %126 = add i8 %125, 1, !dbg !56291
  store i8 %126, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 26), align 1, !dbg !56291, !nosanitize !4137
  br label %130, !dbg !56291

127:                                              ; preds = %121
  %128 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 27), align 1, !dbg !56291, !nosanitize !4137
  %129 = add i8 %128, 1, !dbg !56291
  store i8 %129, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 27), align 1, !dbg !56291, !nosanitize !4137
  call void @__asan_report_load_n(i64 %113, i64 8) #42, !dbg !56291
  unreachable

130:                                              ; preds = %._crit_edge123, %._crit_edge122
  %bytes.sroa.0.0.copyload.i.i = load i64, ptr %iter.sroa.0.08.i.i, align 1, !dbg !56291, !alias.scope !56293
  %_13.i.i = and i64 %bytes.sroa.0.0.copyload.i.i, -9187201950435737472, !dbg !56294
  call void @__sanitizer_cov_trace_const_cmp8(i64 0, i64 %_13.i.i), !dbg !56294
  %131 = icmp eq i64 %_13.i.i, 0, !dbg !56294
  br i1 %131, label %bb3.i.i, label %.bb32_crit_edge124, !dbg !56294

.bb32_crit_edge124:                               ; preds = %130
  %132 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 28), align 1, !dbg !56294, !nosanitize !4137
  %133 = add i8 %132, 1, !dbg !56294
  store i8 %133, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 28), align 1, !dbg !56294, !nosanitize !4137
  br label %bb32, !dbg !56294

bb10.i.i:                                         ; preds = %bb3.i.i.bb10.i.i_crit_edge, %bb1.i.i.bb10.i.i_crit_edge
  call void @__sanitizer_cov_trace_const_cmp8(i64 0, i64 %len.i.i.i.i), !dbg !56296
  %_12.i.i.i101 = icmp samesign eq i64 %len.i.i.i.i, 0, !dbg !56296
  br i1 %_12.i.i.i101, label %bb10.i.i.bb1.i.i1.preheader_crit_edge, label %bb13.i.i.i, !dbg !56306

bb10.i.i.bb1.i.i1.preheader_crit_edge:            ; preds = %bb10.i.i
  %134 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 29), align 1, !dbg !56306, !nosanitize !4137
  %135 = add i8 %134, 1, !dbg !56306
  store i8 %135, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 29), align 1, !dbg !56306, !nosanitize !4137
  br label %bb1.i.i1.preheader, !dbg !56306

bb1.i.i.i:                                        ; preds = %287
  call void @__sanitizer_cov_trace_const_cmp8(i64 1, i64 %len.i.i.i.i), !dbg !56296
  %_12.i.i.i = icmp samesign eq i64 %len.i.i.i.i, 1, !dbg !56296
  br i1 %_12.i.i.i, label %bb1.i.i.i.bb1.i.i1.preheader_crit_edge, label %bb13.i.i.i.1, !dbg !56306

bb1.i.i.i.bb1.i.i1.preheader_crit_edge:           ; preds = %bb1.i.i.i
  %136 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 30), align 1, !dbg !56306, !nosanitize !4137
  %137 = add i8 %136, 1, !dbg !56306
  store i8 %137, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 30), align 1, !dbg !56306, !nosanitize !4137
  br label %bb1.i.i1.preheader, !dbg !56306

bb13.i.i.i.1:                                     ; preds = %bb1.i.i.i
  %_22.i1.i.i = getelementptr inbounds nuw i8, ptr %data.i.i.i.i, i64 1, !dbg !56307
  %138 = ptrtoint ptr %_22.i1.i.i to i64, !dbg !56310
  %139 = lshr i64 %138, 3, !dbg !56310
  %140 = add i64 %139, 2147450880, !dbg !56310
  %141 = inttoptr i64 %140 to ptr, !dbg !56310
  %142 = load i8, ptr %141, align 1, !dbg !56310
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %142), !dbg !56310
  %143 = icmp ne i8 %142, 0, !dbg !56310
  br i1 %143, label %146, label %bb13.i.i.i.1._crit_edge, !dbg !56310, !prof !4285

bb13.i.i.i.1._crit_edge:                          ; preds = %bb13.i.i.i.1
  %144 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 31), align 1, !dbg !56310, !nosanitize !4137
  %145 = add i8 %144, 1, !dbg !56310
  store i8 %145, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 31), align 1, !dbg !56310, !nosanitize !4137
  br label %155, !dbg !56310

146:                                              ; preds = %bb13.i.i.i.1
  %147 = and i64 %138, 7, !dbg !56310
  %148 = trunc i64 %147 to i8, !dbg !56310
  call void @__sanitizer_cov_trace_cmp1(i8 %148, i8 %142), !dbg !56310
  %149 = icmp sge i8 %148, %142, !dbg !56310
  br i1 %149, label %152, label %._crit_edge125, !dbg !56310

._crit_edge125:                                   ; preds = %146
  %150 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 32), align 1, !dbg !56310, !nosanitize !4137
  %151 = add i8 %150, 1, !dbg !56310
  store i8 %151, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 32), align 1, !dbg !56310, !nosanitize !4137
  br label %155, !dbg !56310

152:                                              ; preds = %146
  %153 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 33), align 1, !dbg !56310, !nosanitize !4137
  %154 = add i8 %153, 1, !dbg !56310
  store i8 %154, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 33), align 1, !dbg !56310, !nosanitize !4137
  call void @__asan_report_load1(i64 %138) #42, !dbg !56310
  unreachable

155:                                              ; preds = %._crit_edge125, %bb13.i.i.i.1._crit_edge
  %_3.i.i.i.i.1 = load i8, ptr %_22.i1.i.i, align 1, !dbg !56310, !alias.scope !56316, !noalias !56319, !noundef !4137
  call void @__sanitizer_cov_trace_const_cmp1(i8 -1, i8 %_3.i.i.i.i.1), !dbg !56310
  %_0.i.i2.i.i.1 = icmp sgt i8 %_3.i.i.i.i.1, -1, !dbg !56310
  br i1 %_0.i.i2.i.i.1, label %bb1.i.i.i.1, label %.bb32_crit_edge126, !dbg !56322

.bb32_crit_edge126:                               ; preds = %155
  %156 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 34), align 1, !dbg !56322, !nosanitize !4137
  %157 = add i8 %156, 1, !dbg !56322
  store i8 %157, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 34), align 1, !dbg !56322, !nosanitize !4137
  br label %bb32, !dbg !56322

bb1.i.i.i.1:                                      ; preds = %155
  call void @__sanitizer_cov_trace_const_cmp8(i64 2, i64 %len.i.i.i.i), !dbg !56296
  %_12.i.i.i.1 = icmp samesign eq i64 %len.i.i.i.i, 2, !dbg !56296
  br i1 %_12.i.i.i.1, label %bb1.i.i.i.1.bb1.i.i1.preheader_crit_edge, label %bb13.i.i.i.2, !dbg !56306

bb1.i.i.i.1.bb1.i.i1.preheader_crit_edge:         ; preds = %bb1.i.i.i.1
  %158 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 35), align 1, !dbg !56306, !nosanitize !4137
  %159 = add i8 %158, 1, !dbg !56306
  store i8 %159, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 35), align 1, !dbg !56306, !nosanitize !4137
  br label %bb1.i.i1.preheader, !dbg !56306

bb13.i.i.i.2:                                     ; preds = %bb1.i.i.i.1
  %_22.i1.i.i.1 = getelementptr inbounds nuw i8, ptr %data.i.i.i.i, i64 2, !dbg !56307
  %160 = ptrtoint ptr %_22.i1.i.i.1 to i64, !dbg !56310
  %161 = lshr i64 %160, 3, !dbg !56310
  %162 = add i64 %161, 2147450880, !dbg !56310
  %163 = inttoptr i64 %162 to ptr, !dbg !56310
  %164 = load i8, ptr %163, align 1, !dbg !56310
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %164), !dbg !56310
  %165 = icmp ne i8 %164, 0, !dbg !56310
  br i1 %165, label %168, label %bb13.i.i.i.2._crit_edge, !dbg !56310, !prof !4285

bb13.i.i.i.2._crit_edge:                          ; preds = %bb13.i.i.i.2
  %166 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 36), align 1, !dbg !56310, !nosanitize !4137
  %167 = add i8 %166, 1, !dbg !56310
  store i8 %167, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 36), align 1, !dbg !56310, !nosanitize !4137
  br label %177, !dbg !56310

168:                                              ; preds = %bb13.i.i.i.2
  %169 = and i64 %160, 7, !dbg !56310
  %170 = trunc i64 %169 to i8, !dbg !56310
  call void @__sanitizer_cov_trace_cmp1(i8 %170, i8 %164), !dbg !56310
  %171 = icmp sge i8 %170, %164, !dbg !56310
  br i1 %171, label %174, label %._crit_edge127, !dbg !56310

._crit_edge127:                                   ; preds = %168
  %172 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 37), align 1, !dbg !56310, !nosanitize !4137
  %173 = add i8 %172, 1, !dbg !56310
  store i8 %173, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 37), align 1, !dbg !56310, !nosanitize !4137
  br label %177, !dbg !56310

174:                                              ; preds = %168
  %175 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 38), align 1, !dbg !56310, !nosanitize !4137
  %176 = add i8 %175, 1, !dbg !56310
  store i8 %176, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 38), align 1, !dbg !56310, !nosanitize !4137
  call void @__asan_report_load1(i64 %160) #42, !dbg !56310
  unreachable

177:                                              ; preds = %._crit_edge127, %bb13.i.i.i.2._crit_edge
  %_3.i.i.i.i.2 = load i8, ptr %_22.i1.i.i.1, align 1, !dbg !56310, !alias.scope !56316, !noalias !56319, !noundef !4137
  call void @__sanitizer_cov_trace_const_cmp1(i8 -1, i8 %_3.i.i.i.i.2), !dbg !56310
  %_0.i.i2.i.i.2 = icmp sgt i8 %_3.i.i.i.i.2, -1, !dbg !56310
  br i1 %_0.i.i2.i.i.2, label %bb1.i.i.i.2, label %.bb32_crit_edge128, !dbg !56322

.bb32_crit_edge128:                               ; preds = %177
  %178 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 39), align 1, !dbg !56322, !nosanitize !4137
  %179 = add i8 %178, 1, !dbg !56322
  store i8 %179, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 39), align 1, !dbg !56322, !nosanitize !4137
  br label %bb32, !dbg !56322

bb1.i.i.i.2:                                      ; preds = %177
  call void @__sanitizer_cov_trace_const_cmp8(i64 3, i64 %len.i.i.i.i), !dbg !56296
  %_12.i.i.i.2 = icmp samesign eq i64 %len.i.i.i.i, 3, !dbg !56296
  br i1 %_12.i.i.i.2, label %bb1.i.i.i.2.bb1.i.i1.preheader_crit_edge, label %bb13.i.i.i.3, !dbg !56306

bb1.i.i.i.2.bb1.i.i1.preheader_crit_edge:         ; preds = %bb1.i.i.i.2
  %180 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 40), align 1, !dbg !56306, !nosanitize !4137
  %181 = add i8 %180, 1, !dbg !56306
  store i8 %181, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 40), align 1, !dbg !56306, !nosanitize !4137
  br label %bb1.i.i1.preheader, !dbg !56306

bb13.i.i.i.3:                                     ; preds = %bb1.i.i.i.2
  %_22.i1.i.i.2 = getelementptr inbounds nuw i8, ptr %data.i.i.i.i, i64 3, !dbg !56307
  %182 = ptrtoint ptr %_22.i1.i.i.2 to i64, !dbg !56310
  %183 = lshr i64 %182, 3, !dbg !56310
  %184 = add i64 %183, 2147450880, !dbg !56310
  %185 = inttoptr i64 %184 to ptr, !dbg !56310
  %186 = load i8, ptr %185, align 1, !dbg !56310
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %186), !dbg !56310
  %187 = icmp ne i8 %186, 0, !dbg !56310
  br i1 %187, label %190, label %bb13.i.i.i.3._crit_edge, !dbg !56310, !prof !4285

bb13.i.i.i.3._crit_edge:                          ; preds = %bb13.i.i.i.3
  %188 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 41), align 1, !dbg !56310, !nosanitize !4137
  %189 = add i8 %188, 1, !dbg !56310
  store i8 %189, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 41), align 1, !dbg !56310, !nosanitize !4137
  br label %199, !dbg !56310

190:                                              ; preds = %bb13.i.i.i.3
  %191 = and i64 %182, 7, !dbg !56310
  %192 = trunc i64 %191 to i8, !dbg !56310
  call void @__sanitizer_cov_trace_cmp1(i8 %192, i8 %186), !dbg !56310
  %193 = icmp sge i8 %192, %186, !dbg !56310
  br i1 %193, label %196, label %._crit_edge129, !dbg !56310

._crit_edge129:                                   ; preds = %190
  %194 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 42), align 1, !dbg !56310, !nosanitize !4137
  %195 = add i8 %194, 1, !dbg !56310
  store i8 %195, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 42), align 1, !dbg !56310, !nosanitize !4137
  br label %199, !dbg !56310

196:                                              ; preds = %190
  %197 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 43), align 1, !dbg !56310, !nosanitize !4137
  %198 = add i8 %197, 1, !dbg !56310
  store i8 %198, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 43), align 1, !dbg !56310, !nosanitize !4137
  call void @__asan_report_load1(i64 %182) #42, !dbg !56310
  unreachable

199:                                              ; preds = %._crit_edge129, %bb13.i.i.i.3._crit_edge
  %_3.i.i.i.i.3 = load i8, ptr %_22.i1.i.i.2, align 1, !dbg !56310, !alias.scope !56316, !noalias !56319, !noundef !4137
  call void @__sanitizer_cov_trace_const_cmp1(i8 -1, i8 %_3.i.i.i.i.3), !dbg !56310
  %_0.i.i2.i.i.3 = icmp sgt i8 %_3.i.i.i.i.3, -1, !dbg !56310
  br i1 %_0.i.i2.i.i.3, label %bb1.i.i.i.3, label %.bb32_crit_edge130, !dbg !56322

.bb32_crit_edge130:                               ; preds = %199
  %200 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 44), align 1, !dbg !56322, !nosanitize !4137
  %201 = add i8 %200, 1, !dbg !56322
  store i8 %201, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 44), align 1, !dbg !56322, !nosanitize !4137
  br label %bb32, !dbg !56322

bb1.i.i.i.3:                                      ; preds = %199
  call void @__sanitizer_cov_trace_const_cmp8(i64 4, i64 %len.i.i.i.i), !dbg !56296
  %_12.i.i.i.3 = icmp samesign eq i64 %len.i.i.i.i, 4, !dbg !56296
  br i1 %_12.i.i.i.3, label %bb1.i.i.i.3.bb1.i.i1.preheader_crit_edge, label %bb13.i.i.i.4, !dbg !56306

bb1.i.i.i.3.bb1.i.i1.preheader_crit_edge:         ; preds = %bb1.i.i.i.3
  %202 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 45), align 1, !dbg !56306, !nosanitize !4137
  %203 = add i8 %202, 1, !dbg !56306
  store i8 %203, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 45), align 1, !dbg !56306, !nosanitize !4137
  br label %bb1.i.i1.preheader, !dbg !56306

bb13.i.i.i.4:                                     ; preds = %bb1.i.i.i.3
  %_22.i1.i.i.3 = getelementptr inbounds nuw i8, ptr %data.i.i.i.i, i64 4, !dbg !56307
  %204 = ptrtoint ptr %_22.i1.i.i.3 to i64, !dbg !56310
  %205 = lshr i64 %204, 3, !dbg !56310
  %206 = add i64 %205, 2147450880, !dbg !56310
  %207 = inttoptr i64 %206 to ptr, !dbg !56310
  %208 = load i8, ptr %207, align 1, !dbg !56310
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %208), !dbg !56310
  %209 = icmp ne i8 %208, 0, !dbg !56310
  br i1 %209, label %212, label %bb13.i.i.i.4._crit_edge, !dbg !56310, !prof !4285

bb13.i.i.i.4._crit_edge:                          ; preds = %bb13.i.i.i.4
  %210 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 46), align 1, !dbg !56310, !nosanitize !4137
  %211 = add i8 %210, 1, !dbg !56310
  store i8 %211, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 46), align 1, !dbg !56310, !nosanitize !4137
  br label %221, !dbg !56310

212:                                              ; preds = %bb13.i.i.i.4
  %213 = and i64 %204, 7, !dbg !56310
  %214 = trunc i64 %213 to i8, !dbg !56310
  call void @__sanitizer_cov_trace_cmp1(i8 %214, i8 %208), !dbg !56310
  %215 = icmp sge i8 %214, %208, !dbg !56310
  br i1 %215, label %218, label %._crit_edge131, !dbg !56310

._crit_edge131:                                   ; preds = %212
  %216 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 47), align 1, !dbg !56310, !nosanitize !4137
  %217 = add i8 %216, 1, !dbg !56310
  store i8 %217, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 47), align 1, !dbg !56310, !nosanitize !4137
  br label %221, !dbg !56310

218:                                              ; preds = %212
  %219 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 48), align 1, !dbg !56310, !nosanitize !4137
  %220 = add i8 %219, 1, !dbg !56310
  store i8 %220, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 48), align 1, !dbg !56310, !nosanitize !4137
  call void @__asan_report_load1(i64 %204) #42, !dbg !56310
  unreachable

221:                                              ; preds = %._crit_edge131, %bb13.i.i.i.4._crit_edge
  %_3.i.i.i.i.4 = load i8, ptr %_22.i1.i.i.3, align 1, !dbg !56310, !alias.scope !56316, !noalias !56319, !noundef !4137
  call void @__sanitizer_cov_trace_const_cmp1(i8 -1, i8 %_3.i.i.i.i.4), !dbg !56310
  %_0.i.i2.i.i.4 = icmp sgt i8 %_3.i.i.i.i.4, -1, !dbg !56310
  br i1 %_0.i.i2.i.i.4, label %bb1.i.i.i.4, label %.bb32_crit_edge132, !dbg !56322

.bb32_crit_edge132:                               ; preds = %221
  %222 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 49), align 1, !dbg !56322, !nosanitize !4137
  %223 = add i8 %222, 1, !dbg !56322
  store i8 %223, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 49), align 1, !dbg !56322, !nosanitize !4137
  br label %bb32, !dbg !56322

bb1.i.i.i.4:                                      ; preds = %221
  call void @__sanitizer_cov_trace_const_cmp8(i64 5, i64 %len.i.i.i.i), !dbg !56296
  %_12.i.i.i.4 = icmp samesign eq i64 %len.i.i.i.i, 5, !dbg !56296
  br i1 %_12.i.i.i.4, label %bb1.i.i.i.4.bb1.i.i1.preheader_crit_edge, label %bb13.i.i.i.5, !dbg !56306

bb1.i.i.i.4.bb1.i.i1.preheader_crit_edge:         ; preds = %bb1.i.i.i.4
  %224 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 50), align 1, !dbg !56306, !nosanitize !4137
  %225 = add i8 %224, 1, !dbg !56306
  store i8 %225, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 50), align 1, !dbg !56306, !nosanitize !4137
  br label %bb1.i.i1.preheader, !dbg !56306

bb13.i.i.i.5:                                     ; preds = %bb1.i.i.i.4
  %_22.i1.i.i.4 = getelementptr inbounds nuw i8, ptr %data.i.i.i.i, i64 5, !dbg !56307
  %226 = ptrtoint ptr %_22.i1.i.i.4 to i64, !dbg !56310
  %227 = lshr i64 %226, 3, !dbg !56310
  %228 = add i64 %227, 2147450880, !dbg !56310
  %229 = inttoptr i64 %228 to ptr, !dbg !56310
  %230 = load i8, ptr %229, align 1, !dbg !56310
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %230), !dbg !56310
  %231 = icmp ne i8 %230, 0, !dbg !56310
  br i1 %231, label %234, label %bb13.i.i.i.5._crit_edge, !dbg !56310, !prof !4285

bb13.i.i.i.5._crit_edge:                          ; preds = %bb13.i.i.i.5
  %232 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 51), align 1, !dbg !56310, !nosanitize !4137
  %233 = add i8 %232, 1, !dbg !56310
  store i8 %233, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 51), align 1, !dbg !56310, !nosanitize !4137
  br label %243, !dbg !56310

234:                                              ; preds = %bb13.i.i.i.5
  %235 = and i64 %226, 7, !dbg !56310
  %236 = trunc i64 %235 to i8, !dbg !56310
  call void @__sanitizer_cov_trace_cmp1(i8 %236, i8 %230), !dbg !56310
  %237 = icmp sge i8 %236, %230, !dbg !56310
  br i1 %237, label %240, label %._crit_edge133, !dbg !56310

._crit_edge133:                                   ; preds = %234
  %238 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 52), align 1, !dbg !56310, !nosanitize !4137
  %239 = add i8 %238, 1, !dbg !56310
  store i8 %239, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 52), align 1, !dbg !56310, !nosanitize !4137
  br label %243, !dbg !56310

240:                                              ; preds = %234
  %241 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 53), align 1, !dbg !56310, !nosanitize !4137
  %242 = add i8 %241, 1, !dbg !56310
  store i8 %242, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 53), align 1, !dbg !56310, !nosanitize !4137
  call void @__asan_report_load1(i64 %226) #42, !dbg !56310
  unreachable

243:                                              ; preds = %._crit_edge133, %bb13.i.i.i.5._crit_edge
  %_3.i.i.i.i.5 = load i8, ptr %_22.i1.i.i.4, align 1, !dbg !56310, !alias.scope !56316, !noalias !56319, !noundef !4137
  call void @__sanitizer_cov_trace_const_cmp1(i8 -1, i8 %_3.i.i.i.i.5), !dbg !56310
  %_0.i.i2.i.i.5 = icmp sgt i8 %_3.i.i.i.i.5, -1, !dbg !56310
  br i1 %_0.i.i2.i.i.5, label %bb1.i.i.i.5, label %.bb32_crit_edge134, !dbg !56322

.bb32_crit_edge134:                               ; preds = %243
  %244 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 54), align 1, !dbg !56322, !nosanitize !4137
  %245 = add i8 %244, 1, !dbg !56322
  store i8 %245, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 54), align 1, !dbg !56322, !nosanitize !4137
  br label %bb32, !dbg !56322

bb1.i.i.i.5:                                      ; preds = %243
  call void @__sanitizer_cov_trace_const_cmp8(i64 6, i64 %len.i.i.i.i), !dbg !56296
  %_12.i.i.i.5 = icmp samesign eq i64 %len.i.i.i.i, 6, !dbg !56296
  br i1 %_12.i.i.i.5, label %bb1.i.i.i.5.bb1.i.i1.preheader_crit_edge, label %bb13.i.i.i.6, !dbg !56306

bb1.i.i.i.5.bb1.i.i1.preheader_crit_edge:         ; preds = %bb1.i.i.i.5
  %246 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 55), align 1, !dbg !56306, !nosanitize !4137
  %247 = add i8 %246, 1, !dbg !56306
  store i8 %247, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 55), align 1, !dbg !56306, !nosanitize !4137
  br label %bb1.i.i1.preheader, !dbg !56306

bb13.i.i.i.6:                                     ; preds = %bb1.i.i.i.5
  %_22.i1.i.i.5 = getelementptr inbounds nuw i8, ptr %data.i.i.i.i, i64 6, !dbg !56307
  %248 = ptrtoint ptr %_22.i1.i.i.5 to i64, !dbg !56310
  %249 = lshr i64 %248, 3, !dbg !56310
  %250 = add i64 %249, 2147450880, !dbg !56310
  %251 = inttoptr i64 %250 to ptr, !dbg !56310
  %252 = load i8, ptr %251, align 1, !dbg !56310
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %252), !dbg !56310
  %253 = icmp ne i8 %252, 0, !dbg !56310
  br i1 %253, label %256, label %bb13.i.i.i.6._crit_edge, !dbg !56310, !prof !4285

bb13.i.i.i.6._crit_edge:                          ; preds = %bb13.i.i.i.6
  %254 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 56), align 1, !dbg !56310, !nosanitize !4137
  %255 = add i8 %254, 1, !dbg !56310
  store i8 %255, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 56), align 1, !dbg !56310, !nosanitize !4137
  br label %265, !dbg !56310

256:                                              ; preds = %bb13.i.i.i.6
  %257 = and i64 %248, 7, !dbg !56310
  %258 = trunc i64 %257 to i8, !dbg !56310
  call void @__sanitizer_cov_trace_cmp1(i8 %258, i8 %252), !dbg !56310
  %259 = icmp sge i8 %258, %252, !dbg !56310
  br i1 %259, label %262, label %._crit_edge135, !dbg !56310

._crit_edge135:                                   ; preds = %256
  %260 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 57), align 1, !dbg !56310, !nosanitize !4137
  %261 = add i8 %260, 1, !dbg !56310
  store i8 %261, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 57), align 1, !dbg !56310, !nosanitize !4137
  br label %265, !dbg !56310

262:                                              ; preds = %256
  %263 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 58), align 1, !dbg !56310, !nosanitize !4137
  %264 = add i8 %263, 1, !dbg !56310
  store i8 %264, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 58), align 1, !dbg !56310, !nosanitize !4137
  call void @__asan_report_load1(i64 %248) #42, !dbg !56310
  unreachable

265:                                              ; preds = %._crit_edge135, %bb13.i.i.i.6._crit_edge
  %_3.i.i.i.i.6 = load i8, ptr %_22.i1.i.i.5, align 1, !dbg !56310, !alias.scope !56316, !noalias !56319, !noundef !4137
  call void @__sanitizer_cov_trace_const_cmp1(i8 -1, i8 %_3.i.i.i.i.6), !dbg !56310
  %_0.i.i2.i.i.6 = icmp sgt i8 %_3.i.i.i.i.6, -1, !dbg !56310
  br i1 %_0.i.i2.i.i.6, label %.bb1.i.i1.preheader_crit_edge, label %.bb32_crit_edge136, !dbg !56322

.bb32_crit_edge136:                               ; preds = %265
  %266 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 59), align 1, !dbg !56322, !nosanitize !4137
  %267 = add i8 %266, 1, !dbg !56322
  store i8 %267, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 59), align 1, !dbg !56322, !nosanitize !4137
  br label %bb32, !dbg !56322

.bb1.i.i1.preheader_crit_edge:                    ; preds = %265
  %268 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 60), align 1, !dbg !56322, !nosanitize !4137
  %269 = add i8 %268, 1, !dbg !56322
  store i8 %269, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 60), align 1, !dbg !56322, !nosanitize !4137
  br label %bb1.i.i1.preheader, !dbg !56322

bb1.i.i1.preheader:                               ; preds = %.bb1.i.i1.preheader_crit_edge, %bb1.i.i.i.5.bb1.i.i1.preheader_crit_edge, %bb1.i.i.i.4.bb1.i.i1.preheader_crit_edge, %bb1.i.i.i.3.bb1.i.i1.preheader_crit_edge, %bb1.i.i.i.2.bb1.i.i1.preheader_crit_edge, %bb1.i.i.i.1.bb1.i.i1.preheader_crit_edge, %bb1.i.i.i.bb1.i.i1.preheader_crit_edge, %bb10.i.i.bb1.i.i1.preheader_crit_edge, %bb1.i.i.i.i.bb1.i.i1.preheader_crit_edge, %bb15.i.i.i.bb1.i.i1.preheader_crit_edge
  br label %bb1.i.i1, !dbg !56323

bb13.i.i.i:                                       ; preds = %bb10.i.i
  %270 = ptrtoint ptr %data.i.i.i.i to i64, !dbg !56310
  %271 = lshr i64 %270, 3, !dbg !56310
  %272 = add i64 %271, 2147450880, !dbg !56310
  %273 = inttoptr i64 %272 to ptr, !dbg !56310
  %274 = load i8, ptr %273, align 1, !dbg !56310
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %274), !dbg !56310
  %275 = icmp ne i8 %274, 0, !dbg !56310
  br i1 %275, label %278, label %bb13.i.i.i._crit_edge, !dbg !56310, !prof !4285

bb13.i.i.i._crit_edge:                            ; preds = %bb13.i.i.i
  %276 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 61), align 1, !dbg !56310, !nosanitize !4137
  %277 = add i8 %276, 1, !dbg !56310
  store i8 %277, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 61), align 1, !dbg !56310, !nosanitize !4137
  br label %287, !dbg !56310

278:                                              ; preds = %bb13.i.i.i
  %279 = and i64 %270, 7, !dbg !56310
  %280 = trunc i64 %279 to i8, !dbg !56310
  call void @__sanitizer_cov_trace_cmp1(i8 %280, i8 %274), !dbg !56310
  %281 = icmp sge i8 %280, %274, !dbg !56310
  br i1 %281, label %284, label %._crit_edge137, !dbg !56310

._crit_edge137:                                   ; preds = %278
  %282 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 62), align 1, !dbg !56310, !nosanitize !4137
  %283 = add i8 %282, 1, !dbg !56310
  store i8 %283, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 62), align 1, !dbg !56310, !nosanitize !4137
  br label %287, !dbg !56310

284:                                              ; preds = %278
  %285 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 63), align 1, !dbg !56310, !nosanitize !4137
  %286 = add i8 %285, 1, !dbg !56310
  store i8 %286, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 63), align 1, !dbg !56310, !nosanitize !4137
  call void @__asan_report_load1(i64 %270) #42, !dbg !56310
  unreachable

287:                                              ; preds = %._crit_edge137, %bb13.i.i.i._crit_edge
  %_3.i.i.i.i = load i8, ptr %data.i.i.i.i, align 1, !dbg !56310, !alias.scope !56316, !noalias !56319, !noundef !4137
  call void @__sanitizer_cov_trace_const_cmp1(i8 -1, i8 %_3.i.i.i.i), !dbg !56310
  %_0.i.i2.i.i = icmp sgt i8 %_3.i.i.i.i, -1, !dbg !56310
  br i1 %_0.i.i2.i.i, label %bb1.i.i.i, label %.bb32_crit_edge138, !dbg !56322

.bb32_crit_edge138:                               ; preds = %287
  %288 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 64), align 1, !dbg !56322, !nosanitize !4137
  %289 = add i8 %288, 1, !dbg !56322
  store i8 %289, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 64), align 1, !dbg !56322, !nosanitize !4137
  br label %bb32, !dbg !56322

bb1.i.i1:                                         ; preds = %bb1.i.i1.backedge, %bb1.i.i1.preheader
  %290 = phi i64 [ 0, %bb1.i.i1.preheader ], [ %376, %bb1.i.i1.backedge ]
  %.lcssa513.i.i = phi i64 [ 0, %bb1.i.i1.preheader ], [ %.lcssa512.i.i, %bb1.i.i1.backedge ]
  %_2.i.i.i.i = phi i1 [ false, %bb1.i.i1.preheader ], [ %377, %bb1.i.i1.backedge ]
  br i1 %_2.i.i.i.i, label %bb1.i.i1._RNvXsY_NtNtCshZBO5P2NUJi_4core3str4iterINtB5_5SplitcENtNtNtNtB9_4iter6traits8iterator8Iterator4nextCsiKgSYIST2hs_15spiral_protocol.exit.i.i_crit_edge, label %bb2.i.i.i.i, !dbg !56323

bb1.i.i1._RNvXsY_NtNtCshZBO5P2NUJi_4core3str4iterINtB5_5SplitcENtNtNtNtB9_4iter6traits8iterator8Iterator4nextCsiKgSYIST2hs_15spiral_protocol.exit.i.i_crit_edge: ; preds = %bb1.i.i1
  %291 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 65), align 1, !dbg !56323, !nosanitize !4137
  %292 = add i8 %291, 1, !dbg !56323
  store i8 %292, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 65), align 1, !dbg !56323, !nosanitize !4137
  br label %_RNvXsY_NtNtCshZBO5P2NUJi_4core3str4iterINtB5_5SplitcENtNtNtNtB9_4iter6traits8iterator8Iterator4nextCsiKgSYIST2hs_15spiral_protocol.exit.i.i, !dbg !56323

bb2.i.i.i.i:                                      ; preds = %bb1.i.i1
  call void @__sanitizer_cov_trace_cmp8(i64 %name.1, i64 %290), !dbg !56338
  %_4232.i.i.i.i.i = icmp ult i64 %name.1, %290, !dbg !56338
  br i1 %_4232.i.i.i.i.i, label %bb2.i.i.i.i.bb6.i.i.i.i_crit_edge, label %bb2.i.i.i.i.bb18.i.i.i.i.i_crit_edge, !dbg !56338

bb2.i.i.i.i.bb18.i.i.i.i.i_crit_edge:             ; preds = %bb2.i.i.i.i
  br label %bb18.i.i.i.i.i, !dbg !56338

bb2.i.i.i.i.bb6.i.i.i.i_crit_edge:                ; preds = %bb2.i.i.i.i
  %293 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 66), align 1, !dbg !56338, !nosanitize !4137
  %294 = add i8 %293, 1, !dbg !56338
  store i8 %294, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 66), align 1, !dbg !56338, !nosanitize !4137
  br label %bb6.i.i.i.i, !dbg !56338

bb18.i.i.i.i.i:                                   ; preds = %bb10.i.i.i.i.i.bb18.i.i.i.i.i_crit_edge, %bb2.i.i.i.i.bb18.i.i.i.i.i_crit_edge
  %295 = phi i64 [ %339, %bb10.i.i.i.i.i.bb18.i.i.i.i.i_crit_edge ], [ %290, %bb2.i.i.i.i.bb18.i.i.i.i.i_crit_edge ]
  %new_len.i.i.i.i.i = sub nuw i64 %name.1, %295, !dbg !56351
  %_45.i.i.i.i.i = getelementptr inbounds nuw i8, ptr %name.0, i64 %295, !dbg !56352
  call void @__sanitizer_cov_trace_const_cmp8(i64 16, i64 %new_len.i.i.i.i.i), !dbg !56356
  %_3.i12.i.i.i.i.i = icmp samesign ult i64 %new_len.i.i.i.i.i, 16, !dbg !56356
  br i1 %_3.i12.i.i.i.i.i, label %bb6.preheader.i.i.i.i.i.i, label %bb2.i13.i.i.i.i.i, !dbg !56356

bb6.preheader.i.i.i.i.i.i:                        ; preds = %bb18.i.i.i.i.i
  call void @__sanitizer_cov_trace_cmp8(i64 %name.1, i64 %295), !dbg !56361
  %_98.not.i.i.i.i.i.i = icmp eq i64 %name.1, %295, !dbg !56361
  br i1 %_98.not.i.i.i.i.i.i, label %bb6.preheader.i.i.i.i.i.i._RNvNtNtCshZBO5P2NUJi_4core5slice6memchr6memchr.exit.i.i.i.i.i_crit_edge, label %bb6.preheader.i.i.i.i.i.i.bb8.i.i.i.i.i.i_crit_edge, !dbg !56361

bb6.preheader.i.i.i.i.i.i.bb8.i.i.i.i.i.i_crit_edge: ; preds = %bb6.preheader.i.i.i.i.i.i
  br label %bb8.i.i.i.i.i.i, !dbg !56361

bb6.preheader.i.i.i.i.i.i._RNvNtNtCshZBO5P2NUJi_4core5slice6memchr6memchr.exit.i.i.i.i.i_crit_edge: ; preds = %bb6.preheader.i.i.i.i.i.i
  %296 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 67), align 1, !dbg !56361, !nosanitize !4137
  %297 = add i8 %296, 1, !dbg !56361
  store i8 %297, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 67), align 1, !dbg !56361, !nosanitize !4137
  br label %_RNvNtNtCshZBO5P2NUJi_4core5slice6memchr6memchr.exit.i.i.i.i.i, !dbg !56361

bb2.i13.i.i.i.i.i:                                ; preds = %bb18.i.i.i.i.i
; call core::slice::memchr::memchr_aligned
  %298 = call { i64, i64 } @_RNvNtNtCshZBO5P2NUJi_4core5slice6memchr14memchr_aligned(i8 noundef 46, ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) %_45.i.i.i.i.i, i64 noundef range(i64 0, -9223372036854775808) %new_len.i.i.i.i.i) #35, !dbg !56363, !noalias !56364
  %299 = extractvalue { i64, i64 } %298, 0, !dbg !56363
  %300 = extractvalue { i64, i64 } %298, 1, !dbg !56363
  %301 = trunc nuw i64 %299 to i1, !dbg !56376
  br i1 %301, label %bb2.i13.i.i.i.i.i.bb4.i.i.i.i.i.i_crit_edge, label %bb2.i13.i.i.i.i.i._RNvNtNtCshZBO5P2NUJi_4core5slice6memchr6memchr.exit.i.i.i.i.i_crit_edge, !dbg !56376

bb2.i13.i.i.i.i.i._RNvNtNtCshZBO5P2NUJi_4core5slice6memchr6memchr.exit.i.i.i.i.i_crit_edge: ; preds = %bb2.i13.i.i.i.i.i
  %302 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 68), align 1, !dbg !56376, !nosanitize !4137
  %303 = add i8 %302, 1, !dbg !56376
  store i8 %303, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 68), align 1, !dbg !56376, !nosanitize !4137
  br label %_RNvNtNtCshZBO5P2NUJi_4core5slice6memchr6memchr.exit.i.i.i.i.i, !dbg !56376

bb2.i13.i.i.i.i.i.bb4.i.i.i.i.i.i_crit_edge:      ; preds = %bb2.i13.i.i.i.i.i
  %304 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 69), align 1, !dbg !56376, !nosanitize !4137
  %305 = add i8 %304, 1, !dbg !56376
  store i8 %305, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 69), align 1, !dbg !56376, !nosanitize !4137
  br label %bb4.i.i.i.i.i.i, !dbg !56376

bb4.i.i.i.i.i.i:                                  ; preds = %.bb4.i.i.i.i.i.i_crit_edge, %bb2.i13.i.i.i.i.i.bb4.i.i.i.i.i.i_crit_edge
  %result.sroa.5.0.i.i.i.i.i.i = phi i64 [ %300, %bb2.i13.i.i.i.i.i.bb4.i.i.i.i.i.i_crit_edge ], [ %i.sroa.0.09.i.i.i.i.i.i, %.bb4.i.i.i.i.i.i_crit_edge ], !dbg !56377
  %result.sroa.0.0.i.i.i.i.i.i = phi i64 [ %299, %bb2.i13.i.i.i.i.i.bb4.i.i.i.i.i.i_crit_edge ], [ 1, %.bb4.i.i.i.i.i.i_crit_edge ], !dbg !56377
  call void @__sanitizer_cov_trace_cmp8(i64 %result.sroa.5.0.i.i.i.i.i.i, i64 %new_len.i.i.i.i.i), !dbg !56378
  %cond.i.i.i.i.i.i = icmp ult i64 %result.sroa.5.0.i.i.i.i.i.i, %new_len.i.i.i.i.i, !dbg !56378
  br i1 %cond.i.i.i.i.i.i, label %bb4.i.i.i.i.i.i._RNvNtNtCshZBO5P2NUJi_4core5slice6memchr6memchr.exit.i.i.i.i.i_crit_edge, label %bb1.i.i.i.i.i.i.i, !dbg !56379, !prof !4290

bb4.i.i.i.i.i.i._RNvNtNtCshZBO5P2NUJi_4core5slice6memchr6memchr.exit.i.i.i.i.i_crit_edge: ; preds = %bb4.i.i.i.i.i.i
  %306 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 70), align 1, !dbg !56379, !nosanitize !4137
  %307 = add i8 %306, 1, !dbg !56379
  store i8 %307, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 70), align 1, !dbg !56379, !nosanitize !4137
  br label %_RNvNtNtCshZBO5P2NUJi_4core5slice6memchr6memchr.exit.i.i.i.i.i, !dbg !56379

bb1.i.i.i.i.i.i.i:                                ; preds = %bb4.i.i.i.i.i.i
  %308 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 71), align 1, !dbg !56382, !nosanitize !4137
  %309 = add i8 %308, 1, !dbg !56382
  store i8 %309, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 71), align 1, !dbg !56382, !nosanitize !4137
  call void @__asan_handle_no_return(), !dbg !56382
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCshZBO5P2NUJi_4core9panicking18panic_nounwind_fmt(ptr noundef nonnull @alloc_64e308ef4babfeb8b6220184de794a17, ptr noundef nonnull inttoptr (i64 443 to ptr), i1 noundef zeroext false, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_ac8fce308ee1f106aaa4bc0c23b74cc5) #43, !dbg !56382, !noalias !56364
  unreachable, !dbg !56382

bb8.i.i.i.i.i.i:                                  ; preds = %bb10.i.i.i.i.i.i.bb8.i.i.i.i.i.i_crit_edge, %bb6.preheader.i.i.i.i.i.i.bb8.i.i.i.i.i.i_crit_edge
  %i.sroa.0.09.i.i.i.i.i.i = phi i64 [ %331, %bb10.i.i.i.i.i.i.bb8.i.i.i.i.i.i_crit_edge ], [ 0, %bb6.preheader.i.i.i.i.i.i.bb8.i.i.i.i.i.i_crit_edge ]
  %310 = getelementptr inbounds nuw i8, ptr %_45.i.i.i.i.i, i64 %i.sroa.0.09.i.i.i.i.i.i, !dbg !56383
  %311 = ptrtoint ptr %310 to i64, !dbg !56383
  %312 = lshr i64 %311, 3, !dbg !56383
  %313 = add i64 %312, 2147450880, !dbg !56383
  %314 = inttoptr i64 %313 to ptr, !dbg !56383
  %315 = load i8, ptr %314, align 1, !dbg !56383
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %315), !dbg !56383
  %316 = icmp ne i8 %315, 0, !dbg !56383
  br i1 %316, label %319, label %bb8.i.i.i.i.i.i._crit_edge, !dbg !56383, !prof !4285

bb8.i.i.i.i.i.i._crit_edge:                       ; preds = %bb8.i.i.i.i.i.i
  %317 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 72), align 1, !dbg !56383, !nosanitize !4137
  %318 = add i8 %317, 1, !dbg !56383
  store i8 %318, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 72), align 1, !dbg !56383, !nosanitize !4137
  br label %328, !dbg !56383

319:                                              ; preds = %bb8.i.i.i.i.i.i
  %320 = and i64 %311, 7, !dbg !56383
  %321 = trunc i64 %320 to i8, !dbg !56383
  call void @__sanitizer_cov_trace_cmp1(i8 %321, i8 %315), !dbg !56383
  %322 = icmp sge i8 %321, %315, !dbg !56383
  br i1 %322, label %325, label %._crit_edge139, !dbg !56383

._crit_edge139:                                   ; preds = %319
  %323 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 73), align 1, !dbg !56383, !nosanitize !4137
  %324 = add i8 %323, 1, !dbg !56383
  store i8 %324, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 73), align 1, !dbg !56383, !nosanitize !4137
  br label %328, !dbg !56383

325:                                              ; preds = %319
  %326 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 74), align 1, !dbg !56383, !nosanitize !4137
  %327 = add i8 %326, 1, !dbg !56383
  store i8 %327, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 74), align 1, !dbg !56383, !nosanitize !4137
  call void @__asan_report_load1(i64 %311) #42, !dbg !56383
  unreachable

328:                                              ; preds = %._crit_edge139, %bb8.i.i.i.i.i.i._crit_edge
  %_12.i.i.i.i.i.i = load i8, ptr %310, align 1, !dbg !56383, !alias.scope !56384, !noalias !56364, !noundef !4137
  call void @__sanitizer_cov_trace_const_cmp1(i8 46, i8 %_12.i.i.i.i.i.i), !dbg !56383
  %_11.i.i.i.i.i.i = icmp eq i8 %_12.i.i.i.i.i.i, 46, !dbg !56383
  br i1 %_11.i.i.i.i.i.i, label %.bb4.i.i.i.i.i.i_crit_edge, label %bb10.i.i.i.i.i.i, !dbg !56383

.bb4.i.i.i.i.i.i_crit_edge:                       ; preds = %328
  %329 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 75), align 1, !dbg !56383, !nosanitize !4137
  %330 = add i8 %329, 1, !dbg !56383
  store i8 %330, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 75), align 1, !dbg !56383, !nosanitize !4137
  br label %bb4.i.i.i.i.i.i, !dbg !56383

bb10.i.i.i.i.i.i:                                 ; preds = %328
  %331 = add nuw nsw i64 %i.sroa.0.09.i.i.i.i.i.i, 1, !dbg !56387
  %exitcond.not.i.i.i.i.i.i = icmp eq i64 %331, %new_len.i.i.i.i.i, !dbg !56361
  br i1 %exitcond.not.i.i.i.i.i.i, label %bb10.i.i.i.i.i.i._RNvNtNtCshZBO5P2NUJi_4core5slice6memchr6memchr.exit.i.i.i.i.i_crit_edge, label %bb10.i.i.i.i.i.i.bb8.i.i.i.i.i.i_crit_edge, !dbg !56361

bb10.i.i.i.i.i.i.bb8.i.i.i.i.i.i_crit_edge:       ; preds = %bb10.i.i.i.i.i.i
  %332 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 76), align 1, !dbg !56361, !nosanitize !4137
  %333 = add i8 %332, 1, !dbg !56361
  store i8 %333, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 76), align 1, !dbg !56361, !nosanitize !4137
  br label %bb8.i.i.i.i.i.i, !dbg !56361

bb10.i.i.i.i.i.i._RNvNtNtCshZBO5P2NUJi_4core5slice6memchr6memchr.exit.i.i.i.i.i_crit_edge: ; preds = %bb10.i.i.i.i.i.i
  %334 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 77), align 1, !dbg !56361, !nosanitize !4137
  %335 = add i8 %334, 1, !dbg !56361
  store i8 %335, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 77), align 1, !dbg !56361, !nosanitize !4137
  br label %_RNvNtNtCshZBO5P2NUJi_4core5slice6memchr6memchr.exit.i.i.i.i.i, !dbg !56361

_RNvNtNtCshZBO5P2NUJi_4core5slice6memchr6memchr.exit.i.i.i.i.i: ; preds = %bb10.i.i.i.i.i.i._RNvNtNtCshZBO5P2NUJi_4core5slice6memchr6memchr.exit.i.i.i.i.i_crit_edge, %bb4.i.i.i.i.i.i._RNvNtNtCshZBO5P2NUJi_4core5slice6memchr6memchr.exit.i.i.i.i.i_crit_edge, %bb2.i13.i.i.i.i.i._RNvNtNtCshZBO5P2NUJi_4core5slice6memchr6memchr.exit.i.i.i.i.i_crit_edge, %bb6.preheader.i.i.i.i.i.i._RNvNtNtCshZBO5P2NUJi_4core5slice6memchr6memchr.exit.i.i.i.i.i_crit_edge
  %result.sroa.5.1.i.i.i.i.i.i = phi i64 [ %result.sroa.5.0.i.i.i.i.i.i, %bb4.i.i.i.i.i.i._RNvNtNtCshZBO5P2NUJi_4core5slice6memchr6memchr.exit.i.i.i.i.i_crit_edge ], [ %300, %bb2.i13.i.i.i.i.i._RNvNtNtCshZBO5P2NUJi_4core5slice6memchr6memchr.exit.i.i.i.i.i_crit_edge ], [ undef, %bb6.preheader.i.i.i.i.i.i._RNvNtNtCshZBO5P2NUJi_4core5slice6memchr6memchr.exit.i.i.i.i.i_crit_edge ], [ undef, %bb10.i.i.i.i.i.i._RNvNtNtCshZBO5P2NUJi_4core5slice6memchr6memchr.exit.i.i.i.i.i_crit_edge ], !dbg !56377
  %result.sroa.0.1.i.i.i.i.i.i = phi i64 [ %result.sroa.0.0.i.i.i.i.i.i, %bb4.i.i.i.i.i.i._RNvNtNtCshZBO5P2NUJi_4core5slice6memchr6memchr.exit.i.i.i.i.i_crit_edge ], [ 0, %bb2.i13.i.i.i.i.i._RNvNtNtCshZBO5P2NUJi_4core5slice6memchr6memchr.exit.i.i.i.i.i_crit_edge ], [ 0, %bb6.preheader.i.i.i.i.i.i._RNvNtNtCshZBO5P2NUJi_4core5slice6memchr6memchr.exit.i.i.i.i.i_crit_edge ], [ 0, %bb10.i.i.i.i.i.i._RNvNtNtCshZBO5P2NUJi_4core5slice6memchr6memchr.exit.i.i.i.i.i_crit_edge ], !dbg !56377
  %336 = trunc nuw i64 %result.sroa.0.1.i.i.i.i.i.i to i1, !dbg !56388
  br i1 %336, label %bb4.i.i.i.i.i, label %_RNvNtNtCshZBO5P2NUJi_4core5slice6memchr6memchr.exit.i.i.i.i.i.bb6.i.i.i.i_crit_edge, !dbg !56388

_RNvNtNtCshZBO5P2NUJi_4core5slice6memchr6memchr.exit.i.i.i.i.i.bb6.i.i.i.i_crit_edge: ; preds = %_RNvNtNtCshZBO5P2NUJi_4core5slice6memchr6memchr.exit.i.i.i.i.i
  %337 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 78), align 1, !dbg !56388, !nosanitize !4137
  %338 = add i8 %337, 1, !dbg !56388
  store i8 %338, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 78), align 1, !dbg !56388, !nosanitize !4137
  br label %bb6.i.i.i.i, !dbg !56388

bb4.i.i.i.i.i:                                    ; preds = %_RNvNtNtCshZBO5P2NUJi_4core5slice6memchr6memchr.exit.i.i.i.i.i
  %_16.i.i.i.i.i = add i64 %295, 1, !dbg !56389
  %339 = add i64 %_16.i.i.i.i.i, %result.sroa.5.1.i.i.i.i.i.i, !dbg !56390
  %340 = add i64 %295, %result.sroa.5.1.i.i.i.i.i.i, !dbg !56391
  call void @__sanitizer_cov_trace_cmp8(i64 %340, i64 %name.1), !dbg !56391
  %or.cond88.not = icmp ult i64 %340, %name.1, !dbg !56391
  br i1 %or.cond88.not, label %bb31.i.i.i.i.i, label %bb4.i.i.i.i.i.bb10.i.i.i.i.i_crit_edge, !dbg !56391

bb4.i.i.i.i.i.bb10.i.i.i.i.i_crit_edge:           ; preds = %bb4.i.i.i.i.i
  %341 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 79), align 1, !dbg !56391, !nosanitize !4137
  %342 = add i8 %341, 1, !dbg !56391
  store i8 %342, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 79), align 1, !dbg !56391, !nosanitize !4137
  br label %bb10.i.i.i.i.i, !dbg !56391

bb10.i.i.i.i.i:                                   ; preds = %.bb10.i.i.i.i.i_crit_edge, %bb4.i.i.i.i.i.bb10.i.i.i.i.i_crit_edge
  %_42.i.i.i.i.i = icmp ult i64 %name.1, %339, !dbg !56338
  br i1 %_42.i.i.i.i.i, label %bb10.i.i.i.i.i.bb6.i.i.i.i_crit_edge, label %bb10.i.i.i.i.i.bb18.i.i.i.i.i_crit_edge, !dbg !56338

bb10.i.i.i.i.i.bb18.i.i.i.i.i_crit_edge:          ; preds = %bb10.i.i.i.i.i
  %343 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 80), align 1, !dbg !56338, !nosanitize !4137
  %344 = add i8 %343, 1, !dbg !56338
  store i8 %344, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 80), align 1, !dbg !56338, !nosanitize !4137
  br label %bb18.i.i.i.i.i, !dbg !56338

bb10.i.i.i.i.i.bb6.i.i.i.i_crit_edge:             ; preds = %bb10.i.i.i.i.i
  %345 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 81), align 1, !dbg !56338, !nosanitize !4137
  %346 = add i8 %345, 1, !dbg !56338
  store i8 %346, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 81), align 1, !dbg !56338, !nosanitize !4137
  br label %bb6.i.i.i.i, !dbg !56338

bb31.i.i.i.i.i:                                   ; preds = %bb4.i.i.i.i.i
  %found_char.i.i.i.i.i = add i64 %result.sroa.5.1.i.i.i.i.i.i, %295, !dbg !56392
  %_61.i.i.i.i.i = getelementptr inbounds nuw i8, ptr %name.0, i64 %found_char.i.i.i.i.i, !dbg !56393
  %347 = ptrtoint ptr %_61.i.i.i.i.i to i64, !dbg !56402
  %348 = lshr i64 %347, 3, !dbg !56402
  %349 = add i64 %348, 2147450880, !dbg !56402
  %350 = inttoptr i64 %349 to ptr, !dbg !56402
  %351 = load i8, ptr %350, align 1, !dbg !56402
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %351), !dbg !56402
  %352 = icmp ne i8 %351, 0, !dbg !56402
  br i1 %352, label %355, label %bb31.i.i.i.i.i._crit_edge, !dbg !56402, !prof !4285

bb31.i.i.i.i.i._crit_edge:                        ; preds = %bb31.i.i.i.i.i
  %353 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 82), align 1, !dbg !56402, !nosanitize !4137
  %354 = add i8 %353, 1, !dbg !56402
  store i8 %354, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 82), align 1, !dbg !56402, !nosanitize !4137
  br label %364, !dbg !56402

355:                                              ; preds = %bb31.i.i.i.i.i
  %356 = and i64 %347, 7, !dbg !56402
  %357 = trunc i64 %356 to i8, !dbg !56402
  call void @__sanitizer_cov_trace_cmp1(i8 %357, i8 %351), !dbg !56402
  %358 = icmp sge i8 %357, %351, !dbg !56402
  br i1 %358, label %361, label %._crit_edge140, !dbg !56402

._crit_edge140:                                   ; preds = %355
  %359 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 83), align 1, !dbg !56402, !nosanitize !4137
  %360 = add i8 %359, 1, !dbg !56402
  store i8 %360, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 83), align 1, !dbg !56402, !nosanitize !4137
  br label %364, !dbg !56402

361:                                              ; preds = %355
  %362 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 84), align 1, !dbg !56402, !nosanitize !4137
  %363 = add i8 %362, 1, !dbg !56402
  store i8 %363, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 84), align 1, !dbg !56402, !nosanitize !4137
  call void @__asan_report_load1(i64 %347) #42, !dbg !56402
  unreachable

364:                                              ; preds = %._crit_edge140, %bb31.i.i.i.i.i._crit_edge
  %lhsc = load i8, ptr %_61.i.i.i.i.i, align 1, !dbg !56402
  call void @__sanitizer_cov_trace_const_cmp1(i8 46, i8 %lhsc), !dbg !56402
  %_27.i.i.i.i.i = icmp eq i8 %lhsc, 46, !dbg !56402
  br i1 %_27.i.i.i.i.i, label %bb7.i.i.i.i, label %.bb10.i.i.i.i.i_crit_edge, !dbg !56411

.bb10.i.i.i.i.i_crit_edge:                        ; preds = %364
  %365 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 85), align 1, !dbg !56411, !nosanitize !4137
  %366 = add i8 %365, 1, !dbg !56411
  store i8 %366, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 85), align 1, !dbg !56411, !nosanitize !4137
  br label %bb10.i.i.i.i.i, !dbg !56411

bb7.i.i.i.i:                                      ; preds = %364
  call void @__sanitizer_cov_trace_cmp8(i64 %found_char.i.i.i.i.i, i64 %.lcssa513.i.i), !dbg !56412
  %_4.i.i.i.i.i = icmp uge i64 %found_char.i.i.i.i.i, %.lcssa513.i.i, !dbg !56412
  call void @__sanitizer_cov_trace_cmp8(i64 %found_char.i.i.i.i.i, i64 %name.1), !dbg !56037
  %_5.i.i.i.i.i = icmp ule i64 %found_char.i.i.i.i.i, %name.1
  %or.cond.i.i.i.i.i = and i1 %_5.i.i.i.i.i, %_4.i.i.i.i.i, !dbg !56412
  br i1 %or.cond.i.i.i.i.i, label %_RNvNvXs5_NtNtCshZBO5P2NUJi_4core3str6traitsINtNtNtBb_3ops5range5RangejEINtNtNtBb_5slice5index10SliceIndexeE13get_unchecked18precondition_check.exit.i.i.i.i, label %bb3.i.i.i.i.i, !dbg !56412, !prof !7452

bb3.i.i.i.i.i:                                    ; preds = %bb7.i.i.i.i
  %367 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 86), align 1, !dbg !56427, !nosanitize !4137
  %368 = add i8 %367, 1, !dbg !56427
  store i8 %368, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 86), align 1, !dbg !56427, !nosanitize !4137
  call void @__asan_handle_no_return(), !dbg !56427
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCshZBO5P2NUJi_4core9panicking18panic_nounwind_fmt(ptr noundef nonnull @alloc_91f2a00ff2cd9cdc4bb205a66832e2bb, ptr noundef nonnull inttoptr (i64 439 to ptr), i1 noundef zeroext false, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_801dfecfd438b8fcd7a121f4442d14bb) #43, !dbg !56427, !noalias !56429
  unreachable, !dbg !56427

_RNvNvXs5_NtNtCshZBO5P2NUJi_4core3str6traitsINtNtNtBb_3ops5range5RangejEINtNtNtBb_5slice5index10SliceIndexeE13get_unchecked18precondition_check.exit.i.i.i.i: ; preds = %bb7.i.i.i.i
  %369 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 87), align 1, !dbg !56430, !nosanitize !4137
  %370 = add i8 %369, 1, !dbg !56430
  store i8 %370, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 87), align 1, !dbg !56430, !nosanitize !4137
  %new_len.i.i.i.i = sub nuw i64 %found_char.i.i.i.i.i, %.lcssa513.i.i, !dbg !56430
  %self1.i.i.i.i = getelementptr inbounds nuw i8, ptr %name.0, i64 %.lcssa513.i.i, !dbg !56431
  br label %_RNvXsY_NtNtCshZBO5P2NUJi_4core3str4iterINtB5_5SplitcENtNtNtNtB9_4iter6traits8iterator8Iterator4nextCsiKgSYIST2hs_15spiral_protocol.exit.i.i, !dbg !56435

bb6.i.i.i.i:                                      ; preds = %bb10.i.i.i.i.i.bb6.i.i.i.i_crit_edge, %_RNvNtNtCshZBO5P2NUJi_4core5slice6memchr6memchr.exit.i.i.i.i.i.bb6.i.i.i.i_crit_edge, %bb2.i.i.i.i.bb6.i.i.i.i_crit_edge
  %371 = phi i64 [ %290, %bb2.i.i.i.i.bb6.i.i.i.i_crit_edge ], [ %339, %bb10.i.i.i.i.i.bb6.i.i.i.i_crit_edge ], [ %name.1, %_RNvNtNtCshZBO5P2NUJi_4core5slice6memchr6memchr.exit.i.i.i.i.i.bb6.i.i.i.i_crit_edge ]
  call void @__sanitizer_cov_trace_cmp8(i64 %name.1, i64 %.lcssa513.i.i), !dbg !56436
  %_4.i.i.i.i.i.i.not = icmp ult i64 %name.1, %.lcssa513.i.i, !dbg !56436
  br i1 %_4.i.i.i.i.i.i.not, label %bb3.i.i.i.i.i.i, label %_RNvNvXs5_NtNtCshZBO5P2NUJi_4core3str6traitsINtNtNtBb_3ops5range5RangejEINtNtNtBb_5slice5index10SliceIndexeE13get_unchecked18precondition_check.exit.i.i.i.i.i, !dbg !56436, !prof !15906

bb3.i.i.i.i.i.i:                                  ; preds = %bb6.i.i.i.i
  %372 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 88), align 1, !dbg !56446, !nosanitize !4137
  %373 = add i8 %372, 1, !dbg !56446
  store i8 %373, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 88), align 1, !dbg !56446, !nosanitize !4137
  call void @__asan_handle_no_return(), !dbg !56446
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCshZBO5P2NUJi_4core9panicking18panic_nounwind_fmt(ptr noundef nonnull @alloc_91f2a00ff2cd9cdc4bb205a66832e2bb, ptr noundef nonnull inttoptr (i64 439 to ptr), i1 noundef zeroext false, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_801dfecfd438b8fcd7a121f4442d14bb) #43, !dbg !56446, !noalias !56447
  unreachable, !dbg !56446

_RNvNvXs5_NtNtCshZBO5P2NUJi_4core3str6traitsINtNtNtBb_3ops5range5RangejEINtNtNtBb_5slice5index10SliceIndexeE13get_unchecked18precondition_check.exit.i.i.i.i.i: ; preds = %bb6.i.i.i.i
  %374 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 89), align 1, !dbg !56450, !nosanitize !4137
  %375 = add i8 %374, 1, !dbg !56450
  store i8 %375, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 89), align 1, !dbg !56450, !nosanitize !4137
  %new_len.i4.i.i.i.i = sub nuw i64 %name.1, %.lcssa513.i.i, !dbg !56450
  %self2.i.i.i.i.i = getelementptr inbounds nuw i8, ptr %name.0, i64 %.lcssa513.i.i, !dbg !56451
  br label %_RNvXsY_NtNtCshZBO5P2NUJi_4core3str4iterINtB5_5SplitcENtNtNtNtB9_4iter6traits8iterator8Iterator4nextCsiKgSYIST2hs_15spiral_protocol.exit.i.i, !dbg !56455

_RNvXsY_NtNtCshZBO5P2NUJi_4core3str4iterINtB5_5SplitcENtNtNtNtB9_4iter6traits8iterator8Iterator4nextCsiKgSYIST2hs_15spiral_protocol.exit.i.i: ; preds = %bb1.i.i1._RNvXsY_NtNtCshZBO5P2NUJi_4core3str4iterINtB5_5SplitcENtNtNtNtB9_4iter6traits8iterator8Iterator4nextCsiKgSYIST2hs_15spiral_protocol.exit.i.i_crit_edge, %_RNvNvXs5_NtNtCshZBO5P2NUJi_4core3str6traitsINtNtNtBb_3ops5range5RangejEINtNtNtBb_5slice5index10SliceIndexeE13get_unchecked18precondition_check.exit.i.i.i.i.i, %_RNvNvXs5_NtNtCshZBO5P2NUJi_4core3str6traitsINtNtNtBb_3ops5range5RangejEINtNtNtBb_5slice5index10SliceIndexeE13get_unchecked18precondition_check.exit.i.i.i.i
  %376 = phi i64 [ %290, %bb1.i.i1._RNvXsY_NtNtCshZBO5P2NUJi_4core3str4iterINtB5_5SplitcENtNtNtNtB9_4iter6traits8iterator8Iterator4nextCsiKgSYIST2hs_15spiral_protocol.exit.i.i_crit_edge ], [ %339, %_RNvNvXs5_NtNtCshZBO5P2NUJi_4core3str6traitsINtNtNtBb_3ops5range5RangejEINtNtNtBb_5slice5index10SliceIndexeE13get_unchecked18precondition_check.exit.i.i.i.i ], [ %371, %_RNvNvXs5_NtNtCshZBO5P2NUJi_4core3str6traitsINtNtNtBb_3ops5range5RangejEINtNtNtBb_5slice5index10SliceIndexeE13get_unchecked18precondition_check.exit.i.i.i.i.i ]
  %.lcssa512.i.i = phi i64 [ %.lcssa513.i.i, %bb1.i.i1._RNvXsY_NtNtCshZBO5P2NUJi_4core3str4iterINtB5_5SplitcENtNtNtNtB9_4iter6traits8iterator8Iterator4nextCsiKgSYIST2hs_15spiral_protocol.exit.i.i_crit_edge ], [ %339, %_RNvNvXs5_NtNtCshZBO5P2NUJi_4core3str6traitsINtNtNtBb_3ops5range5RangejEINtNtNtBb_5slice5index10SliceIndexeE13get_unchecked18precondition_check.exit.i.i.i.i ], [ %.lcssa513.i.i, %_RNvNvXs5_NtNtCshZBO5P2NUJi_4core3str6traitsINtNtNtBb_3ops5range5RangejEINtNtNtBb_5slice5index10SliceIndexeE13get_unchecked18precondition_check.exit.i.i.i.i.i ]
  %377 = phi i1 [ true, %bb1.i.i1._RNvXsY_NtNtCshZBO5P2NUJi_4core3str4iterINtB5_5SplitcENtNtNtNtB9_4iter6traits8iterator8Iterator4nextCsiKgSYIST2hs_15spiral_protocol.exit.i.i_crit_edge ], [ false, %_RNvNvXs5_NtNtCshZBO5P2NUJi_4core3str6traitsINtNtNtBb_3ops5range5RangejEINtNtNtBb_5slice5index10SliceIndexeE13get_unchecked18precondition_check.exit.i.i.i.i ], [ true, %_RNvNvXs5_NtNtCshZBO5P2NUJi_4core3str6traitsINtNtNtBb_3ops5range5RangejEINtNtNtBb_5slice5index10SliceIndexeE13get_unchecked18precondition_check.exit.i.i.i.i.i ]
  %_0.sroa.4.1.i.i.i.i = phi i64 [ undef, %bb1.i.i1._RNvXsY_NtNtCshZBO5P2NUJi_4core3str4iterINtB5_5SplitcENtNtNtNtB9_4iter6traits8iterator8Iterator4nextCsiKgSYIST2hs_15spiral_protocol.exit.i.i_crit_edge ], [ %new_len.i.i.i.i, %_RNvNvXs5_NtNtCshZBO5P2NUJi_4core3str6traitsINtNtNtBb_3ops5range5RangejEINtNtNtBb_5slice5index10SliceIndexeE13get_unchecked18precondition_check.exit.i.i.i.i ], [ %new_len.i4.i.i.i.i, %_RNvNvXs5_NtNtCshZBO5P2NUJi_4core3str6traitsINtNtNtBb_3ops5range5RangejEINtNtNtBb_5slice5index10SliceIndexeE13get_unchecked18precondition_check.exit.i.i.i.i.i ], !dbg !56456
  %_0.sroa.0.1.i.i.i.i = phi ptr [ null, %bb1.i.i1._RNvXsY_NtNtCshZBO5P2NUJi_4core3str4iterINtB5_5SplitcENtNtNtNtB9_4iter6traits8iterator8Iterator4nextCsiKgSYIST2hs_15spiral_protocol.exit.i.i_crit_edge ], [ %self1.i.i.i.i, %_RNvNvXs5_NtNtCshZBO5P2NUJi_4core3str6traitsINtNtNtBb_3ops5range5RangejEINtNtNtBb_5slice5index10SliceIndexeE13get_unchecked18precondition_check.exit.i.i.i.i ], [ %self2.i.i.i.i.i, %_RNvNvXs5_NtNtCshZBO5P2NUJi_4core3str6traitsINtNtNtBb_3ops5range5RangejEINtNtNtBb_5slice5index10SliceIndexeE13get_unchecked18precondition_check.exit.i.i.i.i.i ], !dbg !56456
  %.not.i.i = icmp ne ptr %_0.sroa.0.1.i.i.i.i, null, !dbg !56457
  %378 = add i64 %_0.sroa.4.1.i.i.i.i, -1
  call void @__sanitizer_cov_trace_const_cmp8(i64 63, i64 %378), !dbg !56037
  %or.cond.i.i.i.i = icmp ult i64 %378, 63
  %or.cond.i.i = select i1 %.not.i.i, i1 %or.cond.i.i.i.i, i1 false, !dbg !56458
  br i1 %or.cond.i.i, label %bb4.i.i.i.i, label %_RINvYINtNtNtCshZBO5P2NUJi_4core3str4iter5SplitcENtNtNtNtBa_4iter6traits8iterator8Iterator8try_folduNCINvNvBK_3all5checkReNCNvNtCsiKgSYIST2hs_15spiral_protocol9handshake17validate_identity0E0INtNtNtBa_3ops12control_flow11ControlFlowuEEB21_.exit.loopexit9.i, !dbg !56458

bb4.i.i.i.i:                                      ; preds = %_RNvXsY_NtNtCshZBO5P2NUJi_4core3str4iterINtB5_5SplitcENtNtNtNtB9_4iter6traits8iterator8Iterator4nextCsiKgSYIST2hs_15spiral_protocol.exit.i.i
  %379 = ptrtoint ptr %_0.sroa.0.1.i.i.i.i to i64, !dbg !56459
  %380 = lshr i64 %379, 3, !dbg !56459
  %381 = add i64 %380, 2147450880, !dbg !56459
  %382 = inttoptr i64 %381 to ptr, !dbg !56459
  %383 = load i8, ptr %382, align 1, !dbg !56459
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %383), !dbg !56459
  %384 = icmp ne i8 %383, 0, !dbg !56459
  br i1 %384, label %387, label %bb4.i.i.i.i._crit_edge, !dbg !56459, !prof !4285

bb4.i.i.i.i._crit_edge:                           ; preds = %bb4.i.i.i.i
  %385 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 90), align 1, !dbg !56459, !nosanitize !4137
  %386 = add i8 %385, 1, !dbg !56459
  store i8 %386, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 90), align 1, !dbg !56459, !nosanitize !4137
  br label %396, !dbg !56459

387:                                              ; preds = %bb4.i.i.i.i
  %388 = and i64 %379, 7, !dbg !56459
  %389 = trunc i64 %388 to i8, !dbg !56459
  call void @__sanitizer_cov_trace_cmp1(i8 %389, i8 %383), !dbg !56459
  %390 = icmp sge i8 %389, %383, !dbg !56459
  br i1 %390, label %393, label %._crit_edge141, !dbg !56459

._crit_edge141:                                   ; preds = %387
  %391 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 91), align 1, !dbg !56459, !nosanitize !4137
  %392 = add i8 %391, 1, !dbg !56459
  store i8 %392, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 91), align 1, !dbg !56459, !nosanitize !4137
  br label %396, !dbg !56459

393:                                              ; preds = %387
  %394 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 92), align 1, !dbg !56459, !nosanitize !4137
  %395 = add i8 %394, 1, !dbg !56459
  store i8 %395, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 92), align 1, !dbg !56459, !nosanitize !4137
  call void @__asan_report_load1(i64 %379) #42, !dbg !56459
  unreachable

396:                                              ; preds = %._crit_edge141, %bb4.i.i.i.i._crit_edge
  %397 = load i8, ptr %_0.sroa.0.1.i.i.i.i, align 1, !dbg !56459, !alias.scope !56476, !noalias !56487, !noundef !4137
  %398 = add i8 %397, -48, !dbg !56459
  call void @__sanitizer_cov_trace_const_cmp1(i8 10, i8 %398), !dbg !56459
  %_3.sroa.0.0.i.i.i.i.i.i.i = icmp ult i8 %398, 10, !dbg !56459
  call void @__sanitizer_cov_trace_const_cmp1(i8 64, i8 %397), !dbg !56488
  %_7.i.i.i.i.i.i.i = icmp ugt i8 %397, 64, !dbg !56488
  call void @__sanitizer_cov_trace_const_cmp1(i8 91, i8 %397), !dbg !56488
  %_8.i.i.i.i.i.i.i = icmp ult i8 %397, 91, !dbg !56488
  %_6.sroa.0.0.i.i.i.i.i.i.i = select i1 %_7.i.i.i.i.i.i.i, i1 %_8.i.i.i.i.i.i.i, i1 %_3.sroa.0.0.i.i.i.i.i.i.i, !dbg !56488
  call void @__sanitizer_cov_trace_const_cmp1(i8 96, i8 %397), !dbg !56491
  %_10.i.i.i.i.i.i.i = icmp ugt i8 %397, 96, !dbg !56491
  call void @__sanitizer_cov_trace_const_cmp1(i8 123, i8 %397), !dbg !56491
  %_11.i.i.i.i.i.i.i = icmp ult i8 %397, 123, !dbg !56491
  %_9.sroa.0.0.i.i.i.i.i.i.i = select i1 %_10.i.i.i.i.i.i.i, i1 %_11.i.i.i.i.i.i.i, i1 %_6.sroa.0.0.i.i.i.i.i.i.i, !dbg !56491
  br i1 %_9.sroa.0.0.i.i.i.i.i.i.i, label %bb8.i.i.i.i, label %.bb32_crit_edge142, !dbg !56494

.bb32_crit_edge142:                               ; preds = %396
  %399 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 93), align 1, !dbg !56494, !nosanitize !4137
  %400 = add i8 %399, 1, !dbg !56494
  store i8 %400, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 93), align 1, !dbg !56494, !nosanitize !4137
  br label %bb32, !dbg !56494

bb8.i.i.i.i:                                      ; preds = %396
  %401 = getelementptr i8, ptr %_0.sroa.0.1.i.i.i.i, i64 %_0.sroa.4.1.i.i.i.i, !dbg !56495
  %last.i.i.i.i.i = getelementptr i8, ptr %401, i64 -1, !dbg !56495
  %.not.i3.i.i.i.i = icmp eq ptr %last.i.i.i.i.i, null, !dbg !56499
  br i1 %.not.i3.i.i.i.i, label %bb8.i.i.i.i.bb32_crit_edge, label %bb2.i4.i.i.i.i, !dbg !56501

bb8.i.i.i.i.bb32_crit_edge:                       ; preds = %bb8.i.i.i.i
  %402 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 94), align 1, !dbg !56501, !nosanitize !4137
  %403 = add i8 %402, 1, !dbg !56501
  store i8 %403, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 94), align 1, !dbg !56501, !nosanitize !4137
  br label %bb32, !dbg !56501

bb2.i4.i.i.i.i:                                   ; preds = %bb8.i.i.i.i
  %404 = ptrtoint ptr %last.i.i.i.i.i to i64, !dbg !56502
  %405 = lshr i64 %404, 3, !dbg !56502
  %406 = add i64 %405, 2147450880, !dbg !56502
  %407 = inttoptr i64 %406 to ptr, !dbg !56502
  %408 = load i8, ptr %407, align 1, !dbg !56502
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %408), !dbg !56502
  %409 = icmp ne i8 %408, 0, !dbg !56502
  br i1 %409, label %412, label %bb2.i4.i.i.i.i._crit_edge, !dbg !56502, !prof !4285

bb2.i4.i.i.i.i._crit_edge:                        ; preds = %bb2.i4.i.i.i.i
  %410 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 95), align 1, !dbg !56502, !nosanitize !4137
  %411 = add i8 %410, 1, !dbg !56502
  store i8 %411, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 95), align 1, !dbg !56502, !nosanitize !4137
  br label %421, !dbg !56502

412:                                              ; preds = %bb2.i4.i.i.i.i
  %413 = and i64 %404, 7, !dbg !56502
  %414 = trunc i64 %413 to i8, !dbg !56502
  call void @__sanitizer_cov_trace_cmp1(i8 %414, i8 %408), !dbg !56502
  %415 = icmp sge i8 %414, %408, !dbg !56502
  br i1 %415, label %418, label %._crit_edge143, !dbg !56502

._crit_edge143:                                   ; preds = %412
  %416 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 96), align 1, !dbg !56502, !nosanitize !4137
  %417 = add i8 %416, 1, !dbg !56502
  store i8 %417, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 96), align 1, !dbg !56502, !nosanitize !4137
  br label %421, !dbg !56502

418:                                              ; preds = %412
  %419 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 97), align 1, !dbg !56502, !nosanitize !4137
  %420 = add i8 %419, 1, !dbg !56502
  store i8 %420, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 97), align 1, !dbg !56502, !nosanitize !4137
  call void @__asan_report_load1(i64 %404) #42, !dbg !56502
  unreachable

421:                                              ; preds = %._crit_edge143, %bb2.i4.i.i.i.i._crit_edge
  %422 = load i8, ptr %last.i.i.i.i.i, align 1, !dbg !56502, !alias.scope !56505, !noalias !56487, !noundef !4137
  %423 = add i8 %422, -48, !dbg !56502
  call void @__sanitizer_cov_trace_const_cmp1(i8 10, i8 %423), !dbg !56502
  %_3.sroa.0.0.i.i.i5.i.i.i.i = icmp ult i8 %423, 10, !dbg !56502
  call void @__sanitizer_cov_trace_const_cmp1(i8 64, i8 %422), !dbg !56512
  %_7.i.i.i6.i.i.i.i = icmp ugt i8 %422, 64, !dbg !56512
  call void @__sanitizer_cov_trace_const_cmp1(i8 91, i8 %422), !dbg !56512
  %_8.i.i.i7.i.i.i.i = icmp ult i8 %422, 91, !dbg !56512
  %_6.sroa.0.0.i.i.i8.i.i.i.i = select i1 %_7.i.i.i6.i.i.i.i, i1 %_8.i.i.i7.i.i.i.i, i1 %_3.sroa.0.0.i.i.i5.i.i.i.i, !dbg !56512
  call void @__sanitizer_cov_trace_const_cmp1(i8 96, i8 %422), !dbg !56513
  %_10.i.i.i9.i.i.i.i = icmp ugt i8 %422, 96, !dbg !56513
  call void @__sanitizer_cov_trace_const_cmp1(i8 123, i8 %422), !dbg !56513
  %_11.i.i.i10.i.i.i.i = icmp ult i8 %422, 123, !dbg !56513
  %_9.sroa.0.0.i.i.i11.i.i.i.i = select i1 %_10.i.i.i9.i.i.i.i, i1 %_11.i.i.i10.i.i.i.i, i1 %_6.sroa.0.0.i.i.i8.i.i.i.i, !dbg !56513
  br i1 %_9.sroa.0.0.i.i.i11.i.i.i.i, label %bb12.i.i.i.i, label %.bb32_crit_edge144, !dbg !56514

.bb32_crit_edge144:                               ; preds = %421
  %424 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 98), align 1, !dbg !56514, !nosanitize !4137
  %425 = add i8 %424, 1, !dbg !56514
  store i8 %425, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 98), align 1, !dbg !56514, !nosanitize !4137
  br label %bb32, !dbg !56514

bb12.i.i.i.i:                                     ; preds = %421
  call void @llvm.assume(i1 true) [ "nonnull"(ptr %401) ]
  call void @__sanitizer_cov_trace_const_cmp8(i64 0, i64 %_0.sroa.4.1.i.i.i.i), !dbg !56515
  %_6.i.i.i.i.i.not.i.not.i.i.i103 = icmp eq i64 %_0.sroa.4.1.i.i.i.i, 0, !dbg !56515
  br i1 %_6.i.i.i.i.i.not.i.not.i.i.i103, label %bb12.i.i.i.i.bb1.i.i1.backedge_crit_edge, label %bb12.i.i.i.i.bb3.i.i.i.i.i.i.i.i_crit_edge, !dbg !56532

bb12.i.i.i.i.bb3.i.i.i.i.i.i.i.i_crit_edge:       ; preds = %bb12.i.i.i.i
  br label %bb3.i.i.i.i.i.i.i.i, !dbg !56532

bb12.i.i.i.i.bb1.i.i1.backedge_crit_edge:         ; preds = %bb12.i.i.i.i
  %426 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 99), align 1, !dbg !56532, !nosanitize !4137
  %427 = add i8 %426, 1, !dbg !56532
  store i8 %427, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 99), align 1, !dbg !56532, !nosanitize !4137
  br label %bb1.i.i1.backedge, !dbg !56532

bb1.i.i1.backedge:                                ; preds = %bb1.i.i.i.i.i.i.i.i.bb1.i.i1.backedge_crit_edge, %bb12.i.i.i.i.bb1.i.i1.backedge_crit_edge
  br label %bb1.i.i1, !dbg !56323

bb1.i.i.i.i.i.i.i.i:                              ; preds = %449
  %spec.select.i.i.i.i = getelementptr inbounds nuw i8, ptr %_16.i2.i.i.i.i.i.i.i.i104, i64 1, !dbg !56533
  %_6.i.i.i.i.i.not.i.not.i.i.i = icmp eq ptr %spec.select.i.i.i.i, %401, !dbg !56515
  br i1 %_6.i.i.i.i.i.not.i.not.i.i.i, label %bb1.i.i.i.i.i.i.i.i.bb1.i.i1.backedge_crit_edge, label %bb1.i.i.i.i.i.i.i.i.bb3.i.i.i.i.i.i.i.i_crit_edge, !dbg !56532

bb1.i.i.i.i.i.i.i.i.bb3.i.i.i.i.i.i.i.i_crit_edge: ; preds = %bb1.i.i.i.i.i.i.i.i
  %428 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 100), align 1, !dbg !56532, !nosanitize !4137
  %429 = add i8 %428, 1, !dbg !56532
  store i8 %429, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 100), align 1, !dbg !56532, !nosanitize !4137
  br label %bb3.i.i.i.i.i.i.i.i, !dbg !56532

bb1.i.i.i.i.i.i.i.i.bb1.i.i1.backedge_crit_edge:  ; preds = %bb1.i.i.i.i.i.i.i.i
  %430 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 101), align 1, !dbg !56532, !nosanitize !4137
  %431 = add i8 %430, 1, !dbg !56532
  store i8 %431, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 101), align 1, !dbg !56532, !nosanitize !4137
  br label %bb1.i.i1.backedge, !dbg !56532

bb3.i.i.i.i.i.i.i.i:                              ; preds = %bb1.i.i.i.i.i.i.i.i.bb3.i.i.i.i.i.i.i.i_crit_edge, %bb12.i.i.i.i.bb3.i.i.i.i.i.i.i.i_crit_edge
  %_16.i2.i.i.i.i.i.i.i.i104 = phi ptr [ %spec.select.i.i.i.i, %bb1.i.i.i.i.i.i.i.i.bb3.i.i.i.i.i.i.i.i_crit_edge ], [ %_0.sroa.0.1.i.i.i.i, %bb12.i.i.i.i.bb3.i.i.i.i.i.i.i.i_crit_edge ]
  %432 = ptrtoint ptr %_16.i2.i.i.i.i.i.i.i.i104 to i64, !dbg !56534
  %433 = lshr i64 %432, 3, !dbg !56534
  %434 = add i64 %433, 2147450880, !dbg !56534
  %435 = inttoptr i64 %434 to ptr, !dbg !56534
  %436 = load i8, ptr %435, align 1, !dbg !56534
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %436), !dbg !56534
  %437 = icmp ne i8 %436, 0, !dbg !56534
  br i1 %437, label %440, label %bb3.i.i.i.i.i.i.i.i._crit_edge, !dbg !56534, !prof !4285

bb3.i.i.i.i.i.i.i.i._crit_edge:                   ; preds = %bb3.i.i.i.i.i.i.i.i
  %438 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 102), align 1, !dbg !56534, !nosanitize !4137
  %439 = add i8 %438, 1, !dbg !56534
  store i8 %439, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 102), align 1, !dbg !56534, !nosanitize !4137
  br label %449, !dbg !56534

440:                                              ; preds = %bb3.i.i.i.i.i.i.i.i
  %441 = and i64 %432, 7, !dbg !56534
  %442 = trunc i64 %441 to i8, !dbg !56534
  call void @__sanitizer_cov_trace_cmp1(i8 %442, i8 %436), !dbg !56534
  %443 = icmp sge i8 %442, %436, !dbg !56534
  br i1 %443, label %446, label %._crit_edge145, !dbg !56534

._crit_edge145:                                   ; preds = %440
  %444 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 103), align 1, !dbg !56534, !nosanitize !4137
  %445 = add i8 %444, 1, !dbg !56534
  store i8 %445, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 103), align 1, !dbg !56534, !nosanitize !4137
  br label %449, !dbg !56534

446:                                              ; preds = %440
  %447 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 104), align 1, !dbg !56534, !nosanitize !4137
  %448 = add i8 %447, 1, !dbg !56534
  store i8 %448, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 104), align 1, !dbg !56534, !nosanitize !4137
  call void @__asan_report_load1(i64 %432) #42, !dbg !56534
  unreachable

449:                                              ; preds = %._crit_edge145, %bb3.i.i.i.i.i.i.i.i._crit_edge
  %elt.i.i.i.i.i.i.i.i.i = load i8, ptr %_16.i2.i.i.i.i.i.i.i.i104, align 1, !dbg !56534, !alias.scope !56538, !noalias !56541, !noundef !4137
  %450 = add i8 %elt.i.i.i.i.i.i.i.i.i, -123, !dbg !56550
  call void @__sanitizer_cov_trace_const_cmp1(i8 -26, i8 %450), !dbg !56550
  %_0.sroa.0.0.i.i.i.i.i.i.i.i.i.i.i.i = icmp ult i8 %450, -26, !dbg !56550
  %451 = add i8 %elt.i.i.i.i.i.i.i.i.i, -58, !dbg !56561
  call void @__sanitizer_cov_trace_const_cmp1(i8 -10, i8 %451), !dbg !56561
  %_0.sroa.0.0.i1.i.i.i.i.i.i.i.i.i.i.i = icmp ult i8 %451, -10, !dbg !56561
  call void @__sanitizer_cov_trace_const_cmp1(i8 45, i8 %elt.i.i.i.i.i.i.i.i.i), !dbg !56561
  %452 = icmp ne i8 %elt.i.i.i.i.i.i.i.i.i, 45, !dbg !56561
  %spec.select.i.not1.i.i.i.i.i.i.i.i.i.i = and i1 %452, %_0.sroa.0.0.i1.i.i.i.i.i.i.i.i.i.i.i, !dbg !56561
  %_0.sroa.0.0.i.not.i.i.i.i.i.i.i.i.i.i = and i1 %_0.sroa.0.0.i.i.i.i.i.i.i.i.i.i.i.i, %spec.select.i.not1.i.i.i.i.i.i.i.i.i.i, !dbg !56562
  br i1 %_0.sroa.0.0.i.not.i.i.i.i.i.i.i.i.i.i, label %.bb32_crit_edge146, label %bb1.i.i.i.i.i.i.i.i, !dbg !56563

.bb32_crit_edge146:                               ; preds = %449
  %453 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 105), align 1, !dbg !56563, !nosanitize !4137
  %454 = add i8 %453, 1, !dbg !56563
  store i8 %454, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 105), align 1, !dbg !56563, !nosanitize !4137
  br label %bb32, !dbg !56563

_RINvYINtNtNtCshZBO5P2NUJi_4core3str4iter5SplitcENtNtNtNtBa_4iter6traits8iterator8Iterator8try_folduNCINvNvBK_3all5checkReNCNvNtCsiKgSYIST2hs_15spiral_protocol9handshake17validate_identity0E0INtNtNtBa_3ops12control_flow11ControlFlowuEEB21_.exit.loopexit9.i: ; preds = %_RNvXsY_NtNtCshZBO5P2NUJi_4core3str4iterINtB5_5SplitcENtNtNtNtB9_4iter6traits8iterator8Iterator4nextCsiKgSYIST2hs_15spiral_protocol.exit.i.i
  br i1 %.not.i.i, label %_RINvYINtNtNtCshZBO5P2NUJi_4core3str4iter5SplitcENtNtNtNtBa_4iter6traits8iterator8Iterator8try_folduNCINvNvBK_3all5checkReNCNvNtCsiKgSYIST2hs_15spiral_protocol9handshake17validate_identity0E0INtNtNtBa_3ops12control_flow11ControlFlowuEEB21_.exit.loopexit9.i.bb32_crit_edge, label %bb10, !dbg !56564

_RINvYINtNtNtCshZBO5P2NUJi_4core3str4iter5SplitcENtNtNtNtBa_4iter6traits8iterator8Iterator8try_folduNCINvNvBK_3all5checkReNCNvNtCsiKgSYIST2hs_15spiral_protocol9handshake17validate_identity0E0INtNtNtBa_3ops12control_flow11ControlFlowuEEB21_.exit.loopexit9.i.bb32_crit_edge: ; preds = %_RINvYINtNtNtCshZBO5P2NUJi_4core3str4iter5SplitcENtNtNtNtBa_4iter6traits8iterator8Iterator8try_folduNCINvNvBK_3all5checkReNCNvNtCsiKgSYIST2hs_15spiral_protocol9handshake17validate_identity0E0INtNtNtBa_3ops12control_flow11ControlFlowuEEB21_.exit.loopexit9.i
  %455 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 106), align 1, !dbg !56564, !nosanitize !4137
  %456 = add i8 %455, 1, !dbg !56564
  store i8 %456, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 106), align 1, !dbg !56564, !nosanitize !4137
  br label %bb32, !dbg !56564

bb10:                                             ; preds = %_RINvYINtNtNtCshZBO5P2NUJi_4core3str4iter5SplitcENtNtNtNtBa_4iter6traits8iterator8Iterator8try_folduNCINvNvBK_3all5checkReNCNvNtCsiKgSYIST2hs_15spiral_protocol9handshake17validate_identity0E0INtNtNtBa_3ops12control_flow11ControlFlowuEEB21_.exit.loopexit9.i
  %457 = add i64 %26, 4, !dbg !56565
  %458 = inttoptr i64 %457 to ptr, !dbg !56565
  store i16 0, ptr %458, align 1, !dbg !56565
  %459 = add i64 %26, 6, !dbg !56565
  %460 = inttoptr i64 %459 to ptr, !dbg !56565
  store i8 1, ptr %460, align 1, !dbg !56565
; call <core::net::ip_addr::IpAddr as core::str::traits::FromStr>::from_str
  call void @_RNvXs0_NtNtCshZBO5P2NUJi_4core3net6parserNtNtB7_7ip_addr6IpAddrNtNtNtB9_3str6traits7FromStr8from_str(ptr noalias nofree noundef nonnull sret([17 x i8]) align 1 captures(address) dereferenceable(17) %21, ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) %name.0, i64 noundef %name.1) #35, !dbg !56566
  %461 = load i8, ptr %21, align 1, !dbg !56569, !range !6067, !alias.scope !56574, !noundef !4137
  call void @__sanitizer_cov_trace_const_cmp1(i8 2, i8 %461), !dbg !56569
  %.not = icmp ne i8 %461, 2, !dbg !56569
  %462 = add i64 %26, 4, !dbg !56577
  %463 = inttoptr i64 %462 to ptr, !dbg !56577
  store i16 -1800, ptr %463, align 1, !dbg !56577
  %464 = add i64 %26, 6, !dbg !56577
  %465 = inttoptr i64 %464 to ptr, !dbg !56577
  store i8 -8, ptr %465, align 1, !dbg !56577
  %466 = add i64 %service.1, -65
  call void @__sanitizer_cov_trace_const_cmp8(i64 -64, i64 %466), !dbg !56037
  %or.cond7 = icmp ult i64 %466, -64
  %or.cond105 = or i1 %.not, %or.cond7, !dbg !56565
  br i1 %or.cond105, label %bb10.bb32_crit_edge, label %bb21, !dbg !56565

bb10.bb32_crit_edge:                              ; preds = %bb10
  %467 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 107), align 1, !dbg !56565, !nosanitize !4137
  %468 = add i8 %467, 1, !dbg !56565
  store i8 %468, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 107), align 1, !dbg !56565, !nosanitize !4137
  br label %bb32, !dbg !56565

bb21:                                             ; preds = %bb10
  %469 = ptrtoint ptr %service.0 to i64, !dbg !56578
  %470 = lshr i64 %469, 3, !dbg !56578
  %471 = add i64 %470, 2147450880, !dbg !56578
  %472 = inttoptr i64 %471 to ptr, !dbg !56578
  %473 = load i8, ptr %472, align 1, !dbg !56578
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %473), !dbg !56578
  %474 = icmp ne i8 %473, 0, !dbg !56578
  br i1 %474, label %477, label %bb21._crit_edge, !dbg !56578, !prof !4285

bb21._crit_edge:                                  ; preds = %bb21
  %475 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 108), align 1, !dbg !56578, !nosanitize !4137
  %476 = add i8 %475, 1, !dbg !56578
  store i8 %476, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 108), align 1, !dbg !56578, !nosanitize !4137
  br label %486, !dbg !56578

477:                                              ; preds = %bb21
  %478 = and i64 %469, 7, !dbg !56578
  %479 = trunc i64 %478 to i8, !dbg !56578
  call void @__sanitizer_cov_trace_cmp1(i8 %479, i8 %473), !dbg !56578
  %480 = icmp sge i8 %479, %473, !dbg !56578
  br i1 %480, label %483, label %._crit_edge147, !dbg !56578

._crit_edge147:                                   ; preds = %477
  %481 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 109), align 1, !dbg !56578, !nosanitize !4137
  %482 = add i8 %481, 1, !dbg !56578
  store i8 %482, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 109), align 1, !dbg !56578, !nosanitize !4137
  br label %486, !dbg !56578

483:                                              ; preds = %477
  %484 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 110), align 1, !dbg !56578, !nosanitize !4137
  %485 = add i8 %484, 1, !dbg !56578
  store i8 %485, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 110), align 1, !dbg !56578, !nosanitize !4137
  call void @__asan_report_load1(i64 %469) #42, !dbg !56578
  unreachable

486:                                              ; preds = %._crit_edge147, %bb21._crit_edge
  %487 = load i8, ptr %service.0, align 1, !dbg !56578, !alias.scope !56580, !noundef !4137
  %488 = add i8 %487, -48, !dbg !56578
  call void @__sanitizer_cov_trace_const_cmp1(i8 10, i8 %488), !dbg !56578
  %_3.sroa.0.0.i = icmp ult i8 %488, 10, !dbg !56578
  call void @__sanitizer_cov_trace_const_cmp1(i8 64, i8 %487), !dbg !56583
  %_7.i = icmp ugt i8 %487, 64, !dbg !56583
  call void @__sanitizer_cov_trace_const_cmp1(i8 91, i8 %487), !dbg !56583
  %_8.i = icmp ult i8 %487, 91, !dbg !56583
  %_6.sroa.0.0.i = select i1 %_7.i, i1 %_8.i, i1 %_3.sroa.0.0.i, !dbg !56583
  call void @__sanitizer_cov_trace_const_cmp1(i8 96, i8 %487), !dbg !56584
  %_10.i = icmp ugt i8 %487, 96, !dbg !56584
  call void @__sanitizer_cov_trace_const_cmp1(i8 123, i8 %487), !dbg !56584
  %_11.i = icmp ult i8 %487, 123, !dbg !56584
  %_9.sroa.0.0.i = select i1 %_10.i, i1 %_11.i, i1 %_6.sroa.0.0.i, !dbg !56584
  br i1 %_9.sroa.0.0.i, label %bb25, label %.bb32_crit_edge148, !dbg !56585

.bb32_crit_edge148:                               ; preds = %486
  %489 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 111), align 1, !dbg !56585, !nosanitize !4137
  %490 = add i8 %489, 1, !dbg !56585
  store i8 %490, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 111), align 1, !dbg !56585, !nosanitize !4137
  br label %bb32, !dbg !56585

bb25:                                             ; preds = %486
  %_9.i = getelementptr inbounds nuw i8, ptr %service.0, i64 %service.1, !dbg !56586
  call void @__sanitizer_cov_trace_const_cmp8(i64 0, i64 %service.1), !dbg !56597
  %_6.i.i.i.i.i540.not = icmp samesign eq i64 %service.1, 0, !dbg !56597
  br i1 %_6.i.i.i.i.i540.not, label %bb25.bb32_crit_edge, label %bb3.i.i.i.i.preheader, !dbg !56610

bb25.bb32_crit_edge:                              ; preds = %bb25
  %491 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 112), align 1, !dbg !56610, !nosanitize !4137
  %492 = add i8 %491, 1, !dbg !56610
  store i8 %492, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 112), align 1, !dbg !56610, !nosanitize !4137
  br label %bb32, !dbg !56610

bb3.i.i.i.i.preheader:                            ; preds = %bb25
  %spec.select42 = getelementptr inbounds nuw i8, ptr %service.0, i64 1, !dbg !56611
  br label %bb3.i.i.i.i, !dbg !56612

bb1.critedge.i.i.i.i:                             ; preds = %bb7.i.i.i.i.i.i.i.bb1.critedge.i.i.i.i_crit_edge152, %bb7.i.i.i.i.i.i.i.bb1.critedge.i.i.i.i_crit_edge151, %bb7.i.i.i.i.i.i.i.bb1.critedge.i.i.i.i_crit_edge150, %bb7.i.i.i.i.i.i.i.bb1.critedge.i.i.i.i_crit_edge, %.bb1.critedge.i.i.i.i_crit_edge
  %_6.i.i.i.i.i5 = icmp ne ptr %spec.select45, %_9.i, !dbg !56597
  %spec.select.idx = zext i1 %_6.i.i.i.i.i5 to i64, !dbg !56611
  %spec.select = getelementptr inbounds nuw i8, ptr %spec.select45, i64 %spec.select.idx, !dbg !56611
  br i1 %_6.i.i.i.i.i5, label %bb1.critedge.i.i.i.i.bb3.i.i.i.i_crit_edge, label %bb1.critedge.i.i.i.i.bb32_crit_edge, !dbg !56610

bb1.critedge.i.i.i.i.bb32_crit_edge:              ; preds = %bb1.critedge.i.i.i.i
  %493 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 113), align 1, !dbg !56610, !nosanitize !4137
  %494 = add i8 %493, 1, !dbg !56610
  store i8 %494, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 113), align 1, !dbg !56610, !nosanitize !4137
  br label %bb32, !dbg !56610

bb1.critedge.i.i.i.i.bb3.i.i.i.i_crit_edge:       ; preds = %bb1.critedge.i.i.i.i
  %495 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 114), align 1, !dbg !56610, !nosanitize !4137
  %496 = add i8 %495, 1, !dbg !56610
  store i8 %496, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 114), align 1, !dbg !56610, !nosanitize !4137
  br label %bb3.i.i.i.i, !dbg !56610

bb3.i.i.i.i:                                      ; preds = %bb1.critedge.i.i.i.i.bb3.i.i.i.i_crit_edge, %bb3.i.i.i.i.preheader
  %spec.select45 = phi ptr [ %spec.select, %bb1.critedge.i.i.i.i.bb3.i.i.i.i_crit_edge ], [ %spec.select42, %bb3.i.i.i.i.preheader ]
  %_16.i2.i.i.i.i43 = phi ptr [ %spec.select45, %bb1.critedge.i.i.i.i.bb3.i.i.i.i_crit_edge ], [ %service.0, %bb3.i.i.i.i.preheader ]
  %497 = ptrtoint ptr %_16.i2.i.i.i.i43 to i64, !dbg !56620
  %498 = lshr i64 %497, 3, !dbg !56620
  %499 = add i64 %498, 2147450880, !dbg !56620
  %500 = inttoptr i64 %499 to ptr, !dbg !56620
  %501 = load i8, ptr %500, align 1, !dbg !56620
  call void @__sanitizer_cov_trace_const_cmp1(i8 0, i8 %501), !dbg !56620
  %502 = icmp ne i8 %501, 0, !dbg !56620
  br i1 %502, label %505, label %bb3.i.i.i.i._crit_edge, !dbg !56620, !prof !4285

bb3.i.i.i.i._crit_edge:                           ; preds = %bb3.i.i.i.i
  %503 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 115), align 1, !dbg !56620, !nosanitize !4137
  %504 = add i8 %503, 1, !dbg !56620
  store i8 %504, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 115), align 1, !dbg !56620, !nosanitize !4137
  br label %514, !dbg !56620

505:                                              ; preds = %bb3.i.i.i.i
  %506 = and i64 %497, 7, !dbg !56620
  %507 = trunc i64 %506 to i8, !dbg !56620
  call void @__sanitizer_cov_trace_cmp1(i8 %507, i8 %501), !dbg !56620
  %508 = icmp sge i8 %507, %501, !dbg !56620
  br i1 %508, label %511, label %._crit_edge149, !dbg !56620

._crit_edge149:                                   ; preds = %505
  %509 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 116), align 1, !dbg !56620, !nosanitize !4137
  %510 = add i8 %509, 1, !dbg !56620
  store i8 %510, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 116), align 1, !dbg !56620, !nosanitize !4137
  br label %514, !dbg !56620

511:                                              ; preds = %505
  %512 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 117), align 1, !dbg !56620, !nosanitize !4137
  %513 = add i8 %512, 1, !dbg !56620
  store i8 %513, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 117), align 1, !dbg !56620, !nosanitize !4137
  call void @__asan_report_load1(i64 %497) #42, !dbg !56620
  unreachable

514:                                              ; preds = %._crit_edge149, %bb3.i.i.i.i._crit_edge
  %elt.i.i.i.i.i = load i8, ptr %_16.i2.i.i.i.i43, align 1, !dbg !56620, !alias.scope !56621, !noalias !56624, !noundef !4137
  %515 = add i8 %elt.i.i.i.i.i, -97, !dbg !56633
  call void @__sanitizer_cov_trace_const_cmp1(i8 26, i8 %515), !dbg !56633
  %_0.sroa.0.0.i.i.i.i.i.i.i.i = icmp ult i8 %515, 26, !dbg !56633
  %516 = add i8 %elt.i.i.i.i.i, -48
  call void @__sanitizer_cov_trace_const_cmp1(i8 10, i8 %516), !dbg !56037
  %_0.sroa.0.0.i1.i.i.i.i.i.i.i = icmp ult i8 %516, 10
  %or.cond.i.i.i.i.i.i.i = or i1 %_0.sroa.0.0.i.i.i.i.i.i.i.i, %_0.sroa.0.0.i1.i.i.i.i.i.i.i, !dbg !56612
  br i1 %or.cond.i.i.i.i.i.i.i, label %.bb1.critedge.i.i.i.i_crit_edge, label %bb7.i.i.i.i.i.i.i, !dbg !56612

.bb1.critedge.i.i.i.i_crit_edge:                  ; preds = %514
  %517 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 118), align 1, !dbg !56612, !nosanitize !4137
  %518 = add i8 %517, 1, !dbg !56612
  store i8 %518, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 118), align 1, !dbg !56612, !nosanitize !4137
  br label %bb1.critedge.i.i.i.i, !dbg !56612

bb7.i.i.i.i.i.i.i:                                ; preds = %514
  %519 = zext i8 %elt.i.i.i.i.i to i64, !dbg !56635
  call void @__sanitizer_cov_trace_switch(i64 %519, ptr @__sancov_gen_cov_switch_values.2186), !dbg !56635
  switch i8 %elt.i.i.i.i.i, label %bb7.i.i.i.i.i.i.i.bb32_crit_edge [
    i8 46, label %bb7.i.i.i.i.i.i.i.bb1.critedge.i.i.i.i_crit_edge
    i8 95, label %bb7.i.i.i.i.i.i.i.bb1.critedge.i.i.i.i_crit_edge150
    i8 47, label %bb7.i.i.i.i.i.i.i.bb1.critedge.i.i.i.i_crit_edge151
    i8 45, label %bb7.i.i.i.i.i.i.i.bb1.critedge.i.i.i.i_crit_edge152
  ], !dbg !56635

bb7.i.i.i.i.i.i.i.bb1.critedge.i.i.i.i_crit_edge152: ; preds = %bb7.i.i.i.i.i.i.i
  %520 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 119), align 1, !dbg !56635, !nosanitize !4137
  %521 = add i8 %520, 1, !dbg !56635
  store i8 %521, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 119), align 1, !dbg !56635, !nosanitize !4137
  br label %bb1.critedge.i.i.i.i, !dbg !56635

bb7.i.i.i.i.i.i.i.bb1.critedge.i.i.i.i_crit_edge151: ; preds = %bb7.i.i.i.i.i.i.i
  %522 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 120), align 1, !dbg !56635, !nosanitize !4137
  %523 = add i8 %522, 1, !dbg !56635
  store i8 %523, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 120), align 1, !dbg !56635, !nosanitize !4137
  br label %bb1.critedge.i.i.i.i, !dbg !56635

bb7.i.i.i.i.i.i.i.bb1.critedge.i.i.i.i_crit_edge150: ; preds = %bb7.i.i.i.i.i.i.i
  %524 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 121), align 1, !dbg !56635, !nosanitize !4137
  %525 = add i8 %524, 1, !dbg !56635
  store i8 %525, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 121), align 1, !dbg !56635, !nosanitize !4137
  br label %bb1.critedge.i.i.i.i, !dbg !56635

bb7.i.i.i.i.i.i.i.bb1.critedge.i.i.i.i_crit_edge: ; preds = %bb7.i.i.i.i.i.i.i
  %526 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 122), align 1, !dbg !56635, !nosanitize !4137
  %527 = add i8 %526, 1, !dbg !56635
  store i8 %527, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 122), align 1, !dbg !56635, !nosanitize !4137
  br label %bb1.critedge.i.i.i.i, !dbg !56635

bb7.i.i.i.i.i.i.i.bb32_crit_edge:                 ; preds = %bb7.i.i.i.i.i.i.i
  %528 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 123), align 1, !dbg !56635, !nosanitize !4137
  %529 = add i8 %528, 1, !dbg !56635
  store i8 %529, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 123), align 1, !dbg !56635, !nosanitize !4137
  br label %bb32, !dbg !56635

bb32:                                             ; preds = %bb7.i.i.i.i.i.i.i.bb32_crit_edge, %bb1.critedge.i.i.i.i.bb32_crit_edge, %bb25.bb32_crit_edge, %.bb32_crit_edge148, %bb10.bb32_crit_edge, %_RINvYINtNtNtCshZBO5P2NUJi_4core3str4iter5SplitcENtNtNtNtBa_4iter6traits8iterator8Iterator8try_folduNCINvNvBK_3all5checkReNCNvNtCsiKgSYIST2hs_15spiral_protocol9handshake17validate_identity0E0INtNtNtBa_3ops12control_flow11ControlFlowuEEB21_.exit.loopexit9.i.bb32_crit_edge, %.bb32_crit_edge146, %.bb32_crit_edge144, %bb8.i.i.i.i.bb32_crit_edge, %.bb32_crit_edge142, %.bb32_crit_edge138, %.bb32_crit_edge136, %.bb32_crit_edge134, %.bb32_crit_edge132, %.bb32_crit_edge130, %.bb32_crit_edge128, %.bb32_crit_edge126, %.bb32_crit_edge124, %.bb32_crit_edge120, %_RNvNtNtNtCshZBO5P2NUJi_4core9core_arch3x864sse215__mm_loadu_si128.exit27.i.i.i.bb32_crit_edge, %.bb32_crit_edge
  %_0.sroa.0.0 = phi i8 [ 0, %.bb32_crit_edge124 ], [ 0, %.bb32_crit_edge ], [ 0, %_RINvYINtNtNtCshZBO5P2NUJi_4core3str4iter5SplitcENtNtNtNtBa_4iter6traits8iterator8Iterator8try_folduNCINvNvBK_3all5checkReNCNvNtCsiKgSYIST2hs_15spiral_protocol9handshake17validate_identity0E0INtNtNtBa_3ops12control_flow11ControlFlowuEEB21_.exit.loopexit9.i.bb32_crit_edge ], [ 0, %.bb32_crit_edge138 ], [ 0, %.bb32_crit_edge146 ], [ 0, %.bb32_crit_edge120 ], [ 0, %.bb32_crit_edge148 ], [ 0, %.bb32_crit_edge142 ], [ -1, %bb1.critedge.i.i.i.i.bb32_crit_edge ], [ 0, %bb10.bb32_crit_edge ], [ -1, %bb25.bb32_crit_edge ], [ 0, %bb7.i.i.i.i.i.i.i.bb32_crit_edge ], [ 0, %bb8.i.i.i.i.bb32_crit_edge ], [ 0, %.bb32_crit_edge144 ], [ 0, %.bb32_crit_edge136 ], [ 0, %.bb32_crit_edge134 ], [ 0, %.bb32_crit_edge132 ], [ 0, %.bb32_crit_edge130 ], [ 0, %.bb32_crit_edge128 ], [ 0, %.bb32_crit_edge126 ], [ 0, %_RNvNtNtNtCshZBO5P2NUJi_4core9core_arch3x864sse215__mm_loadu_si128.exit27.i.i.i.bb32_crit_edge ], !dbg !56644
  %530 = insertvalue { i8, i8 } poison, i8 %_0.sroa.0.0, 0, !dbg !56645
  %531 = insertvalue { i8, i8 } %530, i8 undef, 1, !dbg !56645
  store i64 1172321806, ptr %20, align 8, !dbg !56645
  call void @__sanitizer_cov_trace_const_cmp8(i64 0, i64 %11), !dbg !56645
  %532 = icmp ne i64 %11, 0, !dbg !56645
  br i1 %532, label %533, label %543, !dbg !56645

533:                                              ; preds = %bb32
  %534 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 124), align 1, !dbg !56645, !nosanitize !4137
  %535 = add i8 %534, 1, !dbg !56645
  store i8 %535, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 124), align 1, !dbg !56645, !nosanitize !4137
  %536 = add i64 %26, 0, !dbg !56645
  %537 = inttoptr i64 %536 to ptr, !dbg !56645
  store i64 -723401728380766731, ptr %537, align 1, !dbg !56645
  %538 = add i64 %26, 8, !dbg !56645
  %539 = inttoptr i64 %538 to ptr, !dbg !56645
  store i64 -723401728380766731, ptr %539, align 1, !dbg !56645
  %540 = getelementptr i8, ptr %12, i64 120, !dbg !56645
  %541 = load i64, ptr %540, align 8, !dbg !56645
  %542 = inttoptr i64 %541 to ptr, !dbg !56645
  store i8 0, ptr %542, align 1, !dbg !56645
  br label %550, !dbg !56645

543:                                              ; preds = %bb32
  %544 = load i8, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 125), align 1, !dbg !56645, !nosanitize !4137
  %545 = add i8 %544, 1, !dbg !56645
  store i8 %545, ptr getelementptr ([126 x i8], ptr @__sancov_gen_.2184, i64 0, i64 125), align 1, !dbg !56645, !nosanitize !4137
  %546 = add i64 %26, 0, !dbg !56645
  %547 = inttoptr i64 %546 to ptr, !dbg !56645
  store i64 0, ptr %547, align 1, !dbg !56645
  %548 = add i64 %26, 8, !dbg !56645
  %549 = inttoptr i64 %548 to ptr, !dbg !56645
  store i32 0, ptr %549, align 1, !dbg !56645
  br label %550, !dbg !56645

550:                                              ; preds = %543, %533
  ret { i8, i8 } %531, !dbg !56645
}

