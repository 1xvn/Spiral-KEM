Spiral KEM v0.3.1 — n=256, η=1 Attack-Cost Calculation Materials

Calculation date: 2026-10-21 UTC

After checking parameters in the attached v0.3.1 source, a pinned version of lattice-estimator was run under SageMath 10.8. Among selected general LWE attacks under the MATZOV classical cost model, the lowest estimate is approximately 2^120.876 for dual hybrid. The comparison Kyber512 public-key model (CBD(3)) under the same conditions is approximately 2^139.656. All results and original output are in `results/`.

These calculations evaluate heuristic attack work for the LWE problems appearing in public keys and ciphertext `u`. No experiment recovered actual operational keys, and no full KEM security proof was performed. No basis is provided for converting cost-model exponents directly into AES security bits, NIST levels, seconds, or dollars.

Target and parameters

The original filename is `spiral_kem_toy_v031(2).py`, copied without content changes to `source/spiral_kem_toy_v031.py`. Original SHA-256:

```text
898e540b4aded14e3710b591c6aa03a44bf5774c1d591f630e488b041655fd6c
```

| Item | Verified value |
|---|---|
| Polynomial ring | Z₃₃₂₉[x] / (x²⁵⁶ + 1) |
| Ring degree n | 256 |
| Module rank k | 2 |
| Modulus q | 3329 |
| Secret s and public-key error e | CBD(1) |
| Encryption secret r and errors e1, e2 | CBD(1) |
| CBD(1) coefficient probabilities | −1: 1/4, 0: 1/2, +1: 1/4 |
| Variance / standard deviation | 1/2 / √(1/2) ≈ 0.70710678 |
| Secret dimension expanded into general LWE | n×k = 512 |
| Scalar equations obtained from public key | n×k = 512 |
| Scalar equations obtained from ciphertext u | n×k = 512 |

Estimator input is as follows. Here `n=512` does not change the source's ring degree 256; it is the dimension after expanding the coefficients of two polynomials.

```python
params = LWE.Parameters(
    n=512, q=3329,
    Xs=ND.CenteredBinomial(1),
    Xe=ND.CenteredBinomial(1),
    m=512,
)
```

Each polynomial multiplication in public-key equation `t=A·s+e` was expanded into a negacyclic matrix. The multiplication matrix for coefficients a has `a[i-j]` for i≥j and `-a[256+i-j]` for i<j. `verify_model.py` uses this independent scalar formula to check agreement with the public key computed by the actual source. Ciphertext `u=Aᵀ·r+e1` was also independently expanded and checked starting with the transpose of A over the ring. This check does not directly reuse the optimized polynomial multiplication function.

Because both problems have identical general LWE inputs, one parameter-estimation result was mapped to both paths. Two independent attack experiments were not performed. Recovering r would allow decrypting the message from `v−tᵀr`, but that recovery was not actually performed. v, whose message is unknown, was not counted as 256 additional general LWE equations.

Execution scope and reading results

| Scenario | Attacks run | Meaning |
|---|---|---|
| MATZOV classical | uSVP, BDD, dual, dual hybrid, BDD hybrid, BDD MITM hybrid, BKW, Arora-GB | Applies RC.MATZOV list_decoding-classical cost to lattice attacks |
| Core-SVP classical | uSVP, dual hybrid | Sensitivity to ADPS16 classical reduction cost 2^(0.292β) |
| Core-SVP quantum | uSVP | Sensitivity to ADPS16 quantum reduction cost 2^(0.265β) |

Each scenario was run on Spiral CBD(1) and comparison CBD(3), yielding 22 results in total. All 22 terminated normally; two Arora-GB runs returned Infinity. Infinity means that path returned no finite estimate, not proof that an attack is impossible.

Primal attack lattice shape was fixed to GSA. Dual attacks use upstream's own formulas. BKW and Arora-GB use neither lattice-reduction cost functions nor GSA. `model`, `reduction_model`, and `shape_model` in original metadata describe scenario settings; not every attack uses those settings. Actual function calls are specified in `run_estimates.py`.

Success probabilities and distinguishing advantages use each upstream function's default assumptions. The results were not measured or normalized to the same experimental success rate for all attacks.

MATZOV models reduction and sieving work costs and overhead; Core-SVP treats reduction cost as a simple exponent. Estimator documentation describes rop as operation count, and reduction implementations include gate-cost approximations. This was not mapped one-to-one to actual CPU cycles. Results from different cost models must not be combined into one security-bit interval. In particular, one Core-SVP quantum uSVP result does not mean the minimum cost of all quantum attacks.

In original `raw_fields`, `eta` may be an internal attack parameter for BDD or other attacks. It must be distinguished from KEM noise parameter η=1. Returned `m`, `N`, and `mem` also follow attack-specific definitions. BKW internally amplifies samples from input m=512, so returned m becomes very large. dual hybrid's N is not a byte count, and this path does not return total memory mem. No claim is made that unlimited memory was actually provisioned.

During execution, comparison parameters were checked against this commit's `schemes.Kyber512`. These calculations also match four rounded representative results in upstream's README. This is a cross-check of estimator execution settings. It is not grounds for treating Spiral as ML-KEM or claiming equivalent security to full ML-KEM.

Assumptions and remaining analysis

1. Actual A is a structured matrix with negacyclic blocks. It does not generate all independent uniform 512×512 matrices. These calculations apply general LWE lattice-attack heuristics to this Module-LWE structure. Additional attacks exploiting special ring/module structure were not evaluated.
2. CBD probabilities describe the distribution when SHAKE output bits are modeled as independent pseudorandom values. Actual s and e expand the same 256-bit seed under different domains. Thus, the Shannon entropy of 512 coefficients cannot be treated as actual secret-seed entropy. Separate attacks exploiting seed structure were not evaluated.
3. Cost minimization gives values returned by the pinned upstream implementation and its search heuristics. It is not a proof of global optimality over all possible algorithms or internal parameters. Costs of dual-family distinguishing attacks were not equated with complete KEM secret-key recovery costs.
4. Actual error probability, the full FO/CCA transform, additional information in ciphertext v, attacks combining multiple targets or many ciphertexts, and side channels such as timing and cache behavior are outside this calculation's scope.
5. The comparison found that small η lowers attack costs in the same general LWE model. Claims of commercial security require parameter review against a target security level and independent analysis of the full protocol. No conclusion was drawn that changing η alone completes commercial readiness.

How to reproduce

Lattice-estimator commit used for the calculations:

```text
e4333d9bf9ef42fd8a29651b0c559fba7ce0d834
```

`vendor/lattice-estimator/` is an unmodified source snapshot of this commit. The Git repository need not be downloaded again. The runner verifies per-file SHA-256 hashes of the target source and snapshot before calculating.

If SageMath is already installed, use `python` in the activated Sage environment. This conda-forge environment used `micromamba run ... python` instead of `sage -python`. Current system Python alone cannot use the Sage dependencies.

Assuming micromamba is installed, run the following in the extracted directory. Path variables are set relative to the current directory.

```bash
TASK_ROOT="$PWD"
TASK_ENV="$TASK_ROOT/sage-env"
micromamba create --yes --prefix "$TASK_ENV" --strict-channel-priority --file environment.yml
micromamba run --prefix "$TASK_ENV" python verify_model.py
micromamba run --prefix "$TASK_ENV" python run_estimates.py --jobs 2 --timeout 300 --out rerun-results
python3 summarize_results.py rerun-results
```

New output is saved in `rerun-results`, preserving submitted `results/` originals. Increase `--timeout` on environments where estimator jobs need more time. Original stdout/stderr is recorded in per-job files during calculation; failures and timeouts are also retained in JSON and exit codes. There is no code sending actual keys or test seeds externally.

An alternative using the same Linux package builds as this run is shown below.

```bash
micromamba create --yes --prefix "$TASK_ENV" --file environment-linux-64.explicit.txt
```

The two installation commands are alternatives. The explicit file pins 386 package URLs and MD5 hashes from the actual environment; additional SHA-256 hashes are in `environment-packages.json`. This environment includes x86-64-v4 packages, so the CPU and platform must match. On other platforms, use `environment.yml`, though slight numerical differences may occur. The Sage environment itself is not included in the archive.

To verify results only, the following command works without Sage to check consistency among originals, source hashes, Core-SVP formulas, and comparison example results, and regenerate tables.

```bash
python3 summarize_results.py
sha256sum --check SHA256SUMS
```

SHA256SUMS checks files as submitted. If rerunning changed result files, they may differ from submission-time hashes. Calculation durations and start times vary by machine; numerical model reproduction and full-file byte agreement are separate matters.

File guide

| File | Contents |
|---|---|
| `run_estimates.py` | Actual cost-calculation code run; executes each job in a separate process |
| `verify_model.py` | Checks source CBD(1) and matrix expansions for public keys and ciphertext u |
| `summarize_results.py` | Checks originals and generates CSV and Korean results tables |
| `results/RESULTS.md` | Numerical results and key interpretations |
| `results/results.json` | All 22 results and complete execution settings |
| `results/raw/*.txt` | Calculation commands, metadata, original estimator output, stdout/stderr |
| `results/raw/*.json` | String representations and log₂ values of original cost fields |
| `results/summary.csv` | Comparison table of all calculations; blank cells indicate metrics not returned |
| `results/audit.json` | Verification results and minimum estimates by scenario |
| `controller-output.txt` | Job termination status and summary output |
| `model-verification.json` | Independent source→mathematical model verification results |
| `source/` | Copy of the evaluated original source |
| `vendor/`, `estimator-source-manifest.json` | Pinned estimator source and hashes |
| `environment*` | Reproduction environment settings and installed package lists |
| `SHA256SUMS` | Hash list for submitted-file integrity checks |
| `NOTICE.txt`, `GPL-3.txt`, `LGPL-3.txt` | Copyright and license notices for included upstream source |

Sources

- [Pinned Lattice-estimator commit](https://github.com/malb/lattice-estimator/tree/e4333d9bf9ef42fd8a29651b0c559fba7ce0d834): cost functions, attack implementations, comparison parameters, and README examples. The same source is included in this package.
- [MATZOV, Report on the Security of LWE: Improved Dual Lattice Attack (2022)](https://zenodo.org/records/6412487): reference for the MATZOV-family cost model used.
- [Alkim, Ducas, Pöppelmann, Schwabe, Post-quantum key exchange—a new hope (2016)](https://www.usenix.org/conference/usenixsecurity16/technical-sessions/presentation/alkim): ADPS16 model reference. Exact constants follow the included `estimator/reduction.py`.
- [SageMath conda-forge installation guide](https://doc.sagemath.org/html/en/installation/conda.html): reference for configuring the execution environment.
- [NIST FIPS 203](https://nvlpubs.nist.gov/nistpubs/FIPS/NIST.FIPS.203.pdf): reference for comparing standard ML-KEM parameters. These calculations confer neither standards compliance nor certification.
