#!/usr/bin/env python3
"""Audit the submitted raw files and regenerate human-readable result tables.

Uses only the Python standard library. It does not run lattice attacks or Sage.
"""
import csv
import hashlib
import json
import math
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
RESULTS = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else ROOT / "results"
document = json.loads((RESULTS / "results.json").read_text())
rows = document["results"]
expected = {tuple(job) for job in document["jobs"]}
seen = {(r["profile"], r["model"], r["attack"]) for r in rows}
assert len(rows) == len(seen) and seen == expected, "Missing or duplicate jobs"
assert all(r["status"] == "ok" for r in rows), "Some calculations did not finish"
for row in rows:
    assert (row["lwe_n"], row["lwe_m"], row["q"]) == (512, 512, 3329)
    key = "__".join((row["profile"], row["model"], row["attack"]))
    raw_json = RESULTS / "raw" / (key + ".json")
    raw = json.loads(raw_json.read_text())
    assert raw == {k: v for k, v in row.items() if k not in ("raw_log", "raw_json")}
    raw_log = (RESULTS / "raw" / (key + ".txt")).read_text()
    assert "RAW_COST_REPR " + row["raw_cost_repr"] in raw_log
    assert "CONTROLLER_TIMEOUT" not in raw_log
    if row["attack"] == "usvp" and row["model"].startswith("core_svp_"):
        coefficient = 0.265 if "quantum" in row["model"] else 0.292
        assert math.isclose(row["log2_metrics"]["rop"],
                            coefficient * int(row["raw_fields"]["beta"]),
                            rel_tol=0, abs_tol=1e-9)

source_hash = hashlib.sha256((ROOT / "source" / "spiral_kem_toy_v031.py").read_bytes()).hexdigest()
assert source_hash == document["target_sha256"]
manifest = json.loads((ROOT / "estimator-source-manifest.json").read_text())
assert manifest["commit"] == document["estimator_commit"]
for filename, expected_hash in manifest["files_sha256"].items():
    assert hashlib.sha256((ROOT / "vendor" / "lattice-estimator" / filename).read_bytes()).hexdigest() == expected_hash
verification = json.loads((ROOT / "model-verification.json").read_text())
assert verification["source_sha256"] == source_hash
assert verification["public_key_expansion_matches"] and verification["ciphertext_u_expansion_matches"]

def fetch(profile, model, attack):
    return next(r for r in rows if (r["profile"], r["model"], r["attack"]) == (profile, model, attack))

def number(value):
    return f"{value:.6f}" if isinstance(value, (float, int)) else str(value)

def cost(profile, model, attack):
    return number(fetch(profile, model, attack)["log2_metrics"]["rop"])

# These checks compare to the rounded examples shipped by the pinned upstream
# README, not to a separate implementation or a cryptographic proof.
reference_checks = {
    "matzov_usvp": ("matzov_classical", "usvp", 143.8),
    "matzov_dual_hybrid": ("matzov_classical", "dual_hybrid", 139.7),
    "core_usvp": ("core_svp_classical", "usvp", 118.6),
    "core_dual_hybrid": ("core_svp_classical", "dual_hybrid", 115.5),
}
for _, (model, attack, rounded) in reference_checks.items():
    assert round(fetch("kyber512_pk_reference_cbd3", model, attack)["log2_metrics"]["rop"], 1) == rounded

columns = ["profile", "model", "attack", "status", "log2_rop", "beta", "d",
           "log2_mem", "log2_N", "returned_m", "estimator_seconds", "raw_log"]
with (RESULTS / "summary.csv").open("w", encoding="utf-8", newline="") as stream:
    writer = csv.DictWriter(stream, fieldnames=columns)
    writer.writeheader()
    for row in rows:
        key = "__".join((row["profile"], row["model"], row["attack"]))
        writer.writerow(dict(
            profile=row["profile"], model=row["model"], attack=row["attack"], status=row["status"],
            log2_rop=number(row["log2_metrics"].get("rop", "")),
            beta=row["raw_fields"].get("beta", ""), d=row["raw_fields"].get("d", ""),
            log2_mem=number(row["log2_metrics"].get("mem", "")),
            log2_N=number(row["log2_metrics"].get("N", "")),
            returned_m=row["raw_fields"].get("m", ""),
            estimator_seconds=row["estimator_seconds"], raw_log="raw/" + key + ".txt"))

minimums = {}
for profile in sorted({r["profile"] for r in rows}):
    minimums[profile] = {}
    for model in sorted({r["model"] for r in rows if r["profile"] == profile}):
        candidates = [r for r in rows if r["profile"] == profile and r["model"] == model
                      and isinstance(r["log2_metrics"].get("rop"), (float, int))]
        best = min(candidates, key=lambda r: r["log2_metrics"]["rop"])
        minimums[profile][model] = dict(attack=best["attack"], log2_rop=best["log2_metrics"]["rop"],
                                     meaning="minimum among this run's selected completed finite estimates")

audit = dict(
    completed=len(rows), finite=sum(isinstance(r["log2_metrics"].get("rop"), (float, int)) for r in rows),
    infinite=sum(r["log2_metrics"].get("rop") == "Infinity" for r in rows),
    failed=0, timed_out=0, raw_json_and_logs_match=True,
    source_hash_verified=True, vendored_source_files_verified=len(manifest["files_sha256"]),
    core_svp_usvp_formula_checks=True, upstream_reference_rounded_examples_match=True,
    model_mapping_checks=True, minimums=minimums,
    caution="Heuristic work factors, not certified KEM security levels or actual key recovery."
)
(RESULTS / "audit.json").write_text(json.dumps(audit, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

s, k = "spiral_cbd1", "kyber512_pk_reference_cbd3"
text = [
    "Spiral KEM v0.3.1 estimation results — 2026-10-21 UTC\n",
    "Each b below is log₂ of the estimator-returned work rop; read the work as 2^b. It is not an actual attack duration, monetary charge, or established security level.\n",
    f"All {len(rows)} calculations completed, returning {audit['finite']} finite estimates and {audit['infinite']} Infinity values without timeouts or execution errors. Infinity means the model returned no finite cost.\n",
    "| Cost model and attack | Spiral CBD(1): log₂ rop | Comparison Kyber512 public key CBD(3): log₂ rop |",
    "|---|---:|---:|",
]
for model, attack, label in [
    ("matzov_classical", "dual_hybrid", "MATZOV classical / dual hybrid (lowest selected attack)"),
    ("matzov_classical", "bdd", "MATZOV classical / primal BDD"),
    ("matzov_classical", "usvp", "MATZOV classical / primal uSVP"),
    ("core_svp_classical", "dual_hybrid", "Core-SVP classical / dual hybrid (lowest of two attacks)"),
    ("core_svp_classical", "usvp", "Core-SVP classical / primal uSVP"),
    ("core_svp_quantum_primal", "usvp", "Core-SVP quantum / primal uSVP only"),
]:
    text.append(f"| {label} | {cost(s, model, attack)} | {cost(k, model, attack)} |")

text += [
    "\nCore-SVP simplifies the exponential component of lattice-reduction cost. Do not interpret it as a range or error bar in the same units as MATZOV. The quantum calculation does not search for the cheapest of all quantum attacks.\n",
    "Complete MATZOV scenario results:\n",
    "| Attack | Spiral log₂ rop | Comparison public key log₂ rop |",
    "|---|---:|---:|",
]
for attack in ("usvp", "bdd", "dual", "dual_hybrid", "bdd_hybrid", "bdd_mitm_hybrid", "bkw", "arora_gb"):
    text.append(f"| {attack} | {cost(s, 'matzov_classical', attack)} | {cost(k, 'matzov_classical', attack)} |")

delta = float(cost(k, "matzov_classical", "dual_hybrid")) - float(cost(s, "matzov_classical", "dual_hybrid"))
text += [
    f"\nThe exponent gap between these public-key estimates under the same dual hybrid / MATZOV model is approximately {delta:.2f}. This compares public-key problems with different error distributions; it does not replace a full-KEM or NIST security-category comparison.\n",
    "BKW and Arora-GB do not use the lattice-reduction cost function. Their inclusion in the matzov_classical calculation group does not mean MATZOV reduction costs apply to them.\n",
    "BKW's returned m is the quantity after internal sample amplification. Input samples were limited to 512. Raw results also retain the problem field reflecting the post-amplification error distribution.\n",
    "Spiral dual hybrid / MATZOV raw output:\n",
    "```text", fetch(s, "matzov_classical", "dual_hybrid")["raw_cost_repr"], "```\n",
    "Here N is a model quantity for samples/vectors required by an internal distinguishing stage, not the original public-key sample count m or a memory byte count. This path returns no total-memory mem field, so no GB/TB memory estimate is reported.\n",
    "Formula check: Spiral primal uSVP has β=345, giving Core-SVP classical exponent 0.292×345=100.74 and quantum exponent 0.265×345=91.425. summarize_results.py checks these formulas against the raw results.\n",
    "CSV estimator_seconds measures the estimator calculation's runtime, not an actual lattice attack.\n",
    "Model settings, limits and rerun instructions are in ../README.md; raw output is under raw/*.txt and raw/*.json; complete machine-readable results are in results.json.\n",
]
(RESULTS / "RESULTS.md").write_text("\n".join(text) + "\n", encoding="utf-8")
print(json.dumps(audit, ensure_ascii=False, indent=2))
