#!/usr/bin/env python3
"""Reproducible generic-LWE estimates; run with SageMath's Python.

This estimates attacks, not executes them. No KEM security certification is made.
The upstream estimator source is never patched. Each calculation has its own
process and raw stdout/stderr log. The controller records failures and timeouts.
"""
from __future__ import annotations

import argparse
import concurrent.futures
import datetime
import hashlib
import json
import math
import os
from pathlib import Path
import subprocess
import sys
import time
import traceback

ROOT = Path(__file__).resolve().parent
COMMIT = "e4333d9bf9ef42fd8a29651b0c559fba7ce0d834"
TARGET_SHA256 = "898e540b4aded14e3710b591c6aa03a44bf5774c1d591f630e488b041655fd6c"
FULL_ATTACKS = ("usvp", "bdd", "dual", "dual_hybrid", "bdd_hybrid",
                "bdd_mitm_hybrid", "bkw", "arora_gb")
PROFILES = {"spiral_cbd1": 1, "kyber512_pk_reference_cbd3": 3}
MODELS = {
    "matzov_classical": FULL_ATTACKS,
    "core_svp_classical": ("usvp", "dual_hybrid"),
    "core_svp_quantum_primal": ("usvp",),
}


def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2,
                               allow_nan=False) + "\n", encoding="utf-8")


def validate_sources(estimator_dir):
    source = ROOT / "source" / "spiral_kem_toy_v031.py"
    actual = hashlib.sha256(source.read_bytes()).hexdigest()
    if actual != TARGET_SHA256:
        raise RuntimeError("The supplied KEM does not match the assessed source hash")
    manifest = json.loads((ROOT / "estimator-source-manifest.json").read_text())
    if manifest["commit"] != COMMIT:
        raise RuntimeError("Estimator commit manifest mismatch")
    for relative, expected in manifest["files_sha256"].items():
        actual = hashlib.sha256((estimator_dir / relative).read_bytes()).hexdigest()
        if actual != expected:
            raise RuntimeError(f"Estimator source differs: {relative}")


def worker(args):
    estimator_dir = Path(args.estimator_dir).resolve()
    validate_sources(estimator_dir)
    sys.path.insert(0, str(estimator_dir))
    from sage.all import RR, log, oo
    from sage.env import SAGE_VERSION
    from estimator import LWE, ND, RC, schemes
    from estimator.reduction import ADPS16
    from estimator.lwe_guess import guess_composition

    eta = PROFILES[args.profile]
    params = LWE.Parameters(n=512, q=3329, Xs=ND.CenteredBinomial(eta),
                            Xe=ND.CenteredBinomial(eta), m=512,
                            tag=args.profile)
    if eta == 3:
        if params.updated(tag=schemes.Kyber512.tag) != schemes.Kyber512:
            raise RuntimeError("Reference differs from upstream schemes.Kyber512")
    if args.model == "matzov_classical":
        model = RC.MATZOV
    elif args.model == "core_svp_classical":
        model = ADPS16(mode="classical")
    else:
        model = ADPS16(mode="quantum")

    metadata = {
        "profile": args.profile, "model": args.model, "attack": args.attack,
        "estimator_commit": COMMIT, "sage_version": SAGE_VERSION,
        "python_version": sys.version, "source_sha256": TARGET_SHA256,
        "lwe_n": 512, "lwe_m": 512, "q": 3329,
        "secret_distribution": f"CenteredBinomial({eta})",
        "error_distribution": f"CenteredBinomial({eta})",
        "sigma": str(params.Xe.stddev), "shape_model": "GSA",
        "reduction_model": type(model).__name__,
        "reduction_model_state": {k: str(v) for k, v in vars(model).items()},
        "started_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    }
    print("METADATA", json.dumps(metadata, ensure_ascii=False), flush=True)
    print("PARAMETERS", repr(params), flush=True)
    common = dict(red_cost_model=model)
    started = time.perf_counter()
    if args.attack == "usvp":
        cost = LWE.primal_usvp(params, red_shape_model="gsa", **common)
    elif args.attack == "bdd":
        cost = LWE.primal_bdd(params, red_shape_model="gsa", **common)
    elif args.attack in ("bdd_hybrid", "bdd_mitm_hybrid"):
        use_mitm = args.attack == "bdd_mitm_hybrid"
        cost = LWE.primal_hybrid(params, mitm=use_mitm, babai=use_mitm,
                                red_shape_model="gsa", **common)
    elif args.attack == "dual":
        cost = LWE.dual(params, **common)
    elif args.attack == "dual_hybrid":
        cost = LWE.dual_hybrid(params, **common)
    elif args.attack == "bkw":
        cost = LWE.coded_bkw(params)
    else:
        cost = guess_composition(LWE.arora_gb)(params)
    seconds = time.perf_counter() - started
    print("RAW_COST_REPR", repr(cost), flush=True)
    print("RAW_FIELDS", repr(dict(cost)), flush=True)
    metrics = {}
    for key in ("rop", "red", "svp", "guess", "mem", "N", "m"):
        if key not in cost:
            continue
        value = cost[key]
        try:
            if value == oo:
                metrics[key] = "Infinity"
            elif value == 0:
                metrics[key] = "-Infinity"
            elif value > 0:
                metrics[key] = float(log(RR(value), 2))
        except (TypeError, ValueError):
            pass
    result = dict(metadata, status="ok", estimator_seconds=seconds,
                  raw_cost_repr=repr(cost),
                  raw_fields={str(k): str(v) for k, v in cost.items()},
                  log2_metrics=metrics)
    write_json(args.output, result)
    print("ELAPSED_SECONDS", seconds, flush=True)
    print("RESULT_FILE", args.output, flush=True)


def run_job(job, args):
    profile, model, attack = job
    job_id = f"{profile}__{model}__{attack}"
    output_dir = Path(args.out).resolve()
    result_path = output_dir / "raw" / f"{job_id}.json"
    log_path = output_dir / "raw" / f"{job_id}.txt"
    if args.resume and result_path.exists():
        old = json.loads(result_path.read_text())
        if old.get("status") == "ok":
            return old
    command = [sys.executable, str(Path(__file__).resolve()), "--worker",
               "--estimator-dir", str(Path(args.estimator_dir).resolve()),
               "--profile", profile, "--model", model, "--attack", attack,
               "--output", str(result_path)]
    log_path.parent.mkdir(parents=True, exist_ok=True)
    started = time.perf_counter()
    fallback = dict(profile=profile, model=model, attack=attack,
                    timeout_seconds=args.timeout, command=command)
    with log_path.open("w", encoding="utf-8") as stream:
        stream.write("COMMAND " + json.dumps(command) + "\n")
        stream.flush()
        try:
            completed = subprocess.run(command, stdout=stream,
                                       stderr=subprocess.STDOUT,
                                       timeout=args.timeout, check=False)
            if completed.returncode != 0:
                fallback.update(status="error", exit_code=completed.returncode)
                write_json(result_path, fallback)
        except subprocess.TimeoutExpired:
            fallback.update(status="timeout", elapsed_seconds=time.perf_counter()-started)
            write_json(result_path, fallback)
            stream.write("\nCONTROLLER_TIMEOUT\n")
    result = json.loads(result_path.read_text())
    result["raw_log"] = str(log_path.relative_to(output_dir))
    result["raw_json"] = str(result_path.relative_to(output_dir))
    print(job_id, result["status"], result.get("log2_metrics", {}), flush=True)
    return result


def controller(args):
    validate_sources(Path(args.estimator_dir).resolve())
    profiles = args.profiles.split(",") if args.profiles else list(PROFILES)
    models = args.models.split(",") if args.models else list(MODELS)
    selected_attacks = set(args.attacks.split(",")) if args.attacks else None
    jobs = [(p, m, a) for p in profiles for m in models for a in MODELS[m]
            if selected_attacks is None or a in selected_attacks]
    output_dir = Path(args.out).resolve()
    metadata = dict(estimator_commit=COMMIT, target_sha256=TARGET_SHA256,
                    jobs=jobs, max_parallel=args.jobs,
                    timeout_seconds=args.timeout, argv=sys.argv,
                    interpretation="Heuristic generic-LWE attack estimates; not KEM security bits")
    write_json(output_dir / "run-manifest.json", metadata)
    results = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=args.jobs) as pool:
        pending = {pool.submit(run_job, job, args): job for job in jobs}
        for future in concurrent.futures.as_completed(pending):
            results.append(future.result())
            results.sort(key=lambda row: (row["profile"], row["model"], row["attack"]))
            write_json(output_dir / "results.json", dict(metadata, results=results))
    return int(any(x["status"] != "ok" for x in results))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--estimator-dir", default=str(ROOT / "vendor" / "lattice-estimator"))
    parser.add_argument("--out", default=str(ROOT / "results"))
    parser.add_argument("--jobs", type=int, default=2)
    parser.add_argument("--timeout", type=int, default=300)
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--profiles")
    parser.add_argument("--models")
    parser.add_argument("--attacks")
    parser.add_argument("--worker", action="store_true", help=argparse.SUPPRESS)
    parser.add_argument("--profile", choices=PROFILES, help=argparse.SUPPRESS)
    parser.add_argument("--model", choices=MODELS, help=argparse.SUPPRESS)
    parser.add_argument("--attack", choices=FULL_ATTACKS, help=argparse.SUPPRESS)
    parser.add_argument("--output", help=argparse.SUPPRESS)
    args = parser.parse_args()
    if args.worker:
        worker(args)
        return 0
    return controller(args)


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception:
        traceback.print_exc()
        raise SystemExit(1)
