Spiral KEM v0.3.1 Calculation Results — 2026-10-21 UTC

The number b below is log₂ of the work rop returned by the estimator. Read work as 2^b. It does not mean actual attack time, billed cost, or a confirmed security classification.

All 22 calculations terminated normally, returning 20 finite estimates and 2 Infinity values. There were no timeouts or execution errors. Infinity means no finite cost was returned under that model.

| Cost model and attack | Spiral CBD(1): log₂ rop | Comparison Kyber512 public key CBD(3): log₂ rop |
|---|---:|---:|
| MATZOV classical / dual hybrid (lowest among selected attacks) | 120.875640 | 139.656041 |
| MATZOV classical / primal BDD | 123.537624 | 140.199473 |
| MATZOV classical / primal uSVP | 126.823073 | 143.771733 |
| Core-SVP classical / dual hybrid (lowest of 2 attacks) | 97.901991 | 115.509894 |
| Core-SVP classical / primal uSVP | 100.740000 | 118.552000 |
| Core-SVP quantum / only primal uSVP evaluated | 91.425000 | 107.590000 |

Core-SVP simplifies the exponential portion of lattice-reduction costs. It must not be interpreted as a range or error bar in the same units as MATZOV results. The quantum result is not an investigation of the minimum cost over all quantum attacks.

Full MATZOV scenario results:

| Attack | Spiral log₂ rop | Comparison public key log₂ rop |
|---|---:|---:|
| usvp | 126.823073 | 143.771733 |
| bdd | 123.537624 | 140.199473 |
| dual | 131.571253 | 149.884251 |
| dual_hybrid | 120.875640 | 139.656041 |
| bdd_hybrid | 123.563066 | 140.208243 |
| bdd_mitm_hybrid | 174.077792 | 262.070429 |
| bkw | 154.190230 | 178.760167 |
| arora_gb | Infinity | Infinity |

Under the same dual hybrid / MATZOV model, the exponent difference between the two public-key estimates is approximately 18.78. This compares public-key problems with different error distributions; it does not replace comparison of full KEMs or NIST security levels.

BKW and Arora-GB do not use lattice-reduction cost functions. Inclusion in the calculation group named matzov_classical does not mean these two attacks use MATZOV reduction costs.

BKW's returned m is the quantity after internal sample amplification. Input samples were limited to 512. The originals also retain the problem field with changed error after amplification.

Original Spiral dual hybrid / MATZOV output:

```text
rop: ≈2^120.9, red: ≈2^120.7, guess: ≈2^117.7, β: 319, p: 3, ζ: 20, t: 40, β': 327, N: ≈2^67.7, m: 512
```

Here N is a modeled sample/vector count needed for the internal distinguishing stage. It is neither the public key's original sample count m nor memory in bytes. This path does not return total memory mem, so no memory costs in GB/TB are reported.

Formula check: Spiral has β=345 in primal uSVP, so the Core-SVP classical exponent is 0.292×345=100.74 and the quantum exponent is 0.265×345=91.425. summarize_results.py checks agreement between these formulas and original results.

estimator_seconds in the CSV is the estimator's execution time for this calculation. It is not the time to execute an actual lattice attack.

Model settings, limitations, and rerun procedures are in ../README.md; originals are in raw/*.txt and raw/*.json; complete machine-readable results are in results.json.

