#!/usr/bin/env python3
"""Check the source-to-LWE mapping independently of the optimized ring product."""
import collections
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
from unittest.mock import patch

ROOT = Path(__file__).resolve().parent
source = ROOT / "source" / "spiral_kem_toy_v031.py"
spec = importlib.util.spec_from_file_location("assessed_spiral", source)
module = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = module
spec.loader.exec_module(module)
kem = module.SpiralKEM()
n, k, q = kem.p.n, kem.p.k, kem.p.q
if (n, k, q, kem.p.eta, kem.p.key_bytes) != (256, 2, 3329, 1, 32):
    raise RuntimeError("Unexpected source parameters")


def flat(vector):
    return tuple(x for poly in vector for x in poly)


def apply_expanded_matrix(matrix, vector):
    """Independent scalar matrix formula for multiplication modulo x^n+1."""
    vector = flat(vector)
    out = []
    for block_row in range(k):
        for i in range(n):
            value = 0
            for block_col in range(k):
                poly = matrix[block_row][block_col]
                for j in range(n):
                    coeff = poly[i-j] if i >= j else -poly[n+i-j]
                    value += coeff * vector[block_col*n+j]
            out.append(value % q)
    return tuple(out)


# Explicit synthetic fixtures. These are not production keys or RNG changes.
rho, sigma, z = bytes(range(32)), b"S"*32, b"Z"*32
message = bytes(range(32))
with patch.object(module.secrets, "token_bytes", side_effect=[rho, sigma, z]):
    pk, sk = kem.keygen()
matrix = kem._base_matrix(rho)
e = kem._small_vector(sigma, b"key/e")
expanded_as = apply_expanded_matrix(matrix, sk.s)
t_expected = tuple((a+b) % q for a, b in zip(expanded_as, flat(e)))
if t_expected != flat(pk.t):
    raise RuntimeError("Public-key scalar expansion does not match source")

coins = kem._coin_seed(pk, message)
r = kem._small_vector(coins, b"enc/r")
e1 = kem._small_vector(coins, b"enc/e1")
transposed = tuple(tuple(matrix[j][i] for j in range(k)) for i in range(k))
expanded_ar = apply_expanded_matrix(transposed, r)
ct = kem._encrypt_message(pk, message)
if tuple((a+b) % q for a, b in zip(expanded_ar, flat(e1))) != flat(ct.u):
    raise RuntimeError("Ciphertext-u scalar expansion does not match source")

counts = collections.Counter()
for positive in (0, 1):
    for negative in (0, 1):
        stream = bytes((positive, negative)) * n
        with patch.object(kem, "_xof", return_value=stream):
            sampled = kem._small_poly(b"test", b"test")
        expected = (positive-negative) % q
        if sampled != (expected,) * n:
            raise RuntimeError("CBD(1) bit mapping differs")
        counts[positive-negative] += 1

result = {
    "source_sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
    "ring_degree": n, "module_rank": k, "q": q,
    "scalar_secret_dimension": n*k, "public_key_scalar_equations": n*k,
    "ciphertext_u_scalar_equations": n*k,
    "public_key_expansion_matches": True, "ciphertext_u_expansion_matches": True,
    "ideal_independent_bits_cbd1_counts_out_of_4": dict(sorted(counts.items())),
    "ideal_variance": "1/2", "wire_minus_one": q-1,
    "assumptions_not_tests": [
        "SHAKE output bits across labels are modeled as independent pseudorandom bits.",
        "Generic LWE cost heuristics are applied to a structured Module-LWE instance.",
        "512 samples are available; this is not an unlimited-sample model.",
        "Ciphertext v adds information not included in this generic model.",
        "The bounded error polynomial e2 allows message decoding once r is recovered.",
    ],
}
output = ROOT / "model-verification.json"
output.write_text(json.dumps(result, ensure_ascii=False, indent=2)+"\n")
print(json.dumps(result, ensure_ascii=False, indent=2))
