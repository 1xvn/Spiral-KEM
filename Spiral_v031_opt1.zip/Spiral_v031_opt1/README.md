**Start with just this**

1. Extract the ZIP and open the `Spiral_v031_opt1` directory.
2. Open a terminal in that directory and run the following single line.

```powershell
py compare_spiral_opt1.py
```

No additional packages are required. Use Python 3.10 or later. It first verifies identical results between the original and improved implementations and runs the existing regression checks; if they pass, it measures each implementation 300 times.

Check the original → opt1 time and reduction rate under 'total' at the end. Results are saved to a new JSON file. Use these results to judge the speed improvement on Windows.

The improved implementation is `spiral_kem_toy_v031_opt1.py`; the comparison original is `spiral_kem_toy_v031.py`. You can compare them within this directory without overwriting existing project files. The improved implementation reduces repeated summation in one function that generates small secret values and errors.

The total median measured here on Linux was 13.553ms → 10.491ms, a time reduction of approximately 22.6%. Detailed conditions and verification results are in `RESULTS.md`; changes are in `opt1_changes.diff`.
