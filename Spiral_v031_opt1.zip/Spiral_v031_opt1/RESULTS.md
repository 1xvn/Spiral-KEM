**Spiral-KEM 0.3.1 opt1 — Performance improvement in one function**

Measurement completed: 2026-10-23 08:56:02 (Korea time). Both the original and opt1 in this table were measured afresh in the same Linux process.

| Including byte input/output | Original 0.3.1 | opt1 | Time reduction |
|---|---:|---:|---:|
| Key generation | 2.775 ms | 1.934 ms | 30.3% |
| Encapsulation | 4.449 ms | 3.416 ms | 23.2% |
| Decapsulation | 6.155 ms | 4.898 ms | 20.4% |
| All three stages | 13.553 ms | 10.491 ms | 22.6% |

Each received 30 warmups and 300 measurements. Implementation execution order was shuffled each round, and fresh keys were generated using OS randomness. The table reports medians; the total is the median after summing the three stages in each round. The CPU was not pinned, and GC remained enabled by default. Network time was excluded. Both implementations had 0/300 key mismatches, with 1,109-byte public keys, 1,589-byte ciphertexts, and 32-byte shared keys.

This environment differs from the earlier Windows measurements. Windows improvement can be measured by running the included tool for the original and opt1 on the same PC. Separate ML-KEM measurements were not mixed into this table.

**Changes and why behavior is preserved**

The executable code change is confined to `_small_poly`. Parameter validation already permits only eta=1. Therefore, the two sums for each coefficient are each the least significant bit of one byte, and the original expression equals `((positive & 1) - (negative & 1)) % q`. Computing this expression directly reduces the two sum/generator calls per coefficient and reads q as a local variable.

SHAKE input frames, output lengths, labels, byte consumption order, coefficient order, and modular arithmetic are preserved. VERSION and DOMAIN, parameters, key and ciphertext formats, input validation, reencryption checks, and fallback-key path code are identical. See `opt1_changes.diff` for the source differences. This improves performance of a research implementation and makes no new claims about security strength or constant-time Python execution.

**Verification actually run**

- AST comparison to verify executable code differs only in `_small_poly`: passed.
- Comparison of all 65,536 combinations of two input bytes and SHAKE call arguments: passed.
- Comparison of 864 seed/label combinations for supported n=8,16,32,64,128,256: passed.
- Comparison of 24 full exchanges using fixed test randomness: public keys, secret polynomials, ciphertexts, and shared keys matched; byte-format interoperability passed.
- 144 tampered ciphertexts in canonical format: confirmed the same fallback-key behavior as the original.
- Original 21 regression checks and opt1 21 regression checks: each passed with trials=50.
- 600 performance measurement records: execution order, total times, all summary statistics, and source hashes passed recalculation.

Fixed randomness was used only to generate test data. Both implementations used default OS randomness for performance measurements. Key, message, and ciphertext values generated in normal measurements were not saved to JSON. Agreement in 300 rounds does not prove a rare decryption-failure probability.

**Reproduction materials**

- Original actual measurement data: `Spiral_opt1_comparison_20261023_075602_51274e5a.json`
- Verification logs and environment: verification and environment in the JSON above
- Audit summary: `result_audit.json`
- Before/after measurement and automated verification: `py compare_spiral_opt1.py`
- Run verification only: `py verify_equivalence.py`
- Environment: `Linux-6.18.55-x86_64-with-glibc2.39`, CPython `3.12.14`, 9 logical CPUs.
- Original source SHA-256: `898e540b4aded14e3710b591c6aa03a44bf5774c1d591f630e488b041655fd6c`
- opt1 source SHA-256: `7ffb12c4494f92327bc560d4579731a642d749ec812e120ad955f6fc49391b51`

These commands use only Python 3.10 or later and the standard library. Each run generates a newly named JSON file, so the included Linux records are not overwritten.
