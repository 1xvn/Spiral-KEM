#!/usr/bin/env python3
"""Certified Chernoff arithmetic for ideal-independent-CBD decryption failure.

Run in SageMath. For one coefficient W=sum_{i=1}^{2nk} X_i Y_i + E,
all X_i,Y_i,E are modeled as independent CBD(eta). The integer noise identity
is checked against the KEM by verify_candidates.py. Coefficients of W are NOT
assumed independent; a union bound is used for all n message bits.
"""
from collections import Counter
import json
import math
from pathlib import Path
import sys
import numpy as np
from scipy.optimize import minimize_scalar
from scipy.special import logsumexp
from sage.all import QQ, RealIntervalField
from sage.env import SAGE_VERSION

ROOT=Path(__file__).resolve().parent
PROFILES=json.loads((ROOT/'profiles.json').read_text())
RI=RealIntervalField(256)

def certificate(interval):
    lo,hi=QQ(interval.lower()),QQ(interval.upper())
    return dict(lower_rational=str(lo),upper_rational=str(hi),
                lower_decimal=str(interval.lower()),upper_decimal=str(interval.upper()))

def compute(p):
    eta,n,k=p['eta'],p['n'],p['k']
    cbd={x:math.comb(2*eta,eta+x) for x in range(-eta,eta+1)}
    product=Counter()
    for x,wx in cbd.items():
        for y,wy in cbd.items():product[x*y]+=wx*wy
    denom_cbd=2**(2*eta);denom_product=denom_cbd**2
    assert sum(cbd.values())==denom_cbd and sum(product.values())==denom_product
    count=2*n*k
    products=np.array(sorted(product),dtype=float)
    lp=np.array([math.log(product[int(x)]/denom_product) for x in products])
    values=np.array(sorted(cbd),dtype=float)
    le=np.array([math.log(cbd[int(x)]/denom_cbd) for x in values])
    def log_mgf(t):
        return count*logsumexp(lp+products*t)+logsumexp(le+values*t)
    certificates={};bounds={}
    for threshold in (832,833):
        result=minimize_scalar(lambda t:log_mgf(t)-threshold*t,bounds=(0,16),method='bounded',options={'xatol':1e-14})
        t_num,t_den=float(result.x).as_integer_ratio()
        rational_t=QQ(t_num)/t_den
        assert rational_t>0
        t=RI(rational_t)
        # Float optimization selects t only. Every probability bound below
        # is recomputed using outward-rounded 256-bit interval arithmetic.
        my=sum((RI(weight)*(t*x).exp() for x,weight in product.items()),RI(0))/denom_product
        me=sum((RI(weight)*(t*x).exp() for x,weight in cbd.items()),RI(0))/denom_cbd
        bound=me*(my**count)*(-threshold*t).exp()
        assert bound.upper()<1 and bound.lower()>0
        bounds[threshold]=bound
        certificates[str(threshold)]=dict(threshold=threshold,positive_t_exact=str(rational_t),
            optimization_success=bool(result.success),chernoff_interval=certificate(bound),
            log2_interval=certificate(bound.log()/RI(2).log()))
    bit0=2*bounds[833]
    bit1=bounds[832]+bounds[833]
    # Bit 1 has the larger bound: decoding ties at residue 832 go to bit 0.
    total=n*bit1
    log2_total=total.log()/RI(2).log()
    exponent=int(log2_total.upper().ceil())
    return dict(parameters=p,cbd_integer_weights=cbd,cbd_denominator=denom_cbd,
        product_integer_weights=dict(sorted(product.items())),product_denominator=denom_product,
        independent_product_terms_per_coefficient=count,noise_variance=str(QQ(n*k*eta*eta+eta)/2),
        maximum_possible_abs_noise=count*eta*eta+eta,
        one_sided_tail_certificates=certificates,bit0_failure_upper=certificate(bit0),bit1_failure_upper=certificate(bit1),
        full_message_union_upper=certificate(total),log2_full_message_upper=float(log2_total.upper()),
        certified_binary_bound_exponent=exponent,certified_bound=f'P[key mismatch] <= 2^({exponent})',
        precision_bits=256,sage_version=SAGE_VERSION,python_version=sys.version,
        assumptions=['All s,e,r,e1,e2 coefficients modeled as independent CBD(eta)',
                     'SHAKE/coin derivation treated as ideal domain-separated pseudorandom expansion',
                     'One fresh honest key exchange, exact source arithmetic, no hardware faults',
                     'No independence assumption between different output coefficients'],
        interpretation='A model-conditional upper bound, not an exact probability or a fixed-SHAKE security proof')

results=[]
for name,p in PROFILES.items():
    result=compute(p);result['profile']=name;results.append(result)
    output=ROOT/'results/failure-bounds';output.mkdir(parents=True,exist_ok=True)
    (output/(name+'.json')).write_text(json.dumps(result,indent=2)+'\n')
    print(name,result['certified_bound'],'log2 bound',result['log2_full_message_upper'],flush=True)
(ROOT/'results/failure-bounds/summary.json').write_text(json.dumps(results,indent=2)+'\n')
