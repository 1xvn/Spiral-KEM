#!/usr/bin/env python3
"""Fresh synthetic key/message trials with public replay seeds; no attack timing."""
import argparse
from concurrent.futures import ProcessPoolExecutor, as_completed
import datetime
import hashlib
import json
import math
import secrets
import time
from unittest.mock import patch
from scipy.stats import beta
from common import ROOT, PROFILES, make_kem, fixture, write_json

def run_profile(name, count):
    module,kem=make_kem(name)
    out=ROOT/'results/correctness';out.mkdir(parents=True,exist_ok=True)
    failures=0;exceptions=0;sizes=None
    started=time.perf_counter()
    utc=datetime.datetime.now(datetime.timezone.utc).isoformat()
    with (out/(name+'.jsonl')).open('w') as stream:
        for i in range(count):
            seed=secrets.token_hex(32)
            row=dict(trial=i,fixture_seed_hex=seed)
            try:
                with patch.object(module.secrets,'token_bytes',side_effect=fixture(seed)):
                    pk,sk=kem.keygen();ct,key=kem.encapsulate(pk)
                pk_wire=kem.serialize_public_key(pk)
                ct_wire=kem.serialize_ciphertext(ct)
                _,receiver=make_kem(name)
                pk2=receiver.deserialize_public_key(pk_wire)
                ct2=receiver.deserialize_ciphertext(ct_wire)
                assert receiver.serialize_public_key(pk2)==pk_wire
                assert receiver.serialize_ciphertext(ct2)==ct_wire
                recovered=receiver.decapsulate(sk,ct2)
                failure=recovered!=key
                failures+=int(failure)
                now_sizes=(len(pk_wire),len(ct_wire))
                if sizes is None:sizes=now_sizes
                assert now_sizes==sizes
                row.update(key_mismatch=failure,pk_sha256=hashlib.sha256(pk_wire).hexdigest(),
                           ct_sha256=hashlib.sha256(ct_wire).hexdigest())
            except Exception as exc:
                exceptions+=1
                row.update(error=type(exc).__name__+': '+str(exc))
            stream.write(json.dumps(row,separators=(',',':'))+'\n')
            if (i+1)%250==0:stream.flush()
    valid_trials=count-exceptions
    upper=1.0 if failures==valid_trials else float(beta.ppf(.95,failures+1,valid_trials-failures))
    result=dict(profile=name,started_utc=utc,trials=count,key_mismatches=failures,exceptions=exceptions,
                one_sided_95pct_binomial_upper=upper,
                binomial_interval_assumption='iid trials under the pseudorandom fixture model; replay does not add samples',
                pk_bytes=sizes[0] if sizes else None,ct_bytes=sizes[1] if sizes else None,
                elapsed_test_seconds=time.perf_counter()-started,
                seeds_are_public_synthetic_test_material=True,raw_file=name+'.jsonl')
    write_json(out/(name+'.json'),result)
    return result

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--trials',type=int,default=2000);ap.add_argument('--jobs',type=int,default=2)
    args=ap.parse_args();results=[]
    with ProcessPoolExecutor(max_workers=args.jobs) as pool:
        fs=[pool.submit(run_profile,name,args.trials) for name in PROFILES]
        for f in as_completed(fs):
            r=f.result();results.append(r);results.sort(key=lambda x:x['profile'])
            write_json(ROOT/'results/correctness/summary.json',results)
            print(r['profile'],'failures',r['key_mismatches'],'exceptions',r['exceptions'],'trials',r['trials'],flush=True)
    return int(any(r['exceptions'] or r['key_mismatches'] for r in results))

if __name__=='__main__':raise SystemExit(main())
