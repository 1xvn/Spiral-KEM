#!/usr/bin/env python3
"""Independent scalar/ring mapping, CBD enumeration, boundaries and controls."""
from collections import Counter
from dataclasses import replace
import hashlib
import itertools
import math
from unittest.mock import patch
import numpy as np
from common import ROOT, PROFILES, original, make_kem, fixture, centered, write_json

def mul_integer(a, b):
    c = np.convolve(np.array(a, dtype=np.int64), np.array(b, dtype=np.int64))
    out = c[:len(a)].copy()
    out[:len(a)-1] -= c[len(a):]
    return out

def flat(v):
    return tuple(x for p in v for x in p)

def expanded(matrix, vector, n=256, q=3329):
    v = flat(vector)
    out = []
    for row in matrix:
        for i in range(n):
            out.append(sum((a[i-j] if i>=j else -a[n+i-j])*v[col*n+j]
                           for col,a in enumerate(row) for j in range(n)) % q)
    return tuple(out)

checks=[]
wires={}
for name, p in PROFILES.items():
    module, kem = make_kem(name)
    eta, n, q, k = p['eta'], p['n'], p['q'], p['k']
    observed=Counter()
    for bits in itertools.product((0,1), repeat=2*eta):
        with patch.object(kem, '_xof', return_value=bytes(bits)*n):
            sample=kem._small_poly(b'fixture', b'fixture')
        x=sum(bits[:eta])-sum(bits[eta:])
        assert sample==(x%q,)*n
        observed[x]+=1
    expected={x:math.comb(2*eta,eta+x) for x in range(-eta,eta+1)}
    assert dict(observed)==expected
    # Compare all residues to the nearest circular encoding center, ties to 0.
    for start in range(0,q,n):
        residues=list(range(start,min(start+n,q)))
        decoded=kem._decode_message(tuple(residues+[0]*(n-len(residues))))
        for i,v in enumerate(residues):
            d0=min(v,q-v)
            d1=min(abs(v-q//2),q-abs(v-q//2))
            assert ((decoded[i//8]>>(i%8))&1)==int(d1<d0)
    largest_noise=0
    for index in range(20):
        seed=hashlib.sha256(f'verify/{name}/{index}'.encode()).hexdigest()
        values=fixture(seed)
        with patch.object(module.secrets,'token_bytes',side_effect=values):
            pk,sk=kem.keygen()
            ct,key=kem.encapsulate(pk)
        assert kem.decapsulate(sk,ct)==key
        e=kem._small_vector(values[1],b'key/e')
        coins=kem._coin_seed(pk,values[3])
        r=kem._small_vector(coins,b'enc/r')
        e1=kem._small_vector(coins,b'enc/e1')
        e2=kem._small_poly(coins,b'enc/e2')
        w=np.array(centered(e2),dtype=np.int64)
        for j in range(k):
            w+=mul_integer(centered(e[j]),centered(r[j]))
            w-=mul_integer(centered(sk.s[j]),centered(e1[j]))
        aligned=kem._poly_sub(ct.v,kem._dot(sk.s,ct.u))
        encoded=kem._encode_message(values[3])
        assert tuple((int(x)+m)%q for x,m in zip(w,encoded))==aligned
        largest_noise=max(largest_noise,int(np.max(np.abs(w))))
        if index==0:
            a=kem._base_matrix(pk.matrix_seed)
            assert tuple((x+y)%q for x,y in zip(expanded(a,sk.s),flat(e)))==flat(pk.t)
            at=tuple(tuple(a[j][i] for j in range(k)) for i in range(k))
            assert tuple((x+y)%q for x,y in zip(expanded(at,r),flat(e1)))==flat(ct.u)
            wires[name]=(kem.serialize_public_key(pk),kem.serialize_ciphertext(ct))
            bad_s=(tuple([eta+1]+list(sk.s[0][1:])),)+sk.s[1:]
            try: kem.decapsulate(replace(sk,s=bad_s),ct)
            except module.InputValidationError: pass
            else: raise AssertionError('Secret-support validation failed')
        if p['label']=='A':
            mod2,other=make_kem(name,force_research=True)
            with patch.object(mod2.secrets,'token_bytes',side_effect=values):
                pk2,sk2=other.keygen();ct2,key2=other.encapsulate(pk2)
            assert kem.serialize_public_key(pk)==other.serialize_public_key(pk2)
            assert kem.serialize_ciphertext(ct)==other.serialize_ciphertext(ct2)
            assert sk.s==sk2.s and key==key2==other.decapsulate(sk2,ct2)
    # Verify the sufficient error event used by the Chernoff bound, across the
    # entire possible integer noise support, including modular wraparound.
    max_w=2*n*k*eta*eta+eta
    for bit in (0,1):
        for w in range(-max_w,max_w+1):
            residue=(bit*(q//2)+w)%q
            d0=min(residue,q-residue)
            d1=min(abs(residue-q//2),q-abs(residue-q//2))
            if int(d1<d0)!=bit:
                assert (w<=-833 or w>=833) if bit==0 else (w<=-832 or w>=833)
    checks.append(dict(profile=name,cbd_counts=expected,cbd_denominator=2**(2*eta),
                       independent_noise_identity_transcripts=20, largest_observed_abs_noise=largest_noise,
                       scalar_public_key_and_ciphertext_mapping=True, all_decoder_residues_checked=q,
                       full_support_error_event_bound_checked=True, secret_support_rejection=True))
    print(name,'verified',flush=True)
cross_rejections=0
for name in PROFILES:
    module,kem=make_kem(name)
    for other,(pk_wire,ct_wire) in wires.items():
        if other==name: continue
        for wire,read in [(pk_wire,kem.deserialize_public_key),(ct_wire,kem.deserialize_ciphertext)]:
            try: read(wire)
            except module.InputValidationError: cross_rejections+=1
            else: raise AssertionError('Cross-profile wire accepted')
for kwargs in [dict(eta=2),dict(k=3)]:
    try: original.Parameters(**kwargs)
    except original.InputValidationError: pass
    else: raise AssertionError('Original source unexpectedly allows research profiles')
write_json(ROOT/'results/model-verification.json',dict(profiles=checks,baseline_original_vs_variant_transcripts=20,
    cross_profile_wire_rejections=cross_rejections,original_restrictions_preserved=True,
    ideal_probability_assumption='Independent CBD coefficients from domain-separated ideal SHAKE outputs; not a proof about fixed SHAKE'))
