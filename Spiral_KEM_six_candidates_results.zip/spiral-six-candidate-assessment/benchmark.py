#!/usr/bin/env python3
"""Sequential balanced benchmarks of normal public APIs, with OS randomness."""
import argparse
import csv
import datetime
import gc
import json
import os
import platform
import random
import statistics
import sys
import time
from common import ROOT, PROFILES, make_kem, write_json

def percentile(values,p):
    values=sorted(values);pos=(len(values)-1)*p;i=int(pos)
    return values[i]+(values[min(i+1,len(values)-1)]-values[i])*(pos-i)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--rounds',type=int,default=300);ap.add_argument('--warmup',type=int,default=30)
    args=ap.parse_args()
    initial_affinity=sorted(os.sched_getaffinity(0)) if hasattr(os,'sched_getaffinity') else None
    if initial_affinity:os.sched_setaffinity(0,{initial_affinity[0]})
    cpu_info='unavailable'
    if os.path.exists('/proc/cpuinfo'):
        cpu_info=next((line.split(':',1)[1].strip() for line in open('/proc/cpuinfo') if line.startswith('model name')),'unavailable')
    quota_path='/sys/fs/cgroup/cpu.max'
    metadata=dict(started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        python=sys.version,platform=platform.platform(),cpu_model=cpu_info,cpu_count=os.cpu_count(),
        cpu_affinity_before=initial_affinity,cpu_affinity_used=sorted(os.sched_getaffinity(0)) if initial_affinity else None,
        cgroup_cpu_max=open(quota_path).read().strip() if os.path.exists(quota_path) else None,
        rounds_per_candidate=args.rounds,warmup_rounds_per_candidate=args.warmup,
        order_seed=20261021,garbage_collection_enabled=gc.isenabled(),
        measurement='perf_counter_ns around one normal keygen, encapsulate, or decapsulate API call',
        external_serialization_and_network_excluded=True,randomness='secrets.token_bytes, operating system RNG',
        cache_policy='No application-level A-matrix cache; unmodified source arithmetic',
        protocol_format='v0.3 raw uint16 coefficients; full domain/type/parameter headers included in sizes',
        initial_load_average=os.getloadavg())
    out=ROOT/'results/benchmark';out.mkdir(parents=True,exist_ok=True)
    write_json(out/'environment.json',metadata)
    kems={name:make_kem(name)[1] for name in PROFILES}
    order=random.Random(20261021)
    fields=['round','profile','keygen_ns','encapsulate_ns','decapsulate_ns','pk_serialize_ns','ct_serialize_ns','pk_bytes','ct_bytes']
    rows=[]
    with (out/'raw_timings.csv').open('w',newline='') as stream:
        writer=csv.DictWriter(stream,fieldnames=fields);writer.writeheader()
        for iteration in range(-args.warmup,args.rounds):
            names=list(PROFILES);order.shuffle(names)
            for name in names:
                kem=kems[name]
                a=time.perf_counter_ns();pk,sk=kem.keygen();b=time.perf_counter_ns()
                ct,ka=kem.encapsulate(pk);c=time.perf_counter_ns()
                kb=kem.decapsulate(sk,ct);d=time.perf_counter_ns()
                assert ka==kb,'Honest exchange failed during timing'
                e=time.perf_counter_ns();pk_wire=kem.serialize_public_key(pk);f=time.perf_counter_ns()
                ct_wire=kem.serialize_ciphertext(ct);g=time.perf_counter_ns()
                if iteration>=0:
                    row=dict(round=iteration,profile=name,keygen_ns=b-a,encapsulate_ns=c-b,decapsulate_ns=d-c,
                             pk_serialize_ns=f-e,ct_serialize_ns=g-f,pk_bytes=len(pk_wire),ct_bytes=len(ct_wire))
                    rows.append(row);writer.writerow(row)
            if iteration>=0 and (iteration+1)%50==0:
                stream.flush();print('timed rounds',iteration+1,'of',args.rounds,flush=True)
    results=[]
    for name in PROFILES:
        selected=[r for r in rows if r['profile']==name]
        result=dict(profile=name,samples=len(selected),pk_bytes=selected[0]['pk_bytes'],ct_bytes=selected[0]['ct_bytes'],operations={})
        for operation in ['keygen','encapsulate','decapsulate','pk_serialize','ct_serialize']:
            values=[r[operation+'_ns']/1e6 for r in selected]
            result['operations'][operation]=dict(median_ms=statistics.median(values),p95_ms=percentile(values,.95),
                mean_ms=statistics.mean(values),minimum_ms=min(values),maximum_ms=max(values))
        result['median_three_operations_total_ms']=statistics.median([(r['keygen_ns']+r['encapsulate_ns']+r['decapsulate_ns'])/1e6 for r in selected])
        results.append(result)
    metadata['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
    metadata['final_load_average']=os.getloadavg()
    write_json(out/'environment.json',metadata);write_json(out/'summary.json',results)
    print(json.dumps(results,indent=2),flush=True)

if __name__=='__main__':main()
