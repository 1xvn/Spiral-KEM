Spiral-KEM 6-Candidate Comparison Results — 2026-10-21 (Korea time)

n=256, q=3329, and 32-byte shared keys were fixed. A is original 0.3.1; B–F are experimental variants extending only its parameter and secret-key coefficient range validation. These are not results from an official 0.3.2 release.

| Candidate | k | η | MATZOV classical work | Key-mismatch probability bound under ideal CBD model | Observed failures/trials |
|---|---:|---:|---:|---:|---:|
| A | 2 | 1 | 2^120.88 | ≤ 2^(-1850) | 0/2000 |
| B | 2 | 2 | 2^132.84 | ≤ 2^(-422) | 0/2000 |
| C | 2 | 3 | 2^139.66 | ≤ 2^(-190) | 0/2000 |
| D | 3 | 1 | 2^179.88 | ≤ 2^(-1227) | 0/2000 |
| E | 3 | 2 | 2^196.37 | ≤ 2^(-295) | 0/2000 |
| F | 3 | 3 | 2^207.24 | ≤ 2^(-129) | 0/2000 |

Attack costs are the lowest heuristic operation counts returned for the same commit and attack list; all six candidates selected dual hybrid. Actual key recovery and full KEM security classification were not performed.

Decryption-failure probabilities are Chernoff/union bounds assuming independent CBD coefficients and ideal domain-separated SHAKE outputs. They are neither exact failure probabilities nor guarantees for a fixed SHAKE implementation. Calculation error is enclosed outward using 256-bit interval arithmetic, and display exponents are rounded upward conservatively.

The per-candidate 95% one-sided binomial bound from 0/2000 trials alone is 0.1497%. The small rare-failure figures are bounds from the mathematical model above, not repeated trials.

| Candidate | Median key generation ms | Median encapsulation ms | Median decapsulation ms | Public key bytes | Ciphertext bytes |
|---|---:|---:|---:|---:|---:|
| A | 1.952 | 2.958 | 4.096 | 1109 | 1589 |
| B | 2.044 | 3.103 | 4.211 | 1109 | 1589 |
| C | 2.154 | 3.264 | 4.306 | 1109 | 1589 |
| D | 3.735 | 5.149 | 6.606 | 1621 | 2101 |
| E | 3.890 | 5.359 | 6.849 | 1621 | 2101 |
| F | 4.059 | 5.540 | 7.085 | 1621 | 2101 |

Environment: AMD EPYC 9V74 80-Core Processor, Python 3.12.14, Linux. Each candidate received 30 warmups followed by 300 measurements. Execution was pinned to one CPU, shuffling candidate order every round. Measurements ran sequentially after attack estimation and correctness tests completed. These figures describe this host rather than other PCs.

Normal public API call times were measured; network transmission and external serialization/deserialization are excluded from the three columns above. Validation, serialization, and hashes performed within the APIs are included. Separate public-key/ciphertext serialization measurements and all p95/raw nanosecond records are in results/benchmark/.

Sizes are the full byte-string lengths returned by actual serialize functions. They include protocol, type, and parameter headers; coefficients are stored uncompressed at 2 bytes each. Changing η at the same k does not change this serialization format's size.

| Candidate | Minimum Core-SVP classical log₂ work | Core-SVP quantum uSVP log₂ work |
|---|---:|---:|
| A | 97.902 | 91.425 |
| B | 108.625 | 101.230 |
| C | 115.510 | 107.590 |
| D | 157.098 | 150.255 |
| E | 174.324 | 165.360 |
| F | 184.922 | 174.900 |

Core-SVP is a different cost model, so its figures are not directly mixed with MATZOV or interpreted as a single security range. Quantum results evaluate only uSVP.

In this comparison, increasing η or k increased estimated general LWE attack costs and the modeled decryption-failure bound. These results can inform security, correctness, and performance choices. Final parameter approval and full protocol validation are separate.

Original figures, reproduction commands, bound derivations, and experimental variant details are in README.md and FAILURE_ANALYSIS.md.

