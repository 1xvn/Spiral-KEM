Decryption-Failure Probability Analysis — Ideal Independent CBD Model

The figures in this document are distinguished from failure rates in actual repeated tests. Repeated tests confirm normal implementation behavior; the formulas below compute upper bounds on extremely rare failures under explicitly stated idealized assumptions. These are not unconditional probability guarantees for actual code using a fixed SHAKE function and finite-length seeds.

Error equations in the code

The public-key and ciphertext equations are as follows. Operations take place in Z₃₃₂₉[x]/(x²⁵⁶+1).

```text
t = A s + e
u = Aᵀ r + e1
v = tᵀ r + e2 + Encode(m)
v − sᵀu = Encode(m) + eᵀr − sᵀe1 + e2
W = eᵀr − sᵀe1 + e2
```

For 20 synthetic key exchanges per candidate, `verify_candidates.py` separately computes W using NumPy integer convolution. This was compared with the decryption input obtained through the original optimized modular multiplication. Expansion of the coefficient matrices for public keys and ciphertext u was also checked separately for each candidate.

Distribution of one coefficient

Assume that all coefficients of small secret values and errors independently follow CBD(η). CBD probabilities are represented by the following integer weights.

```text
P[X=x] = binom(2η, η+x) / 2^(2η),   −η ≤ x ≤ η
Y = X·X'  (X and X' are independent)
P[Y=y] = sum_{x·x'=y} binom(2η,η+x)binom(2η,η+x') / 2^(4η)
```

For a fixed output coefficient, each polynomial multiplication involves n distinct coefficient pairs. Thus, in the independent model, one coefficient of W has the same distribution as the sum of 2nk independent Y values and one CBD(η) error E. Signs from negacyclic multiplication and subtraction do not change this symmetric distribution.

```text
W_j ≡ sum_{i=1}^{2nk} Y_i + E  (equality in distribution; integers before modular reduction)
Var(W_j) = nkη²/2 + η/2
|W_j| ≤ 2nkη² + η
```

Different output coefficients W_i and W_j share coefficients and are therefore not treated as independent. This is why a union bound is used in the final step.

Actual decoder boundaries

Bit 0 is encoded as 0; bit 1 is encoded as floor(3329/2)=1664. The decoder returns 1 for residues from 833 through 2496, and 0 otherwise. In particular, a tie at 832 is resolved as 0.

Thus, the following conditions hold for integer error W.

```text
Failure for original bit 0 ⇒ W ≤ −833 or W ≥ 833
Failure for original bit 1 ⇒ W ≤ −832 or W ≥ 833
```

These remain necessary conditions for failure even when the error wraps modulo q multiple times. They give an upper bound because some values in the outer regions that decode correctly again are also counted as failure events. The verification code checked the full possible integer error range and all decoder residues for every candidate.

Chernoff bound and whole-message bound

Applying Markov's inequality for positive t gives the following.

```text
B(a,t) = exp(−t·a) · M_Y(t)^(2nk) · M_E(t)
P[W_j ≥ a] ≤ B(a,t)
M_Y(t) = sum_y P[Y=y] exp(t·y)
M_E(t) = sum_x P[E=x] exp(t·x)
```

A suitable t for each of 832 and 833 was selected using floating-point optimization, then fixed as an exact binary rational. All probability calculations were then repeated using SageMath's 256-bit RealIntervalField to include rounding errors. Even if optimization does not find the global optimum, the bound itself remains valid for any positive t.

By symmetry and the union bound, the full decryption-failure bound for any message is computed as follows.

```text
p0 ≤ 2·B(833)
p1 ≤ B(832)+B(833)
P[at least one bit decodes incorrectly] ≤ n · (B(832)+B(833))
P[shared-key mismatch in an honest key exchange] ≤ P[at least one bit decodes incorrectly]
```

The last inequality holds because correct message decryption makes deterministic reencryption and key derivation agree. The bound was not reduced by accounting for cases where accidental key collisions eliminate a mismatch.

Meaning of output values

`results/failure-bounds/*.json` contains integer weights for each distribution, exact rational values of selected t, rational endpoints of probability intervals, log₂ bounds, and rounded-up display exponents. For example, a computed log₂ bound of −190.98 is shown in the table as the more conservative `≤2^−190`.

This analysis makes the following assumptions.

- Coefficients of s, e, r, e1, e2 are treated as independent CBD variables.
- Domain-separated SHAKE output and coins derivation are modeled as ideal pseudorandom expansion. Actual s/e share one seed, while r/e1/e2 share another. Their actual dependencies have not been eliminated by proof.
- One exchange of honestly generated keys and ciphertexts is evaluated. Attacker-chosen ciphertexts, fault injection, side channels, and many adaptive queries are excluded.
- Integer operations and the code's decoding expressions are assumed to execute correctly.

Statistical limits of observed failure rates

Each candidate underwent 2,000 trials using fresh synthetic keys and messages. Each trial uses a public experimental seed drawn from OS randomness and reproducibly generates rho, secret seed, fallback-key seed, and message through separate SHAKE streams. Experimental seeds and public-key/ciphertext hashes are in the original JSONL. They are not secrets from an actual service.

With 0 failures, the per-candidate 95% one-sided binomial upper bound under the independent identically distributed trial assumption is `1 − 0.05^(1/2000)`. Thus, 0/2000 is not claimed to empirically establish a cryptographically small probability. This is also not an adjusted interval guaranteeing all six candidates simultaneously. The extremely small bounds above come from a separate ideal probability model.
