"""Shared source loading and explicitly synthetic, replayable test fixtures."""
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
PROFILES = json.loads((ROOT / "profiles.json").read_text())
manifest = json.loads((ROOT / "variant-manifest.json").read_text())
assert hashlib.sha256((ROOT / "source" / "spiral_kem_toy_v031.py").read_bytes()).hexdigest() == manifest["original_sha256"]
assert hashlib.sha256((ROOT / "research" / "spiral_kem_six_candidates.py").read_bytes()).hexdigest() == manifest["research_variant_sha256"]

def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module

original = load_module("spiral_original_v031", ROOT / "source" / "spiral_kem_toy_v031.py")
research = load_module("spiral_six_research", ROOT / "research" / "spiral_kem_six_candidates.py")

def make_kem(profile, force_research=False):
    p = PROFILES[profile]
    module = original if p["label"] == "A" and not force_research else research
    params = module.Parameters(n=p["n"], k=p["k"], q=p["q"], eta=p["eta"], key_bytes=32)
    return module, module.SpiralKEM(params, lab_mode=module is research)

def fixture(seed_hex):
    """Four public research-only values: rho, sigma, fallback seed, message."""
    stream = hashlib.shake_256(b"Spiral-six-candidate-test-fixture-v1/" + bytes.fromhex(seed_hex)).digest(128)
    return [stream[i:i+32] for i in range(0, 128, 32)]

def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False)+"\n", encoding="utf-8")

def centered(poly, q=3329):
    return tuple(x if x <= q//2 else x-q for x in poly)
