#!/usr/bin/env python3
"""Generate a narrowly scoped parameter experiment from the exact v0.3.1 file."""
from pathlib import Path
import difflib
import hashlib
import json

ROOT = Path(__file__).resolve().parent
EXPECTED = "898e540b4aded14e3710b591c6aa03a44bf5774c1d591f630e488b041655fd6c"
source = ROOT / "source" / "spiral_kem_toy_v031.py"
assert hashlib.sha256(source.read_bytes()).hexdigest() == EXPECTED
original = source.read_text()
old = '''        if self.n not in SUPPORTED_N:
            raise InputValidationError("n must be one of 8, 16, 32, 64, 128, 256.")
        if values[1:] != BASELINE[1:]:
            raise InputValidationError("v0.3 fixes k=2, q=3329, eta=1, key_bytes=32.")'''
new = '''        if (self.n != 256 or self.k not in (2, 3) or self.q != 3329
                or self.eta not in (1, 2, 3) or self.key_bytes != 32):
            raise InputValidationError("Experimental profiles: n=256, k in (2,3), q=3329, eta in (1,2,3), key_bytes=32.")'''
old_secret = '''        if any(x not in (0, 1, self.p.q - 1) for poly in sk.s for x in poly):'''
new_secret = '''        allowed = tuple(range(self.p.eta + 1)) + tuple(
            self.p.q - i for i in range(1, self.p.eta + 1)
        )
        if any(x not in allowed for poly in sk.s for x in poly):'''
assert original.count(old) == original.count(old_secret) == 1
changed = original.replace(old, new).replace(old_secret, new_secret)
changed = "# EXPERIMENT ONLY: v0.3.1 with parameter and secret-support validation extended.\n" + changed
out = ROOT / "research" / "spiral_kem_six_candidates.py"
out.parent.mkdir(exist_ok=True)
out.write_text(changed)
(ROOT / "candidate-validation.patch").write_text("".join(difflib.unified_diff(
    original.splitlines(True), changed.splitlines(True),
    fromfile="source/spiral_kem_toy_v031.py", tofile="research/spiral_kem_six_candidates.py")))
(ROOT / "variant-manifest.json").write_text(json.dumps({
    "original_sha256": EXPECTED,
    "research_variant_sha256": hashlib.sha256(out.read_bytes()).hexdigest(),
    "changed_behavior": ["Allow exactly six n=256 research profiles", "Validate secret coefficients against the selected CBD eta support"],
    "unchanged_math_and_wire_format": True,
    "not_a_v032_release": True,
}, indent=2) + "\n")
print(out)
