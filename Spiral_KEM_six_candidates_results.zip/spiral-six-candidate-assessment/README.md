Evaluation of Attack Costs, Decryption Correctness, Execution Time, and Size for 6 Spiral-KEM Candidates

Evaluation date: 2026-10-21 (Korea time)

Read `RESULTS.md` first for results in the four categories. The numerical table readable in Excel is `results/comparison.csv`; the complete machine-readable summary is `results/comparison.json`.

Candidates evaluated

| Candidate | n | k | q | η | General LWE secret dimension/sample count |
|---|---:|---:|---:|---:|---:|
| A — Original 0.3.1 | 256 | 2 | 3329 | 1 | 512 / 512 |
| B | 256 | 2 | 3329 | 2 | 512 / 512 |
| C | 256 | 2 | 3329 | 3 | 512 / 512 |
| D | 256 | 3 | 3329 | 1 | 768 / 768 |
| E | 256 | 3 | 3329 | 2 | 768 / 768 |
| F | 256 | 3 | 3329 | 3 | 768 / 768 |

The candidate's same CBD(η) is used for secret s, public-key error e, encryption secret r, and encryption errors e1/e2. Shared keys and messages are each 32 bytes. The different error parameters and ciphertext compression of standard ML-KEM were not imported into or mixed with these candidates.

Original and experimental variant

The supplied `spiral_kem_toy_v031(2).py` was preserved without content changes as `source/spiral_kem_toy_v031.py`. Its SHA-256 is as follows.

```text
898e540b4aded14e3710b591c6aa03a44bf5774c1d591f630e488b041655fd6c
```

The original permits only k=2, η=1 and secret-key coefficients −1/0/+1. To run B–F, a separate experimental file was created using `build_research_variant.py`. Changes permit 6 research parameter sets, check secret-key coefficient ranges for the selected η, and add comments identifying the experimental status. Mathematical operations, randomness generation, hashes, serialization, decoder, and ciphertext validation are unchanged. The full diff is in `candidate-validation.patch`. Other original input-format checks are retained.

Tests and timing for A use the original class. B–F use the experimental file in explicit lab mode. 20 cases also compare experimental A with original A to confirm identical public keys, ciphertexts, and shared keys under the same fixed seeds. This is neither an official 0.3.2 release nor approval of commercial parameters.

Scope of attack-cost calculations

Lattice-estimator commit `e4333d9bf9ef42fd8a29651b0c559fba7ce0d834` is included unchanged. This is the same commit as the earlier 0.3.1 evaluation. The following 11 calculations were run for each of the six candidates under SageMath 10.8.

- MATZOV classical scenario: uSVP, BDD, dual, dual hybrid, BDD hybrid, BDD MITM hybrid, coded BKW, Arora-GB.
- Core-SVP classical scenario: uSVP, dual hybrid.
- Core-SVP quantum scenario: uSVP.

stdout/stderr, cost representations, returned-field strings, log₂ values, execution times, and settings for all 66 calculations are saved in `results/attacks/`. Infinity from Arora-GB means no finite cost was returned. BKW/Arora-GB do not use a lattice-reduction cost function, so grouping them under the MATZOV scenario does not apply that function. BKW's returned m is the value after internal sample amplification; input m was limited to n×k.

Primal lattice shape uses GSA. Dual attacks use upstream's own formulas. Success probabilities and distinguishing advantages follow each function's default assumptions. Attacks were not normalized to the same experimental success rate. MATZOV and Core-SVP are different cost models, and their figures are not combined directly into a security-bit interval. Evaluation of one quantum uSVP path is not interpreted as the minimum over all quantum attacks.

Expanding public-key `t=A·s+e` and ciphertext `u=Aᵀ·r+e1` into general LWE gives the same secret/error distributions and dimensions in this experiment. The same cost model therefore applies. v, whose message is unknown, was not counted as an additional independent LWE sample. Independent expansion was checked to avoid confusing the ring-matrix transpose in code with the coefficient-matrix transpose.

The actual matrices have negacyclic block structure. These calculations apply general LWE heuristics and do not prove resistance to special ring/module-structure attacks or security of the full FO/CCA transform. SHAKE-expanded secret-seed structure, attacks across many targets/ciphertexts, side channels, memory limits, and actual hardware costs are separate issues. rop for dual-family distinguishing attacks was not equated with the cost of successful full KEM key recovery. Minimum costs result from the selected implementations and search heuristics; they are not lower bounds over all possible attacks.

Correctness and failure probability

Experimental records are in `results/correctness/`. Each candidate ran 2,000 trials with fresh keys and messages, 12,000 in total, checking shared-key agreement including actual serialization/deserialization. Byte strings were also read and reserialized by a fresh receiver instance. Raw test seeds are public research values. `replay_correctness.py` can replay the same public-key and ciphertext hashes.

A separate mathematical analysis is derived in `FAILURE_ANALYSIS.md`. For one coefficient of the actual integer error W=eᵀr−sᵀe1+e2, the independent CBD model's MGF was computed to obtain a Chernoff bound. A union bound was applied without assuming independence between message bits. SageMath 256-bit interval arithmetic preserved numerical upper bounds. Results include exact rational endpoints in `results/failure-bounds/`.

Even with 0 test failures, the actual failure probability is not recorded as 0. The small theoretical bounds in the table are results under an ideal independent CBD/SHAKE model, not probability proofs for the actual fixed SHAKE implementation. These normal-operation tests also cannot replace review of the full protocol or malicious-ciphertext failure handling.

Time and size

After attack estimation and correctness tests completed, `benchmark.py` was run alone. Affinity was pinned to one CPU, and the order of all six candidates was shuffled each round. Each candidate received 30 warmups and 300 measurements. Public APIs keygen/encapsulate/decapsulate were measured using actual OS randomness. Input validation, hashes, reencryption, and other work inside each API are included; external transmission/deserialization is excluded. Separate serialization times were also recorded.

Raw nanosecond records, median, p95, mean, minimum, maximum, and Python/CPU/platform details are in `results/benchmark/`. Other host workloads and virtualization effects cannot be fully controlled, so identical ms values on other computers are not guaranteed. These are Linux measurements, not Windows PC measurements.

Public-key and ciphertext sizes count actual serialized byte strings. If H denotes the full header length, they also match the following formulas.

```text
H = len(DOMAIN) + len(kind) + 5·4
Public key bytes = H + 32 + 2nk
Ciphertext bytes = H + 2n(k+1)
```

Each coefficient uses 2 bytes without compression. Figures exclude extra headers such as network IP/TLS.

Reproduction

First prepare a Python 3.12 environment in this directory and install `requirements-analysis.txt`. Attack estimation and interval probability calculations require a separate SageMath environment. Assuming micromamba is installed, use the following commands.

```bash
python3 -m pip install -r requirements-analysis.txt
python3 build_research_variant.py
python3 verify_candidates.py

TASK_ROOT="$PWD"
TASK_ENV="$TASK_ROOT/sage-env"
micromamba create --yes --prefix "$TASK_ENV" --strict-channel-priority --file environment.yml
micromamba run --prefix "$TASK_ENV" python run_estimates.py --jobs 2 --timeout 600
micromamba run --prefix "$TASK_ENV" python failure_bounds.py

python3 run_correctness.py --trials 2000 --jobs 2
python3 replay_correctness.py
python3 benchmark.py --rounds 300 --warmup 30
python3 summarize.py
```

The commands update the results directory; to preserve the submitted originals, copy the entire folder and run in the copy. Run the benchmark after all other calculations finish. Fresh tests and timing using OS randomness generate new records. To replay only all existing normal-operation records, use `python3 replay_correctness.py --all`.

An alternative that installs exactly the same conda package builds as this run is shown below. This file, used for the actual installation, includes Linux x86-64-v4 CPU features. On other hardware or platforms, use environment.yml.

```bash
micromamba create --yes --prefix "$TASK_ENV" --file environment-linux-64.explicit.txt
```

System Python without the Sage environment activated has no Sage module. This conda environment was run with `micromamba run ... python` instead of `sage -python`. Sage/conda binaries themselves are not included in this ZIP.

To check only consistency of the submitted records, run `python3 summarize.py` without Sage. The runner rebuilds the results table and verifies logs, JSON, source hashes, measurement medians, and agreement with earlier A/C estimates. Check byte integrity at submission time with `sha256sum --check SHA256SUMS`. Files whose records change in a fresh run may differ from their submission-time hashes.

Evidence and sources

- [Pinned Lattice-estimator commit](https://github.com/malb/lattice-estimator/tree/e4333d9bf9ef42fd8a29651b0c559fba7ce0d834). The same source is included in vendor.
- [MATZOV, Report on the Security of LWE: Improved Dual Lattice Attack (2022)](https://zenodo.org/records/6412487).
- [Alkim, Ducas, Pöppelmann, Schwabe, Post-quantum key exchange—a new hope (2016)](https://www.usenix.org/conference/usenixsecurity16/technical-sessions/presentation/alkim).
- [NIST FIPS 203](https://nvlpubs.nist.gov/nistpubs/FIPS/NIST.FIPS.203.pdf). Standard ML-KEM must be distinguished from these experimental variants.

`NOTICE.txt` and the GPL/LGPL texts explain the copyrights and licenses of the included upstream source. No new license was granted to the user's supplied original code.
