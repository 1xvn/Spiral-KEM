#!/usr/bin/env python3
"""Replay saved synthetic trials; by default first, middle and last per profile."""
import argparse
import hashlib
import json
from unittest.mock import patch
from common import ROOT,PROFILES,make_kem,fixture,write_json

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--all',action='store_true');args=ap.parse_args()
    checks=[]
    for name in PROFILES:
        module,kem=make_kem(name)
        rows=[json.loads(line) for line in (ROOT/'results/correctness'/(name+'.jsonl')).read_text().splitlines()]
        selected=rows if args.all else [rows[0],rows[len(rows)//2],rows[-1]]
        for row in selected:
            with patch.object(module.secrets,'token_bytes',side_effect=fixture(row['fixture_seed_hex'])):
                pk,sk=kem.keygen();ct,key=kem.encapsulate(pk)
            assert hashlib.sha256(kem.serialize_public_key(pk)).hexdigest()==row['pk_sha256']
            assert hashlib.sha256(kem.serialize_ciphertext(ct)).hexdigest()==row['ct_sha256']
            assert (kem.decapsulate(sk,ct)!=key)==row['key_mismatch']
            checks.append(dict(profile=name,trial=row['trial'],matches=True))
    result=dict(replayed=len(checks),all_match=True,checks=checks)
    write_json(ROOT/'results/replay-verification.json',result);print(json.dumps(result,indent=2))

if __name__=='__main__':main()
