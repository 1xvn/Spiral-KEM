#!/usr/bin/env python3
"""Cross-check the evidence and produce the four-metric comparison, no Sage needed."""
import csv
import hashlib
import json
import math
import statistics
from fractions import Fraction
from pathlib import Path

ROOT=Path(__file__).resolve().parent
def read(path):return json.loads((ROOT/path).read_text())
profiles=read('profiles.json')
attack_document=read('results/attacks/results.json')
attacks=attack_document['results']
correctness={r['profile']:r for r in read('results/correctness/summary.json')}
bounds={r['profile']:r for r in read('results/failure-bounds/summary.json')}
benchmark={r['profile']:r for r in read('results/benchmark/summary.json')}
environment=read('results/benchmark/environment.json')
mapping=read('results/model-verification.json')
manifest=read('estimator-source-manifest.json')
variant=read('variant-manifest.json')
replay=read('results/replay-verification.json')
assert replay['all_match']
assert len(attacks)==66 and all(r['status']=='ok' for r in attacks)
assert {(r['profile'],r['model'],r['attack']) for r in attacks}=={tuple(j) for j in attack_document['jobs']}
assert len(mapping['profiles'])==6 and mapping['cross_profile_wire_rejections']==60
assert hashlib.sha256((ROOT/'source/spiral_kem_toy_v031.py').read_bytes()).hexdigest()==variant['original_sha256']
assert hashlib.sha256((ROOT/'research/spiral_kem_six_candidates.py').read_bytes()).hexdigest()==variant['research_variant_sha256']
for name,digest in manifest['files_sha256'].items():
    assert hashlib.sha256((ROOT/'vendor/lattice-estimator'/name).read_bytes()).hexdigest()==digest
for r in attacks:
    p=profiles[r['profile']]
    assert r['lwe_n']==r['lwe_m']==256*p['k'] and r['q']==3329
    raw=read('results/attacks/'+r['raw_json'])
    assert raw=={k:v for k,v in r.items() if k not in ('raw_log','raw_json')}
    assert 'RAW_COST_REPR '+r['raw_cost_repr'] in (ROOT/'results/attacks'/r['raw_log']).read_text()
    if r['attack']=='usvp' and r['model'].startswith('core_svp_'):
        coefficient=.265 if 'quantum' in r['model'] else .292
        assert abs(r['log2_metrics']['rop']-coefficient*int(r['raw_fields']['beta']))<1e-9

previous=read('previous/v031-cost-results.json')['results']
for name,prior_name in [('A_k2_eta1','spiral_cbd1'),('C_k2_eta3','kyber512_pk_reference_cbd3')]:
    for old in [r for r in previous if r['profile']==prior_name]:
        new=next(r for r in attacks if (r['profile'],r['model'],r['attack'])==(name,old['model'],old['attack']))
        a,b=new['log2_metrics']['rop'],old['log2_metrics']['rop']
        assert a==b or (isinstance(a,float) and isinstance(b,float) and abs(a-b)<1e-8)

with (ROOT/'results/benchmark/raw_timings.csv').open() as f:timings=list(csv.DictReader(f))
summaries=[]
for name,p in profiles.items():
    trial=correctness[name];bound=bounds[name];bench=benchmark[name]
    b832=bound['one_sided_tail_certificates']['832']['chernoff_interval']
    b833=bound['one_sided_tail_certificates']['833']['chernoff_interval']
    assert Fraction(b832['lower_rational'])>=Fraction(b833['upper_rational'])
    upper=Fraction(bound['full_message_union_upper']['upper_rational'])
    assert upper>=256*(Fraction(b832['upper_rational'])+Fraction(b833['upper_rational']))
    assert 0<Fraction(bound['full_message_union_upper']['lower_rational'])<=upper
    assert upper<=Fraction(2)**bound['certified_binary_bound_exponent']
    rows=[json.loads(line) for line in (ROOT/'results/correctness'/(name+'.jsonl')).read_text().splitlines()]
    assert len(rows)==trial['trials']==2000 and trial['exceptions']==0
    assert sum(int(r['key_mismatch']) for r in rows)==trial['key_mismatches']
    selected=[r for r in timings if r['profile']==name]
    assert len(selected)==bench['samples']
    for op in ('keygen','encapsulate','decapsulate'):
        assert statistics.median(int(r[op+'_ns'])/1e6 for r in selected)==bench['operations'][op]['median_ms']
    header=len(b'Spiral-KEM-v0.3/research-only/')+len(b'pk/')+5*4
    assert bench['pk_bytes']==trial['pk_bytes']==header+32+2*256*p['k']
    assert bench['ct_bytes']==trial['ct_bytes']==header+2*256*(p['k']+1)
    models={}
    for model in ('matzov_classical','core_svp_classical','core_svp_quantum_primal'):
        choices=[r for r in attacks if r['profile']==name and r['model']==model and isinstance(r['log2_metrics'].get('rop'),(float,int))]
        best=min(choices,key=lambda r:r['log2_metrics']['rop'])
        models[model]=dict(attack=best['attack'],log2_rop=best['log2_metrics']['rop'],raw_log=best['raw_log'])
    summaries.append(dict(profile=name,parameters=p,attack_models=models,
        trials=trial['trials'],key_mismatches=trial['key_mismatches'],empirical_95pct_upper=trial['one_sided_95pct_binomial_upper'],
        ideal_cbd_failure_bound_exponent=bound['certified_binary_bound_exponent'],
        ideal_cbd_log2_failure_upper=bound['log2_full_message_upper'],
        keygen_median_ms=bench['operations']['keygen']['median_ms'],encapsulate_median_ms=bench['operations']['encapsulate']['median_ms'],
        decapsulate_median_ms=bench['operations']['decapsulate']['median_ms'],
        keygen_p95_ms=bench['operations']['keygen']['p95_ms'],encapsulate_p95_ms=bench['operations']['encapsulate']['p95_ms'],
        decapsulate_p95_ms=bench['operations']['decapsulate']['p95_ms'],pk_bytes=bench['pk_bytes'],ct_bytes=bench['ct_bytes']))

(ROOT/'results/comparison.json').write_text(json.dumps(summaries,ensure_ascii=False,indent=2)+'\n')
columns=['candidate','n','k','eta','lwe_n','lwe_m','matzov_log2_rop','matzov_attack','core_classical_log2_rop','core_quantum_usvp_log2_rop',
    'honest_trials','key_mismatches','empirical_95pct_upper','ideal_cbd_failure_bound_exponent',
    'keygen_median_ms','encapsulate_median_ms','decapsulate_median_ms','keygen_p95_ms','encapsulate_p95_ms','decapsulate_p95_ms','pk_bytes','ct_bytes']
with (ROOT/'results/comparison.csv').open('w',newline='',encoding='utf-8-sig') as f:
    writer=csv.DictWriter(f,fieldnames=columns);writer.writeheader()
    for s in summaries:
        p=s['parameters'];model=s['attack_models']
        row=dict(candidate=p['label'],n=256,k=p['k'],eta=p['eta'],lwe_n=p['lwe_n'],lwe_m=p['lwe_m'],
            matzov_log2_rop=model['matzov_classical']['log2_rop'],matzov_attack=model['matzov_classical']['attack'],
            core_classical_log2_rop=model['core_svp_classical']['log2_rop'],core_quantum_usvp_log2_rop=model['core_svp_quantum_primal']['log2_rop'],
            honest_trials=s['trials'],key_mismatches=s['key_mismatches'],empirical_95pct_upper=s['empirical_95pct_upper'],
            ideal_cbd_failure_bound_exponent=s['ideal_cbd_failure_bound_exponent'])
        row.update({key:s[key] for key in columns if key in s and key not in row});writer.writerow(row)

audit=dict(attack_jobs=len(attacks),finite_attack_estimates=sum(isinstance(r['log2_metrics']['rop'],(float,int)) for r in attacks),
    infinite_attack_estimates=sum(r['log2_metrics']['rop']=='Infinity' for r in attacks),
    source_and_vendor_hashes_verified=True,attack_logs_and_json_match=True,prior_A_and_C_estimates_reproduced=True,
    core_svp_usvp_formula_checked=True,correctness_trials=sum(r['trials'] for r in summaries),
    key_mismatches=sum(r['key_mismatches'] for r in summaries),raw_trials_match_summary=True,
    benchmark_raw_medians_match_summary=True,wire_sizes_match_source_formula=True,replayed_trials=replay['replayed'])
audit['probability_certificate_union_and_display_bound_exact_rational_checks']=True
(ROOT/'results/audit.json').write_text(json.dumps(audit,indent=2)+'\n')

lines=['Spiral-KEM six-candidate comparison — 2026-10-21 (UTC+09:00)\n',
    'n=256, q=3329 and a 32-byte shared key are fixed. A is baseline 0.3.1; B–F are experimental variants extending only its parameter and secret-coefficient range checks. This is not a formal 0.3.2 release.\n',
    '| Candidate | k | η | MATZOV classical work | Ideal-CBD-model key-mismatch probability upper bound | Observed failures/trials |',
    '|---|---:|---:|---:|---:|---:|']
for s in summaries:
    p=s['parameters'];b=s['attack_models']['matzov_classical']['log2_rop'];e=s['ideal_cbd_failure_bound_exponent']
    lines.append(f"| {p['label']} | {p['k']} | {p['eta']} | 2^{b:.2f} | ≤ 2^({e}) | {s['key_mismatches']}/{s['trials']} |")
lines += ['\nAttack costs are the minimum heuristic operation counts returned for the same estimator commit and attack list; dual hybrid was lowest for all six candidates. No actual key-recovery attack or full-KEM security-level determination was performed.\n',
    'Decryption-failure probabilities are Chernoff/union bounds assuming independent CBD coefficients and ideal domain-separated SHAKE outputs. They are neither exact failure probabilities nor guarantees for the fixed SHAKE implementation. 256-bit interval arithmetic encloses numerical errors outward, and displayed exponents are rounded conservatively.\n',
    f"The per-candidate one-sided 95% binomial upper bound from 0/2000 trials alone is {100*summaries[0]['empirical_95pct_upper']:.4f}%. Smaller rare-failure figures come from the mathematical model, not repeated trials.\n",
    '| Candidate | Keygen median ms | Encapsulation median ms | Decapsulation median ms | Public-key bytes | Ciphertext bytes |',
    '|---|---:|---:|---:|---:|---:|']
for s in summaries:
    lines.append(f"| {s['parameters']['label']} | {s['keygen_median_ms']:.3f} | {s['encapsulate_median_ms']:.3f} | {s['decapsulate_median_ms']:.3f} | {s['pk_bytes']} | {s['ct_bytes']} |")
lines += [f"\nEnvironment: {environment['cpu_model']}, Python {environment['python'].split()[0]}, Linux. Each candidate received {environment['warmup_rounds_per_candidate']} warmups and {environment['rounds_per_candidate']} measurements. Runs were pinned to one CPU and candidate order was shuffled per round. Measurements ran sequentially after estimation/correctness checks. These figures describe this host rather than other PCs.\n",
    'Normal public-API calls were measured. The three columns exclude network transfer and external serialization/deserialization but include internal validation, serialization and hashing. Separate serialization timings, p95 values and raw nanosecond records are under results/benchmark/.\n',
    'Sizes are complete byte lengths returned by the actual serialize functions, including protocol/kind/parameter headers and uncompressed two-byte coefficients. Changing η at the same k does not change this encoding size.\n',
    '| Candidate | Core-SVP minimum classical log₂ work | Core-SVP quantum uSVP log₂ work |',
    '|---|---:|---:|']
for s in summaries:
    m=s['attack_models'];lines.append(f"| {s['parameters']['label']} | {m['core_svp_classical']['log2_rop']:.3f} | {m['core_svp_quantum_primal']['log2_rop']:.3f} |")
lines += ['\nCore-SVP uses a different cost model; do not combine it with MATZOV values or interpret both as one security range. Only uSVP was evaluated for the quantum result.\n',
    'Increasing η or k raised the estimated generic-LWE attack cost and the modeled decryption-failure upper bound in this comparison. These observations inform security/correctness/performance tradeoffs; final parameter approval and full-protocol validation remain separate work.\n',
    'Raw figures, reproduction commands, bound derivations and variant details are in README.md and FAILURE_ANALYSIS.md.\n']
(ROOT/'RESULTS.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
print(json.dumps(audit,indent=2))
for s in summaries:print(s['profile'],s['attack_models']['matzov_classical']['log2_rop'],s['ideal_cbd_failure_bound_exponent'],s['keygen_median_ms'],s['encapsulate_median_ms'],s['decapsulate_median_ms'],s['pk_bytes'],s['ct_bytes'])
